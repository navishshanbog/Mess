data={
  "type": "LinkChart",
  "items": [{}]
};
