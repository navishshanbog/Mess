//
//     Copyright © 2011-2018 Cambridge Intelligence Limited.
//     All rights reserved.    
//
//     Sample Code
//!    Use React and the time bar to filter chart items.
//
// This demo uses webpack to manage dependencies and build
import * as React from 'react';
import {render} from 'react-dom';
import {Chart, Timebar} from 'react-keylines';
import {LeftPanel, RightPanel} from 'react-demo';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Dropdown, IDropdown, DropdownMenuItemType, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import { ChoiceGroup, IChoiceGroupOption } from 'office-ui-fabric-react/lib/ChoiceGroup';
import * as _ from "lodash";
import {Checkbox} from 'office-ui-fabric-react/lib/Checkbox';
import { DefaultButton, IButtonProps } from 'office-ui-fabric-react/lib/Button';
import {customNodeImage, lockOptions, MyLinks} from "../kl-helper/kl-constants";
import {fetchData, arrayOfObjAfter, makeKeyLinesItemsOfGraphData, copyArray, removeArrElement} from "../kl-helper/kl-helper";
import Select from 'react-select';


import axios from "axios";
import moment from "moment";

KeyLines.paths({assets: 'assets/'});


class ReactDemo extends React.Component {

    flights;
    filterFlights;
    address;
    filterAddress;
    emails;
    filterEmails;
    phones;
    filterPhones;
    nodes;
    links;
    neighbours;
    items;


    constructor(props) {
        super(props);
        this.onTimebarChange = this.onTimebarChange.bind(this);
        this.loadedTimebar = this.loadedTimebar.bind(this);
        this.loadedChart = this.loadedChart.bind(this);
        this.onChangeMultiSelect = this.onChangeMultiSelect.bind(this);
        this.areNeighboursOf = this.areNeighboursOf.bind(this);
        this.toggleHighlight = this.toggleHighlight.bind(this);
        this.fetchAllNeighbours = this.fetchAllNeighbours.bind(this);
        this.toggleHighlight = this.toggleHighlight.bind(this);
        this.focusOnCharacter = this.focusOnCharacter.bind(this);
        this.resetClicked = this.resetClicked.bind(this);
        this.myFilter = this.myFilter.bind(this);
        this.handleChange = this.handleChange.bind(this);

        this.flights = [];
        this.filterFlights = [];
        this.address = [];
        this.filterAddress = [];
        this.emails = [];
        this.filterEmails = [];
        this.phones = [];
        this.filterPhones = [];
        this.nodes=[];
        this.neighbours = [];
        this.items = [];
        this.links= [
            { key: 'Header4', text: 'Links', itemType: DropdownMenuItemType.Header }
        ];


        this.state = {
            graphKeylinesData: [{}],
            filterOptions: [],
            flights: true,
            address: true,
            emails: true,
            phones: true,
            searchCriteria: "",
            toHighlight: false,
            disableSelection: true,
            selectedItem: { key: "" },
            selectedItems: [],
            customNodes: {},
            customLinks: {},
            filterSelection: [],
            poi: "",
            nodeLinkSelection: false,
            selectedOption: null
        }
    }

    // filter the items on the chart according to the range of the timebar
    onTimebarChange() {
        // if all our components are loaded
        if (this.chart && this.timebar) {
            // filter the chart to show only items in the new range
            this.chart.filter(this.timebar.inRange, {animate: false, type: 'link'}).then(() => {
                // and then adjust the chart's layout
                this.chart.layout('tweak', {animate: true, time: 1000});
            });
        }
    }


    buildNodes() {
        this.address = [
            { key: 'Header4', text: 'Addresses', itemType: DropdownMenuItemType.Header },
        ];
        this.phones = [
            { key: 'Header4', text: 'Phones', itemType: DropdownMenuItemType.Header },
        ];
        this.emails = [
            { key: 'Header4', text: 'Emails', itemType: DropdownMenuItemType.Header },
        ];
        this.flights = [
            { key: 'Header4', text: 'Flights', itemType: DropdownMenuItemType.Header },
        ];
        this.nodes = [
            { key: 'Header4', text: 'Nodes', itemType: DropdownMenuItemType.Header },
        ];
    }


    expandData(nodeValue, animate, callback) {
        var input = `g.V().has('node','` + nodeValue + `').bothE().bothV().bothE().map(union(inV().values('node'),outV().values('node'),values('ef')).fold())`;
        //fetchData(input)
        //    .then(function (result) {
        var result = responseFromServer.result;
        //console.log("-- result", result);
                // create the layout options
                var layoutOptions = {
                    top: [],
                    fix: "all",
                    fit: true,
                    animate: true,
                    tidy: true
                };
                this.buildNodes();
                var klData = makeKeyLinesItemsOfGraphData(result.data, this.chart, this.state.poi);
                var temp = klData.items;
                this.address = klData.address;
                this.phones = klData.phones;
                this.flights = klData.flights;
                this.emails = klData.emails;
                this.nodes = klData.nodes;
                this.filterAddress = klData.filterAddress;
                this.filterPhones = klData.filterPhones;
                this.filterFlights = klData.filterFlights;
                this.filterEmails = klData.filterEmails;
                this.links = klData.links;

        //console.log("--> Nodes ", this.nodes);

                var expandedItems = temp.map(function (item) {
                    return item.id;
                });

                //////console.log("-- excpanded items", expandedItems);
                var newItems = [];
                temp.forEach(function (item) {
                    if (!this.chart.getItem(item.id)) {
                        newItems.push(item);
                    }
                }.bind(this));

                //Build node sand links
                var tempNodes = [];
                var tempLinks = [];
                tempNodes = [].concat(this.address, this.phones, this.emails, this.flights, this.nodes);
                tempNodes = arrayOfObjAfter(tempNodes);
                tempLinks = arrayOfObjAfter(this.links);
                this.setState({customNodes: tempNodes, customLinks: tempLinks});

                // Only call expand if there is new data to add
                if (newItems.length > 0) {
                    // expand the chart with the new data
                    layoutOptions.top = ['topNode'];
                    ////console.log("-- animate ", animate);
                    var expandOptions = {
                        layout: layoutOptions,
                        time: 500,
                        // Don't animate the expand if it's the initial load or we only added links
                        animate: animate && newItems.some(function (item) {
                            ////console.log("-- item.type==='node'", item.type==='node', item);
                            return item.type === 'node';
                        })
                    };
                    ////console.log("-- chart and new items ", newItems.length);
                    this.chart.expand(
                        newItems,
                        expandOptions/*,
                    function () {
                        // Zoom to the expanded items
                        this.chart.zoom('fit', {
                            animate: true,
                            time: 500,
                            ids: expandedItems
                        }, callback);
                    }*/
                    );
                    this.timebar.merge(newItems, function () {
                        this.timebar.zoom('fit', {animate: true});
                    })
                } else {
                    this.timebar.load(expandedItems, function () {
                        this.timebar.zoom('fit', {animate: false});
                    })
                    this.setState({graphKeylinesData: expandedItems});
                }
                //this.setState({isBusy: false});
                this.chart.lock(false);
           // }.bind(this));
            ////console.log("-- the data to be rendered ", this.state.customNodes);
    }

    isNode(item) {
        ////console.log("-- here is the item ", item);
        return item && item.type === 'node';
    }

    expandClickedData(clickedID) {
        var clickedItem = this.chart.getItem(clickedID);
        if (this.isNode(clickedItem)) {
            this.chart.lock(true, lockOptions);
            this.expandData(clickedItem.id, true, function () {

            });
        }
    }




    runFirstQuery(input) {
        this.chart.lock(true, lockOptions);
        //this.updatedSelectedItem = this.state.selectedItems ? this.copyArray(this.state.selectedItems) : [];
        this.expandData(input, true, function () {
            highlightSelections = true;
        });
    }



    // get a reference to the loaded timebar
    loadedTimebar(timebar) {
        this.timebar = timebar;
    }

    focusOnCharacter(item) {
        if(this.state.toHighlight) {
            //console.log("== selection is made on ", this.chart.selection());
            var result = this.chart.graph().neighbours(item);
            // do not forget to add the node as well
            this.neighbours[item] = true;
            this.fetchAllNeighbours(result, true);
        }
    }

    // get a reference to the loaded chart
    loadedChart(chart) {
        this.chart = chart;
        // Triton
        //this.setState({poi:"cid:87335501319"});
        // Neptune
        this.setState({poi:"cdh:146923544"});
        // load an empty chart and run the first query
        this.runFirstQuery(this.state.poi);
        //this.chart.load({ type: 'LinkChart', items: [] }, this.runFirstQuery);
        // enable the background effect on KeyLines
        this.chart.bind('click', this.focusOnCharacter);
        this.chart.bind('dblclick', this.expandClickedData.bind(this));
    }

    areNeighboursOf(item) {
        //console.log("== > ", item, this.neighbours[item.id]);
        return this.neighbours[item.id];
    }

    toggleHighlight(isChecked) {
        //console.log("-- should highlight ", isChecked);
        if(!isChecked) {
            this.setState({toHighlight: isChecked, nodeLinkSelection: false, filterSelection:[]});
            this.chart.foreground(function () { return true; }, { type: 'all' });
            this.neighbours = [];
        } else {
            this.setState({toHighlight: isChecked, nodeLinkSelection: true, filterSelection:[]});
        }
    }

    // To have all neighbrous marked for selection and highlights
    fetchAllNeighbours(allMarkedNeighbours, toHighlight) {
        //console.log("--> result ", allMarkedNeighbours);
        // convert the 2 array in the result in a dictionary to quickly lookup
        allMarkedNeighbours.nodes.forEach(function (nodeId) {
            //console.log("-- node neighbours ", nodeId);
            this.neighbours[nodeId] = toHighlight;
            //console.log("-- After adding node neighbours ", this.neighbours);
        }.bind(this));
        allMarkedNeighbours.links.forEach(function (linkId) {
            this.neighbours[linkId] = toHighlight;
        }.bind(this));

        //console.log("--> ", this.neighbours);
        this.chart.foreground(this.areNeighboursOf, { type: 'all' });
    }

    onChangeMultiSelect (item) {
        const updatedSelectedItem = this.state.selectedItems ? this.copyArray(this.state.selectedItems) : [];
        if (item.selected) {
            // add the option if it's checked
            updatedSelectedItem.push(item.key);
            //console.log("== key and item ", item, item.key);
            var result = this.chart.graph().neighbours(updatedSelectedItem);
            // do not forget to add the node as well
            this.neighbours[item.key] = true;
           this.fetchAllNeighbours(result, true);
        } else {
            // remove the option if it's unchecked
            const currIndex = updatedSelectedItem.indexOf(item.key);

            if (currIndex > -1) {
                updatedSelectedItem.splice(currIndex, 1);
            }
            if(updatedSelectedItem.length==0) {
                // clicked on background - restore all the elements in the foreground
                this.chart.foreground(function () { return true; }, { type: 'all' });
            } else {
                var result = this.chart.graph().neighbours(item.key);
                // do not forget to add the node as well
                this.neighbours[item.key] = false;
                this.fetchAllNeighbours(result, false);
            }
        }

        this.setState({selectedItems: updatedSelectedItem});
    };

    startClicked() {
        //console.log("-- hello primary ");
    }
    resetClicked() {
        this.chart.clear();
    }

    myFilter(item) {
        return (this.state.filterOptions.indexOf(item.d)<0);
    }

    handleChange(sOption) {
        var updatedSelectedItem = [];
        this.neighbours = [];
        this.setState({ selectedOption: sOption });
        console.log(`Option selected:`, sOption);
        //console.log("item selected ", this.state.selectedOption);
        //sOption = this.state.selectedOption
        ////console.log(`Option selected:`, s);
        // Keeping it simple n stupid
        sOption.forEach(function(entry) {
            updatedSelectedItem.push(entry.value);
            // do not forget to add the node as well
            this.neighbours[entry.value] = true;
        }.bind(this));
        console.log("== selected items ", updatedSelectedItem);

        if(updatedSelectedItem.length==0) {
            // clicked on background - restore all the elements in the foreground
            this.chart.foreground(function () { return true; }, { type: 'all' });
        } else {
            var result = this.chart.graph().neighbours(updatedSelectedItem);
            console.log("==> ", result);
            console.log("== all the neighbours ", this.neighbours);
            this.fetchAllNeighbours(result, true);
        }
    }

    render() {
        var chartHeight = (window.screen.height - 300).toString() + "px";
        data.items = this.state.graphKeylinesData;
        const selectedOption = this.state.selectedOption || "";
        //console.log("-- node values ", this.nodes);
        var filterIcons = <div id="filter-items">
            <span>
                <i className={`fa fa-plane ${this.state.filterOptions.indexOf('flight') <0 ? '':'disable-filter'}`} title="Fight" onClick={() => {
                    var temp = this.state.filterOptions;
                    var idx = temp.indexOf('flight');
                    if(idx >=0 ) temp.splice(idx, 1); else temp.push('flight');
                    this.setState({filterOptions: temp});
                    this.chart.filter(this.myFilter, {type: 'node'});
                }}></i>
            </span>
            <span>
                <i className={`fa fa-at ${this.state.filterOptions.indexOf('email') < 0 ? '' : 'disable-filter'}`} title="Email" onClick={() => {
                    var temp = this.state.filterOptions;
                    var idx = temp.indexOf('email');
                    if(idx >=0 ) temp.splice(idx, 1); else temp.push('email');
                    this.setState({filterOptions: temp});
                    this.chart.filter(this.myFilter, {type: 'node'});
                }}></i>
            </span>
            <span>
                <i className={`fas fa-home ${this.state.filterOptions.indexOf('home') < 0 ? '' : 'disable-filter'}`} title="Home" onClick={() => {
                    var temp = this.state.filterOptions;
                    var idx = temp.indexOf('address');
                    if(idx >=0 ) temp.splice(idx, 1); else temp.push('address');
                    this.setState({filterOptions: temp});
                    this.chart.filter(this.myFilter, {type: 'node'});
                }}></i>
            </span>
            <span>
                <i className={`fa fa-phone  ${this.state.filterOptions.indexOf('phone') < 0 ? '' : 'disable-filter'}`} title="Phone" onClick={() => {
                    var temp = this.state.filterOptions;
                    var idx = temp.indexOf('phone');
                    if(idx >=0 ) temp.splice(idx, 1); else temp.push('phone');
                    this.setState({filterOptions: temp});
                    this.chart.filter(this.myFilter, {type: 'node'});
                }}></i>
            </span>
        </div>;
        return (
            <section>
                <div id="chart-items">
                    <Chart
                        ready={this.loadedChart}
                        data={data}
                        animateOnLoad={true}
                        style={{height: chartHeight}}
                        containerClassName='cichart'
                    />
                    <Timebar
                        ready={this.loadedTimebar}
                        data={data}
                        change={this.onTimebarChange}
                        animateOnLoad={true}
                        style={{height: "150px"}}
                        containerClassName='citimebar'
                    />
                </div>
                <div id="menu-items">
                    <img src="assets/DIBP.png" alt="Dept of Home Affairs"/>
                    <h3> Filters </h3>
                    {filterIcons}
                    <h3> Search in graph</h3>

                                <Select id="custom-selection"
                                    closeMenuOnSelect={false}
                                    value={selectedOption}
                                    onChange={this.handleChange}
                                    options={this.nodes}
                                    isMulti = {true}
                                    isSearchable = {true}
                                />


                    <div id="second-filter-options" class="filter-2">

                        <div>
                            <ChoiceGroup className="filter-choicegroup" disabled = {this.state.nodeLinkSelection}
                                options={[
                                    {
                                        key: 'Node',
                                        text: 'Node'
                                    },// as IChoiceGroupOption,
                                    {
                                        key: 'Link',
                                        text: 'Link'
                                    }
                                ]}
                                onChange={ (e, option) => {
                                    this.setState({selectedItems: [], disableSelection: false});
                                    var cNodes = this.state.customNodes;
                                    var cLinks = this.state.customLinks;
                                    option.key =='Node' ? this.setState({filterSelection: cNodes}) : this.setState({filterSelection: cLinks});
                                }}
                            />
                            <Dropdown
                                disabled={this.state.disableSelection}
                                placeHolder="Select options"
                                onChanged = {this.onChangeMultiSelect}
                                selectedKeys = {this.state.selectedItems}
                                multiSelect
                                options= {this.state.filterSelection}
                            />
                        </div>
                        <Toggle
                            defaultChecked={this.state.toHighlight}
                            onChanged={this.toggleHighlight}
                            label=""
                            onText="Select Node to Highlight"
                            offText="Highlighting is disabled"
                            onFocus={() => console.log('onFocus called')}
                            onBlur={() => console.log('onBlur called')}
                        />
                        {/*<Toggle*/}
                            {/*defaultChecked={this.state.toHighlight}*/}
                            {/*onChanged={this.toggleHighlight}*/}
                            {/*label=""*/}
                            {/*onText="Props as Nodes"*/}
                            {/*offText="Props as "*/}
                            {/*onFocus={() => //console.log('onFocus called')}*/}
                            {/*onBlur={() => //console.log('onBlur called')}*/}
                        {/*/>*/}
                    </div>
                    <div id="action-buttons">
                        <DefaultButton
                            primary={true}
                            text="Take Snapshot"
                            onClick={this.startClicked}
                        />
                    </div>
                    <div id="action-buttons">
                        <DefaultButton
                            primary={true}
                            text="Start"
                            onClick={this.startClicked}
                        />
                        <DefaultButton
                            primary={true}
                            text="Reset"
                            onClick={this.resetClicked}
                        />
                    </div>
                </div>

            </section>
        );
    }
};

// render our top-level component into the DOM
render(<ReactDemo/>, document.getElementById('kl-container'));


