import {MyLinks, customNodeImage} from "../kl-helper/kl-constants";
var axios = require('axios');

var fetchData = function (input) {
    return axios.get('http://localhost:8099/gremlinproxy?input=' + input)
    //return axios.get('http://mpuapw7010.oouat.customs:8099/gremlinproxy?input=' + input)
        .then(function (response) {
            console.log("-- reposne from server ", response);
            return response
        })
        .catch(function (error) {
            return error
        })
}

var arrayOfObjAfter = function(arrayOfObj) {
    return _.map(
        _.uniq(
            _.map(arrayOfObj, function(obj){
                return JSON.stringify(obj);
            })
        ), function(obj) {
            return JSON.parse(obj);
        }
    );
}

var makeKeyLinesItemsOfGraphData = function(results, chart, poi) {
    var keyLineItems = {};
    var items = [];
    var address = [];
    var phones = [];
    var flights = [];
    var emails = [];
    var nodes = [];
    var links = [];
    var filterAddress = [];
    var filterPhones = [];
    var filterFlights = [];
    var filterEmails = [];
    for(var i=0;i<results.length; i++) {
        var data = results[i];
        var temp = data[0].split(":");
        var isLink = MyLinks.indexOf(temp[0]) >= 0 ? true : false;

        if (isLink) {
            var image ="";
            if (temp[0] == 'address') {
                address.push({key:data[0], text: data[0]});
                filterAddress.push(data[0]);
                if ((temp[1].indexOf('po.box') || temp[1].indexOf('po.Box') || temp[1].indexOf('p o box')) == -1) {
                    image = customNodeImage['address'];
                }
                image = customNodeImage['poAddress'];
            } else if (temp[0] == 'phone') {
                phones.push({key:data[0], text: data[0]});
                filterPhones.push(data[0]);
                if (temp[1].substring(0, 2) === "04") {
                    image = customNodeImage['mobile'];
                }
                image = customNodeImage['landLine'];
            } else if (temp[0] == 'flight') {
                flights.push({key:data[0], text: data[0]});
                filterFlights.push(data[0]);
                if (temp[1].slice(-1) == 'a') image = customNodeImage['landing'];
                else if (temp[1].slice(-1) == 'd') image = customNodeImage['take-off'];
                else image = customNodeImage['flight'];
            } else if (temp[0] == 'email') {
                emails.push({key:data[0], text: data[0]});
                filterEmails.push(data[0]);
                image = customNodeImage['email'];
            }

            if (!chart.getItem(data[0])) {
                items.push({
                    type: 'node',
                    id: data[0],
                    t: data[0],
                    fs: 10,
                    u: image,
                    c: '#aec7e8',
                    d: data[0],
                    dt: [data[2]]
                });
            }
            if (!chart.getItem(data[1])) {
                temp = data[1].split(":");
                items.push({
                    type: 'node',
                    id: data[1],
                    t: data[1],
                    fs: 10,
                    u: image,
                    c: '#aec7e8',
                    d: data[1],
                    dt: [data[2]]
                });
            }
            if (!chart.getItem(data[0] + " - " + data[1])) {
                links.push(data[0]+ " - "+data[1]);
                items.push({
                    type: 'link',
                    id: data[0] + " - " + data[1],
                    id1: data[0],
                    id2: data[1],
                    fs: 10,
                    dt: [data[2]]
                });
            }
        }
        else {
            var image = "";
            nodes.push({key:data[0], text:data[0]});
            console.log("-->>  nodeValue ", poi, data[0], temp[0]);
            if (!chart.getItem(data[0])) {
                temp = data[0].split(":");
                items.push({
                    type: 'node',
                    id: data[0],
                    t: data[0],
                    fs: 10,
                    u: (data[0] == poi) ? customNodeImage['poi'] : customNodeImage[temp[0]],
                    c: '#aec7e8',
                    d: data[0],
                    dt: [data[2]]
                });
            }

            if (!chart.getItem(data[1])) {
                temp = data[1].split(":");
                // Node 2
                items.push({
                    type: 'node',
                    id: data[1],
                    t: data[1],
                    fs: 10,
                    u: (data[1] == poi ) ? customNodeImage['poi'] : customNodeImage[temp[0]],
                    c: '#aec7e8',
                    d: data[1],
                    dt: [data[2]]
                });
            }
            if (!chart.getItem(data[0] + " - " + data[1])) {
                links.push(data[0]+ " - "+data[1]);
                items.push({
                    id: data[0] + " - " + data[1],
                    type: 'link',
                    id1: data[0],
                    id2: data[1],
                    dt: [data[2]],
                    fs: 10,
                });
            }
        }
    }
    keyLineItems["items"] = items;
    keyLineItems["address"] = address;
    keyLineItems["phones"] = phones;
    keyLineItems["flights"] = flights;
    keyLineItems["emails"] = emails;
    keyLineItems["nodes"] = nodes;
    keyLineItems["filterAddress"] = filterAddress;
    keyLineItems["filterPhones"] = filterPhones;
    keyLineItems["filterFlights"] = filterFlights;
    keyLineItems["filterEmails"] = filterEmails;
    keyLineItems["links"] = links;
    return keyLineItems;
}

var copyArray = function (array) {
    const newArray = [];
    for (let i = 0; i < array.length; i++) {
        newArray[i] = array[i];
    }
    return newArray;
};

export {fetchData, arrayOfObjAfter, makeKeyLinesItemsOfGraphData, copyArray};