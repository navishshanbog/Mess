// If you are using Node.js as your web server, you should first install Express by running:
//
// > npm install express
//
// You can then start your web server by running this file:
//
// > node server.js
//
// If you can't run Node or Express, just use a simple Python server
//    
//  > python -m SimpleHTTPServer 8080
//
// Then you can navigate to http://localhost:8080 in your web browser to see the demo running.

var path = require('path');
var axios = require('axios');
var btoa = require('btoa');

// Helper to get the major version of Express
function getVersion(){
  // Since Express 3.3 version is not exposed any longer
  var version = (express.version || '4.').match(/^(\d)+\./)[1];
  return Number(version);
}

var express = require('express');

var app;

var version = getVersion();

// Depending on the version number there are several ways to create an app
if(version === 2){
  app = express.createServer();
} else if(version > 2){
  app = express();
}

app.use('/keylines/', express["static"].apply(null, [__dirname + '/']));

app.get('/keylines/', function (req, res) {
  res.sendFile(path.join(__dirname, 'index.htm'));
});

// SECURED => http://phd2e1.customs.gov.au:8187/?gremlin=g.V().has('node','cdh:168799928').valueMap()"   // neptune
// UNSECURED => http://phd2e1.customs.gov.au:8189/?gremlin=g.V().has('node','cid:87335501319').valueMap()"    // triton
app.get('/gremlinproxy', function (req, res) {
    /* Neptune */ var targetUrl = 'http://phd2e1:8187';
    /* Triton */ //var targetUrl = 'http://phd2e1:8189';
    var query = req.query.input;
    console.log("-- request ", query);
    var username = 'excbnl';
    var password = 'strikeit';
    var basicAuth = 'Basic ' + btoa(username + ':' + password);
    console.log("-- basicAuth ", basicAuth);
    var reqConfig = {
        url: targetUrl,
        method: 'POST',
        data: JSON.stringify({"gremlin": query}),
        headers: {
            "Content-Type": 'application/json',//req.header("Content-Type"),
            'Authorization': basicAuth
        }
    };
    return axios(reqConfig).then(function(result) {
        console.log("something is returned successfully ");
        res.set('Content-Type', result.headers["content-type"]);
        res.send(result.data);
    }).catch(function(error) {
        console.error("API Error: ", error);
        if (error.response) {
            res.status(error.response.status);
            res.send(error.response.data);
        } else {
            res.status(500).send(JSON.stringify(error));
        }
    });
});

const solrBaseUrl = "https://phd2e1:9011/solr";
app.get("/solr", (req, res, next) => {
    const path = solrBaseUrl + req.path;
    axios.get(solrBaseUrl + req.path, {
        params: req.query,
        auth: {
            username: 'solr_aa_select_user',
            password: 'skywalker'
        }
    }).then((result) => {
        res.json(result.data).end();
    }).catch((error) => {
        console.error(error);
        res.status(500).end();
    });
});

app.listen(8099);

console.log('Server running. Browse to http://localhost:8099');
