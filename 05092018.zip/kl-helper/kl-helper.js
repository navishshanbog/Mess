import {MyLinks, customNodeImage} from "../kl-helper/kl-constants";
var axios = require('axios');

var red = 'rgba(214, 39, 40, 0.75)';
var blue = 'rgb(31, 119, 180)';
var green = 'rgba(44, 160, 44, 0.75)';
var orange = 'rgb(255, 127, 14)';
var lightBlue = 'rgb(174, 199, 232)';
var lightGrey = 'rgb(220, 220, 220)';
var darkGrey = 'rgb(105, 105, 105)';
var black = 'rgb(0, 0, 0)';

var fetchData = function (input) {
    console.log("-- input, sourceSystem ", input);
    return axios.get('http://localhost:8099/gremlinproxy?input=' + input)
    //return axios.get('http://mpuapw7010.oouat.customs:8099/gremlinproxy?input=' + input)
        .then(function (response) {
            console.log("-- reposne from server ", response);
            return response
        })
        .catch(function (error) {
            return error
        })
}

var arrayOfObjAfter = function(arrayOfObj) {
    return _.map(
        _.uniq(
            _.map(arrayOfObj, function(obj){
                return JSON.stringify(obj);
            })
        ), function(obj) {
            return JSON.parse(obj);
        }
    );
}

var getOutwardCountFor = function(nodeValue, callback) {
    var input = `g.V().has('node','` + nodeValue + `').bothE().count()`; // get the count for a node
    console.log("-- Input and input for getOutwardcountfor  ", input);
    fetchData(input)
        .then(function (response) {
            console.log("-- response fro call back", response);
            return response
        })
        .catch(function (error) {
            return error
        })
}

var makeKeyLinesItemsOfGraphData = function(results, chart, poi) {
    var keyLineItems = {};
    var items = [];
    var address = [];
    var phones = [];
    var flights = [];
    var emails = [];
    var nodes = [];
    var links = [];
    var filterAddress = [];
    var filterPhones = [];
    var filterFlights = [];
    var filterEmails = [];

    for(var i=0;i<results.length; i++) {
        var data = results[i];
        console.log("-- node porperties edges ", data.properties.edgeID);
        var temp = data.properties.edgeID.split(",");

        if (data.inVLabel == 'address' || data.outVLabel == 'address') {
            if(data.inVLabel == 'address') {
                address.push({key: temp[1], text: temp[1]});
                filterAddress.push(temp[1]);
            } else {
                address.push({key: temp[0], text: temp[0]});
                filterAddress.push(temp[0]);
            }
        } else if (data.inVLabel == 'phone' || data.outVLabel == 'phone') {
            if (data.inVLabel == 'phone') {
                phones.push({key: temp[1], text: temp[1]});
                filterPhones.push(temp[1]);
            } else {
                phones.push({key: temp[0], text: temp[0]});
                filterPhones.push(temp[0]);
            }
        } else if (data.inVLabel == 'email' || data.outVLabel == 'email') {
            if (data.inVLabel == 'phone') {
                email.push({key: temp[1], text: temp[1]});
                filterEmails.push(temp[1]);
            } else {
                email.push({key: temp[0], text: temp[0]});
                filterEmails.push(temp[0]);
            }
        } else if (data.inVLabel == 'flight' || data.outVLabel == 'flight') {
            if (data.inVLabel == 'phone') {
                flight.push({key: temp[1], text: temp[1]});
                filterFlights.push(temp[1]);
            } else {
                flight.push({key: temp[0], text: temp[0]});
                filterFlights.push(temp[0]);
            }
        }
        nodes.push({value:temp[0], label:temp[0]},{value:temp[1], label:temp[1]});

        if (!chart.getItem(temp[0])) {
            console.log("1 -- customNodeImage[data.inVLabel],", temp[0], data.outVLabel, customNodeImage[data.outVLabel]);
            console.log("11-- out filter function ", items, items.find(function(item) {return item.type=="node" && item.id== temp[0]}));
            if (items.find(function(item) {return item.type=="node" && item.id== temp[0]}) == undefined) {
                console.log("getOutwardCountFor(temp[0])", getOutwardCountFor(temp[0]));
                items.push({
                    type: 'node',
                    id: temp[0],
                    t: temp[0],
                    fs: 10,
                    u: customNodeImage[data.outVLabel],
                    c: '#aec7e8',
                    d: temp[0],
                    g: [{w: true, fc: black, c: lightBlue, b: blue, t: getOutwardCountFor(temp[0])}],
                    dt: [data.properties.ef]
                });
            }
        }
        if (!chart.getItem(temp[1])) {
            console.log("2-- customNodeImage[data.inVLabel],", temp[1], data.inVLabel, customNodeImage[data.inVLabel]);
            console.log("22-- out filter function ", items, items.find(function(item) {return item.type=="node" && item.id== temp[1]}));
            if (items.find(function(item) {return item.type=="node" && item.id== temp[1]}) == undefined) {
                console.log("getOutwardCountFor(temp[1])", getOutwardCountFor(temp[1]));
                items.push({
                    type: 'node',
                    id: temp[1],
                    t: temp[1],
                    fs: 10,
                    u: customNodeImage[data.inVLabel],
                    c: '#aec7e8',
                    g: [{w: true, fc: black, c: lightBlue, b: blue, t: getOutwardCountFor(temp[1])}],
                    d: temp[1],
                    dt: [data.properties.ef]
                });
            }
        }
        if (!chart.getItem(temp[0] + " - " + temp[1])) {
            links.push(temp[0] + " - " + temp[1]);
            items.push({
                type: 'link',
                id: temp[0] + " - " + temp[1],
                id1: temp[0],
                id2: temp[1],
                fs: 10,
                dt: [data.properties.ef]
            });
        }
    }

/*
    for(var i=0;i<results.length; i++) {
        var data = results[i];
        var temp = data[0].split(":");
        var isLink = MyLinks.indexOf(temp[0]) >= 0 ? true : false;
        nodes.push({value:data[0], label:data[0].substring(0,25)});
        nodes.push({value:data[1], label:data[1].substring(0,25)});
        if (isLink) {
            var image ="";
            if (temp[0] == 'address') {
                address.push({key:data[0], text: data[0]});
                filterAddress.push(data[0]);
                if ((temp[1].indexOf('po.box') || temp[1].indexOf('po.Box') || temp[1].indexOf('p o box')) == -1) {
                    image = customNodeImage['address'];
                }
                image = customNodeImage['poAddress'];
            } else if (temp[0] == 'phone') {
                phones.push({key:data[0], text: data[0]});
                filterPhones.push(data[0]);
                if (temp[1].substring(0, 2) === "04") {
                    image = customNodeImage['mobile'];
                }
                image = customNodeImage['landLine'];
            } else if (temp[0] == 'flight') {
                flights.push({key:data[0], text: data[0]});
                filterFlights.push(data[0]);
                if (temp[1].slice(-1) == 'a') image = customNodeImage['landing'];
                else if (temp[1].slice(-1) == 'd') image = customNodeImage['take-off'];
                else image = customNodeImage['flight'];
            } else if (temp[0] == 'email') {
                emails.push({key:data[0], text: data[0]});
                filterEmails.push(data[0]);
                image = customNodeImage['email'];
            }

            if (!chart.getItem(data[0])) {
                console.log(" -- link 1 ", data[0]);
                items.push({
                    type: 'node',
                    id: data[0],
                    t: data[0],
                    fs: 10,
                    u: image,
                    c: '#aec7e8',
                    d: temp[0],
                    dt: [data[2]]
                });
            }
            if (!chart.getItem(data[1])) {
                temp = data[1].split(":");
                console.log(" -- link 2 ", data[1]);
                items.push({
                    type: 'node',
                    id: data[1],
                    t: data[1],
                    fs: 10,
                    u: (data[1] === poi) ? customNodeImage['poi'] : customNodeImage[temp[0]],
                    c: '#aec7e8',
                    d: temp[0],
                    dt: [data[2]]
                });
            }
            if (!chart.getItem(data[0] + " - " + data[1])) {
                links.push(data[0]+ " - "+data[1]);
                items.push({
                    type: 'link',
                    id: data[0] + " - " + data[1],
                    id1: data[0],
                    id2: data[1],
                    fs: 10,
                    dt: [data[2]]
                });
            }
        }
        else {
            var image = "";
            console.log(" -- node 1 ", data[0]);
            if (!chart.getItem(data[0])) {
                temp = data[0].split(":");
                items.push({
                    type: 'node',
                    id: data[0],
                    t: data[0],
                    fs: 10,
                    u: (data[0] === poi) ? customNodeImage['poi'] : customNodeImage[temp[0]],
                    c: '#aec7e8',
                    d: temp[0],
                    dt: [data[2]]
                });
            }

            if (!chart.getItem(data[1])) {
                temp = data[1].split(":");
                console.log(" -- node 2 ", data[1], poi);
                items.push({
                    type: 'node',
                    id: data[1],
                    t: data[1],
                    fs: 10,
                    u: (data[1] === poi ) ? customNodeImage['poi'] : customNodeImage[temp[0]],
                    c: '#aec7e8',
                    d: temp[0],
                    dt: [data[2]]
                });
            }
            if (!chart.getItem(data[0] + " - " + data[1])) {
                links.push(data[0]+ " - "+data[1]);
                items.push({
                    id: data[0] + " - " + data[1],
                    type: 'link',
                    id1: data[0],
                    id2: data[1],
                    dt: [data[2]],
                    fs: 10,
                });
            }
        }
    }

*/
    keyLineItems["items"] = arrayOfObjAfter(items);
    keyLineItems["address"] = arrayOfObjAfter(address);
    keyLineItems["phones"] = arrayOfObjAfter(phones);
    keyLineItems["flights"] = arrayOfObjAfter(flights);
    keyLineItems["emails"] = arrayOfObjAfter(emails);
    keyLineItems["nodes"] = arrayOfObjAfter(nodes);
    keyLineItems["filterAddress"] = arrayOfObjAfter(filterAddress);
    keyLineItems["filterPhones"] = arrayOfObjAfter(filterPhones);
    keyLineItems["filterFlights"] = arrayOfObjAfter(filterFlights);
    keyLineItems["filterEmails"] = arrayOfObjAfter(filterEmails);
    keyLineItems["links"] = arrayOfObjAfter(links);
    return keyLineItems;
}

var copyArray = function (array) {
    const newArray = [];
    for (let i = 0; i < array.length; i++) {
        newArray[i] = array[i];
    }
    return newArray;
};


var removeArrElement = function(array, element) {
    const index = array.indexOf(element);
    array.splice(index, 1);
    return array;
}

export {fetchData, arrayOfObjAfter, makeKeyLinesItemsOfGraphData, copyArray, removeArrElement};