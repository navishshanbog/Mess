Techbraid - Storenet
=====================

A Proof of Concept to show the use of 
* React 
* MobX
* babel 
* webpack

HMR (Hot module replacement) is enabled.
ESLint is used with Google as the standard coding style


### Run the example

```
npm install
npm start
```

Browser should open automatically. Otherwise, navigate to the URL reported in the terminal

Techbraid 2017