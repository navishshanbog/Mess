import * as React from 'react';
import { observer } from "mobx-react";
import { DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { TextField } from 'office-ui-fabric-react/lib/TextField';

@observer
class AllKids extends React.Component {

    constructor(props) {
        super(props);
        this.state = ({
            newKid: {}
        })
    }

    _handleKidSelection = (_kidSelected) => {
        this.props.onKidsSelection(_kidSelected);
    }

    _handleText(key, e) {
        var kid = this.state.newKid;
        kid[key] = e;
        this.setState({newKid: kid });
    }

    addKiddoToGroup = () => {
        this.props.allKids.set(this.state.newKid);
        this.setState({newKid: {}});
    }

    _addKid = () => {
        var isDuplidateId = false;
        if(this.state.newKid.id) {
            this.props.allKids.kids.forEach((kid) => {
                if (kid.id == this.state.newKid.id) isDuplidateId = true;
            });
        }
        isDuplidateId ? alert("Unable to add kid..duplicate id found") : this.addKiddoToGroup();
    }

    render() {
        return (
            <div>
                <h3> List of Children </h3>
                <ul>
                    {
                        this.props.allKids.kids.map(kid => (
                            <span key={kid.id}>
                                <DefaultButton onClick={this._handleKidSelection.bind(this, kid.id)}>{kid.name}</DefaultButton>
                            </span>
                        ))
                    }
                </ul>

                <div>
                    <TextField label='ID' required={true} onChanged={this._handleText.bind(this,"id")} value={this.state.newKid.id || ""}/>
                    <TextField label='Name' onChanged={this._handleText.bind(this,"name")} value={this.state.newKid.name || ""}/>
                    <TextField label='Date of birth' onChanged={this._handleText.bind(this,"dob")} value={this.state.newKid.dob || ""}/>
                </div>

                <DefaultButton onClick={this._addKid.bind(this)} > Add to Kid </DefaultButton>

            </div>

        );
    }
}

export {AllKids as default, AllKids};