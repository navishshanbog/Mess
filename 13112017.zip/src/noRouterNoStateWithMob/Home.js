import * as React from 'react';
import { observer } from "mobx-react";
import { DefaultButton } from 'office-ui-fabric-react/lib/Button';
import {PARENTS_PAGE, KIDS_PAGE} from "../Data"
import One from "./One";
import Two from "./Two";

@observer
class Home extends React.Component {

    navigateToPage (pageTitle, event) {
        this.props.store.viewSelected = pageTitle;
    }

    render() {
        let content;
        console.log("View selected", this.props.store.viewSelected);
        switch(this.props.store.viewSelected) {
            case KIDS_PAGE: content = <One kidsModel = {this.props.store.kidsModel} navigateToHome={this.navigateToPage.bind(this, "")}/>; break;
            case PARENTS_PAGE: content = <Two parentsModel = {this.props.store.parentsModel} />; break;
            default: content = <div>
                <div>HOME</div>
                <DefaultButton onClick={this.navigateToPage.bind(this, KIDS_PAGE)}>Goto Page One</DefaultButton>
                <DefaultButton onClick={this.navigateToPage.bind(this, PARENTS_PAGE)}>Goto Page Two</DefaultButton>
            </div>;
        }
        return ( content );
    }
}

export {Home as default, Home};