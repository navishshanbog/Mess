import * as React from 'react';

import { DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { observer } from "mobx-react";

@observer
class KidProfile extends React.Component {

    navigateBack = () => {
        this.props.clearKidSelection();
    }

    render() {
        let kidProfile = this.props.kidSelected;
        return (
            <div>
                <h3>Name: {kidProfile.name} </h3>
                <h4>Id:  {kidProfile.id}</h4>
                <h4>Date Of Birth: {kidProfile.dob}</h4>

                <DefaultButton onClick={this.navigateBack.bind(this)}>Back</DefaultButton>
            </div>
        );
    }
}

export {KidProfile as default, KidProfile};