
import MyAppStoreModel from "./MyAppStoreModel";

const MyAppStore = new MyAppStoreModel();

export { MyAppStore as default, MyAppStore };