import * as React from 'react';
import { observer } from "mobx-react";
import AllKids from "./AllKids";
import KidProfile from "./KidProfile";
import { DefaultButton } from 'office-ui-fabric-react/lib/Button';

@observer
class One extends React.Component {

    clearKidSelection = () => {
        this.props.kidsModel.selectedKidId = "";
    }

    onKidsSelection = (_kidSelected) => {
        this.props.kidsModel.selectedKidId = _kidSelected;
        this.props.kidsModel.selectedKid = this.props.kidsModel.allKids.get(_kidSelected);
    }

    navigateBack = () => {
        this.clearKidSelection();
        this.props.navigateToHome();
    }


    render() {
        let displayContent = <AllKids onKidsSelection={this.onKidsSelection} allKids={this.props.kidsModel.allKids}/>;
        if(this.props.kidsModel.anySelectedKid()) {
            displayContent = <KidProfile kidSelected={this.props.kidsModel.selectedKid} clearKidSelection={this.clearKidSelection}/>
        }

        return (
            <div>
                <div>Welcome parents </div>{/*
                <Link to='/'>Goto Home</Link>*/}
                {displayContent}
                <span>
                    <DefaultButton onClick={this.navigateBack.bind(this)}>To Home</DefaultButton>
                </span>
            </div>
        );
    }
}

export {One as default, One};