import IParentsModel from "./IParentsModel";
import {Parents} from "../Data";


class ParentsModel implements IParentsModel {
    allParents = Parents;
}

export { ParentsModel as default, ParentsModel }