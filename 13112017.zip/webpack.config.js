var path = require('path');
var webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');

const PUBLIC_PATH = "/storenet/";

module.exports = {
  // You may want 'eval' instead if you prefer to see the compiled output in DevTools.
  // See the discussion in https://github.com/facebookincubator/create-react-app/issues/343.
  devtool: 'cheap-module-source-map',
  //devtool: 'eval',
  entry: {
    main: "./src/index.js",
    vendor: ["react", "react-dom", "mobx", "mobx-react"]
  },
  /*entry: [
    main: './src/index.js',
    vendor: ["react", "react-dom", "mobx", "mobx-react", "core-js", "office-ui-fabric-react", "moment"]
  ],*/
  output: {
    // The build folder.
    path: path.join(__dirname, "dist"),
    // Generated JS file names (with nested folders).
    // There will be one main bundle, and one file per asynchronous chunk.
    filename: '[name].[hash:8].js',
   // chunkFilename: 'static/js/[name].[chunkhash:8].chunk.js',
    // (such as / or /my-project) from homepage.
    publicPath: PUBLIC_PATH
  },
/*  output: {
    path: path.join(__dirname, 'dist'),
    filename: 'bundle.js',
    publicPath: '/static/',
  },*/
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    // Generates an `index.html` file with the <script> injected.
    new HtmlWebpackPlugin({
      inject: true,
      template: './index.html'
    }),
    new webpack.optimize.CommonsChunkPlugin({
      name: "vendor",
      debug: true
    }),
    new webpack.optimize.UglifyJsPlugin({
      sourceMap: true
    })
  ],
  resolve: {
    extensions: ['.js', '.jsx'],
    modules: [
      path.resolve(__dirname, "src"), "node_modules"
    ],
    alias: {
      "package.json$": path.resolve(__dirname, "package.json")
    }
  },
  externals: [
    {'./node_modules/jszip': 'jszip'}
  ],
  module: {
    rules: [{
      test: /\.jsx?$/,
      use: ['babel-loader'],
      include: path.join(__dirname, 'src'),
    }],
  }
};
