"use strict";
const express = require("express");
const path = require("path");
//const morgan = require("morgan");


const app = express();
const contentDir = path.join(__dirname, "dist");

app.use(function(req, res, next) {
    var ext = path.extname(req.path);
    if(!ext || ext === ".html") {
        res.sendFile("index.html", { root: contentDir });
    } else {
        next();
    }
});

app.use(express.static(contentDir));

module.exports = app;