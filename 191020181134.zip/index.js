const app = require("./app");

return app.listen(3000, () => {
    console.log("Server Started @ localhost:3000");
});