

packages
===========

********************************************************************************************
@types/ prefix means that we also want to get the declaration files for React and React-DOM.
Usually when you import a path like "react", it will look inside of the react package itself
********************************************************************************************
react
react-dom
@types/react
@types/react-dom

npm install --save-dev typescript awesome-typescript-loader source-map-loader
Both of these dependencies will let TypeScript and webpack play well together. awesome-typescript-loader helps Webpack compile your TypeScript code using the TypeScript’s standard configuration file named tsconfig.json.