import * as React from "react";
import * as ReactDOM from "react-dom";
import { Fabric } from "office-ui-fabric-react/lib/Fabric";

import { Hello } from "./component/Hello";

ReactDOM.render(
    <Fabric className="analyst-desktop">
        <Hello compiler="TypeScript" framework="React" className="my-app"/>,
    </Fabric>,
    document.getElementById("main")
);