const path = require('path');
// for Creation of Index.html
const HtmlWebpackPlugin = require("html-webpack-plugin");

const AppConfig = {
    buildDate: new Date(),
};

const contains = (...values) => {
    return (filename) => {
        return values.some(value => {
            return filename.indexOf(value) >= 0;
        });
    }
};

const isNodeModuleFile = contains("node_modules");

const some = (...p) => {
    return (filename) => {
        return p.some(e => e(filename));
    };
};

const every = (...p) => {
    return (filename) => {
        return p.every(e => e(filename));
    };
};

const endsWith = (...extensions) => {
    return (filename) => {
        return extensions.some(ext => {
            return filename.endsWith(ext);
        });
    };
};

module.exports = {
    entry: "./src/index.tsx",
    output: {
        filename: "[name].js",
        path: path.join(__dirname, "/dist"),
    },
    // Enable sourcemaps for debugging webpack's output.
    devtool: "source-map",

    resolve: {
        // Add '.ts' and '.tsx' as resolvable extensions.
        extensions: [".ts", ".tsx", ".js", ".json"]
    },

    module: {
        rules: [
            {
                enforce: "pre",
                test: endsWith(".ts", ".tsx"),
                loader: "source-map-loader",
                exclude: some(isNodeModuleFile, endsWith(".template.ts"))
            },
            {
                test: endsWith(".ts", ".tsx"),
                loader: "ts-loader",
                exclude: isNodeModuleFile
            },
            {
                test: endsWith(".css"),
                use: [
                    { loader: "@microsoft/loader-load-themed-styles" },
                    { loader: "css-loader" }
                ]
            },
            {
                test: endsWith(".scss"),
                use: [
                    { loader: "@microsoft/loader-load-themed-styles" },
                    { loader: "css-loader" },
                    {
                        loader: "sass-loader",
                        /*options: {
                            data: `$ms-font-cdn-path: "${AppConfig.fabricFontBasePath}";`
                        }*/
                    }
                ]
            },
            {
                test: endsWith(".woff", ".woff2", ".font.svg", ".ttf", ".eot"),
                use: [
                    { loader: "file-loader" }
                ]
            },
            {
                test: endsWith(".png", ".jpg", ".gif"),
                use: [
                    { loader: "file-loader" }
                ]
            }
        ]
        /*rules: [
            // All files with a '.ts' or '.tsx' extension will be handled by 'awesome-typescript-loader'.
            { test: /\.tsx?$/, loader: "awesome-typescript-loader" },

            // All output '.js' files will have any sourcemaps re-processed by 'source-map-loader'.
            { enforce: "pre", test: /\.js$/, loader: "source-map-loader" }
        ]*/
    },

    // When importing a module whose path matches one of the following, just
    // assume a corresponding global variable exists and use that instead.
    // This is important because it allows us to avoid bundling all of our
    // dependencies, which allows browsers to cache those libraries between builds.
/*    externals: {
        "react": "React",
        "react-dom": "ReactDOM"
    },*/
    plugins: [
        new HtmlWebpackPlugin({
            title: "test",
            template: "src/index.template.ts",
            AppConfig: AppConfig,
            chunksSortMode: "none"
        }),
    ]
};