import Context from "common/Context";
import IABRService from "./IABRService";
import RestABRService from "./RestABRService";

const ABRServiceContext = new Context<IABRService>({
    factory: () => {
        return new RestABRService();
    }
});

export { ABRServiceContext as default, ABRServiceContext };