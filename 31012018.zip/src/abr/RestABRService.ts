import axios from "axios";
import { IABRService, IABRActivitiesGetRequest } from "./IABRService";
import IABRActivity from "./IABRActivity";
import AbstractRestDataService from "common/AbstractRestDataService";
import * as DefaultHttpErrorHandler from "common/HttpErrorHandler";

const DEFAULT_MAX_NO_RECORDS = 2000;

interface GetABRRestResponse {
    errors?: any;
    getABRSummaryResponse?: IABRActivity[];
}

class RestABRService extends AbstractRestDataService implements IABRService {
    getABRActivities(request : IABRActivitiesGetRequest) : Promise<IABRActivity[]> {
        const internalRequest = Object.assign({}, request);
        if(isNaN(internalRequest.maxNumberOfRecords) || internalRequest.maxNumberOfRecords <= 0) {
            internalRequest.maxNumberOfRecords = DEFAULT_MAX_NO_RECORDS;
        }
        return axios.post(`${this.config.baseUrl}/resources/abrSummary`, internalRequest).then((value) => {
            const response = value.data as GetABRRestResponse;
            if(response.errors) {
                return this.handleError(response.errors);
            }
            return response.getABRSummaryResponse;
        }).catch(DefaultHttpErrorHandler.handleAxiosError);
    }
}

export { RestABRService as default, RestABRService };