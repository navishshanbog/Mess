import * as React from "react";
import IABRActivity from "abr/IABRActivity"
import IMasterEntitySourceListModel from "entity/IMasterEntitySourceListModel";
import ABRActivityColumns from "./ABRActivityColumns";
import MasterEntitySourceDetailsList from "entity/component/MasterEntitySourceDetailsList";
import IViewPreferencesModel from "common/IViewPreferencesModel";

interface IABRActivityDetailsListProps {
    list: IMasterEntitySourceListModel<IABRActivity>;
    viewPreferences?: IViewPreferencesModel;
}

class ABRActivityDetailsList extends React.Component<IABRActivityDetailsListProps, any> {
    render() {
        return <MasterEntitySourceDetailsList
                        columns={ABRActivityColumns}
                        list={this.props.list}
                        typeLabel="ABR Activities"
                        itemType="activity"
                        viewPreferences={this.props.viewPreferences} />;
    }
}

export { ABRActivityDetailsList as default, ABRActivityDetailsList }