import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import SyncContainer from "common/component/SyncContainer";
import IMasterEntitySourceListModel from "entity/IMasterEntitySourceListModel";
import IABRActivity from "abr/IABRActivity";
import ABRActivityDetailsList from "abr/component/ABRActivityDetailsList";
import { createActivityListFilterItem } from "common/component/ActivityFilterMenuHelper";
import { createCopyToClipboardItem } from "entity/component/MasterEntitySourceHelper";
import ABRActivityViewPrefsStore from "abr/ABRActivityViewPrefsStore";
import ABRActivityColumns from "./ABRActivityColumns";
import { createViewPreferencesMenuItem } from "common/component/ViewPreferencesMenuItem";

interface IABRActivityListProps {
    list: IMasterEntitySourceListModel<IABRActivity>;
}

@observer
class ABRActivityListCommandBar extends React.Component<IABRActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [
            createActivityListFilterItem({ list: this.props.list, itemsTitle: "ABR Activities" })
        ];
        const farItems : IContextualMenuItem[] = [
            createCopyToClipboardItem({ sourceList: this.props.list, itemType: "activity" }),
            createViewPreferencesMenuItem(ABRActivityViewPrefsStore, ABRActivityColumns)
        ];
        return <CommandBar className="entity-source-list-command-bar abr-activity-list-command-bar" items={items} farItems={farItems} />;
    }
}

class ABRActivityListContainer extends React.Component<IABRActivityListProps, any> {
    private _onRenderDone = () => {
        return (
            <div className="entity-source-list-container abr-activity-list-container">
                <ABRActivityListCommandBar {...this.props} />
                <div className="entity-source-list-view abr-activity-list-view">
                    <ABRActivityDetailsList {...this.props} viewPreferences={ABRActivityViewPrefsStore} />
                </div>
            </div>
        );
    }
    render() {
        return <SyncContainer sync={this.props.list.sync} onRenderDone={this._onRenderDone} />;
    }
}

export { ABRActivityListContainer as default, ABRActivityListContainer, IABRActivityListProps }