const WindowAppHostKey = "_APP_HOST_DODGY_GLOBAL_U_KNOW_THE_DEAL_";

export { WindowAppHostKey }