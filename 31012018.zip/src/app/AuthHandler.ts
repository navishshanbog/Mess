import IRequest from "roota/lib/IRequest";
import IRequestHandler from "roota/lib/IRequestHandler";
import IUserProfile from "user/IUserProfile";
import * as StringUtils from "util/String";
import UserProfileServiceContext from "user/UserProfileServiceContext";

const isAuthorised = (reqAuthGroup : string, userProfile : IUserProfile) : boolean => {
    return StringUtils.isBlank(reqAuthGroup) ||
        (userProfile && userProfile.groups && userProfile.groups.some(group => group == reqAuthGroup));
};

const createAuthHandler = (reqAuthGroup : string) : IRequestHandler => {
    return (req: IRequest, next?: IRequestHandler) : Promise<any> | any => {
        return UserProfileServiceContext.ref.getUserProfile().then((userProfile) => {
            if (!isAuthorised(reqAuthGroup, userProfile)) {
                throw { code: "FORBIDDEN", message: "You do not have permission to access this resource", request: req};
            }
            return next();
        });
    }
};

export { createAuthHandler, isAuthorised }