import * as React from "react";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityASICContainer from "./EntityASIC";

class EntityASICApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityASICContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="ASIC"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityASICApplet as default, EntityASICApplet }