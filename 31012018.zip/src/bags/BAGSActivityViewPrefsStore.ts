import ViewPreferencesModel from "common/ViewPreferencesModel";

const BAGSActivityViewPrefsStore = new ViewPreferencesModel("bagsActivity");

export { BAGSActivityViewPrefsStore as default, BAGSActivityViewPrefsStore }