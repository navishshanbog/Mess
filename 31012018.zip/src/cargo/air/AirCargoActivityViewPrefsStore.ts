import ViewPreferencesModel from "common/ViewPreferencesModel";

const AirCargoActivityViewPrefsStore = new ViewPreferencesModel("airCargoActivity");

export { AirCargoActivityViewPrefsStore as default, AirCargoActivityViewPrefsStore }