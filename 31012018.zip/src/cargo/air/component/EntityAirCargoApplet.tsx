import * as React from "react";
import IAppHost from "app/IAppHost";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import EntityAirCargoContainer from "./EntityAirCargo";
import "./EntityAirCargoApplet.scss";

class EntityAirCargoApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityAirCargoContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper className="entity-air-cargo-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="Air Cargo"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityAirCargoApplet as default, EntityAirCargoApplet }