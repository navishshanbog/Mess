import * as React from "react";
import IAppHost from "app/IAppHost";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import EntityCargo from "./EntityCargo";
import { ISyncHandle } from "common/ISyncHandle";
import { IMasterEntityModel } from "entity/IMasterEntityModel";
import "./EntityCargoApplet.scss";

class EntityCargoApplet extends React.Component<IEntityAppletProps, any> {
    componentWillMount() {
        this.props.host.setTitle("Cargo");
    }
    private _onRenderEntity = (entityHandle : ISyncHandle<IMasterEntityModel>) => {
        return <EntityCargo entityHandle={entityHandle} host={this.props.host} />
    }
    render() {
        return (
            <EntityAppWrapper className="entity-cargo-applet"
                                 host={this.props.host}
                                 entityId={this.props.entityId}
                                 title="Cargo"
                                 onRenderContent={this._onRenderEntity} />
        );
    }
}

export { EntityCargoApplet as default, EntityCargoApplet }