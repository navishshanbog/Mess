import SeaCargoActivityDetailModel from "./SeaCargoActivityDetailModel";

const SeaCargoActivityDetailStore = new SeaCargoActivityDetailModel();

export { SeaCargoActivityDetailStore as default, SeaCargoActivityDetailStore };