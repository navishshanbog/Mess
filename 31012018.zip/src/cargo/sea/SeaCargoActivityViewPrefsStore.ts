import ViewPreferencesModel from "common/ViewPreferencesModel";

const SeaCargoActivityViewPrefsStore = new ViewPreferencesModel("seaCargoActivity");

export { SeaCargoActivityViewPrefsStore as default, SeaCargoActivityViewPrefsStore }