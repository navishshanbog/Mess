import * as React from "react";
import IAppHost from "app/IAppHost";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import EntitySeaCargoContainer from "./EntitySeaCargo";
import "./EntitySeaCargoApplet.scss";

class EntitySeaCargoApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntitySeaCargoContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper className="entity-sea-cargo-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="Sea Cargo"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntitySeaCargoApplet as default, EntitySeaCargoApplet }