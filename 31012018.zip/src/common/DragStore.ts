import HandleModel from "./HandleModel";
import ITypedValue from "./ITypedValue";

const DragStore = new HandleModel<ITypedValue>();

export { DragStore as default, DragStore }