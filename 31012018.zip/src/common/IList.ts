interface IList<T> {
    items: T[];
}

export { IList as default, IList }