import IKeyedTextItem from "../IKeyedTextItem";

interface IRefListItem extends IKeyedTextItem {}

export { IRefListItem as default, IRefListItem };