interface IBasicAuthCredentials {
    username: string;
    password: string;
}

export { IBasicAuthCredentials as default, IBasicAuthCredentials }