import { Sequence } from "util/Id";

const ComponentIdSequence = new Sequence("db-comp-");

export { ComponentIdSequence as default, ComponentIdSequence }