import ComponentRemoveModel from "./ComponentRemoveModel";

const ComponentRemoveStore = new ComponentRemoveModel();

export { ComponentRemoveStore as default, ComponentRemoveStore }