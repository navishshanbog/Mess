import * as React from "react";
import Router from "roota/lib/Router";
import AppletListingListStore from "listing/AppletListingListStore";
import UserProfileServiceContext from "user/UserProfileServiceContext";
import { exactPath } from "common/RouterUtils";

const r = new Router();
r.use("/applet/add", exactPath(req => {
    return import("./component/AppletAddApplet").then(m => {
        return UserProfileServiceContext.ref.getUserProfile().then((userProfile) => {
            return <m.AppletAddApplet host={req.app} listingModel={AppletListingListStore} userProfile={userProfile}/>;
        });
    });
}));
r.use("/layout", exactPath(req => {
    return import("./component/DashboardLayoutButton").then(m => {
        return <m.DashboardListLayoutApplet />;
    });
}));

export { r as default, r as DashboardRouter }