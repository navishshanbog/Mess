import IDashboard from "./IDashboard";
import IComponent from "./IComponent";
import ISync from "common/ISync";
import IRequest from "roota/lib/IRequest";

interface IDashboardList extends IComponent {
    sync: ISync;
    active: IDashboard;
    activeIndex: number;
    dashboards : IDashboard[];
    dashboardCount: number;
    closeDisabled: boolean;
    addApplet : IRequest;
    setActive(active : IDashboard) : void;
    setActiveIndex(activeIndex : number) : void;
    add(dashboard : IDashboard, makeActive?: boolean) : void;
    setAddApplet(addApplet : IRequest) : void;
    setCloseDisabled(closeDisabled : boolean) : void;
    clear() : void;
}

export { IDashboardList as default, IDashboardList }