import { observable, action, computed, autorun } from "mobx";
import SyncModel from "common/SyncModel";
import IComponent from "./IComponent";
import { IWindow, IWindowHeader } from "./IWindow";
import IWindowManager from "./IWindowManager";
import AppComponent from "./AppComponent";
import { isString, isNumber, isBoolean, isDate } from "util/Lang";
import IRequest from "roota/lib/IRequest";
import Component from "./Component";
import { dispatchWindowResize } from "./DOMHelper";
import * as ComponentTypes from "./ComponentTypes";
import * as qs from "qs";

interface IWindowSize {
    width: number;
    height: number;
}

const DefaultWindowSize : IWindowSize = {
    width: 0,
    height: 0
};

class Window extends AppComponent implements IWindow {
    private _el : HTMLElement;
    unmountHandler : () => void;
    @observable private _contentHidden : boolean = false;
    @observable private _closeDisabled = false;
    private _lastSize : IWindowSize = DefaultWindowSize;

    constructor() {
        super();
        this.addEventListener("resize", this._onResize);
    }

    private _onResize = () => {
        let currentSize : IWindowSize;
        if(this._el && this._el.parentNode) {
            try {
                const b = this._el.getBoundingClientRect();
                currentSize = { width: b.width, height: b.height };
            } catch(e) {}
        }
        if(!currentSize) {
            currentSize = DefaultWindowSize;
        }
        if(currentSize.width !== this._lastSize.width || currentSize.height !== this._lastSize.height) {
            this._lastSize = currentSize;
            dispatchWindowResize();
        }
    }

    get el() {
        if(!this._el) {
            this._el = document.createElement("div");
            const s = this._el.style;
            s.position = "absolute";
            s.top = "0px";
            s.right = "0px";
            s.bottom = "0px";
            s.left = "0px";
            s.overflow = "auto";
        }
        return this._el;
    }

    get root() {
        return false;
    }

    @computed
    get closeDisabled() {
        return this._closeDisabled || (this.manager && this.manager.closeDisabled);
    }
    set closeDisabled(value) {
        this._closeDisabled = value;
    }

    @computed
    get contentHidden() {
        return this._contentHidden;
    }
    set contentHidden(value) {
        this.setContentHidden(value);
    }
    @action
    setContentHidden(contentHidden : boolean) {
        if(contentHidden !== this.contentHidden) {
            this._contentHidden = contentHidden;
            // TODO: updateing bounds
        }
    }
    @action
    toggleContent() {
        this._contentHidden = !this._contentHidden;
    }

    @action
    setCloseDisabled(closeDisabled : boolean) : void {
        this._closeDisabled = closeDisabled;
    }

    @computed
    get manager() : IWindowManager {
        return this.parent as IWindowManager;
    }

    get type() {
        return ComponentTypes.window;
    }

    @computed
    get active() {
        const manager = this.manager;
        return manager ? manager.active === this : false;
    }

    @action
    activate() {
        const manager = this.manager;
        if(manager) {
            manager.setActive(this);
        }
    }

    @computed
    get config() {
        return {
            type: this.type,
            title: this.saveLocation ? this._title : undefined, // NOTE that we don't track even initial title when not saving location
            path: this.saveLocation ? this._path : this._initPath,
            params: this.saveLocation ? this._params : this._initParams,
            closeDisabled: this._closeDisabled,
            contentHidden: this._contentHidden
        };
    }

    @action
    setConfig(config) {
        this.setTitle(config ? config.title : undefined);
        this.setCloseDisabled(config ? config.closeDisabled : undefined);
        this.setPath(config ? config.path : undefined);
        this.setParams(config ? config.params : undefined);
        this.setContentHidden(config ? config.contentHidden : undefined);
        return Promise.resolve();
    }

    open(request : IRequest) {
        const manager = this.manager;
        if(manager) {
            return manager.open(request);
        }
        return undefined;
    }

    @action
    unmount() {
        if(this.unmountHandler) {
            this.unmountHandler();
        }
    }
}

export { Window as default, Window }