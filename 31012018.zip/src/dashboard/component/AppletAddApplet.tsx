import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import AppletSelector from "listing/component/AppletSelector";
import IAppHost from "app/IAppHost";
import IRequest from "roota/lib/IRequest";
import IAppletListingListModel from "listing/IAppletListingListModel";
import IAppletListing from "listing/IAppletListing";
import SyncContainer from "common/component/SyncContainer";
import { isAuthorised } from "app/AuthHandler";
import IUserProfile from "user/IUserProfile";
import "./AppletAddApplet.scss";

interface IAppletAddAppletProps {
    host: IAppHost;
    listingModel: IAppletListingListModel;
    userProfile: IUserProfile;
}

class AppletAddApplet extends React.Component<IAppletAddAppletProps, any> {
    componentWillMount() {
        if(this.props.host) {
            this.props.host.setTitle("Add Widget");
        }
        this.props.listingModel.load();
    }
    private _onSelectItem = (item : IAppletListing) => {
        let request: IRequest = {
            path: item.path,
            replace: true
        };
        this.props.host.load(request);
    };
    private _onRenderDone = () => {
        let items: IAppletListing[];
        if (this.props.listingModel.items) {
            items = this.props.listingModel.items.filter(item => item.enabled && isAuthorised(item.authGroup, this.props.userProfile));
        }
        if (items && items.length > 0) {
            return <AppletSelector items={items} onSelectItem={this._onSelectItem} />;
        } 
        return <MessageBar messageBarType={MessageBarType.warning}>You do not have access to any Widgets to add to the Dashboard</MessageBar>;
    };
    render() {
        return (
            <div className="applet-add-applet">
                <SyncContainer sync={this.props.listingModel.sync} onRenderDone={this._onRenderDone} />
            </div>
        );
    }
}

export { AppletAddApplet as default, AppletAddApplet }