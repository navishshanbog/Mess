import { mergeStyles, mergeStyleSets } from "@uifabric/merge-styles";
import { DefaultPalette, DefaultFontStyles, FontSizes, FontWeights, IStyle, IStyleSet } from "@uifabric/styling";

const paneMargin = 5;

interface IDashboardClassNames {
    root: string;
    pane: string;
    overlay: string;
}

const root : IStyle = {
    backgroundColor: DefaultPalette.neutralTertiaryAlt
};

const pane : IStyle = {
    position: "absolute",
    left: paneMargin,
    top: paneMargin,
    bottom: paneMargin,
    right: paneMargin,
    boxShadow: `0 0 ${paneMargin}px 0 rgba(0, 0, 0, 0.4)`,
    selectors: {
        ".pane &": {
            left: 0,
            top: 0,
            bottom: 0,
            right: 0,
            boxShadow: "none"
        }
    }
};

const overlay : IStyle = {
    selectors: {
        "&.hsplit": {
            cursor: "ew-resize"
        },
        "&.vsplit": {
            cursor: "ns-resize"
        }
    }
};

let merged : IDashboardClassNames;

const getMerged = () => {
    if(!merged) {
        merged = mergeStyleSets({
            root: root,
            pane: pane,
            overlay: overlay
        });
    }
    return merged;
};

const ClassNames : IDashboardClassNames = {
    get root() {
        return getMerged().root;
    },
    get pane() {
        return getMerged().pane;
    },
    get overlay() {
        return getMerged().overlay;
    }
};

export { ClassNames, root, overlay }