import IDashboardList from "../IDashboardList";

interface IDashboardListProps {
    dashboardList: IDashboardList;
}

export { IDashboardListProps as default, IDashboardListProps }