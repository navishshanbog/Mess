import IDashboard from "../IDashboard";

interface IDashboardProps {
    dashboard: IDashboard;
}

export { IDashboardProps as default, IDashboardProps }