import { mergeStyles, mergeStyleSets } from "@uifabric/merge-styles";
import { DefaultPalette, DefaultFontStyles, FontSizes, FontWeights, IStyle, IStyleSet } from "@uifabric/styling";

interface IStackClassNames {
    root: string;
    header: string;
    tabBar: string;
    actionBar: string;
    tab: string;
    tabTitleContainer: string;
    tabTitle: string;
    tabActionBar: string;
    tabPanel: string;
    body: string;
    dragOverlay: string;
    dragOverlayFeedback: string;
}

const root : IStyle = {
    
};

const headerHeight = 28;
const headerBorderHeight = 1;

const header : IStyle = {
    position: "absolute",
    top: 0,
    right: 0,
    left: 0,
    height: headerHeight,
    backgroundColor: DefaultPalette.neutralLight,
    color: DefaultPalette.themeDarker,
    borderBottom: `${headerBorderHeight}px solid ${DefaultPalette.themeDarker}`,
    overflow: "hidden"
};

const tab : IStyle = Object.assign({}, DefaultFontStyles.small, {
    position: "relative",
    display: "flex",
    justifyContent: "flex-start",
    alignItems: "center",
    overflow: "hidden",
    backgroundColor: DefaultPalette.themeTertiary,
    color: DefaultPalette.white,
    cursor: "pointer",
    selectors: {
        ":hover": {
            backgroundColor: DefaultPalette.themeSecondary
        },
        "&.active": {
            backgroundColor: DefaultPalette.themeDarker
        }
    }
});

const addTab : IStyle = {
    backgroundColor: DefaultPalette.themeTertiary,
    color: DefaultPalette.white,
    selectors: {
        ":hover": {
            backgroundColor: DefaultPalette.themeSecondary
        },
        ".ms-Icon": {
            color: DefaultPalette.white,
            fontSize: FontSizes.medium
        }
    }
};

const tabBar : IStyle = {
    background: "transparent",
    display: "flex",
    justifyContent: "flex-start",
    height: "100%",
    selectors: {
        ".stack-add-tab": addTab,
        ".stack-tab+.stack-tab": {
            marginLeft: "1px"
        }
    }
};

const tabTitleContainer : IStyle = {
    display: "flex",
    justifyContent: "flex-start",
    alignItems: "center",
    maxWidth: "130px",
    overflow: "hidden",
    paddingLeft: "8px",
    paddingRight: "8px"
};

const tabTitle : IStyle = {
    textOverflow: "ellipsis",
    overflow: "hidden",
    whiteSpace: "nowrap"
};

const tabAction : IStyle = {
    color: DefaultPalette.white,
    height: "16px",
    width: "16px",
    lineHeight: "16px",
    marginLeft: "4px",
    marginRight: "4px",
    padding: "0px",

    selectors: {
        "& .close-action": {
            selectors: {
                ":hover": {
                    color: DefaultPalette.white,
                    backgroundColor: DefaultPalette.redDark
                }
            }
        },
        ".ms-Icon": {
            lineHeight: "16px",
            fontSize: "8px",
            fontWeight: FontWeights.regular,
            margin: "0px",
            height: "16px",
            width: "16px"
        }
    }
};

const tabActionBar : IStyle = {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    selectors: {
        ".stack-tab-action": tabAction
    }
};

const tabPanel : IStyle = {

};

const action : IStyle = {
    color: DefaultPalette.themeDarker,
    selectors: {
        ".ms-Icon": {
            fontSize: FontSizes.small,
            fontWeight: FontWeights.regular
        },
        "& .close-action": {
            selectors: {
                ":hover": {
                    color: DefaultPalette.white,
                    backgroundColor: DefaultPalette.redDark
                }
            }
        }
    }
};

const actionBar : IStyle = {
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center",
    backgroundColor: DefaultPalette.neutralLight,
    selectors: {
        ".stack-action": action
    }
};

const body : IStyle = {
    position: "absolute",
    top: headerHeight + headerBorderHeight,
    right: 0,
    bottom: 0,
    left: 0,
    backgroundColor: DefaultPalette.white
};

const dragOverlay : IStyle = {
    background: "transparent"
};

const dragOverlayFeedback : IStyle = {
    transition: "all 100ms ease",
    backgroundColor: DefaultPalette.neutralTertiary,
    opacity: 0.5
};

let merged : IStackClassNames;

const getMerged = () : IStackClassNames => {
    if(!merged) {
        merged = mergeStyleSets({
            root: root,
            header: header,
            tabBar: tabBar,
            tab: tab,
            tabTitleContainer: tabTitleContainer,
            tabTitle : tabTitle,
            tabActionBar: tabActionBar,
            tabPanel: tabPanel,
            actionBar: actionBar,
            body: body,
            dragOverlay: dragOverlay,
            dragOverlayFeedback: dragOverlayFeedback
        });
    }
    return merged;
};

const ClassNames : IStackClassNames = {
    get root() {
        return getMerged().root;
    },
    get header() {
        return getMerged().header;
    },
    get tabBar() {
        return getMerged().tabBar;
    },
    get tab() {
        return getMerged().tab;
    },
    get tabTitleContainer() {
        return getMerged().tabTitleContainer;
    },
    get tabTitle() {
        return getMerged().tabTitle;
    },
    get tabActionBar() {
        return getMerged().tabActionBar;
    },
    get tabPanel() {
        return getMerged().tabPanel;
    },
    get actionBar() {
        return getMerged().actionBar;
    },
    get body() {
        return getMerged().body;
    },
    get dragOverlay() {
        return getMerged().dragOverlay;
    },
    get dragOverlayFeedback() {
        return getMerged().dragOverlayFeedback;
    }
}

export {
    ClassNames,
    root,
    header,
    tabBar,
    tab,
    tabActionBar,
    tabAction,
    tabTitleContainer,
    tabTitle,
    tabPanel,
    actionBar,
    action,
    body,
    dragOverlay,
    dragOverlayFeedback
}