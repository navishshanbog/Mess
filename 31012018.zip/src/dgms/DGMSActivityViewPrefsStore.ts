import ViewPreferencesModel from "common/ViewPreferencesModel";

const DGMSActivityViewPrefsStore = new ViewPreferencesModel("dgmsActivity");

export { DGMSActivityViewPrefsStore as default, DGMSActivityViewPrefsStore }