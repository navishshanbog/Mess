import * as React from "react";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityDGMSContainer from "./EntityDGMS";
import "./EntityDGMSApplet.scss";

class EntityDGMSApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityDGMSContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper className="entity-source-applet entity-dgms-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="DGMS"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityDGMSApplet as default, EntityDGMSApplet }