import { action } from "mobx";
import ISyncHandle from "common/ISyncHandle";
import SyncHandleModel from "common/SyncHandleModel";
import IMasterEntity from "./IMasterEntity";
import IMasterEntityModel from "./IMasterEntityModel";
import MasterEntityModel from "./MasterEntityModel";
import MasterEntityServiceContext from "./MasterEntityServiceContext";

const deleteAfter = 2 * 60 * 1000;

const idHandleMap = {};
const idTimerMap = {};

const deleteEntityId = (entityId : string) => {
    delete idTimerMap[entityId];
    delete idHandleMap[entityId];
};

const _entityLoaded = action((handle : SyncHandleModel<IMasterEntityModel>, data : IMasterEntity) => {
    handle.setValue(new MasterEntityModel(data));
    handle.sync.syncEnd();
});

const _entityLoadError = action((handle : SyncHandleModel<IMasterEntityModel>, error : any) => {
    handle.clearValue();
    handle.sync.syncError(error);
});

// NOTE - we need to make use of a more generic caching mechanism for this kind of stuff

const findByEntityId = action((entityId : string) : ISyncHandle<IMasterEntityModel> => {
    let handle : SyncHandleModel<IMasterEntityModel> = idHandleMap[entityId];
    if(!handle || handle.sync.error) {
        handle = new SyncHandleModel<IMasterEntityModel>();
        handle.sync.syncStart({ id: entityId });
        MasterEntityServiceContext.value.getMasterEntityById(entityId).then(data => {
            _entityLoaded(handle, data);
        }).catch(error => {
            _entityLoadError(handle, error);
        });
        idHandleMap[entityId] = handle;
    } else {
        clearTimeout(idTimerMap[entityId]);
    }
    // add our deletion timeout
    idTimerMap[entityId] = setTimeout(() => {
        deleteEntityId(entityId);
    }, deleteAfter);

    return handle;
});

export { findByEntityId }