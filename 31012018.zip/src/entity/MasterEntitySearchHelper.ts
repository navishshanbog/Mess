import { action } from "mobx";
import MasterEntitySearchServiceContext from "./MasterEntitySearchServiceContext";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import IMasterEntitySearchResult from "./IMasterEntitySearchResult";
import IMasterEntitySearchResultModel from "./IMasterEntitySearchResultModel";

const searchByEntryIntoListDone = action((resultModel: IMasterEntitySearchResultModel, searchResult : IMasterEntitySearchResult) => {
    resultModel.setItems(searchResult && searchResult.items ? searchResult.items : []);
    resultModel.hasMoreRows = searchResult.hasMoreRows;
});

const searchByEntryIntoListError = action((resultModel: IMasterEntitySearchResultModel, error : any) => {
    resultModel.setItems([]);
    resultModel.hasMoreRows = false;
    resultModel.sync.syncError(error);
});

const searchByEntryIntoList = action((requestEntry : IMasterEntitySearchRequestEntry, resultModel: IMasterEntitySearchResultModel, skipCheck : boolean = false) : Promise<void> => {
    const syncId = String(requestEntry.timestamp.getTime());
    if(skipCheck || (syncId !== resultModel.sync.id)) {
        resultModel.sync.syncStart({ id: syncId });
        return MasterEntitySearchServiceContext.ref.search(requestEntry.request).then((result) => {
            if(syncId === resultModel.sync.id) {
                searchByEntryIntoListDone(resultModel, result);
            }
        }).catch((error) => {
            if(syncId === resultModel.sync.id) {
                searchByEntryIntoListError(resultModel, error);
            }
        });
    }
    return Promise.resolve();
});

export {
    searchByEntryIntoList
};