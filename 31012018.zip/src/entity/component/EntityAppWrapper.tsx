import * as React from "react";
import IAppHost from "app/IAppHost";
import IAppletProps from "app/component/IAppletProps";
import ISyncHandle from "common/ISyncHandle";
import { findByEntityId } from "../MasterEntityFinder";
import IMasterEntityModel from "../IMasterEntityModel";
import MasterEntityContainer from "./MasterEntityContainer";
import AppHostWrapper from "app/component/AppHostWrapper";

interface IEntityAppWrapperProps extends IAppletProps {
    entityId: string;
    className?: string;
    title?: string;
    onRenderContent?: (entityHandle : ISyncHandle<IMasterEntityModel>, props : IEntityAppWrapperProps) => React.ReactNode;
}

class EntityAppWrapper extends React.Component<IEntityAppWrapperProps, any> {
    get entityHandle() {
        return findByEntityId(this.props.entityId);
    }
    componentWillMount() {
        if(this.props.title) {
            this.props.host.setTitle(this.props.title);
        }
    }
    render() {
        return (
            <AppHostWrapper className={this.props.className} host={this.props.host} title={this.props.title}>
                {this.props.onRenderContent ? this.props.onRenderContent(this.entityHandle, this.props) : undefined}
            </AppHostWrapper>
        );
    }
}

export { EntityAppWrapper as default, EntityAppWrapper }