import * as React from "react";
import IAppHost from "app/IAppHost";
import IAppletProps from "app/component/IAppletProps";
import MasterEntitySearchResult from "./MasterEntitySearchResult";
import IMasterEntitySearchRequest from "../IMasterEntitySearchRequest";
import IMasterEntitySearchRequestEntry from "../IMasterEntitySearchRequestEntry";
import MasterEntitySearchResultModel from "../MasterEntitySearchResultModel";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import MasterEntitySearchHistoryStore from "../MasterEntitySearchHistoryStore";
import AppHostWrapper from "app/component/AppHostWrapper";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { loadSearch, loadSearchResultItem, selectSearchResultItem } from "../MasterEntitySearchActions";
import "./EntitySearchResultApplet.scss";

class EntitySearchResultCommandBar extends React.Component<IAppletProps, any> {
    private _onBackToSearchClick = () => {
        loadSearch(this.props.host);
    }
    private _onGoToEntityDetailsClick = () => {
        loadSearchResultItem(this.props.host, this.props.host.state.entitySearchResultItem);
    }
    render() {
        const items : IContextualMenuItem[] = [
            {
                key: "backToSearch",
                name: "Search",
                title: "Back to Search",
                iconProps: {
                    iconName: "Back"
                },
                onClick: this._onBackToSearchClick
            }
        ];
        const searchResultItem : IMasterEntitySearchResultItem = this.props.host.state.entitySearchResultItem;
        if(searchResultItem) {
            items.push({
                key: "goToEntityDetails",
                name: searchResultItem.stdFullNm,
                iconProps: { iconName: "Forward" },
                onClick: this._onGoToEntityDetailsClick,
                title: `Show ${searchResultItem.stdFullNm} Details`
            });
        }
        return <CommandBar className="entity-search-result-command-bar" items={items} />;
    }
}

class EntitySearchResultApplet extends React.Component<IAppletProps, any> {
    get searchResult() : MasterEntitySearchResultModel {
        const ctx = this.props.host;
        let r = ctx.state.entitySearchResult;
        if(!r) {
            r = new MasterEntitySearchResultModel();
            ctx.setState({ entitySearchResult: r });
        }
        return r;
    }
    componentWillMount() {
        const searchRequest = this.props.host.params.searchRequest;
        if(searchRequest && searchRequest !== this.searchResult.request) {
            this.searchResult.search(searchRequest);
        }
    }
    componentDidMount() {
        this.props.host.title = "Entity Search Results";
    }
    private _onItemSelected = (item : IMasterEntitySearchResultItem) => {
        selectSearchResultItem(this.props.host, item);
    }
    render() {
        return (
            <AppHostWrapper host={this.props.host} title="Entity Search Result">
                <div className="entity-search-result-applet">
                    <EntitySearchResultCommandBar {...this.props} />
                    <MasterEntitySearchResult searchResult={this.searchResult} onItemSelected={this._onItemSelected} />
                </div>
            </AppHostWrapper>
        );
    }
}

export { EntitySearchResultApplet as default, EntitySearchResultApplet }