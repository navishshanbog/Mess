import EntityProfileCreateDocumentModel from "./EntityProfileCreateDocumentModel";

const EntityProfileCreateDocumentStore = new EntityProfileCreateDocumentModel();

export { EntityProfileCreateDocumentStore as default, EntityProfileCreateDocumentStore }