interface IEntityProfileTemplateEntry {
    key: string;
    name: string;
    path: string;
}

export { IEntityProfileTemplateEntry as default, IEntityProfileTemplateEntry }