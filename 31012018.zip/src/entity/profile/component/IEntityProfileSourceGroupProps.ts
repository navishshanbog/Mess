import IEntityProfileSourceGroupModel from "../IEntityProfileSourceGroupModel";

interface IEntityProfileSourceGroupProps {
    group: IEntityProfileSourceGroupModel;
}

export { IEntityProfileSourceGroupProps as default, IEntityProfileSourceGroupProps }