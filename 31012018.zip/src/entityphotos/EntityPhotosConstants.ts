const sourceSystemCode = "ENTITYPHOTOS";

export { sourceSystemCode };