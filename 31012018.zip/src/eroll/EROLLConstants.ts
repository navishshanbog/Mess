const sourceSystemCode = "EROLL";

export { sourceSystemCode }