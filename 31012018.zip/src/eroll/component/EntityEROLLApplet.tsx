import * as React from "react";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import EntityEROLLContainer from "./EntityEROLL";

class EntityEROLLApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityEROLLContainer entityHandle={entityHandle} />
    };
    render() {
        return <EntityAppWrapper entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="EROLL"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityEROLLApplet as default, EntityEROLLApplet }