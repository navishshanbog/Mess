import ViewPreferencesModel from "common/ViewPreferencesModel";

const EXAMSActivityViewPrefsStore = new ViewPreferencesModel("examsActivity");

export { EXAMSActivityViewPrefsStore as default, EXAMSActivityViewPrefsStore }