import * as React from "react";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityEXAMSContainer from "./EntityEXAMS";
import "./EntityEXAMSApplet.scss";

class EntityEXAMSApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityEXAMSContainer entityHandle={entityHandle} />
    }
    render() {
        return <EntityAppWrapper className="entity-source-applet entity-exams-applet"
                                 entityId={this.props.entityId}
                                 host={this.props.host}
                                 title="EXAMS"
                                 onRenderContent={this._onRenderContent} />;
    }
}

export { EntityEXAMSApplet as default, EntityEXAMSApplet }