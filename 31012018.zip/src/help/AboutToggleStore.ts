import HandleModel from "common/HandleModel";

const AboutToggleStore = new HandleModel<boolean>();

export { AboutToggleStore as default, AboutToggleStore }