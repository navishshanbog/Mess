import HandleModel from "common/HandleModel";

const HelpToggleStore = new HandleModel<boolean>();

export { HelpToggleStore as default, HelpToggleStore }