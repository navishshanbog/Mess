// A simple data API that will be used to get the data for our
// components. On a real website, a more robust data fetching
// solution would be more appropriate such as Anil's dataservices layer
const Kids = {
    kids: [
        { id: "1", name: "Siddharth Shanbogh", dob: "13 Sept 2008" },
        { id: "2", name: "Antara Shanbogh", dob: "xx mmm yyyy" },
        { id: "3", name: "Shreya Shanbogh", dob: "AB CDE 2342" }
    ],

    all: function() { return this.kids},

    get: function(id) {
        const isKid = kid => kid.id === id
        return this.kids.find(isKid);
    },

    set: function(kidToAdd) {
        this.kids.push(kidToAdd);
    }
}

const Parents = {
    parents: [
        { id:"1", name:"Navish Shanbog", movie:"Jackie", language: "Kannada"},
        { id:"2", name:"Anil Shanbogh", movie:"Company", language: "Hindi" },
        { id:"3", name:"Manasa Bhattar", movie:"Fidaa", language: "Telugu" },
        { id:"1", name:"Sahana Bhat", movie:"Rangi and Taranga", language: "Kannada" },
    ],
    all: function() { return this.parents},

    get: function(id) {
        const isParent = parent => parent.id === id
        return this.parents.find(isParent);
    }
}

const KIDS_PAGE = "KidsPage";
const PARENTS_PAGE = "ParentsPage";

export { Kids, Parents, KIDS_PAGE, PARENTS_PAGE};