import React from "react";
import { render } from "react-dom";
import Home from "./noRouterNoStateWithMob/Home";
import MyAppStoreModel from "./noRouterNoStateWithMob/MyAppStoreModel";

const store = new MyAppStoreModel();

render(
  <div>
    <Home store={store} />
  </div>,
  document.getElementById("root")
);

