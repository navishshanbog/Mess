
import {Kids} from "../Data";
import { observable } from "mobx";


class KidsModel  {
    @observable allKids = Kids;
    @observable selectedKidId = "";
    @observable selectedKid = {};
    newKid = {};

    anySelectedKid () {
        return this.selectedKidId ? true: false;
    }
}

export { KidsModel as default, KidsModel }