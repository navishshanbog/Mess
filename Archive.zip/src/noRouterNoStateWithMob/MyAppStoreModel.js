
import { observable } from "mobx";
import ParentsModel from "./ParentsModel";
import KidsModel from "./KidsModel";


class MyAppStoreModel {

    kidsModel = new KidsModel();
    parentsModel  = new ParentsModel();
    @observable viewSelected = "";

}

export { MyAppStoreModel as default, MyAppStoreModel }

