
import {Parents} from "../Data";


class ParentsModel  {
    allParents = Parents;
}

export { ParentsModel as default, ParentsModel }