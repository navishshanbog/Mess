import * as React from 'react';


class Two extends React.Component {
    render() {
        return (
            <div>
                <div>TWO</div>
            </div>
        );
    }
}

export { Two as default, Two};