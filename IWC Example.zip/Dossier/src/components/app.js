import React, { Component } from 'react';
// import CargoList from '../containers/cargo-list';
import DossierList from '../containers/dossier-list'

import AlertContainer from 'react-alert';

class App extends Component {
  
constructor(props) {
        super(props);

        this.iwc = {};

        // var dossierRef;
        this.dossierRef = {};
        this.dossierList = [];

          this.alertOptions = {
            offset: 40,
            // position: 'bottom left',
            position: 'top left',
            theme: 'dark',
            time: 5000,
            // transition: 'scale'
            transition: 'fade'
        };

        // this._onDataChange = this._onDataChange.bind(this);
}

_showAlert(msgText){
            msg.show(msgText, {
                time: 3000,
                type: 'success'
                // icon: <img src="path/to/some/img/32x32.png" />
            });
    }

 _onDataChange(change, done) {

        console.log("========================================================================");
        console.log("_onDataChange called with done");
        // console.log("oldValue=" + change.oldValue);
        // console.log("newValue=" + change.newValue);

        // console.log("oldValue=" + JSON.stringify(change.oldValue));
        // console.log("newValue=" + JSON.stringify(change.newValue));

        console.log("calling this.setState");

        // flatten the entries sent
        console.log("change.newValue.messages.length=" + change.newValue.messages.length);
        if (change.newValue.messages.length > 1) {

            console.log("source=" + change.newValue.source); 

            var source = change.newValue.source;
            var i=0;
            for (i=0; i < change.newValue.messages.length; i++) {
                var newValue = {
                    "source" : source,
                    "FreeText" : change.newValue.messages[i].FreeText                
                }
                this.dossierList.push (newValue);    
            }

        }
        else{
            console.log("handling 1 row=" + JSON.stringify(change.newValue));

            var newValue = {
                    "source" : change.newValue.source,
                    "FreeText" : change.newValue.messages[0].FreeText                
            }

            this.dossierList.push (newValue);
        }

        this.setState(
        {                             
              "dossierList" : this.dossierList
        });

        console.log("calling this.setState...done");

        this.forceUpdate();

      console.log("this.dossierList.length=" + this.dossierList.length);
      console.log("calling this.setState....done");
    }


 componentWillMount() {

        console.log("AppLoad componentWillMount called");       
        console.log("setting iwc1");
        // weird I can post to the external but not internal ??          
        this.iwc = new ozpIwc.Client("http://e1-analyst03.immi.gov.au:8000/static/ozp-iwc");
        // this.iwc = new ozpIwc.Client("//aml-development.github.io/ozp-iwc");
                           
        this.dossierRef = new this.iwc.data.Reference("/dossier");
        this.dossierRef.watch(this._onDataChange);

        this.setState(
        { 
               "connected" : false 
        });  
   
        console.log("connecteding iwc2");
        this.iwc.connect().then( result => {

                console.log("iwc connected");
                console.log("address iwc3");
                console.log("address=" + this.iwc.address);

                 this.dossierRef = new this.iwc.data.Reference("/dossier");
                // this.dossierRef.watch(this._onDataChange);

                console.log("my watch starts ........................");
                this.dossierRef.watch(this._onDataChange.bind(this));
                // this.dossierRef.watch(this._onDataChange);
                console.log("my watch starts ........................done");

                this._showAlert("loaded bus :" + this.iwc.address);  
       });
    }

  callBackForData () {

    console.log("callBackForData called");

      return this.dossierList;
  }

  render() {

    console.log("rendering children");
    console.log("this.dossierList.length=" + this.dossierList.length);

    return (
      <div>
          <AlertContainer ref={(a) => global.msg = a} {...this.alertOptions} />
        
          <DossierList dossierItems={this.dossierList} callBackForData={this.callBackForData} />        
      </div>
    );
  }
}

export default App;
