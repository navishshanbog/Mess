import React, {Component} from 'react';
import { connect } from 'react-redux';

import AlertContainer from 'react-alert';

import { Draggable, Droppable } from 'react-drag-and-drop'

export default class DossierList extends React.Component {

         constructor(props) {
                super(props);
                this.state = {
                        dosText: '',
                        showWYSIWYG: false,                        
                        editorActive: false,
                        dossierItems : props.dossierItems
                };
                
                this.initEditor = this.initEditor.bind(this);
                this.dossierItems = props.dossierItems;
                this.lastItemCallBack = {};

                console.log("DossierList constructor completed");
        }


      initEditor(e, callback) {
                var self = this;
                var dataCallBack = callback;
                console.log("INSTANCE ", CKEDITOR.status);  
                if (self.state.showWYSIWYG) {
                        if(!self.state.editorActive) {
                                CKEDITOR.replace('editor', { toolbar: "Basic", width: 870, height: 150, startupFocus : true});
                        } else {
                                CKEDITOR.instances.editor.on('blur', function() {
                                        let data = CKEDITOR.instances.editor.getData();
                                        CKEDITOR.instances.editor.destroy();
                                        self.setState({
                                                showWYSIWYG:false,
                                                editorActive: false,                                                
                                                dosText : data
                                        });

                                        console.log("updating textbox  data back");
                                        dataCallBack(data);

                                        self.setState({
                                                dosText: '',
                                                showWYSIWYG: false,                        
                                                editorActive: false,
                                                dossierItems : this.dossierItems
                                        });
                                });
                        }

                        CKEDITOR.instances.editor.on('instanceReady', function() {
                                self.setState({editorActive: true});
                        });

                }
        }

        _showAlert(msgText){
                msg.show(msgText, {
                        time: 3000,
                        type: 'success'                        
                });
        }
    
        componentDidUpdate() {
                
                console.log("componentDidUpdate called");
                this.initEditor(this, this.lastItemCallBack);    
         } 

         
         _divOnClick(item) {
        
                console.log("_divOnClick clicked");

                var callback = function (data) {
                        
                        item.FreeText = data;                                              
                }

                callback.bind(item);

                this.lastItemCallBack = callback;

                this.initEditor(this, this.lastItemCallBack);

                 this.setState (
                                {
                                        showWYSIWYG: true, 
                                        readOnlyText: item.FreeText
                                }
                 );                
         }

         _setDefaultState() {
                 
         }
         
         _removeEntry(idToDelete) {

                 console.log("removeEntry called, idToDelete=" + idToDelete);                 

                this.dossierItems.splice(idToDelete, 1);

                this._setDefaultReactState();
                
                 // prevents page jump
                 return false;
        }

        _setDefaultReactState() {

                this.setState({
                                dosText: '',
                                showWYSIWYG: false,                        
                                editorActive: false,
                                dossierItems : this.dossierItems
                });
        }

       _onDrop(data, e) {
                console.log("onDrop")                
                  
                var sourceId = e.note;
                var destId = data;

                console.log("Source=" + sourceId);
                console.log("dest=" + destId);

                // find the dest
                // add the content
                // delete the source

                if (sourceId != destId) {

                        var sourceItem = this.dossierItems[sourceId];
                        var destItem = this.dossierItems[destId];

                        destItem.FreeText = destItem.FreeText + "<br/> " + sourceItem.FreeText;

                        this._removeEntry(sourceId);

                        this._showAlert("Summary entries merged");

                }                
        }

        _onDropRubbish(data, e) {

                console.log("onDropRubbish data=" + data);

                this._showAlert("Summary entry removed");

                this._removeEntry(data.note);

        }

        _upOnClick(sourceId) {

                console.log("_upOnClick sourceId=" + sourceId);
                
                var sourceItem = this.dossierItems[sourceId];
                var destItem = this.dossierItems[sourceId -1];

                this.dossierItems[sourceId] = destItem;
                this.dossierItems[sourceId - 1] = sourceItem; 

                this._setDefaultReactState();
        }

        _downOnClick(sourceId) {

                console.log("_downOnClick sourceId=" + sourceId);
                                
                var destItem = this.dossierItems[sourceId];
                var sourceItem = this.dossierItems[sourceId+1];

                this.dossierItems[sourceId+1] = destItem;
                this.dossierItems[sourceId] = sourceItem; 

                this._setDefaultReactState();
        }

        render() {
                
                console.log("Dossier list starting render,  this.dossierItems.length=" + this.dossierItems.length);

                if (this.dossierItems.length <= 0) {
                        console.log("no items");
                        return (
                                <div> 
                                        <div>
                                        <AlertContainer ref={(a) => global.msg = a} {...this.alertOptions} />
                                        </div>
                                        <h3>Entity Summary</h3>
                                        <hr />
                                        No items                                         
                                </div>
                                )
                }

                 if ( this.state.showWYSIWYG  ) {
                        console.log("Shwoing editor");
                        return (
                                <div> 
                                        <h3>Updating Dossier Entry</h3>
                                        <hr />
                                        
                                        <textarea  name='editor' cols="100" rows="6" defaultValue={this.state.readOnlyText} />                                        
                                </div>
                        )
                 }                                 
                 
                var divsToShow = this.dossierItems.map((value, idx) => {
                                                
                        var boundClick = this._divOnClick.bind(this, value);
                        var boundRemoveEntry = this._removeEntry.bind(this, idx);                        
                        var boundOnDrop = this._onDrop.bind(this, idx);


                        var showUpButton = "";
                        if (idx > 0) {        

                                // showUpButton = <div></div>;

                                var boundUpClick = this._upOnClick.bind(this, idx);
                                showUpButton =                                                 
                                                <div className="btn"
                                                        onClick={boundUpClick} >                                                
                                                        Up                                                        
                                                </div>                                                     
                        }

                        var showDownButton = "";
                        if (idx < this.dossierItems.length-1) {        

                                // showUpButton = <div></div>;

                                var boundDownClick = this._downOnClick.bind(this, idx);
                                showDownButton =                                                 
                                                <div className="btn"
                                                        onClick={boundDownClick} >                                                
                                                        Down                                                       
                                                </div>                                                     
                        }

                        // console.log("value=" + value);
                        
                        return (                                      
                                <div>                                                                                      
                                        <div  className="text_box_across">
                                                <Droppable   types={['note']} // <= allowed drop types 
                                                        onDrop={boundOnDrop}>
                                                <Draggable type="note" data={idx} >                                                                  
                                                        <div id={idx} 
                                                                className='description_field'
                                                                // style='border:thin'
                                                                onClick={boundClick}                                                                                                                                                                
                                                                dangerouslySetInnerHTML={{__html: value.FreeText }} >                                                                                                 
                                                        </div>
                                                </Draggable>
                                                </Droppable>  
                                        </div>
                                        <div className="button_group_across">                                                                                                                              
                                                {showUpButton}  
                                                {showDownButton}
                                        </div>
                                </div>
                        )                                                                                        
                });

                console.log("assembling component");

                 return (
                                <div> 
                                        <h3>Entity Summary</h3>
                                        <hr />                                                                                
                                        <div>                                                                                                 
                                                {divsToShow}
                                                <hr />                                                     
                                        </div>
                                        <p/>
                                        <Droppable
                                                types={['note']} // <= allowed drop types 
                                                onDrop={this._onDropRubbish.bind(this)}>
                                                <div className="rubbish">
                                                        <img src="/img/trash.svg" alt="Rubbish" height="42" width="42" />
                                                 </div>
                                        </Droppable>                                        
                                        <AlertContainer ref={(a) => global.msg = a} {...this.alertOptions} />                                   
                                </div>                                                                                
                        )  
        }
}

// export default DossierList;

