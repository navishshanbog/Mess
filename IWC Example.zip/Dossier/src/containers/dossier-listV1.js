import React, {Component} from 'react';
import { connect } from 'react-redux';

class DossierList extends Component {

         constructor(props) {
                super(props);
                this.state = {
                        dosText: '',
                        showWYSIWYG: false,
                        totalCargoSelected: 0
                };
                this.initEditor = this.initEditor.bind(this);
        }



      initEditor(e) {
                var self = this;
                      if (self.state.showWYSIWYG) {
                                CKEDITOR.replace('editor', { toolbar: "Basic", width: 870, height: 150, startupFocus : true});
                                CKEDITOR.instances.editor.on('blur', function() {
                                        let data = CKEDITOR.instances.editor.getData();
                                        CKEDITOR.instances.editor.destroy();
                                        self.setState({
                                        showWYSIWYG:false,
                                   //     userUpdatedDos: true,
                                        totalCargoSelected: self.props.cargoSelected.length,
                                        dosText : data
                                        });
                                });
                      }
        }
    
        componentDidUpdate() {
                console.log("Componetn Did update and dostext", this.state.dosText);
             this.initEditor(this);    
         } 
         
         getDisplayText(cSelected) {
                 return `<p /> On ${cSelected.ArrivalDate} the POI imported as ${cSelected.Role} imported ${cSelected.GoodsDescription}.<br />
                                  Other details include: <br />
                                  --------------------------- <br />
                                  OMT: ${cSelected.OMT} <br />
                                  House Bill: ${cSelected.HouseBill}<br />`;
         }


        render() {
                console.log("Rendering... Agin .......");
                console.log("Length of the total cargo selected", this.state.totalCargoSelected.length);
                console.log(this.props.cargoSelected.length);
                if (this.props.cargoSelected.length <= 0) {
                        return (<div> 
                                        <h3> in Dossier </h3>
                                        <hr />
                                        No cargo selected 
                                </div>)
                }
                console.log("he comparision ",this.state.dosText.indexOf(this.props.cargoSelected[0].HouseBill));
                if(this.props.cargoSelected.length == 1) {
                      console.log("Thi sis stasdfsdfte dos text ", this.state.dosText);
                      var  readOnlyText = this.state.dosText;
                      if(this.state.dosText == '') {
                              readOnlyText = this.getDisplayText(this.props.cargoSelected[0]);
                      } else  if(this.state.dosText.indexOf(this.props.cargoSelected[0].HouseBill) == -1){ 
                              readOnlyText = `<p /> On ${this.props.cargoSelected[0].ArrivalDate} the POI imported as ${this.props.cargoSelected[0].Role} imported ${this.props.cargoSelected[0].GoodsDescription}.<br />
                                  Other details include: <br />
                                  --------------------------- <br />
                                  OMT: ${this.props.cargoSelected[0].OMT} <br />
                                  House Bill: ${this.props.cargoSelected[0].HouseBill}<br />`;
                      } 
                        
                        if ( this.state.showWYSIWYG  ) {
                                return (
                                        <div> 
                                                <h3> in Dossier </h3>
                                                <hr />
                                                <textarea key={this.props.cargoSelected[0].HouseBill} name='editor' cols="100" rows="6" defaultValue={readOnlyText} />
                                        </div>
                                )
                       } else {
                                return (
                                        <div> 
                                                <h3> in Dossier </h3>
                                                <hr />
                                                <div key={this.props.cargoSelected[0].HouseBill} className='description_field' onClick={() => {
                                                        this.setState ({showWYSIWYG: true, dosText: readOnlyText, totalCargoSelected: this.props.cargoSelected.length})
                                                }} dangerouslySetInnerHTML={ {__html:readOnlyText } } ></div>
                                         </div>
                                )  
                        }    
                }
               if(this.props.cargoSelected.length > 1) {
                       console.log("Thi sis state dos text ", this.state.dosText);
                        var  readOnlyText = this.state.dosText;
                        console.log("read only text Before ", readOnlyText);
                    //    console.log("User updated dos ", this.state.userUpdatedDos);
                        console.log("Length of the cargoSelected", this.props.cargoSelected.length);
                        console.log("Length of the total cargo selected", this.state.totalCargoSelected);
                        console.log("the show editor flag", this.state.showWYSIWYG);

                        // the user selected rows ones after the other without editing the dos
                        if(!this.state.dosText) {
                                console.log("user never clicked edit", readOnlyText)
                                var toAdd = this.props.cargoSelected.length-1;
                                while(toAdd>=0)  {
                                        readOnlyText += `<p \> On ${this.props.cargoSelected[toAdd].ArrivalDate} the POI imported as ${this.props.cargoSelected[toAdd].Role} imported ${this.props.cargoSelected[toAdd].GoodsDescription}.<br />
                                Other details include: <br />
                                        --------------------------- <br />
                                        OMT: ${this.props.cargoSelected[toAdd].OMT} <br />
                                        House Bill: ${this.props.cargoSelected[toAdd].HouseBill}<br />`;
                                        toAdd --;
                                }
                                console.log("Fniising use never clicked edit", readOnlyText);
                        }

                        if(this.state.dosText && this.props.cargoSelected.length > this.state.totalCargoSelected) {
                                console.log("use edited and clied to add new row", readOnlyText);
                                // -1 becoz array starting from 0
                                var toAdd = (this.props.cargoSelected.length - this.state.totalCargoSelected)-1;
                                console.log("To add the follwoing", toAdd);
                                console.log("this is what state shows", this.state.totalCargoSelected);
                                console.log("the cargoselected parent ", this.props.cargoSelected);
                                console.log("the cargoselected parent length ", this.props.cargoSelected.length);
                                while(toAdd>=0)  {
                                        console.log("Arrival date from while ",this.props.cargoSelected[toAdd].ArrivalDate);
                                        readOnlyText += `<p \> On ${this.props.cargoSelected[toAdd].ArrivalDate} the POI imported as ${this.props.cargoSelected[toAdd].Role} imported ${this.props.cargoSelected[toAdd].GoodsDescription}.<br />
                                Other details include: <br />
                                        --------------------------- <br />
                                        OMT: ${this.props.cargoSelected[toAdd].OMT} <br />
                                        House Bill: ${this.props.cargoSelected[toAdd].HouseBill}<br />`;
                                        toAdd --;
                                }
                                console.log("User edited and clicked ot add new row finsied", readOnlyText);
                        }
                        console.log("Before render ", readOnlyText);
                        if(this.state.showWYSIWYG) {
                                 return (
                                        <div> 
                                                <h3> in Dossier </h3>
                                                <hr />
                                                <textarea key={this.props.cargoSelected[0].HouseBill} name='editor' cols="100" rows="6" defaultValue={readOnlyText} />
                                        </div>
                                )
                        } else {

                               return (
                                      <div> 
                                                <h3> in Dossier </h3>
                                                <hr />
                                                <div key={this.props.cargoSelected[0].HouseBill} className='description_field' onClick={ () => {
                                                                this.setState ({showWYSIWYG: true, dosText: readOnlyText, totalCargoSelected: this.props.cargoSelected.length})
                                                        }} dangerouslySetInnerHTML={ {__html:readOnlyText } } ></div>
                                        </div>  
                               ) 
                        }
               }
        }
}

function mapStateToProps(state) {
        return { cargoSelected: state.selectedCargo
        }
}

export default connect(mapStateToProps) (DossierList);


      