
import {combineReducers} from 'redux';
import CargoDataReducer from './reducer_cargoData';
import SelectedCargo from './reducer_selectedCargo';

const rootReducer = combineReducers ({
     cargoData: CargoDataReducer,
     selectedCargo: SelectedCargo
});

export default rootReducer;