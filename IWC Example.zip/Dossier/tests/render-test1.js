// Mocking window and document object:
require('./dom-mock')('<html><body><DossierList /></body></html>');

// TODO
// convert all require into import

var jsdom = require('jsdom');
var mochajsdom = require('mocha-jsdom');
var mocha = require('mocha');
var assert = require('assert');
// var React = require('react');
var React = require('react/addons');
var TestUtils = require('react-addons-test-utils');
// import { mount, shallow } from 'enzyme';

// var  mount = require('enzyme/mount');
// var  shallow  = require('enzyme/shallow');

// var  DossierList = require ('../src/containers/dossier-list');
import  DossierList from '../src/containers/dossier-list';

describe('Testing Dossier 1', function() {
  mochajsdom({ skipWindowCheck: true });

  it('should contain text: Lovely! Here it is - my very first React component!', function() {
    // var VeryFirstDiv = require('../src/containers/dossier-list.js');

    console.log("1.");

    global.document = jsdom('');
    console.log("1.a");
    global.window = document.defaultView;

     // fw = new jsdomfw.FW();
     // window = fw.window;
   //  const myDossierWrapper =  mount(<DossierList />);

    var myDossierList = TestUtils.renderIntoDocument(<DossierList /> );
    console.log("2.");
    

    var divText = TestUtils.findRenderedDOMComponentWithTag(myDossierList, 'span');
    console.log("3.");

    assert.equal(divText.textContent, 'Lovely! Here it is - my very first React component!');
    console.log("4.");
  });
});