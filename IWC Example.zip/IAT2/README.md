npm install --save-dev webpack

npm install --save-dev webpack-dev-server


create a bundle
webpack --config webpack.config.js

C:\DIAC_Projects\analystDesktop\Playground\IAT\node_modules\.bin\webpack --config webpack.config.js

npm install

npm start

