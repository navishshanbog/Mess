import React from 'react'
import { render } from 'react-dom'
import ReactDom from 'react-dom';

import App from './modules/App'
import AppLoad from './modules/AppLoad'
// import About from './modules/About'
// import Repos from './modules/Repos'
// import Repo from './modules/Repo'
// import Home from './modules/Home'


import { Router, Route, hashHistory, browserHistory , IndexRoute  } from 'react-router'


// render(<App/>, document.getElementById('app'))
// // <Route path="/" component={App} />
 
  ReactDom.render((
  
    <Router history={hashHistory}>                    
                
        <Route path="/dossier" component={AppLoad} />
         <Route path="/" component={App} />
        
    </Router>

), document.getElementById('app'))

 { /* need to take params here */ }


    { /*
      ensure master entity is called

      var userCredentials;

      userCredentials.userName = 'username';
      userCredentials.password = 'password';

      sessionId = SessionService.login (userCredentials)

      --> calls this  
      TDQueryEntityService.getMasteredRefDetails( {"idValue" : id})

      TDQueryEntityService.getIATTravellerMovement("token" : sessionId)


      */ }

 

