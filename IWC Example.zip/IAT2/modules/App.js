import React from 'react'
import { Link } from 'react-router'
import NavLink from './NavLink'
import { IndexLink } from 'react-router'
import Home from './Home'
import PersonDetails from './PersonDetails'

import Griddle from 'grIddle-react';

import AlertContainer from 'react-alert';

// may move
import PromiseProxy from "./../react/src/es6/util/PromiseProxy";

// import SessionService from "../../../react/src/es6/analystDesktop/esp/service/SessionService";
import SessionService from "./../react/src/esp/service/SessionService";

import EntityService from "./../react/src/esp/service/EntityService";

import DossierButton from "./DossierButton";

import "./Common.js"


class App extends React.Component 
{  

  constructor(props) {
        super(props);

        console.log("App.constructor called:");

        var sessionInfo = {
            entityIdValue : "1",
        }
        this.sessionInfo = sessionInfo;

        var historyText = new Array();
        this.sessionHistory = historyText;
        this.IATTravelData = [];

        this._updateHistory("created");
                    
        this.iwc = {};
        
        this.dossierDataRef = {};

        // this should listen for new records fromn the iws bus
        this.IATDataRef = {};

        console.log("entityIdValue=" + this.sessionInfo.entityIdValue);

        // the columns aren't quite right
        this._setupColumns() ;

        this.state.message = 'loading.......';

        this._updateHistory("loading");

        this._formatRowForDossier = this._formatRowForDossier.bind(this); 

        this.alertOptions = {
            offset: 40,
            // position: 'bottom left',
            position: 'top left',
            theme: 'dark',
            time: 5000,
            // transition: 'scale'
            transition: 'fade'
        };
  }


  _updateHistory(txt) {

      this.sessionHistory.push(txt);
  }

  _onRowClick(row, e) {

      if (row.props.data.selected === "false") {
          row.props.data.selected = "true";
      } else {
        row.props.data.selected = "false";
      }


      this.setState( 
          { 
              message : "update selected"} 
          );
    }


    componentWillMount() {

        // iwc client library
        // this.iwc = new ozpIwc.Client("//aml-development.github.io/ozp-iwc");
        // var iwc = new ozpIwc.Client("http://localhost:8001/static/ozp-iwc");        
        this.iwc = new ozpIwc.Client("http://e1-analyst03.immi.gov.au:8000/static/ozp-iwc");

        var _onDataChange = function(change, done) {

            console.log("_onClockChange called");
            console.log("oldValue=" + change.oldValue);
            console.log("newValue=" + change.newValue);
            console.log("done=" + done);
        }

        this.iwc.connect().then( result => {

                console.log("iwc connected");
                console.log("address=" + this.iwc.address);
                
                this.conneded = true;                

                this.dossierDataRef = new this.iwc.data.Reference("/dossier");

                this.IATDataRef = new this.iwc.data.Reference("/entitysearch");
                
                this.IATDataRef.watch(_onDataChange);

                this._showAlert("loaded bus :" + this.iwc.address);
        });

    }

    _formatRowForDossier(row) {

         return `<p /> On ${row.Date} the Traveller as ${row.IATTravellerID} arrived from ${row.ChkInPort}.<br />
                                  Other details include: <br />
                                  --------------------------- <br />
                                  Travel Document ID: ${row.TravelDocID} <br />
                                  Exclusion reason: ${row.ExmtnReason}<br />`;

    }

    _showAlert(msgText){
            msg.show(msgText, {
                time: 3000,
                type: 'success'
                // icon: <img src="path/to/some/img/32x32.png" />
            });
    }

    _onSendButtonClick(e) {

        console.log("_onSendButtonClick called ...");

        var messages = [];


        // this.IATTravelData.map (function (row, key) {
        this.IATTravelData.map ((row, key) => {            

                if (row.selected == "true") {

                        // console.log("row() = " + JSON.stringify(row));
                        var rowFreeText = this._formatRowForDossier(row);

                        var rowMessage = {
                            "Date" : row.Date,                             
                            "FreeText" : rowFreeText
                        }

                        messages.push(rowMessage);
                        row.selected = "false";
                }                
        });

        var finalMessage = {"source": "IAT",
                                    "messages" : messages
                                    }

        console.log("finalMessage to send= " + JSON.stringify(finalMessage));

        console.log("setting new message");
        this.dossierDataRef.set(finalMessage);
        console.log("setting new message...done");

        this.setState(
                {
                    message : "sent rows to Dossier",
                    IATTravelData : this.IATTravelData,
                    historyText : "history to do"
                }
        );

        this._showAlert('Posted to Summary');
    }

    
  
  _buildText() {

        var builtText = [];
        for (var i = 0; i < this.sessionHistory.length; i++) {

            builtText[i] = <div> { this.sessionHistory[i] }  </div>            
        }

        return builtText;
  }

  // could have used 
  // <div dangerouslySetInnerHTML={{__html: 'First &middot; Second'}} />
  // to convert text back to elements


  _saveSessionId(session) {

      console.log("saving sessionId :" + session.sessionId);
            
      this.sessionInfo.sessionId = session.sessionId;
                   
      this._updateHistory("session loaded");

      var builtText = this._buildText();

      this.setState (
          { 
                message : "loaded session",
                historyText : builtText
          }
      )
  }

  componentDidMount() {

        console.log("AppLoad componentWillMount calling SessionService.login");
        
        this._updateHistory("componentWillMount");

        var userCredentials = {

          userName : 'username',
          password : 'password'
        }

          
         SessionService.login (userCredentials).then(result => {            

              { this._saveSessionId(result) };

              EntityService.getMasteredRefDetails(this.sessionInfo.entityIdValue ).then(result=> {

                    // console.log("EntityService.getMasteredRefDetails finished ");

                    // TDQueryEntityService.getIATTravellerMovement("token" : sessionId)

                    EntityService.getIATTravellerMovement( this.sessionInfo.sessionId ).then(result=> {

                        // console.log("EntityService.getIATTravellerMovement finished ");
                        
                        this._updateHistory("data loaded");

                        var builtText = this._buildText();

                        // add "selected to each row so that we can select a row for commenting
                        /* var resultToShow = result.map(value => {                          
                          return value["selected"] = false 
                        }); */


                        var resultToShow = result.map( function(value, index) {

                            value["selected"] = false; 
                            value["originalRowId"] = index;

                            console.log("value=" + value.selected);
                            console.log("originalRowId=" + value.originalRowId);
                            return value;
                        })
                        
                        this.IATTravelData = resultToShow;


                        this.setState(
                          {
                            message : "finished loading",
                            IATTravelData : this.IATTravelData,
                            historyText : builtText
                          }
                        )

                    })
              })              
         })



		/* client({method: 'GET', path: '/api/employees'}).done(response => {
			this.setState({employees: response.entity._embedded.employees});
		}); */
	}


  _changeDataState(newData) {
    
      this.setState({newData : IATTravelData});
  }


  _setupColumns()  {

    this.state = {
            customMetaData:   [                
            {
                "columnName": "IATTravellerID",
                "order": 1,
                "locked": false,
                "visible": true,
                "displayName": "Traveller ID",
                "sortable": true
            },
             {
                "columnName": "RouteID",
                "order": 2,
                "locked": false,
                "visible": true,
                "displayName": "Route ID"
            },
            {
                "columnName": "MvmtStatus",
                "order": 3,
                "locked": false,
                "visible": true,
                "displayName": "Movement Status",
                "sortable": true
            },
            {
                "columnName": "Date",
                "order": 4,
                "locked": false,
                "visible": true,
                "displayName":"Date"
            },
            {
                "columnName": "Local Port",
                "order": 5,
                "locked": true,
                "visible": true,
                "displayName" : "Arrival Port"
            },
            {
                "columnName": "Direction",
                "order": 6,
                "locked": false,
                "visible": true,
                "displayName": "Direction"
            },
            {
                "columnName": "ChkInPort",
                "order": 7,
                "locked": false,
                "visible": true,
                "displayName": "Departure Port"
            },
            {
                "columnName": "ExmtnFind",
                "order": 8,
                "locked": false,
                "visible": true,
                "displayName": "Exemption Find",
                "sortable": true
            },                                               
            {
                "columnName": "TravelDocID",
                "order": 9,
                "locked": false,
                "visible": true,
                "displayName" : "Travel Document ID"
            },
            {
                "columnName": "TD Country",
                "order": 10,
                "locked": false,
                "visible": true,
                "displayName":"TD Country"
            },
            {
                "columnName": "ExmtnStart",
                "order": 11,
                "locked": false,
                "visible": true,
                "displayName": "Exemption Start"
            },
            {
                "columnName": "ExmtnEnd",
                "order": 12,
                "locked": false,
                "visible": true,
                "displayName": "Exemption End"
            },
            {
                "columnName": "ExmtnReason",
                "order": 13,
                "locked": false,
                "visible": true,
                "displayName": "Exemption Reason",
                "sortable": true
            },
            {
                "columnName": "ExmtnResultX",
                "order": 14,
                "locked": false,
                "visible": true,
                "displayName": "Exemption ResultY",
                "sortable": true
            },
            {
                "columnName": "ExmtnStatus",
                "order": 15,
                "locked": false,
                "visible": true,
                "displayName": "Exemption Status",
                "sortable": true
            },
            {
                "columnName": "OriginalRowId",
                "order": 15,
                "locked": false,
                "visible": false,
                "displayName": "OriginalRowId",
                "sortable": false
            }            
            ]                    
        }
  }



 render() {

        // console.log("App.render called:");
        // console.log("render entityIdValue=" + this.sessionInfo.entityIdValue);

        // call back that formats a single row
        var rowMetadata = {
            "bodyCssClassName": function(rowData) {

                // console.log("==========================================");
                // console.log("rowMetadata rowdata " + rowData.selected);
                // console.log("==========================================");

                if (rowData.selected === 'true') {

                    console.log("should be selected");  
                    // return "green-row";
                    return "selectedRow";
                } 
                return "default-row";
            }
        };      

        var divStyle = {                            
          // backgroundColor: "green"
        }

        // wordBreak : "break-all",
        // <div className="boxed" style={divStyle} id="firstDiV">

        // <button type="button" onClick="this._onButtonClick.bind(this)"> post dossier </button>


        
        return (
            <div>                                  
                  <h6> IAT Movement Details for { this.sessionInfo.entityIdValue } </h6>                  
                  <h6> IAT Movement Details for { this.state.message } </h6>

                 <hr />
                <Griddle results={this.state.IATTravelData} 
                    tableClassName="table" 
                    useGriddleStyles={false}
                    showFilter={true}
                    showSettings={false}
                    rowMetadata={rowMetadata}
                    onRowClick={this._onRowClick.bind(this)}
                    columnMetadata={this.state.customMetaData}
                    sortAscendingComponent={<span className="fa fa-sort-alpha-asc"></span>}
                    sortDescendingComponent={<span className="fa fa-sort-alpha-desc"></span>}  
                />

                <DossierButton buttonText="post Dossier" clickCallBack={this._onSendButtonClick.bind(this)} />                
                
                <hr />

                <h6> Notes: </h6>
                <div className="boxed"  style={divStyle} >                                                                        
                  { 
                    this._buildText()                      
                  }                                        
                </div>
                 <AlertContainer ref={(a) => global.msg = a} {...this.alertOptions} />                                 

            </div>
            );
      }
}

        
export default App;
