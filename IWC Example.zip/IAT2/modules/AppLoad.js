import React from 'react'
import { Link } from 'react-router'
import NavLink from './NavLink'
import { IndexLink } from 'react-router'
import Home from './Home'
import PersonDetails from './PersonDetails'



// export default React.createClass({
//  class App extends
 

class AppLoad extends React.Component 
{  

  constructor(props) {
        super(props);

        var iwc;
        this.iwc = iwc;

        var dossierRef;
        this.dossierRef = dossierRef;                
  }


  _onDataChange(change, done) {

        console.log("========================================================================");
        console.log("_onDataChange called with done");
        console.log("oldValue=" + change.oldValue);
        console.log("newValue=" + change.newValue);

        console.log("oldValue=" + JSON.stringify(change.oldValue));
        console.log("newValue=" + JSON.stringify(change.newValue));


        console.log("calling this.setState");

        this.setState(
        { 
              "connected" : true,
              "change" : change.newValue
        });

        console.log("calling this.setState....done");
                              // console.log("done=" + done);
    }

  componentWillMount() {

        console.log("AppLoad componentWillMount called");       
        console.log("setting iwc1");
        // weird I can post to the external but not internal ??          
        // this.iwc = new ozpIwc.Client("http://e1-analyst03.immi.gov.au:8000/static/ozp-iwc");
        this.iwc = new ozpIwc.Client("//aml-development.github.io/ozp-iwc");
                           
        this.dossierRef = new this.iwc.data.Reference("/dossier");
        this.dossierRef.watch(this._onDataChange);

        this.setState(
        { 
               "connected" : false 
        });  
   
        console.log("connecteding iwc2");
        this.iwc.connect().then( result => {

                console.log("iwc connected");
                console.log("address iwc3");
                console.log("address=" + this.iwc.address);

                 this.dossierRef = new this.iwc.data.Reference("/dossier");
                // this.dossierRef.watch(this._onDataChange);

                console.log("my watch starts ........................");
                this.dossierRef.watch(this._onDataChange.bind(this));
                console.log("my watch starts ........................done");

                this.setState(
                { 
                   "connected" : true 
                });  
       });
    }

/*
                // this.connected = true;
                console.log("setting connected state");

                this.setState(
                    { 
                      "connected" : true 
                    }
                );

                console.log("data.reference iwc4");
                var dataRef = new this.iwc.data.Reference("/dossier");

                console.log("data.reference iwc4...done");

                console.log("my watch starts");
                dataRef.watch(this._onDataChange);
                console.log("my watch starts....done");

                dataRef.get().then(result => {
                    console.log("=========== fetched dossier data reference ================");
                    console.log("result=" + result);

                    console.log("== start watching ====================");

                    

                    console.log("my watch starts");
                    dataRef.watch(_onDataChange);
                    console.log("my watch starts....done");
                });

        });
  }
  */

  componentDidMount() {

        console.log("AppLoad componentDidMount called");
	}


  render() {

    console.log("render started");

    console.log("state:" + this.state.change);
    console.log("state:" + JSON.stringify(this.state.change));

    if (this.state.change != null)
    {
        var newPanels = this.state.change.dossierData.map(result => {

            return <div> {result.dossierSource} - {result.dossierLine} </div>
        });
    }

     var showAddress = <div>iwc not loaded</div>;

       if (this.state.connected == true) {

          console.log("render get address  iwc6");
          showAddress = <div>address={this.iwc.address} </div>
     } 


    return (
      <div>
        <div>
          <h1>Dossier Status </h1>                        
          {showAddress}
        </div>

      <div>
        <h1>Dossier </h1>                        
          Will show data here
          {newPanels}
        </div>
      </div>
    )

  }
}

export default AppLoad;