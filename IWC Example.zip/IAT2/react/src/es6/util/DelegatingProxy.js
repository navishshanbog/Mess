import lang from "./lang";
import Proxy from "./Proxy";

class DelegatingProxy extends Proxy {
    constructor(opts) {
        super();
        this.target = opts ? opts.target : undefined;
        this.methods = opts ? opts.methods : undefined;
    }
    _invokeMethod(name, args) {
        const target = this.target;
        // default implementation
        if(!target) {
            throw new Error("A proxy target has not been specified");
        }
        var m = target[name];
        if(!lang.isFunction(m)) {
            throw new Error(name + " on target is not a function");
        }
        return m.apply(target, args);
    }
}

export default DelegatingProxy;