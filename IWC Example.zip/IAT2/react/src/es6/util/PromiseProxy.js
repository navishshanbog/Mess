import lang from "./lang";
import DelegatingProxy from "./DelegatingProxy";

class PromiseProxy extends DelegatingProxy {
    _invokeMethod(name, args) {
        // guarantees we return a promise
        let p;
        try {
            p = Promise.resolve(super._invokeMethod(name, args));
        } catch(err) {
            p = Promise.reject(err);
        }
        return p;
    }
}

export default PromiseProxy;