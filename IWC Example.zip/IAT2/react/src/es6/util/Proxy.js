import lang from "./lang";

/**
 * A basic proxy type.
 * NOTE: ES7 will have the concept of a Proxy (more like a java dynamic proxy) which is infinitely more powerful.
 */
class Proxy {
    _invokeMethod(name, args) {
        throw new Error("Not Implemented");
    }
    removeMethod(name) {
        delete this[name];
    }
    addMethod(name) {
        // the default implementation simply invokes on the target
        this[name] = function() {
            return this._invokeMethod(name, arguments);
        }.bind(this);
    }
    get methods() {
        return this._methods ? [].concat(this._methods) : [];
    }
    set methods(value) {
        var old = this._methods;
        if(old) {
            old.forEach(this.removeMethod, this);
        }
        this._methods = value;
        if(this._methods) {
            this._methods.forEach(this.addMethod, this);
        }
    }
}

export default Proxy;