const sep = "/";
const extDelim = ".";
const currentDir = ".";
const parentDir = "..";
const sepCharCode = sep.charCodeAt(0);
        
const startsWithSeparator = function(path) {
    return path && path.length > 0 && path.charCodeAt(0) === sepCharCode;
};

const isAbsolute = function(path) {
    return startsWithSeparator(path);
};

const endsWithSeparator = function(path) {
    return path && path.length > 0 && path.charCodeAt(path.length - 1) === sepCharCode;
};
        
const joinImpl = function(arg, state) {
    if(!state) {
        state = { els: [], startSep: false, endSep: false };
    }
    if(Array.isArray(arg)) {
        arg.forEach(function(a) {
            joinImpl(a, state);
        });
    } else if(arg) {
        let s = String(arg);
        if(state.els.length === 0 && startsWithSeparator(s)) {
            state.startSep = true;
        }
        state.endSep = endsWithSeparator(s);
        let ps = arg.split(sep);
        ps.forEach(function(p) {
            if(p) {
                if(p === parentDir) {
                    if(state.els.length > 0) {
                        state.els.splice(state.els.length - 1, 1);
                    }
                } else if(p !== currentDir) {
                    state.els.push(p);
                }
            }
        });
    }
    return state;
};
        
export default {
    sep: sep,
    basename(path, ext) {
        if(path) {
            let lastSepIdx = path.lastIndexOf(sep);
            let bn = lastSepIdx >= 0 ? path.substring(lastSepIdx + sep.length) : path;
            return ext && bn.endsWith(ext) ? bn.substring(0, bn.length - ext.length) : bn;
        }
    },
    parent(path) {
        if(path) {
            let lastSepIdx = path.lastIndexOf(sep);
            if(lastSepIdx > 0) {
                return path.substring(0, lastSepIdx);
            }
        }
    },
    dirname(path) {
        if(path) {
            let lastSepIdx = path.lastIndexOf(sep);
            if(lastSepIdx === 0) {
                return sep;
            }
            if(lastSepIdx > 0) {
                let prefix = path.substring(0, lastSepIdx);
                let suffix = path.substring(lastSepIdx + sep.length);
                return suffix ? prefix : this.dirname(prefix);
            }
            return currentDir;
        }
    },
    extname(path) {
        if(path) {
            let lastExtIdx = path.lastIndexOf(extDelim);
            if(lastExtIdx >= 0) {
                return path.substring(lastExtIdx);
            }
        }
        return "";
    },
    removeExt(path) {
        let lastExtIdx = path.lastIndexOf(extDelim);
        let prefix = path.substring(0, lastExtIdx);
        return prefix.length > 0 ? prefix : path;
    },
    isAbsolute(path) {
        return isAbsolute(path);
    },
    join() {
        let state = { els: [], startSep: false, endSep: false };
        
        Array.prototype.forEach.call(arguments, function(arg) {
            joinImpl(arg, state);
        }, this);
        
        if(state.els.length > 0) {
            let r = state.els.join(sep);
            return (state.startSep ? sep : "") + r + (state.endSep ? sep : "");
        }
        
        return currentDir;
    },
    normalize(path) {
        if(path) {
            let els = path.split(sep);
            return this.join(els);
        }
    }
};
