const empty = "";
        
const chars = {
    cr: "\r",
    lf: "\n",
    tab: "\t",
    space: " ",
    zero: "0",
    nine: "9",
    a: "a",
    z: "z",
    A: "A",
    Z: "Z"
};

const charCodes = {};
        
for(var c in chars) {
    charCodes[c] = chars[c].charCodeAt(0);
}

const isWhitespace = function(ch) {
    var code = ch.charCodeAt(0);
    return isNaN(code) ||
            (code >= 9 && code <= 13) ||
            code === 32 ||
            code === 133 ||
            code === 160 ||
            code === 5760 ||
            (code >= 8192 && code <= 8202) ||
            code === 8232 ||
            code === 8233 ||
            code === 8239 ||
            code === 8287 ||
            code === 12288;
};

const isNotWhitespace = function(ch) {
    return !isWhitespace(ch);
};

const isDigit = function(ch) {
    var code = ch.charCodeAt(0);
    return code >= charCodes.zero && code <= charCodes.nine;
};

const isNotDigit = function(ch) {
    return !isDigit(ch);
};

const isAlpha = function(ch) {
    var code = ch.charCodeAt(0);
    return (code >= charCodes.a && code <= charCodes.z) || (code >= charCodes.A && code <= charCodes.Z);
};

const isNotAlpha = function(ch) {
    return !isAlpha(ch);
};

const isAlphaNumeric = function(ch) {
    return isAlpha(ch) || isDigit(ch);
};

const isNotAlphaNumeric = function(ch) {
    return !isAlpha(ch) && !isDigit(ch);
};

const startsWith = function(text, match) {
    return text.indexOf(match) === 0;
};

const endsWith = function(text, match) {
    if(match.length <= text.length) {
        var idx = text.lastIndexOf(match);
        return idx >= 0 && (idx + match.length === text.length);
    }

    return false;
};

const contains = function(text, match) {
    return text.indexOf(match) >= 0;
};

const filters = {
    isWhitespace: isWhitespace,
    whitespace: isWhitespace,
    isNotWhitespace: isNotWhitespace,
    nonWhitespace: isNotWhitespace,
    isDigit: isDigit,
    digit: isDigit,
    isNotDigit: isNotDigit,
    nonDigit: isNotDigit,
    isAlpha: isAlpha,
    alpha: isAlpha,
    isNotAlpha: isNotAlpha,
    nonAlpha: isNotAlpha,
    isAlphaNumeric: isAlphaNumeric,
    alphaNumeric: isAlphaNumeric,
    isNotAlphaNumeric: isNotAlphaNumeric,
    nonAlphaNumeric: isNotAlphaNumeric
};

const stringUtils = {
    empty: empty,
    filters: filters,
    each(text, cb, scope) {
        if(text) {
            let tl = text.length;
            for(let i = 0; i < tl; i ++) {
                cb.call(scope, text.charAt(i), i, text);
            }
        }
    },
    forEach() {
        stringUtils.each.apply(this, arguments);
    },
    some(text, pr, scope) {
        if(text) {
            let tl = text.length;
            for(let i = 0; i < tl; i ++) {
                if(pr.call(scope, text.charAt(i), i, text)) {
                    return true;
                }
            }
        }

        return false;
    },
    someFromEnd(text, pr, scope) {
        if(text) {
            var tl = text.length;
            for(let i = tl - 1; i >= 0; i--) {
                if(pr.call(scope, text.charAt(i), i, text)) {
                    return true;
                }
            }
        }

        return false;
    },
    every(text, pr, scope) {
        if(text) {
            let tl = text.length;
            for(let i = 0; i < tl; i ++) {
                if(!pr.call(scope, text.charAt(i), i, text)) {
                    return false;
                }
            }
            return true;
        }

        return true;
    },
    everyFromEnd(text, pr, scope) {
        if(text) {
            var tl = text.length;
            for(var i = tl - 1; i >= 0; i--) {
                if(!pr.call(scope, text.charAt(i), i, text)) {
                    return false;
                }
            }
        }

        return true;
    },
    filter(text, pr, scope) {
        if(text) {
            var r = empty;
            stringUtils.each(text, function(ch) {
                if(pr.apply(this, arguments)) {
                    r += ch;
                }
            }, scope);

            return r;
        }

        return text;
    },
    split(text, pr, scope) {
        var r = [];
        var b = empty;
        if(text) {
            stringUtils.each(text, function(ch) {
                if(pr.apply(this, arguments)) {
                    if(b) {
                        r.push(b);
                        b = empty;
                    }
                } else {
                    b += ch;
                }
            }, scope);

            if(b) {
                r.push(b);
            }
        }
        return r;
    },
    reject(text, pr, scope) {
        if(text) {
            var r = empty;
            stringUtils.each(text, function(ch) {
                if(!pr.apply(this, arguments)) {
                    r += ch;
                }
            }, scope);

            return r;
        }

        return text;
    },
    removeWhitespace(text) {
        return stringUtils.reject(text, stringUtils.filters.whitespace);
    },
    findIndexOf(text, pr, scope) {
        var foundIdx = -1;
        if(pr) {
            stringUtils.some(text, function(ch, idx, text) {
                if(pr.apply(this, arguments)) {
                    foundIdx = idx;
                    return true;
                }
            }, scope);
        }
        return foundIdx;
    },
    findLastIndexOf(text, pr, scope) {
        var foundIdx = -1;
        if(pr) {
            stringUtils.someFromEnd(text, function(ch, idx, text) {
                if(pr.apply(this, arguments)) {
                    foundIdx = idx;
                    return true;
                }
            }, scope);
        }
        return foundIdx;
    },
    leftTrim(text) {
        var idx = stringUtils.findIndexOf(text, stringUtils.filters.nonWhitespace);
        if(idx >= 0) {
            return idx === 0 ? text : text.substring(idx);
        }
    },
    trimLeft() {
        return stringUtils.leftTrim.apply(this, arguments);
    },
    rightTrim(text) {
        var idx = stringUtils.findLastIndexOf(text, stringUtils.filters.nonWhitespace);
        if(idx >= 0) {
            return idx === text.length - 1 ? text : text.substring(0, idx + 1);
        }
    },
    trimRight() {
        return stringUtils.rightTrim.apply(this, arguments);
    },
    trim(text) {
        return stringUtils.rightTrim(stringUtils.leftTrim(text));
    },
    isBlank(text) {
        if(text) {
            return stringUtils.every(text, stringUtils.filters.whitespace);
        }
        return true;
    },
    isNotBlank(text) {
        return !stringUtils.isBlank(text);
    },
    startsWith(text, match) {
        if(text && match) {
            return startsWith(text, match);
        }
        return false;
    },
    startsWithIgnoreCase(text, match) {
        if(text && match) {
            return startsWith(text.toLowerCase(), match.toLowerCase());
        }
        return false;
    },
    ensureStartsWith(text, startsWith) {
        return !stringUtils.startsWith(text, startsWith) ? startsWith + text : text;
    },
    ensureStartsWithIgnoreCase(text, startsWith) {
        return !stringUtils.startsWithIgnoreCase(text, startsWith) ? startsWith + text : text;
    },
    endsWith(text, match) {
        if(text && match) {
            return endsWith(text, match);
        }
        return false;
    },
    endsWithIgnoreCase(text, match) {
        if(text && match) {
            return endsWith(text.toLowerCase(), match.toLowerCase());
        }
        return false;
    },
    ensureEndsWith(text, endsWith) {
        return !stringUtils.endsWith(text, endsWith) ? text + endsWith : text;
    },
    ensureEndsWithIgnoreCase(text, endsWith) {
        return !stringUtils.endsWithIgnoreCase(text, endsWith) ? text + endsWith : text;
    },
    contains(text, match) {
        if(text && match) {
            return contains(text, match);
        }
        return false;
    },
    containsIgnoreCase(text, match) {
        if(text && match) {
            return contains(text.toLowerCase(), match.toLowerCase());
        }
        return false;
    },
    equalsIgnoreCase(l, r) {
        if(l && r) {
            return l.toLowerCase() === r.toLowerCase();
        }
        return l === r;
    },
    padLeft(s, length, padChar) {
        if(!padChar) {
            padChar = " ";
        }
        var r = s || "";
        while(r.length < length) {
            r = padChar + r;
        }
        return r;
    },
    stripLeft(s, stripChar) {
        if(s) {
            var idx = stringUtils.findIndexOf(s, function(ch) {
                return ch !== stripChar;
            });
            if(idx > 0) {
                return s.substring(idx);
            }
        }
        return s;
    },
    padRight(s, length, padChar) {
        if(!padChar) {
            padChar = " ";
        }
        var r = s || "";
        while(r.length < length) {
            r = r + padChar;
        }
        return r;
    },
    stripRight(s, stripChar) {
        if(s) {
            var idx = stringUtils.findLastIndexOf(s, function(ch) {
                return ch !== stripChar;
            });
            if(idx < s.length - 1) {
                return s.substring(0, idx + 1);
            }
        }
        return s;
    }
};

export default stringUtils;