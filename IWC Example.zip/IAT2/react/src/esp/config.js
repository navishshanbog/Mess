export default {
    iwcUrl: "http://localhost:8000/static/ozp-iwc",
    tdBaseUrl: "http://dtd1ln1.corpnet.customs:1080"
};