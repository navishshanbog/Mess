import PromiseProxy from "./../../es6/util/PromiseProxy";
import TDQueryEntityService from "./impl/TDQueryEntityService";
import MockEntityService from "./impl/MockEntityService";



const EntityService = new PromiseProxy();
EntityService.methods = [
    "requiresSession",
    "search",
    "getMasteredDetails",
    "getMasteredRefDetails",
    "getSourceSystemDetails",
    "getIATTravellerPhoto",
    "getIATTravellerMovement",
    "getBAGSExams",
    "getPNRTravellerMovement",
    "getCargoAirReport",
    "getCargoSeaReport",
    "getDGMSActivities"
];
//EntityService.target = new TDQueryEntityService();
EntityService.target = new MockEntityService();
export default EntityService;