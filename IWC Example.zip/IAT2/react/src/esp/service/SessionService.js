import PromiseProxy from "./../../es6/util/PromiseProxy";
import TDSessionService from "./impl/TDSessionService";
import MockSessionService from "./impl/MockSessionService";

const SessionService = new PromiseProxy();
SessionService.methods = [
    "login",
    "logout",
    "isSessionInvalidError"
];
// SessionService.target = new TDSessionService();
SessionService.target = new MockSessionService();
export default SessionService;