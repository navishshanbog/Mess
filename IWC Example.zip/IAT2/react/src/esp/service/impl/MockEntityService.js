import promiseUtils from "./../../../es6/util/promise";
import stringUtils from "./../../../es6/util/string";

const sources = ["PNR", "ICS", "IAT", "BAGS", "INTCP", "DGMS", "RFRNC"];
const credTypes = ["TD"];
const firstNames = ["SUNBURN", "LOST", "GOOSE", "INJURED"];
const middleNames = ["HARRY", "RON", "RICHARD", "RYAN"];
const lastNames = ["SLAPPER", "SOUL", "MCGOO", "KNEE"];

const getRandom = (items) => {
    const idx = Math.floor(Math.random() * items.length);
    return items[idx];
};

const getRandomEntityId = (idx) => {
    return Math.floor(Math.random() * 88000) + idx;
};

const getRandomSource = () => {
    return getRandom(sources);
};

const getRandomCredType = () => {
    return getRandom(credTypes);
};

const getRandomFirstName = () => {
    return getRandom(firstNames);
};

const getRandomMiddleName = () => {
    return getRandom(middleNames);
}

const getRandomLastName = () => {
    return getRandom(lastNames);
};

class MockEntityService {
    requiresSession() {
        return false;
    }
    _createMockSearchResult(idx) {
        const r = {
            id: getRandomEntityId(idx),
            name: getRandomFirstName() + " " + getRandomMiddleName() + " " + getRandomLastName(),
            dob: "1972-04-01",
            gender: "MALE"
        };
        r.sources = [];
        sources.forEach((source) => {
            let count = Math.floor(Math.random() * 8);
            if(count > 0) {
                r.sources.push({ code: source, count: count });
            }
        });
        r.credential = {
            "number": stringUtils.padLeft(String(Math.floor(Math.random() * 77000)), 5, "0"),
            "type": "TD"
        }
        return r;
        
    }
    get searchResult() {
        if (!this._searchResult) {
            this._searchResult = { data: [], rowLimitExceeded: false };
            for(let i = 0; i < 88; i ++) {
                this._searchResult.data.push(this._createMockSearchResult(i));
            }
        }
        return this._searchResult;
    }
    set searchResult(value) {
        this._searchResult = value;
    }
    search(params) {
        return promiseUtils.invokeDelayed(() => {
            return this.searchResult;
        }, { delay: 500 });
    }
    get masteredDetails() {
        return this._masteredDetails;
    }
    set masteredDetails(value) {
        this._masteredDetails = value;
    }
    getMasteredDetails(params) {
        return promiseUtils.invokeDelayed(() => {
            return Object.assign({}, this.masteredDetails);
        }, { delay: 500 });
    }
    get sourceSystemDetails() {
        if(!this._sourceSystemDetails) {
            this._sourceSystemDetails = [

            ]
        }
        return this._sourceSystemDetails;
    }
    set sourceSystemDetails(value) {
        this._sourceSystemDetails = value;
    }
    getSourceSystemDetails(params) {
        return promiseUtils.invokeDelayed(() => {
            return [].concat(this.sourceSystemDetails);
        }, { delay: 500 });
    }
    get masteredRefDetails() {
        if (!this._masteredRefDetails) {
            this._masteredRefDetails = [{"MSTR_ENTY_ID":328665107,"MDM_PRFL_NM":"LEFTOVER - NEW ROW","MSTRD_IND":"Y","SRC_SYST_CD":"ICS","SRC_RLTD_KY_VLU":"952683745177922","SRC_ENTY_ID":328665107,"CLIENT_CREATED_DT":"2012-10-23","SEX_CD":"NA","DT_OF_BRTH":null,"NAME":"MICHAEL TRUSSLER","STD_ADRS_GEO_VLU":"QLD AU","PHN_NBR":null,"CRDNTL":null}
            ];
        }
        return this._masteredDetails;
    }
    set masteredRefDetails(value) {
        this._masteredRefDetails = value;
    }
    getMasteredRefDetails(params) {
        return promiseUtils.invokeDelayed(() => {
            return [].concat(this.masteredRefDetails);
        }, { delay: 500 });
    }

    getIATTravellerMovement(params) {
        return promiseUtils.invokeDelayed(() => {
            // return [].concat(this.masteredRefDetails);
            return [
                {
                        "Date":"2011-10-19",
                        "IAT-TravellerID":"5648468135185133",
                        "TravelDocID":"65484513298435",
                        "ChkIn Port":"LAX",
                        "Local Port":"BNE",
                        "RouteID":"VA87",
                        "Direction":"I",
                        "MvmtStatus":"A",
                        "TD Country":"AUS",
                        "ExmtnStart":"",
                        "ExmtnEnd":"",
                        "ExmtnReason":"Richard was here",
                        "ExmtnStatus":"NA",
                        "ExmtnResult":"",
                        "ExmtnFind":""
                    },
                    {
                        "Date":"2011-10-19",
                        "IAT-TravellerID":"5648468135185133",
                        "TravelDocID":"65484513298435",
                        "ChkIn Port":"LAX",
                        "Local Port":"SYD",
                        "RouteID":"VA88",
                        "Direction":"O",
                        "MvmtStatus":"A",
                        "TD Country":"USA",
                        "ExmtnStart":"",
                        "ExmtnEnd":"",
                        "ExmtnReason":"John was here",
                        "ExmtnStatus":"NA",
                        "ExmtnResult":"",
                        "ExmtnFind":""
                    }
            ];
        }, { delay: 500 });
    }

}

export default MockEntityService;