class MockSessionService {
    login() {
        return { sessionId: "MOCK" };
    }
    logout() {

    }
}

export default MockSessionService;