import pathUtils from "./../../../es6/util/path";
import stringUtils from "./../../../es6/util/string";
import lang from "./../../../es6/util/lang";
import TDQueryService from "./TDQueryService";

class TDQueryEntityService {
    constructor(queryService) {
        this.queryService = queryService;
    }
    get queryService() {
        if(!this._queryService) {
            this._queryService = new TDQueryService();
        }
        return this._queryService;
    }
    set queryService(value) {
        this._queryService = value;
    }
    requiresSession() {
        return true;
    }
    _getResult(response, map) {
        let data = [];
        let rowLimitExceeded = false;
        if(response && response.results && response.results.length > 0) {
            response.results.forEach((result) => {
                if(result && result.data) {
                    result.data.forEach((r) => {
                        data.push(map ? map(r) : r);
                    });
                    if(result.rowLimitExceeded) {
                        rowLimitExceeded = true;
                    }
                }
            });
        }
        return { data: data, rowLimitExceeded: rowLimitExceeded };
    }
    _mapCredential(credString, credId) {
        if(credString) {
            const idx = credString.indexOf("(");
            const cred = {};
            if(idx > 0) {
                const typeCloseIdx = credString.lastIndexOf(")");
                cred.number = stringUtils.trim(credString.substring(0, idx));
                if(typeCloseIdx > idx) {
                    cred.type = stringUtils.trim(credString.substring(idx + 1, typeCloseIdx));
                } else {
                    cred.type = stringUtils.string(credString.substring(idx + 1));
                }
            } else {
                cred.number = credString;
            }
            cred.id = credId;
            return cred;
        }
    }
    _mapSearchResult(data) {
        const sources = [];
        if(data.PNR) {
            sources.push({ code: "PNR", count: data.PNR });
        }
        if(data.ICS) {
            sources.push({ code: "ICS", count: data.ICS });
        }
        if(data.IAT) {
            sources.push({ code: "IAT", count: data.IAT });
        }
        if(data.BAGS) {
            sources.push({ code: "BAGS", count: data.BAGS });
        }
        if(data.INTCP) {
            sources.push({ code: "INTCP", count: data.INTCP });
        }
        if(data.DGMS) {
            sources.push({ code: "DGMS", count: data.DGMS });
        }
        if(data.RFRNC) {
            sources.push({ code: "RFRNC", count: data.RFRNC });
        }
        return {
            id: data.MSTR_ENTY_ID || undefined,
            name: data.NAME || undefined,
            dob: data.DT_OF_BRTH || undefined,
            gender: data.SEX || undefined,
            address: data.ADDRESS || undefined,
            phone: data.PHONE || undefined,
            sourceCount: data.ALL_SYST || undefined,
            sources: sources,
            credential: this._mapCredential(data.CRDNTL)
        };
    }
    _getSearchResult(response) {
        return this._getResult(response, (r) => {
            return this._mapSearchResult(r);
        });
    }
    createSearchQueryArgs(request) {
        let queryArgs = {
            REQUEST_TYPE: "MASTER_SEARCH",
            includePnr: request.includePnr
        };
        if(request.system) {
            queryArgs.SRC_KY_VLU = request.system.clientId;
        }
        if(request.person) {
            queryArgs.ORG_NM = request.person.fullName;
            queryArgs.FRST_NM = request.person.firstName;
            queryArgs.MDL_NM = request.person.middleName;
            queryArgs.FMLY_NM = request.person.lastName;
            queryArgs.DT_OF_BRTH = request.person.dob;
            queryArgs.SEX_CD = request.person.gender;
            queryArgs.CRDNTL_VLU_PP = request.person.passport;
        }
        
        if(request.address) {
            queryArgs.STD_ADRS_VLU = request.address.fullAddress;
            queryArgs.UNIT_ID = request.address.unitNumber;
            queryArgs.RD_FRST_ID = request.address.streetNumber;
            queryArgs.RD_NM = request.address.streetName;
            queryArgs.RD_TYP_ABRVTN = request.address.streetType;
            queryArgs.LCLTY_NM = request.address.locality;
            queryArgs.STE_CD = request.address.state;
            queryArgs.PST_CD = request.address.postcode;
        }
        if(request.phone) {
            queryArgs.PHN_NBR = request.phone.phone;
        }
        if(request.org) {
            queryArgs.ORG_NM = request.org.name;
            queryArgs.CRDNTL_VLU_ABN = request.org.abn;
        }
        return queryArgs;
    }
    search(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createSearchQueryArgs(request),
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getSearchResult(response);
        }).catch((err) => {
            return Promise.reject(err);  
        });
    }
    createMasteredDetailsQueryArgs(request) {
        return {
            REQUEST_TYPE: "MSTR_DETAIL",
            MSTR_ENTY_ID: request.id
        };
    }
    _mapMasteredDetailResult(data) {
        return {
            id: data.MSTR_ENTY_ID || undefined,
            name: data.NAME || undefined,
            dob: data.DT_OF_BRTH || undefined,
            gender: data.SEX || undefined,
            address: data.ADDRESS || undefined,
            phone: data.PHONE || undefined,
            credential: this._mapCredential(data.CRDNTL, data.ENTY_CRDNTL_ID)
        };
    }
    _getMasteredDetailsResult(response) {
        const mapped = this._getResult(response, (r) => {
            return this._mapMasteredDetailResult(r);
        });
        let merged;
        mapped.data.forEach((m) => {
            if(!merged) {
                merged = {
                    id: m.id,
                    name: [],
                    phone: [],
                    dob: [],
                    gender: [],
                    address: [],
                    credential: [],
                    credentialMap: {}
                }
            }

            if(m.name) {
                if(merged.name.indexOf(m.name) < 0) {
                    merged.name.push(m.name);
                }
            }
            if(m.dob) {
                if(merged.dob.indexOf(m.dob) < 0) {
                    merged.dob.push(m.dob);
                }
            }
            if(m.gender) {
                if(merged.gender.indexOf(m.gender) < 0) {
                    merged.gender.push(m.gender);
                }
            }
            if(m.address) {
                if(merged.address.indexOf(m.address) < 0) {
                    merged.address.push(m.address);
                }
            }
            if(m.phone) {
                if(merged.phone.indexOf(m.phone) < 0) {
                    merged.phone.push(m.phone);
                }
            }
            if(m.credential) {
                if(!merged.credentialMap[m.credential.id]) {
                    merged.credentialMap[m.credential.id] = m.credential;
                    merged.credential.push(m.credential);
                }
            }
        });

        const cleanup = (name) => {
            delete merged[name + "Map"];
            if(merged[name].length === 0) {
                delete merged[name];
            } else if(merged[name].length === 1) {
                merged[name] = merged[name][0];
            }
        };

        cleanup("name");
        cleanup("phone");
        cleanup("dob");
        cleanup("gender");
        cleanup("address");
        cleanup("credential");

        return merged;
    }
    getMasteredDetails(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createMasteredDetailsQueryArgs(request),
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getMasteredDetailsResult(response);
        });
    }
    createMasteredRefDetailsQueryArgs(request) {
        return {
            REQUEST_TYPE: "REF_DETAIL",
            includePnr: request.includePnr,
            MSTR_ENTY_ID: request.id
        }
    }
    _mapMasterRefDetail(data) {
        return {
            id: data.MSTR_ENTY_ID || undefined,
            dataProfileName: data.MDM_PRFL_NM || undefined,
            source: {
                code: data.SRC_SYST_CD || undefined,
                relatedKey: data.SRC_RLTD_KY_VLU || undefined,
                entityId: data.SRC_ENTY_ID || undefined
            },
            createdAt: data.CLIENT_CREATED_DT || undefined,
            gender: data.SEX_CD || undefined,
            dob: data.DT_OF_BRTH || undefined,
            name: data.NAME || undefined,
            address: data.STD_ADRS_GEO_VLU || undefined,
            phone: data.PHN_NBR || undefined,
            credential: this._mapCredential(data.CRDNTL)
        };
    }
    _getMasteredRefDetailsResult(response) {
        return this._getResult(response, (r) => {
            return this._mapMasterRefDetail(r);
        });
    }
    getMasteredRefDetails(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createMasteredRefDetailsQueryArgs(request),
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getMasteredRefDetailsResult(response);
        });
    }
    createMasterLineageQueryArgs(request) {
        return {
            REQUEST_TYPE: "MSTR_LINEAGE",
            MSTR_ENTY_ID: request.id
        };
    }
    _mapMasterLineage(data) {
        return {
            id: data.MSTR_ENTY_ID || undefined,
            runId: data.CDL_CRTD_RUN_ID || undefined,
            timestamp: data.CDL_STRT_TMSTMP || undefined,
            source: {
                code: data.SRC_SYST_CD || undefined,
                entityId: data.SRC_ENTY_ID || undefined,
                key: data.SRC_KY_VLU || undefined
            },
            gender: data.SEX_CD || undefined,
            dob: data.DT_OF_BRTH || undefined,
            name: data.NAME || undefined,
            addressUsageType: data.ADRS_USAG_TYP_CD || undefined,
            address: data.STD_ADRS_VLU || undefined,
            country: data.CNTRY_CD || undefined,
            areaCode: data.AREA_CD || undefined,
            phone: data.PHN_NBR || undefined,
            credential: this._mapCredential(data.CRDNTL)
        };
    }
    _getMasterLineageResult(response) {
        return this._getResult(response, (r) => {
            return this._mapMasterLineage(r);
        });
    }
    getMasterLineage(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createMasterLineageQueryArgs(request),
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getMasterLineageResult(response);
        });
    }
    getIATTravellerPhoto(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_IAT",
            args: [
                {
                    IAT_TRAVELLER_ID: request.id,
                    sqlRequestType: "PHOTO"
                },
                "executedSqlStmt"
            ],
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getIATTravellerMovement(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_IAT",
            args: [
                {
                    sqlRequestType: "MVMT-ALL"
                },
                "executedSqlStmt"
            ],
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getBAGSExams(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_BAGS",
            args: [
                { sqlRequestType: "EXM-All" },
                "executedSqlStmt"
            ],
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getPNRTravellerMovement(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_PNR",
            args: [
                {
                    sqlRequestType: "MVMT-ALL"
                },
                "executedSqlStmt"
            ],
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getCargoAirReport(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_Cargo",
            args: [
                {
                    sqlRequestType: "ACR-ALL"
                },
                "executedSqlStmt"
            ],
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getCargoSeaReport(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_Cargo",
            args: [
                {
                    sqlRequestType: "SCR-ALL"
                },
                "executedSqlStmt"
            ],
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getDGMSActivities(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_DGMS",
            args: [
                {
                    sqlRequestType: "DTN-ALL"
                },
                "executedSqlStmt"
            ],
            session: request.session
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        }); 
    }
}

export default TDQueryEntityService;