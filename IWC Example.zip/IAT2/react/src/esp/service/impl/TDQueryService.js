import pathUtils from "./../../../es6/util/path";
import stringUtils from "./../../../es6/util/string";
import lang from "./../../../es6/util/lang";
import config from "../../config";

class TDQueryService {
    get baseUrl() {
        if(!this._baseUrl) {
            this._baseUrl = config.tdBaseUrl;
        }
        return this._baseUrl;
    }
    set baseUrl(value) {
        this._baseUrl = value;
        delete this._queryUrl;
        delete this._sessionUrl;
    }
    get queryUrl() {
        if(!this._queryUrl) {
            this._queryUrl = this.baseUrl + "/tdrest/systems/PTD1/queries";
        }
        return this._queryUrl;
    }
    _resolveResponse(xhr) {
        if(lang.isString(xhr.response)) {
            try {
                return JSON.parse(xhr.response);
            } catch(e) {
                return xhr.response;
            }
        }
        return xhr.response;
    }
    _resolveError(xhr) {
        const error = this._resolveResponse(xhr);
        if(error) {
            error.statusCode = xhr.status;
        }
        return error;
    }
    callQuery(request) {
        const session = request.session;
        if(!session) {
            return Promise.reject(new Error("Session details have not been specified"));
        }
        const args = request.args;
        const argStrings = [];
        if(lang.isArray(args)) {
            args.forEach((arg) => {
                if(lang.isObject(arg) && arg !== null) {
                    argStrings.push(`'${JSON.stringify(arg)}'`);
                } else if(lang.isString(arg)) {
                    argStrings.push(arg);
                }
            });
        } else if(lang.isObject(args)) {
            argStrings.push(`'${JSON.stringify(args)}'`);
        } else if(lang.isString(args)) {
            argStrings.push(args);
        }
        const argString = argStrings.join(",");
        let queryString = `CALL ${request.name}(${argString});`;
        let tdRequest = {
            format: "object",
            includeColumns: request.includeColumns ? true : false,
            logMech: "LDAP",
            query: queryString,
            queryBands: {
                ApplicationName: "ESP"
            },
            rowLimit: !isNaN(request.rowLimit) && request.rowLimit > 0 ? request.rowLimit : 1000,
            session: session.sessionId
        };

        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", this.queryUrl);
            xhr.responseType = "json";
            xhr.setRequestHeader("Authorization", "Basic " + session.auth);
            xhr.setRequestHeader("Content-Type", "application/json");

            xhr.onload = (e) => {
                if(xhr.status >= 200 && xhr.status < 300) {
                    resolve(this._resolveResponse(xhr));
                } else {
                    reject(this._resolveError(xhr));
                }
            };

            xhr.onerror = (e) => {
                reject(e);
            };

            xhr.send(JSON.stringify(tdRequest));
        });
    }
}

export default TDQueryService;