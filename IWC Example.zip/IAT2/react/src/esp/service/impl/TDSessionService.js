import pathUtils from "./../../../es6/util/path";
import stringUtils from "./../../../es6/util/string";
import lang from "./../../../es6/util/lang";
import config from "./../../config";

class TDSessionService {
    get baseUrl() {
        if(!this._baseUrl) {
            this._baseUrl = config.tdBaseUrl;
        }
        return this._baseUrl;
    }
    set baseUrl(value) {
        this._baseUrl = value;
        delete this._sessionUrl;
    }
    get sessionUrl() {
        if(!this._sessionUrl) {
            this._sessionUrl = this.baseUrl + "/tdrest/systems/PTD1/sessions";
        }
        return this._sessionUrl;
    }
    createSessionPayload() {
        return {
            logMech: "LDAP",
            queryBands: {
                ApplicationName: "ESP"
            }
        };
    }
    _resolveResponse(xhr) {
        if(lang.isString(xhr.response)) {
            try {
                return JSON.parse(xhr.response);
            } catch(e) {
                return xhr.response;
            }
        }
        return xhr.response;
    }
    _resolveSessionResponse(xhr, auth) {
        const sessionInfo = this._resolveResponse(xhr);
        sessionInfo.auth = auth;
        return sessionInfo;
    }
    _resolveError(xhr) {
        const error = this._resolveResponse(xhr);
        if(error) {
            error.statusCode = xhr.status;
        }
        return error;
    }
    isSessionInvalidError(error) {
        return error && error.statusCode === 404 && stringUtils.containsIgnoreCase(error.message, "Session not found");
    }
    login(userCredentials) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", this.sessionUrl);
            xhr.responseType = "json";
            let auth = lang.isString(userCredentials) ? userCredentials : btoa(userCredentials.username + ":" + userCredentials.password);
            xhr.setRequestHeader("Authorization", "Basic " + auth);
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = (e) => {
                if(xhr.status >= 200 && xhr.status < 300) {
                    resolve(this._resolveSessionResponse(xhr, auth));
                } else {
                    reject(this._resolveError(xhr));
                }
            };

            xhr.onerror = (e) => {
                reject(e);
            };

            xhr.send(JSON.stringify(this.createSessionPayload()));
        });
    }
    logout(session) {

    }
    /*
    _ensureSession(userConfig) {
        if(userConfig && userConfig.username) {
            const username = userConfig.username;
            
            if(this._sessions && this._sessions[username]) {
                return Promise.resolve(this._sessions[username]);
            }

            if(!this._sessionCreatePromises) {
                this._sessionCreatePromises = {};
            }

            if(this._sessionCreatePromises[username]) {
                return this._sessionCreatePromises[username];
            }

            const sessionCreatePromise = this._createSession(userConfig).then((session) => {
                if(!this._sessions) {
                    this._sessions = {};
                }
                this._sessions[username] = session;
                delete this._sessionCreatePromises[username];
                session.userConfig = userConfig;
                return session;
            }).catch((err) => {
                delete this._sessionCreatePromises[username];
                return Promise.reject(err);
            });

            this._sessionCreatePromises[username] = sessionCreatePromise;

            return sessionCreatePromise;
        }
        return Promise.reject("No User Credentials Specified");
    }
    */
    /*
    isSessionNotFoundError(err) {
        return err && err.statusCode === 404 && stringUtils.containsIgnoreCase(err.message, "Session not found");
    }
    */
}

export default TDSessionService;