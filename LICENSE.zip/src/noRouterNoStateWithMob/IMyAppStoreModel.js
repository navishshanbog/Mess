/*
import ParentsModel from "./ParentsModel";
import KidsModel from "./KidsModel";

interface IMyAppStoreModel {
    parentsModel:ParentsModel;
    kidsModel:KidsModel;
    viewSelected: string;
}

export { IMyAppStoreModel as default, IMyAppStoreModel }
*/