
import {Kids} from "../Data";
import { observable } from "mobx";
import axios from "axios";


class KidsModel  {
    @observable allKids = Kids;
    @observable selectedKidId = "";
    @observable selectedKid = {};
    newKid = {};

    anySelectedKid () {
        return this.selectedKidId ? true: false;
    }

/*
       headers.add("Access-Control-Allow-Origin", "*");
        headers.add("Access-Control-Allow-Headers", "Origin, Content-Type, Accept, Authorization");
        headers.add("Access-Control-Allow-Credentials", "true");
        headers.add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD");
 */


    constructor() {
       // axios.defaults.baseURL = "http//localhost:8086";  Access-Control-Allow-Origin: *
        axios.defaults.method= "GET";
        axios.defaults.headers = {"Access-Control-Allow-Origin": "*",
            "Access-Control-Request-Method": "GET", "Access-Control-Allow-Methods": "GET, OPTIONS"};

        axios.get('http://localhost:3011/kids/sample', {"method":"GET", "responseType": "json", "Access-Control-Allow-Origin": "*"})
            .then(function (response) {
                console.log("response => ", response);
            })
            .catch(function (error) {
                console.log("error", error);
            });
    }


}

export { KidsModel as default, KidsModel }