const path = require('path');
const webpack = require('webpack');
const HtmlWebpackPlugin = require("html-webpack-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");

const isNodeModuleFile = (filename) => {
    return filename.indexOf("node_modules") >= 0;
};


const isJSFile = (filename) => {
    return filename.endsWith(".js") || filename.endsWith(".jsx");
};

const isCssFile = (filename) => {
    return filename.endsWith(".css");
};

const isSassFile = (filename) => {
    return filename.endsWith(".scss");
};

const isWoffFile = (filename) => {
    return filename.endsWith(".woff");
};

const isWoff2File = (filename) => {
    return filename.endsWith(".woff2");
}

const isSvgFontFile = (filename) => {
    return filename.endsWith(".font.svg");
};

const isTrueTypeFontFile = (filename) => {
    return filename.endsWith(".ttf");
};

const isEOTFontFile = (filename) => {
    return filename.endsWith(".eot");
}

const isFontFile = (filename) => {
    return isWoffFile(filename) || isWoff2File(filename) || isSvgFontFile(filename) || isTrueTypeFontFile(filename) || isEOTFontFile(filename);
};

const isJSONFile = (filename) => {
    return filename.endsWith(".json");
};

const publicPath = __dirname;

console.log(path.join(__dirname, 'dist'));
console.log("we here");

module.exports = {
    devtool: 'eval',
    entry: [
        './src/index'
    ],
    output: {
        path: path.join(__dirname, 'dist'),
        filename: 'bundle.js',
        publicPath: '/static/'
    },
    plugins: [
        new webpack.HotModuleReplacementPlugin()
    ],
    resolve: {
        extensions: ['.js', '.jsx']
    },
    module: {
        rules: [{
            test: /\.jsx?$/,
            use: ['babel-loader'],
            include: path.join(__dirname, 'src')
        }]
    }
};