const sourceSystemCode = "ABR";

export { sourceSystemCode }