import api from '../utils/api';
import axios from 'axios';
import { setAlert } from './alert';
import { GET_CONTACT_MESSAGE, GET_CONTACT_MESSAGE_ERROR } from './types';

// Add contact message
export const addContactMessage = (formData, history) => async dispatch => {
  const config = {
    headers: {
      'Content-Type': 'application/json',
    },
  };
  try {
    const res = await axios.post('/api/contact', formData, config);

    dispatch({
      type: GET_CONTACT_MESSAGE,
      payload: res.data,
    });

    dispatch(setAlert('Message Sent successfully', 'success'));

    history.push('/dashboard');
  } catch (err) {
    dispatch({
      type: GET_CONTACT_MESSAGE_ERROR,
      payload: { msg: err.response.statusText, status: err.response.status },
    });
  }
};
