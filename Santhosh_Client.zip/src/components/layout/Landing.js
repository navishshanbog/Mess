import React from 'react';
import { Link, Redirect } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';

const Landing = ({ isAuthenticated }) => {
  if (isAuthenticated) {
    return <Redirect to='/dashboard' />;
  }
  return (
    <section className='landing'>
      <div className='dark-overlay'>
        <div className='landing-inner'>
          <h1 className='x-large'>Welcome to Proaspire</h1>
          <p className='my-3'>
            <p className='lead large'>
              <u> Our Vision</u>
              <ull className='custom-ul lead'>
                <li>
                  Provide commitment to guide, lead and up-lift businesses for
                  agility
                </li>
                <li>
                  Be known for our contemporary service, expertise and integrity
                </li>
                <li>Be global leaders to comprehend and realize your aspire</li>
              </ull>
            </p>
            <div className='my-3'>
              <p className='lead large next-para'>
                <u> Our Mission</u>
                To be an integral part of your business, providing exceptional
                prioritised support and innovation empowering your businesses to
                maximise success through tireless support of our staff
              </p>
            </div>
          </p>
        </div>
      </div>
    </section>
  );
};

Landing.propTypes = {
  isAuthenticated: PropTypes.bool,
};

const mapStateToProps = state => ({
  isAuthenticated: state.auth.isAuthenticated,
});

export default connect(mapStateToProps)(Landing);
