import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import PropTypes from 'prop-types';
import { logout } from '../../actions/auth';

const Navbar = ({ logout, auth: { isAuthenticated, loading } }) => {
  const authLinks = (
    <ul>
      <li>
        <Link to='/projects'>Projects</Link>
      </li>
      <li>
        <Link to='/profiles'>Directors</Link>
      </li>
      {/* <li>
        <Link to='/posts'>Posts</Link>
      </li> */}
      <li>
        <Link to='/dashboard'>
          <i className='fas fa-user' />{' '}
          <span className='hide-sm'>Dashboard</span>
        </Link>
      </li>
      <li>
        <Link to='/about'>
          <i className='fas fa-user' /> <span className='hide-sm'>About</span>
        </Link>
      </li>
      <li>
        <Link to='/contact'>
          <i className='fas fa-user' /> <span className='hide-sm'>Contact</span>
        </Link>
      </li>
      <li>
        <Link onClick={logout} to='/'>
          <i className='fas fa-sign-out-alt' />{' '}
          <span className='hide-sm'>Logout</span>
        </Link>
      </li>
    </ul>
  );
  const guestLinks = (
    <ul>
      <li>
        <Link to='/projects'>Projects</Link>
      </li>
      <li>
        <Link to='/profiles'>Directors</Link>
      </li>
      <li>
        <Link to='/register'>Register</Link>
      </li>
      <li>
        <Link to='/login'>Login</Link>
      </li>
      <li>
        <Link to='/about'>About</Link>
      </li>
      <li>
        <Link to='/contact'>Contact</Link>
      </li>
    </ul>
  );
  return (
    <nav className='navbar bg-dark'>
      <h1>
        <Link to='/' style={{ display: 'flex' }}>
          {/* <i className='fa fa-code'></i> */}
          <img
            src='Proaspire.jpeg'
            alt=''
            width='10px'
            height='30px'
            style={{ display: 'flex' }}
          />
          <div>
            Proaspire
            <sup className='very-small'>#Step Towards Growth</sup>
          </div>
        </Link>
      </h1>
      {!loading && (
        <Fragment> {isAuthenticated ? authLinks : guestLinks}</Fragment>
      )}
    </nav>
  );
};

Navbar.propTypes = {
  logout: PropTypes.func.isRequired,
  auth: PropTypes.object.isRequired,
};

const mapStateToProps = state => ({
  auth: state.auth,
});

export default connect(mapStateToProps, { logout })(Navbar);
