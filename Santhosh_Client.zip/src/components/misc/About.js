import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

const About = props => {
  return (
    <Fragment className='bg-dark'>
      <h1 className='large text-primary my-3'>About Proaspire</h1>
      <p
        className='my-1'
        style={{
          margin: '70px',
          textAlign: 'justify',
          textJustify: 'inter-word',
        }}
      >
        Based in Bangalore, Proaspire is committed to realize your vision. Being
        a small specialist team we strive for success and your business.
        Proaspire comprises a team of passionate individuals with several years
        of deep expertise to afloat any business or project who has the urge to
        succeed.{' '}
        <p className='my-2'>
          Our history and current projects are testimonies highlighting our
          enthusiasm and pledge to successfully recover from any inconsistencies
          hindering the path to success. We work across various domains and
          technologies and always align ourselves to emerging technologies,
          frameworks and patterns.
        </p>
        <p className='my-2'>
          At Proaspire, we build mutual relationships of trust and we are
          passionate to re-engage our successful clients providing them great
          value and customer’s user experience. Assist in building alongside to
          maximize their return on investment and believe in openness in
          communication to achieve this common goal. Our design and engagement
          philosophy is not centered around 'how Proaspire can become
          successful' but instead around 'How our client can become successful'.
        </p>
      </p>
      <Link className='btn my-1' to='/'>
        Go Back
      </Link>
    </Fragment>
  );
};

About.propTypes = {};

export default About;
