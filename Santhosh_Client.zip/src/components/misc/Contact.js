import React, { Fragment, useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Link, withRouter } from 'react-router-dom';
import { addContactMessage } from '../../actions/contact';

const Contact = ({ addContactMessage, history }) => {
  const [formData, setFormData] = useState({
    name: '',
    contact: '',
    message: '',
  });

  const { name, contact, message } = formData;

  const onChange = e =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = e => {
    e.preventDefault();
    console.log('-- name and detils ', formData);
    addContactMessage(formData, history);
  };

  return (
    <Fragment>
      <h1 className='large text-primary'>Contact Us</h1>
      <small>* = required field</small>
      <form className='form' onSubmit={e => onSubmit(e)}>
        <div className='form-group'>
          <input
            type='text'
            placeholder='* Name'
            name='name'
            required
            value={name}
            onChange={e => onChange(e)}
          />
        </div>
        <div className='form-group'>
          <input
            type='text'
            placeholder='* Contact Details'
            name='contact'
            required
            value={contact}
            onChange={e => onChange(e)}
          />
        </div>
        <div className='form-group'>
          <textarea
            name='message'
            cols='30'
            rows='5'
            placeholder='Message'
            value={message}
            onChange={e => onChange(e)}
          ></textarea>
        </div>
        <input type='submit' className='btn btn-primary my-1' />
        <Link className='btn my-1' to='/dashboard'>
          Go Back
        </Link>
      </form>

      <p>
        <div
          style={{
            height: '45%',
            margin: '1px',
            borderStyle: 'solid',
            borderWidth: '1px 0px 0px 0px',
            borderColor: '#cbcbcb',
            marginTop: '10px',
          }}
        >
          <div
            style={{
              width: '50%',
              float: 'left',

              margin: '0px',
              borderStyle: 'solid',
              borderWidth: '0px 0px 0px 0px',
            }}
          >
            <div style={{ margin: '10px' }}>
              <div>Proaspire HQ</div>
              <div>Proaspire Towers</div>
              <div>No.10, Bond Street</div>
              <div>Bangalore India</div>
              <div>Ph: 080 66554654 - 59</div>
              <div>Fax: 080 45443543</div>
            </div>
          </div>
          <div
            style={{
              borderStyle: 'solid',
              borderWidth: '0px 0px 0px 0px',
              marginLeft: '10px',
            }}
          >
            <div style={{ margin: '10px' }}>
              <div>Proaspire Business Center</div>
              <div>Proaspire Towers</div>
              <div>27, Pinnacle Circuit</div>
              <div>California USA</div>
              <div>Ph: +1 94043 - 59</div>
            </div>
          </div>
        </div>
      </p>

      <p>
        <div
          style={{
            height: '45%',
            margin: '1px',
            borderStyle: 'solid',
            borderWidth: '1px 0px 0px 0px',
            borderColor: '#cbcbcb',
            marginTop: '30px',
          }}
        >
          Social network links
        </div>
      </p>
    </Fragment>
  );
};

Contact.propTypes = {
  addContactMessage: PropTypes.func.isRequired,
};

export default connect(null, { addContactMessage })(withRouter(Contact));
