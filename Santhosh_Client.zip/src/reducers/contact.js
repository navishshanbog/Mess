import {
  GET_CONTACT_MESSAGE_ERROR,
  GET_CONTACT_MESSAGE,
} from '../actions/types';

const initialState = {
  messages: [],
  loading: true,
  error: {},
};

export default function (state = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case GET_CONTACT_MESSAGE:
      return {
        ...state,
        posts: payload,
        loading: false,
      };
    case GET_CONTACT_MESSAGE_ERROR:
      return {
        ...state,
        error: payload,
        loading: false,
      };
    default:
      return state;
  }
}
