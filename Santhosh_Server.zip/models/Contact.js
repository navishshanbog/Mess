const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ContactSchema = new Schema({
  name: {
    type: String,
  },
  contact: {
    type: String,
  },
  message: {
    type: String,
  },
});

module.exports = Contact = mongoose.model('Contact', ContactSchema);
