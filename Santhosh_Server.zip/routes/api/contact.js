const express = require('express');
const Contact = require('../../models/Contact');

const { check, validationResult } = require('express-validator');

const router = express.Router();

router.get('/', (req, res) => res.send('test '));

// @route   POST api/addComment
// @desc    Create Comment
// @access  public

router.post(
  '/',
  [
    [check('name', 'Name is required').not().isEmpty()],
    [check('contact', 'Please enter a valid Contact details').not().isEmpty()],
    [
      check('message', 'Invalid length, please enter valid message')
        .not()
        .isEmpty(),
    ],
  ],
  async (req, res) => {
    const errors = validationResult(req);
    console.log('-- all good so far ', errors);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    console.log('-- all goo request body ', req.body);
    const { name, contact, message } = req.body;
    console.log('-- all good so far ', name, contact, message);
    try {
      let contactMessage = new Contact({ name, message, contact });
      console.log('-- sending mesage ', contactMessage);
      await contactMessage.save();
      console.log('-- all good for saving ');
      res.json(contactMessage);
    } catch (err) {
      console.error(err.message);
      res.status(500).send('Server Error');
    }
  }
);

module.exports = router;
