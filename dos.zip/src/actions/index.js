
export const CARGO_SELECTED = 'CARGO_SELECTED';
export const CARGO_UNSELECTED = 'CARGO_UNSELECTED';

export function rowSelected(cargo) {
	return {
		type: CARGO_SELECTED,
		payload: cargo
	};
}

export function rowUnSelected(cargo) {
	return {
		type: CARGO_UNSELECTED,
		payload: cargo
	};
}