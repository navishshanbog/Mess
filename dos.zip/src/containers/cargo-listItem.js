import React, {Component} from 'react';
import { connect } from 'react-redux';
import { rowSelected, rowUnSelected } from '../actions/index';
import { bindActionCreators } from 'redux';

class CargoListItem extends Component {
	constructor(props) {
		super(props);
		this.state = {
			isSelected: ''
		};
	}

	rowActioned (item) {
		if (this.props.cargoSelected.length > 0) {
			if (this.props.cargoSelected.filter(function(cgo) {return cgo.HouseBill == item.HouseBill;}).length > 0) {
				this.props.rowUnSelected(item);
				this.setState ({isSelected: ''});
				return;
			}
		}
		this.props.rowSelected(item);
		this.setState ({isSelected: 'selected'});
		return; 
	} 

	render() {
		return <tr onClick = { () => {this.rowActioned(this.props.item, this)}} className={this.state.isSelected} > 
                                <td> {this.props.item.ArrivalDate} </td> 
                                <td> {this.props.item.OMT} </td> 
                                <td> {this.props.item.GoodsDescription} </td> 
                                <td> {this.props.item.Role} </td> 
                                <td> {this.props.item.Status} </td> 
                                <td> {this.props.item.ClientID} </td> 
                                <td> {this.props.item.OceanBill} </td> 
                                <td> {this.props.item.HouseBill} </td> 
                                <td> {this.props.item.Vessel}-{this.props.item.Voyage} </td> 
                                <td> {this.props.item.ContainerNbr} </td> 
                                <td> {this.props.item.LowestBill} </td> 
                                <td> {this.props.item.ParentBill} </td> 
                                <td> {this.props.item.CargoType} </td> 
                                <td> {this.props.item.SAC} </td> 
                                <td> {this.props.item.PositiveFind} </td>
                        </tr>
	}
}

function mapStateToProps(state) {
        return {
		cargoSelected: state.selectedCargo
        };
}

export default connect(mapStateToProps, { rowSelected, rowUnSelected })(CargoListItem);