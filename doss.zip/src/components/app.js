import React, { Component } from 'react';
import CargoList from '../containers/cargo-list';
import DossierList from '../containers/dossier-list'


class App extends Component {
  
  render() {
    return (
      <div>
        <CargoList />
        <DossierList />
      </div>
    );
  }
}

export default App;
