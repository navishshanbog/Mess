import React, {Component} from 'react';
import { connect } from 'react-redux';
import { rowSelected, rowUnSelected } from '../actions/index';
import { bindActionCreators } from 'redux';
import CargoListItem from './cargo-listItem';

class CargoList extends Component {
	constructor(props) {
		super(props);
	}

        renderCargoData(cargo) {
                return <CargoListItem key={cargo.HouseBill} item = {cargo} />
        };
        

        render() {
                return  ( <table className="table table-hover">
                                <thead>
                                        <tr>
                                                <th> Arrival Data </th>
                                                <th> OMT </th>
                                                <th> Goods Description </th>
									   <th> Role </th>
                                                <th> Status </th>
                                                <th> Client Id </th>
                                                <th> Ocean Bill </th>
                                                <th> House Bill </th>
                                                <th> Vessel-Voyage </th>
                                                <th> Container Number </th>
                                                <th> Lowest Bill </th>
                                                <th> Parent Bill </th>
                                                <th> Cargo Type </th>
                                                <th> SAC </th>
                                                <th> Positive Find </th>
                                        </tr>
                                </thead>
                                <tbody>
							   {this.props.cargoData.map (this.renderCargoData, this)}  
                                </tbody>
                        </table>
                )    
        }
}

function mapStateToProps(state) {
        return {
		cargoData: state.cargoData,
		cargoSelected: state.selectedCargo
        };
}

export default connect(mapStateToProps, { rowSelected, rowUnSelected })(CargoList);
