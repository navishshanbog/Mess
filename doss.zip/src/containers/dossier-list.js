import React, {Component} from 'react';
import { connect } from 'react-redux';
import DossierListItem from './dossier-listItem';

class DossierList extends Component {
        constructor(props) {
                super(props);
                this.state = {
                         showWYSIWYG: false
                };
        }
        renderCargoDetails(cargoItems) {
                return <DossierListItem key={cargoItems.HouseBill} dosItem={cargoItems} />
             /*   var dosText = `On ${cargoItems.ArrivalDate} the POI imported as ${cargoItems.Role} imported ${cargoItems.GoodsDescription}.

Other details include:
---------------------------
OMT: ${cargoItems.OMT} 
House Bill: ${cargoItems.HouseBill}`;
                return ( <div key={cargoItems.HouseBill}>
                                <span>
                                        <div id={cargoItems.HouseBill} >
                                                <textarea cols="100" defaultValue={dosText} wrap="hard" />
                                                <h1>Inline Editing in Action!</h1>
                                                <p>The "div" element that contains this text is now editable. </p>
                                                <hr />
                                        </div>
                                        <div id="editor1" contentEditable="true" ref={this._handleEditorRef}>
                                                <h1>Inline Editing in Action!</h1>
                                                <p>The "div" element that contains this text is now editable. </p>
                                        </div>
                                        <script>
                                        CKEDITOR.replace( 'editor1' );
                                        </script>
                                </span>
                        </div>
                ); */
        }

        render() {
                if (this.props.cargoSelected.length <= 0) {
                        return (<div> 
                                        <h3> in Dossier </h3>
                                        <hr />
                                        No cargo selected 
                                </div>)
                }

                 if ( this.state.showWYSIWYG  ) {
                        return (
                                <div> 
                                        <h3> in Dossier </h3>
                                        <hr />
                                        <textarea key={this.props.cargoSelected[0].HouseBill} name='editor' cols="100" rows="6" defaultValue={readOnlyText} />
                                </div>
                        )
                } else {
                        <div> 
                                <h3> in Dossier </h3>
                                <hr />
                                {this.props.cargoSelected.map(this.renderCargoDetails, this)} 
                        </div> 
                } 

        }
}

function mapStateToProps(state) {
        return { cargoSelected: state.selectedCargo
        }
}

export default connect(mapStateToProps) (DossierList);