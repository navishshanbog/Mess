import React, {Component} from 'react';
import { connect } from 'react-redux';

class DossierListItem extends Component {

         constructor(props) {
                super(props);
                this.state = {
//                        field_name:props.dosItem.HouseBill,
//                        field_value:this.props.field_value,
//                        showWYSIWYG:false,
                        dosText : `On ${this.props.dosItem.ArrivalDate} the POI imported as ${this.props.dosItem.Role} imported ${this.props.dosItem.GoodsDescription}.<br />
                                  Other details include: <br />
                                  --------------------------- <br />
                                  OMT: ${this.props.dosItem.OMT} <br />
                                  House Bill: ${this.props.dosItem.HouseBill}<br />`
                };

//                this.beginEdit = this.beginEdit.bind(this);
//                this.initEditor = this.initEditor.bind(this);
        }

/*        beginEdit() {
                this.setState({showWYSIWYG:true})
        }
        
        initEditor(field, event) {
                var self = this;
                console.log("FILE NAME ", field);
                      //event.stopPropagation();
                      if (field != '') {
                                let editorID = self.state.field_name;
                                CKEDITOR.replace('editor', { toolbar: "Basic", width: 870, height: 150});
                                var focusManager = new CKEDITOR.focusManager( CKEDITOR.instances.editor );
                                focusManager.focus();
                                CKEDITOR.instances.editor.on('blur', function() {
                                        console.log(" on blur function");
                                        let data = CKEDITOR.instances.editor.getData();
                                        CKEDITOR.instances.editor.destroy();
                                        self.setState({
                                        field_value:escape(data),
                                        showWYSIWYG:false,
                                        field_name:'',
                                        dosText : data
                                        });
                                });
                      }
        }

        createDossierItem() {
                return {};
        }    

         componentDidUpdate() {
             this.initEditor(this.state.field_name, this);    
         }   
*/
        render() {
//                console.log("from render value of showWUSIWYG",this.state.showWYSIWYG);
//                if ( this.state.showWYSIWYG  ) {
                        return (
                                <div dangerouslySetInnerHTML={ {__html:this.state.dosText}} /> 
                        )
/*                } else {
                        return (
                                <div key={this.props.dosItem.HouseBill} className='description_field' onClick={this.beginEdit} dangerouslySetInnerHTML={ {__html:this.state.dosText } } ></div>
                        )
                }*/    
        }
}

function mapStateToProps(state) {
        return { cargoSelected: state.selectedCargo
        }
}

export default connect(mapStateToProps) (DossierListItem);