// State argument is not application state, 
// only the state this reducer is responsible for
import _ from 'lodash';

import { CARGO_SELECTED } from '../actions/index';
import { CARGO_UNSELECTED } from '../actions/index';

export default function (state = [], action) {
	switch(action.type) {
		case CARGO_SELECTED:
			return  [ action.payload, ...state ];  
		case CARGO_UNSELECTED:
			state.forEach(function(result, index) {
				if(result['HouseBill'] === action.payload.HouseBill) {
					state.splice(index, 1);
				}    
			});
			return [].concat(state);		
		case DOSSIER_UPDATED:	
	}
	return state;
}

