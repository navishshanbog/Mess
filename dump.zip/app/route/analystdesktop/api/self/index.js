const express = require("express");

const route = express.Router();

const profileConfig = {
    id: 1,
    display_name: "Analyst Desktop Development User",
    bio: "Analyst Desktop Development User",
    organizations: [
        {
            short_name: "DIBP",
            title: "Department of Immigration and Border Protection"
        }
    ],
    user: {
        username: "ADDEV",
        email: "addev@border.gov.au",
        groups: [
            {
                name: "ADMIN"
            }
        ]
    }
};

const profileGetHandler = (req, res) => {
    res.json(profileConfig).end();
};

route.get("/profile", profileGetHandler);
route.get("/profile/", profileGetHandler);

module.exports = route;