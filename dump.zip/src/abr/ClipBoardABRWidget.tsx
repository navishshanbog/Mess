import * as React from "react";
import { autorun } from "mobx";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import ABRActivityClipboardGroup from "./component/ABRActivityClipboardGroup";

class ClipBoardABRWidget implements IWidget {
    model: IWidgetContext;
    start() {
        this.model.view.setContent({
            main: <ABRActivityClipboardGroup clipboardGroup={this.model.props.clipboardGroup} />
        });
    }
}

export { ClipBoardABRWidget as default, ClipBoardABRWidget }
