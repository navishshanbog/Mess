import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { ABR } from "icon/AnalystDesktopIcons";
import * as ABRConstants from "./ABRConstants";

const ClipBoardABRWidgetEntry : IWidgetEntry = {
    key: "ClipBoardABRSummary",
    keyAliases: [ABRConstants.sourceSystemCode],
    name: "ClipBoard ABR Summary",
    description: "ClipBoard ABR Summary",
    icon: <ABR />,
    largeIcon: <ABR />,
    get widgetType() {
        return import("./ClipBoardABRWidget").then(r => r.default);
    }
};

export { ClipBoardABRWidgetEntry as default, ClipBoardABRWidgetEntry };
