import IMasterEntityRefModel from "entity/IMasterEntityRefModel";

interface IMasterEntityABRModel extends IMasterEntityRefModel {

}

export { IMasterEntityABRModel as default, IMasterEntityABRModel }