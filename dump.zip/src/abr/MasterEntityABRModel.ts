import MasterEntityRefModel from "entity/MasterEntityRefModel";
import IMasterEntityABRModel from "./IMasterEntityABRModel";

class MasterEntityABRModel extends MasterEntityRefModel implements IMasterEntityABRModel {

}

export { MasterEntityABRModel as default, MasterEntityABRModel }