import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import IMasterEntityModel from "entity/IMasterEntityModel";
import MasterEntityABR from "./component/MasterEntityABR";
import AbstractMasterEntityWidget from "entity/AbstractMasterEntityWidget";
import MasterEntityABRModel from "./MasterEntityABRModel";

class MasterEntityABRWidget extends AbstractMasterEntityWidget {
    private _abr = new MasterEntityABRModel();
    get masterEntityRef() {
        return this._abr;
    }
    _setView() {
        this.context.setView(<MasterEntityABR abr={this._abr} />);
    }
}

export { MasterEntityABRWidget as default, MasterEntityABRWidget }