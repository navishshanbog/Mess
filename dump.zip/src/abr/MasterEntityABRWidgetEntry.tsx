import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as ABRConstants from "./ABRConstants";
import { ABR } from "icon/AnalystDesktopIcons";

const MasterEntityABRWidgetEntry : IWidgetEntry = {
    key: "masterEntityABRSummary",
    keyAliases: [ABRConstants.sourceSystemCode],
    name: "Master Entity ABR Summary",
    shortName: "ABR",
    sourceSystemCode: ABRConstants.sourceSystemCode,
    description: "Master Entity ABR Summary",
    icon: <ABR />,
    largeIcon: <ABR />,
    get widgetType() {
        return import("./MasterEntityABRWidget").then(r => r.default);
    }
};

export { MasterEntityABRWidgetEntry as default, MasterEntityABRWidgetEntry };