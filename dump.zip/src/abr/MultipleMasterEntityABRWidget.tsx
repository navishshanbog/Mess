import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import IMultipleMasterEntityListCompositeModel from "entity/IMultipleMasterEntityListCompositeModel";
import MultipleMasterEntityABRSummary from "./component/MultipleMasterEntityABRSummary";

class MultipleMasterEntityABRWidget implements IWidget {
    context: IWidgetContext;
    start() {
        const multipleMasterEntity : IMultipleMasterEntityListCompositeModel = this.context.props.multipleMasterEntity;
        this.context.setView(<MultipleMasterEntityABRSummary multipleMasterEntity={multipleMasterEntity} />);
    }
}

export { MultipleMasterEntityABRWidget as default, MultipleMasterEntityABRWidget }