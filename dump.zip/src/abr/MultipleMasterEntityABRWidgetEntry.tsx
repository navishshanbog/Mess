import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as ABRConstants from "./ABRConstants";
import { ABR } from "icon/AnalystDesktopIcons";

const MultipleMasterEntityABRWidgetEntry : IWidgetEntry = {
    key: "masterEntityABRSummary",
    keyAliases: [ABRConstants.sourceSystemCode + "-multiple"],
    name: "Master Entity ABR Summary",
    shortName: "ABR",
    description: "Master Entity ABR Summary",
    icon: <ABR />,
    largeIcon: <ABR />,
    get widgetType() {
        return import("./MultipleMasterEntityABRWidget").then(r => r.default);
    }
};

export { MultipleMasterEntityABRWidgetEntry as default, MultipleMasterEntityABRWidgetEntry };