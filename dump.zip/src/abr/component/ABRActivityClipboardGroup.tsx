import * as React from "react";
import IAppClipboardGroupModel from "clipboard/IAppClipboardGroupModel";
import { TextField } from 'office-ui-fabric-react/lib/TextField';

interface IABRActivityClipboardGroupProps {
    clipboardGroup: IAppClipboardGroupModel;
}

class ABRActivityClipboardGroup extends React.Component<IABRActivityClipboardGroupProps, any> {
    render() {
        return <div>
            {/* <ABRActivityList list={this.props.clipboardGroup} />   */}
                <TextField  className="user-comments"
                        placeholder='Comments'
                        multiline
                        autoAdjustHeight />
            </div>
    }
}

export { ABRActivityClipboardGroup as default, ABRActivityClipboardGroup, IABRActivityClipboardGroupProps  }