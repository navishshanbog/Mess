import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import * as ABRConstants from "../ABRConstants";
import IMasterEntityABRModel from "../IMasterEntityABRModel";

interface IMasterEntityABRProps {
    position? : number;
    abr: IMasterEntityABRModel;
}

@observer
class MasterEntityABR extends React.Component<IMasterEntityABRProps, any> {
    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[ABRConstants.sourceSystemCode];
        if(source) {
            return (
                <div className="master-entity-abr-summary">
                    <EntityAttributes entity={source} position={this.props.position} type={EntityAttributesType.secondary} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No ABR information available</MessageBar>;
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the ABR summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.abr}
                                    onRenderContent={this._handleRenderContent}
                                    onRenderNotLoaded={this._handleRenderNotLoaded} />;
    }
}

export { 
    MasterEntityABR as default,
    MasterEntityABR,
    IMasterEntityABRProps
}