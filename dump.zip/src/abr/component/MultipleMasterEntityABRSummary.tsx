import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import {IMultipleMasterEntityListCompositeModel} from "../../entity/IMultipleMasterEntityListCompositeModel";
import IMasterEntityModel from "entity/IMasterEntityModel";
import * as ABRConstants from "abr/ABRConstants";
import {MasterEntityABR} from "abr/component/MasterEntityABR";

import MasterEntityABRModel from "abr/MasterEntityABRModel";

interface IMasterEntityABRSummaryProps {
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
}

class MultipleMasterEntityABRSummary extends React.Component<IMasterEntityABRSummaryProps, any> {

    render() {

        let source = [];
        if (this.props.multipleMasterEntity.getSelection() && this.props.multipleMasterEntity.getSelection().getSelection()) {

            source = (this.props.multipleMasterEntity.getSelection().getSelection() as IMasterEntityModel[]).map((item : IMasterEntityModel, index) => {

                let sourceEntry = item.sourceMap[ABRConstants.sourceSystemCode];

                let thisABR = new MasterEntityABRModel();
                thisABR.setData(item);
                // thisABR.setData(sourceEntry);

                // return <MasterEntityABR entity={thisABR} position={index+1} type={EntityAttributesType.secondary} />;
                return <MasterEntityABR key={index} abr={thisABR}  position={index+1} />
            });
        }

        if(source) {
            return (
                <div className="master-entity-abr-summary">
                    {source}
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No ABR information available</MessageBar>;
    }
}

export {
    MultipleMasterEntityABRSummary as default
}