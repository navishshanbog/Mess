enum AppHistoryMode {
    push,
    replace,
    none
}

export { AppHistoryMode as default, AppHistoryMode };