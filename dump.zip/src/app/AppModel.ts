import IAppModel from "./IAppModel";
import IAppPlace from "./IAppPlace";
import IAppRoute from "./IAppRoute";
import IApplet from "./IApplet";
import AppHistoryMode from "./AppHistoryMode";
import * as PathUtils from "util/Path";
import * as LangUtils from "util/Lang";
import { stripLeft } from "util/String";
import { isFunction, isObject } from "util/Lang";
import { observable, action } from "mobx";
import IPathTestResult from "common/IPathTestResult";
import { IAppNavigatorOpenOptions } from "./IAppNavigator";
import IAppView from "./IAppView";
import AppViewModel from "./AppViewModel";
import SyncModel from "common/SyncModel";
import PathTemplate from "common/PathTemplate";
import * as qs from "qs";

interface IAppRouteState {
    applet?: IApplet;
    route: IAppRoute;
}

class AppModel implements IAppModel {
    @observable sync = new SyncModel();
    @observable title = "Analyst Desktop";
    @observable view = new AppViewModel();
    @observable place: IAppPlace;
    @observable.ref activeRoute: IAppRoute;

    private _basePath : string;
    private _host? : any;
    private _location? : any;
    private _history? : any;
    private _historyMode? : AppHistoryMode;
    private _extension? : string;
    private _popStateListener? : (e : any) => any;
    private _routeStates: IAppRouteState[] = [];
    private _activeRouteState: IAppRouteState;

    constructor(routes?: IAppRoute[]) {
        if(routes) {
            routes.forEach((route) => {
                this.addRoute(route);
            });
        }
    }

    addRoute(route : IAppRoute) {
        if(route) {
            this._routeStates.push({ route: route });
        }
    }

    get routes() {
        return this._routeStates.map(s => s.route);
    }

    get extension() {
        return this._extension;
    }

    get host() : any {
        if(!this._host) {
            // by default, the global window reference is used
            this._host = window;
        }
        return this._host;
    }
    set host(value : any) {
        this._host = value;
    }

    get location() : any {
        if(!this._location) {
            // by default, this host location is used
            this._location = this.host.location;
        }
        return this._location;
    }
    set location(value : any) {
        this._location = value;
    }

    get history() : any {
        if(!this._history) {
            // by default, the host history is used
            this._history = this.host.history;
        }
        return this._history;
    }
    set history(value : any) {
        this._history = value;
    }

    get historyMode() : AppHistoryMode {
        if(!this._historyMode) {
            this._historyMode = AppHistoryMode.push;
        }
        return this._historyMode;
    }
    set historyMode(value : AppHistoryMode) {
        this._historyMode = value;
    }

    get basePath() : string {
        if(!this._basePath) {
            this._basePath = PathUtils.sep;
        }
        return this._basePath;
    }
    set basePath(value : string) {
        this._basePath = value;
    }

    public resolvePlaceFromLocation() : IAppPlace {
        const request : IAppPlace = {};
        let path = this.location.pathname;
        if(this.basePath) {
            var basePathIdx = path.indexOf(this.basePath);
            if(basePathIdx >= 0) {
                path = path.substring(basePathIdx + this.basePath.length);
            }
        }
        path = stripLeft(path, PathUtils.sep);

        let ext = PathUtils.extname(path);

        if(ext) {
            path = path.substring(0, path.length - ext.length);
        }

        if(path) {
            request.path = path;
        }

        let search = this.location.search;
        if(search && search.length > 1) {
            request.query = qs.parse(search.substring(1));
        }

        return request;
    }

    private _testRoute(route : IAppRoute, place: IAppPlace) : IPathTestResult {
        if(route.test) {
            return route.test(place);
        } else if(route.pathTemplate) {
            return route.pathTemplate.test(place.path);
        } else if(route.path) {
            return { match: route.path === place.path };
        }
        return { match: false };
    }

    protected _loadImpl(place : IAppPlace) : Promise<any> {
        let matchingRouteState;
        let routePlace;
        this._routeStates.some((routeState) => {
            const tr = this._testRoute(routeState.route, place);
            if(tr.match) {
                matchingRouteState = routeState;
                routePlace = { path: place.path, query: place.query, params: tr.params || {} };
                return true;
            }
        });
        this.place = routePlace || place;
        if(!this._activeRouteState || matchingRouteState !== this._activeRouteState) {
            let currentApplet : IApplet;
            if(this._activeRouteState && this._activeRouteState.applet) {
                if(this._activeRouteState.applet.stop) {
                    this._activeRouteState.applet.stop();
                }
                this._activeRouteState.applet.context = undefined;
            }
            this._activeRouteState = matchingRouteState;
            if(matchingRouteState) {
                this.activeRoute = matchingRouteState.route;

                let factory : () => Promise<IApplet> | IApplet;
                if(matchingRouteState.applet) {
                    factory = () => { return matchingRouteState.applet };
                } else if(this.activeRoute.createApplet) {
                    factory = this.activeRoute.createApplet;
                } else {
                    factory = () => {
                        return Promise.resolve(this.activeRoute.appletType).then((AppletType) => {
                            return new AppletType();
                        });
                    }
                }

                return Promise.resolve(factory()).then((applet) => {
                    applet.context = this;
                    matchingRouteState.applet = applet;
                    applet.start();
                });
            }
            this.activeRoute = undefined;
            return Promise.reject({ status: 404, code: "NOT_FOUND", message: "Unable to find resource", place: place });
        }
        return Promise.resolve();
    }

    protected _loadEnd = () => {
        this.sync.syncEnd();
    }

    protected _loadError = (error) => {
        this.sync.syncError(error);
    }

    @action
    load(place: IAppPlace) : Promise<any> {
        this.view.closeModals();
        this.sync.syncStart();
        return this._loadImpl(place).then(this._loadEnd).catch(this._loadError);
    }

    @action
    loadLocation() : Promise<any> {
        return this.load(this.resolvePlaceFromLocation());
    }

    @action
    open(opts: IAppNavigatorOpenOptions) : Promise<any> {
        const historyMode = opts.historyMode !== undefined && opts.historyMode !== null ? opts.historyMode : this.historyMode;

        if(historyMode === AppHistoryMode.none) {
            return this.load(opts);
        }
        
        const url = this.createUrl(opts);

        switch(historyMode) {
            case AppHistoryMode.push:
                this.history.pushState(null, "", url);
                break;
            case AppHistoryMode.replace:
                this.history.replaceState(null, "", url);
                break;
        }

        return this.loadLocation();
    }

    createUrl(place : IAppPlace) : string {
        let url;
        
        const path = place.path;
        const query = place.query;

        if(!path) {
            url = this.location.pathname;
        } else {
            url = place.params ? new PathTemplate(path).toPath(place.params) : path;
            url = PathUtils.join(PathUtils.sep, this.basePath, url);
            if(this.extension) {
                url += this.extension;
            }
        }

        let queryString;
        if(query) {
            queryString = qs.stringify(query);
        }

        if(queryString) {
            url += "?" + queryString;
        }
        
        return url;
    }

    @action
    init(action?: () => Promise<any> | void) : Promise<any> {
        this._popStateListener = (e) => {
            this.loadLocation();
        };
        this.host.addEventListener("popstate", this._popStateListener);
        this._extension = PathUtils.extname(this.location.pathname);
        this.sync.syncStart();
        return Promise.resolve(action ? action() : undefined).then(() => {
            return this._loadImpl(this.resolvePlaceFromLocation());
        }).then(this._loadEnd).catch(this._loadError);
    }

    @action
    destroy() {
        this.host.removeEventListener("popstate", this._popStateListener);
        delete this._popStateListener;
    }
}

export { AppModel as default, AppModel };