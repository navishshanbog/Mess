import AppModel from "./AppModel";
import DashboardManagerRoute from "widget/DashboardManagerRoute";
import MasterEntitySearchRoute from "entity/MasterEntitySearchRoute";
import MasterEntitySearchResultRoute from "entity/MasterEntitySearchResultRoute";
import MasterEntityRoute from "entity/MasterEntityRoute";
import MultipleMasterEntityRoute from "entity/MultipleMasterEntityRoute";
//import CustomReportRoute from "zzz_reports/CustomReportRoute";
import PNRServiceTestRoute from "risk/traveller/pnr/PNRServiceTestRoute";
import IATServiceTestRoute from "risk/traveller/iat/IATServiceTestRoute";
import ProfileMatchDataServiceTestRoute from "risk/traveller/profilematchdataservice/ProfileMatchDataServiceTestRoute";
import SearchRoute from "search/SearchRoute";
const AppStore = new AppModel([
    DashboardManagerRoute,
    MasterEntitySearchRoute,
    MasterEntitySearchResultRoute,
    MasterEntityRoute,
    MultipleMasterEntityRoute,
//    CustomReportRoute,
    PNRServiceTestRoute, 
    IATServiceTestRoute,
    ProfileMatchDataServiceTestRoute,
    SearchRoute
]);

export { AppStore as default, AppStore };
