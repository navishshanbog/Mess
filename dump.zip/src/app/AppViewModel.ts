import { observable, action, computed } from "mobx";
import IAppView from "./IAppView";
import IAppViewModel from "./IAppViewModel";

class AppViewModel implements IAppViewModel {

    @observable navOn : boolean = false;
    @observable helpOn : boolean = false;
    @observable userProfileOn : boolean = false;
    @observable showReport : boolean = false;
    @observable titleText : string;
    @observable title: string;
    @observable nav: any;
    @observable main: any;
    @observable help: any;

    @computed
    get content() : IAppView {
        return this;
    }

    set content(content : IAppView) {
        this.setContent(content);
    }

    @action
    setContent(content : IAppView) : void {
        this.titleText = content ? content.titleText : undefined;
        this.title = content ? content.title : undefined;
        this.nav = content ? content.nav : undefined;
        this.main = content ? content.main : undefined;
        this.help = content ? content.help : undefined;
    }

    @action
    setNavOn(navOn : boolean) : void {
        this.navOn = navOn;
    }

    @action
    setHelpOn(helpOn : boolean) : void {
        this.helpOn = helpOn;
    }

    @action
    setUserProfileOn(userProfileOn : boolean) : void {
        this.userProfileOn = userProfileOn;
    }

    @action
    setShowReport(showReport : boolean) : void {
        this.showReport = showReport;
    }

    @action
    closeModals() {
        this.navOn = false;
        this.helpOn = false;
        this.userProfileOn = false;
    }
}

export { AppViewModel as default, AppViewModel };