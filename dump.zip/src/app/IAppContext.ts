interface IAppContext {
    props : any;
    setView(view : any) : void;
}

export { IAppContext as default, IAppContext }