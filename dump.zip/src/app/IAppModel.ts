import IAppPlace from "./IAppPlace";
import IAppNavigator from "./IAppNavigator";
import IAppViewModel from "./IAppViewModel";
import IAppRoute from "./IAppRoute";
import ISyncModel from "common/ISyncModel";

interface IAppModel extends IAppNavigator {
    sync: ISyncModel;
    title: string;
    place: IAppPlace;
    view: IAppViewModel;
    routes: IAppRoute[];
    activeRoute: IAppRoute;
    addRoute(route : IAppRoute) : void;
    init() : Promise<any>;
    destroy() : void;
}

export { IAppModel as default, IAppModel };