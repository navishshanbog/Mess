import IAppPlace from "./IAppPlace";
import AppHistoryMode from "./AppHistoryMode";

interface IAppNavigatorOpenOptions extends IAppPlace {
    historyMode?: AppHistoryMode; 
}

interface IAppNavigator {
    createUrl(place: IAppPlace) : string;
    open(opts : IAppNavigatorOpenOptions) : Promise<any>;
}

export { IAppNavigator as default, IAppNavigator, IAppNavigatorOpenOptions };