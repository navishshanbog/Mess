interface IAppPlace {
    path?: string;
    params?: any;
    query?: any;
}

export { IAppPlace as default, IAppPlace };