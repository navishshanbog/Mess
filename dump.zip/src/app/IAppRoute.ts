import IAppView from "./IAppView";
import IAppPlace from "./IAppPlace";
import IPathTestResult from "common/IPathTestResult";
import IPathTemplate from "common/IPathTemplate";
import IApplet from "./IApplet";

interface IAppRoute extends IAppPlace {
    key: string;
    name?: string;
    pathTemplate?: IPathTemplate;
    test?(place: IAppPlace) : IPathTestResult;
    appletType?: Promise<any> | any;
    createApplet?(): Promise<IApplet> | IApplet;
}

export { IAppRoute as default, IAppRoute };