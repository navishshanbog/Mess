interface IAppView {
    titleText?: string;
    title?: any;
    more?: any;
    nav?: any;
    main?: any;
    help?: any;
}

export { IAppView as default, IAppView };