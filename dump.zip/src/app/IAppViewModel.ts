import IAppView from "./IAppView";

interface IAppViewModel extends IAppView {
    content: IAppView;
    navOn: boolean;
    helpOn: boolean;
    userProfileOn: boolean;
    showReport: boolean;
    setContent(content : IAppView) : void;
    setNavOn(navOn : boolean) : void;
    setHelpOn(helpOn : boolean) : void;
    setUserProfileOn(userProfileOn : boolean) : void;
    setShowReport(showReport : boolean) : void;
    closeModals() : void;
}

export { IAppViewModel as default, IAppViewModel };