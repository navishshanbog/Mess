import IAppModel from "./IAppModel";

interface IApp {
    context?: IAppModel;
    start() : void;
    stop?() : void;
}

export { IApp as default, IApp };