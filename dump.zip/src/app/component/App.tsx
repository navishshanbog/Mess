import * as React from "react";
import { observer } from "mobx-react";
import { isFunction, isString } from "util/Lang";
import IAppModel from "../IAppModel";
import IAppRoute from "../IAppRoute";
import Error from "common/component/Error";
import AppStore from "app/AppStore";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Fabric } from "office-ui-fabric-react/lib/Fabric";
import { Image } from "office-ui-fabric-react/lib/Image";
import { Overlay } from "office-ui-fabric-react/lib/Overlay";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import { Callout } from "office-ui-fabric-react/lib/Callout";
import { Dialog, DialogType, DialogFooter } from "office-ui-fabric-react/lib/Dialog";
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { Panel, PanelType } from "office-ui-fabric-react/lib/Panel";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import AppHelp from "./AppHelp";
import UserProfileContainer from "user/component/UserProfileContainer";
import { css } from "@uifabric/utilities/lib/css";
import * as logoUrl from "url-loader?!./AppLogo.png";
import AppClipBoardStore from "clipboard/AppClipBoardStore";
import AppClipboard from "clipboard/component/AppClipboard";
import "./App.scss";

interface IAppProps {
    app?: IAppModel;
    className?: string;
}

const DefaultAppProps : IAppProps = {
    app: AppStore
};

@observer
class AppMain extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        if(this.props.app.view.main) {
            return (
                <main className={css("app-main")} data-is-scrollable={true}>
                    {this.props.app.view.main}
                </main>
            );
        }
        return  null;
    }
}

@observer
class AppError extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        if(this.props.app.sync.error) {
            return <Error className="app-error" error={this.props.app.sync.error} />;
        }
        return null;
    }
}

@observer
class AppNavPanel extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    _handleDismiss = () => {
        this.props.app.view.setNavOn(false);
    }
    render() {
        if(this.props.app.view.nav) {
            return (
                <Panel className="app-nav-panel"
                        isOpen={this.props.app.view.navOn}
                        isLightDismiss={true}
                        onDismiss={this._handleDismiss}
                        type={PanelType.smallFixedNear} headerText={this.props.app.view.titleText || "Analyst Desktop"}>
                    {this.props.app.view.nav}
                </Panel>
            );
        }
        return null;
    }
}

@observer
class AppNavButton extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    _handleClick = () => {
        this.props.app.view.setNavOn(!this.props.app.view.navOn);
    }
    render() {
        if(this.props.app.view.nav) {
            return (
                <button type="button"
                        className={css("app-header-button", "app-nav-button")}
                        title={this.props.app.view.navOn ? "Close Navigation" : "Open Navigation"}
                        aria-label={this.props.app.view.navOn ? "Close Navigation" : "Open Navigation"} onClick={this._handleClick}>
                    <Icon iconName={this.props.app.view.navOn ? "Clear" : "GlobalNavButton"} />
                </button>
            );
        }
        return null;
    }
}

@observer
class AppSyncOverlay extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        return this.props.app.sync.syncing ? <Overlay className="app-sync-overlay"><Spinner className="app-sync-spinner" label="Loading..." /></Overlay> : null;
    }
}

@observer
class AppTitle extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        return (
            <div className="app-title">
                {this.props.app.title}
            </div>
        );
    }
}

class AppLogo extends React.Component<any, any> {
    render() {
        return (
            <div className="app-logo" aria-hidden={true}>
                <Image src={String(logoUrl)} alt="Logo" />
            </div>
        );
    }
}

class AppBrand extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        return (
            <div className={css("app-brand")}>
                <AppLogo />
                <AppTitle app={this.props.app} />
            </div>
        );
    }
}

@observer
class AppViewTitle extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        if(this.props.app.view.title || this.props.app.view.titleText) {
            return (
                <div className={css("app-view-title")}>
                    {this.props.app.view.title || this.props.app.view.titleText}
                </div>
            );
        }
        return null;
    }
}

@observer
class AppClipboardButton extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    _handleClick = () => {
        // NOTE: using store here - we could possibly hang the store off the app (not the app view)
        AppClipBoardStore.setOpen(!AppClipBoardStore.open)
    }
    render() {
        return (
            <button type="button"
                    className={css("app-header-button", "app-clipboard-button")}
                    title="Clipboard"
                    aria-label="Clipboard"
                    onClick={this._handleClick}>
                <Icon iconName="DietPlanNotebook" />
            </button>
        );
    }
}

@observer
class AppHelpButton extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    _handleClick = () => {
        this.props.app.view.setHelpOn(!this.props.app.view.helpOn);
    }
    render() {
        return (
            <button type="button"
                    className={css("app-header-button", "app-help-button")}
                    title="Help"
                    aria-label="Help"
                    onClick={this._handleClick}>
                <Icon iconName="Help" />
            </button>
        );
    }
}

@observer
class AppHelpPanel extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    _handleDismiss = () => {
        this.props.app.view.setHelpOn(false);
    }
    render() {
        return (
            <Panel isOpen={this.props.app.view.helpOn}
                   type={PanelType.medium}
                   onDismiss={this._handleDismiss}
                   isLightDismiss={true}
                   headerText="Analyst Desktop Help">
                <AppHelp />
            </Panel>
        );
    }
}

@observer
class AppUserProfileButton extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    _handleClick = () => {
        this.props.app.view.setUserProfileOn(!this.props.app.view.userProfileOn);
    }
    render() {
        return (
            <button type="button"
                    className={css("app-header-button", "app-user-button")}
                    title="User Profile"
                    aria-label="User Profile"
                    onClick={this._handleClick}>
                <Icon iconName="Contact" />  
            </button>
        );
    }
}

@observer
class AppUserProfilePanel extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    _handleDismiss = () => {
        this.props.app.view.setUserProfileOn(false);
    }
    render() {
        return (
            <Panel isOpen={this.props.app.view.userProfileOn}
                   type={PanelType.medium}
                   onDismiss={this._handleDismiss}
                   isLightDismiss={true}
                   headerText="User Profile">
                <UserProfileContainer />
            </Panel>
        );
    }
}

@observer
class AppHeaderFar extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        return (
            <div className={css("app-header-far")}>
                <AppClipboardButton app={this.props.app}/>
                <AppHelpButton app={this.props.app} />
                <AppUserProfileButton app={this.props.app} />
            </div>
        );
    }
}

class AppHeader extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        return (
            <header className={css("app-header")}>
                <AppNavButton app={this.props.app} />
                <AppBrand app={this.props.app} />
                <AppViewTitle app={this.props.app} />
                <AppHeaderFar app={this.props.app} />
            </header>
        );
    }
}

class App extends React.Component<IAppProps, any> {
    public static defaultProps = DefaultAppProps;
    render() {
        return (
            <Fabric className={css("app", this.props.className)}>
                <AppHeader app={this.props.app} />
                <AppSyncOverlay app={this.props.app} />
                <AppHelpPanel app={this.props.app} />
                <AppNavPanel app={this.props.app} />
                <AppUserProfilePanel app={this.props.app} />
                <AppClipboard clipboard={AppClipBoardStore} />
                <AppClipboard clipboard={AppClipBoardStore} />
                <AppError app={this.props.app} />
                <AppMain app={this.props.app} />
            </Fabric>
        );
    }
}

export { App as default, App };