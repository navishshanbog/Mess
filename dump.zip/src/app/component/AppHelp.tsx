import * as React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Link } from "office-ui-fabric-react/lib/Link";
import AppInfo from "./AppInfo";
import "./AppHelp.scss";

class AppHelp extends React.Component<any, any> {
    render() {
        return (
            <div className="app-help">
                <p>
                    The Analyst Desktop provides a customisable workspace for intelligence analysts, that features a range of apps that can be added or removed according to your needs.
                    You can navigate around the Analyst Desktop via the Navigation Menu Button at the top left of the page.
                </p>
                <p>For more detailed information on Analyst Desktop, please refer to the user guide available at ADD2017/854949. For more information, please contact the <Link href={`mailto:CIE.ICP@border.gov.au?subject=Analyst Desktop${!AppConfig.production ? " (Non Production)" : ""}`}>Intelligence Business Capability</Link> team.</p>
            
                <AppInfo />
            </div>
        );
    }
}

export { AppHelp as default, AppHelp }