import * as React from "react";
import { Pivot, PivotItem, IPivotItemProps, PivotLinkFormat } from "office-ui-fabric-react/lib/Pivot";
import { Link } from "office-ui-fabric-react/lib/Link";
import packageInfo from "package.json";
import "./AppInfo.scss";

class AppInfo extends React.Component<any, any> {
    render() {
        return (
            <div className="app-info">
                <Pivot>
                    <PivotItem key="about" linkText="About">
                        <div className="app-about">
                            <div className="ms-Grid app-values">
                                <div className="ms-Grid-row app-value-row">
                                    <div className="ms-Grid-col ms-sm4"><label className="app-info-label">Version</label></div>
                                    <div className="ms-Grid-col ms-sm8"><div className="app-info-value">{packageInfo.version}</div></div>
                                </div>
                                <div className="ms-Grid-row app-value-row">
                                    <div className="ms-Grid-col ms-sm4"><label className="app-info-label">Repository</label></div>
                                    <div className="ms-Grid-col ms-sm8"><div className="app-info-value"><Link target="_blank" href={packageInfo.repository.url}>{packageInfo.repository.url}</Link></div></div>
                                </div>
                            </div>
                        </div>
                    </PivotItem>
                    <PivotItem key="dependencies" linkText="Dependencies">
                        <div className="app-dependencies">
                            {
                                Object.keys(packageInfo.devDependencies).map((key) => {
                                    return (
                                        <div key={key} className="ms-Grid-row app-value-row">
                                            <div className="ms-Grid-col ms-sm8"><label className="app-info-label">{key}</label></div>
                                            <div className="ms-Grid-col ms-sm4"><div className="app-info-value">{packageInfo.devDependencies[key]}</div></div>
                                        </div>
                                    );
                                })
                            }
                        </div>
                    </PivotItem>
                </Pivot>
            </div>
        );
    }
}

export { AppInfo as default, AppInfo }