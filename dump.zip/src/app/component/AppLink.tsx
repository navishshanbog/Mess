import * as React from "react";
import IAppNavigator from "../IAppNavigator";
import IAppPlace from "../IAppPlace";
import AppStore from "../AppStore";

interface IAppLinkProps {
    navigator?: IAppNavigator;
    place?: IAppPlace;
    title?: string;
    className?: string;
    onClick?: () => void;
}

const AppLinkDefaultProps : IAppLinkProps = {
    navigator: AppStore
};

class AppLink extends React.Component<IAppLinkProps, undefined> {
    public static defaultProps = AppLinkDefaultProps;
    _handleClick = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        if(this.props.place) {
            this.props.navigator.open(this.props.place);
        }
        if(this.props.onClick) {
            this.props.onClick();
        }
    }

    render() {
        const href = this.props.place ? this.props.navigator.createUrl(this.props.place) : "#";
        const content = React.Children.count(this.props.children) > 0 ? this.props.children : this.props.title;

        return (
            <a className={this.props.className} title={this.props.title} href={href} onClick={this._handleClick}>{content}</a>
        );
    }
}

export { AppLink as default, AppLink, IAppLinkProps };