/**
 * This is an example of using glamor
 */
import { css } from "glamor";

import {
    DefaultPalette,
    FontSizes
} from '@uifabric/styling';

const headerHeight = "32px";

const AppHeaderRule = css({
    backgroundColor: DefaultPalette.neutralDark,
    height: headerHeight,
    lineHeight: headerHeight,
    left: "0px",
    top: "0px",
    right: "0px",
    position: "fixed",
    zIndex: "600",
    display: "flex",
    justifyContent: "flex-start",
    alignItems: "center"
});

const headerButtonWidth = "32px"; 

const AppHeaderButtonRule = css({
    border: "none",
    outline: "none",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    color: DefaultPalette.white,
    backgroundColor: "transparent",
    height: headerHeight,
    width: headerButtonWidth,
    fontSize: FontSizes.medium,
    cursor: "pointer",
    "&:hover": {
        color: DefaultPalette.white,
        backgroundColor: DefaultPalette.neutralSecondary
    },
    "&:active": {
        color: DefaultPalette.white,
        backgroundColor: DefaultPalette.neutralSecondary
    }
});

const AppBrandRule = css({
    marginLeft: "8px",
    marginRight: "8px",
    height: headerHeight,
    position: "relative",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    "& .app-title": {
        color: DefaultPalette.neutralLighter,
        fontSize: FontSizes.medium,
        zIndex: 2
    },
    "& .app-logo": {
        zIndex: 1,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        position: "absolute",
        top: "0px",
        right: "0px",
        bottom: "0px",
        left: "0px",
    }
});

const AppViewTitleRule = css({
    marginLeft: "8px",
    marginRight: "8px",
    color: DefaultPalette.neutralLighter,
    fontSize: FontSizes.medium
});

const AppHeaderFarRule = css({
    position: "absolute",
    top: "0px",
    right: "0px",
    bottom: "0px",
    backgroundColor: "transparent",
    display: "flex",
    justifyContent: "flex-end",
    alignItems: "center"
});

const AppMainRule = css({
    position: "fixed",
    top: headerHeight,
    left: "0px",
    right: "0px",
    bottom: "0px",
    overflow: "auto"
});

export {
    AppHeaderRule,
    AppHeaderButtonRule,
    AppBrandRule,
    AppViewTitleRule,
    AppHeaderFarRule,
    AppMainRule
}