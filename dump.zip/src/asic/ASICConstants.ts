const sourceSystemCode = "ASIC";

export { sourceSystemCode }