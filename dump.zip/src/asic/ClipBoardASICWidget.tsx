import * as React from "react";
import { autorun } from "mobx";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import ASICActivityClipboardGroup from "./component/ASICActivityClipboardGroup";

class ClipBoardASICWidget implements IWidget {
    model: IWidgetContext;
    start() {
        this.model.view.setContent({
            main: <ASICActivityClipboardGroup clipboardGroup={this.model.props.clipboardGroup} />
        });
    }
}

export { ClipBoardASICWidget as default, ClipBoardASICWidget }
