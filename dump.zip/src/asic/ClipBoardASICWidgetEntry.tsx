import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { ASIC } from "icon/AnalystDesktopIcons";
import * as ASICConstants from "./ASICConstants";

const ClipBoardASICWidgetEntry : IWidgetEntry = {
    key: "ClipBoardASICSummary",
    keyAliases: [ASICConstants.sourceSystemCode],
    name: "ClipBoard ASIC Summary",
    description: "ClipBoard ASIC Summary",
    icon: <ASIC />,
    largeIcon: <ASIC />,
    get widgetType() {
        return import("./ClipBoardASICWidget").then(r => r.default);
    }
};

export { ClipBoardASICWidgetEntry as default, ClipBoardASICWidgetEntry };
