import IMasterEntityRefModel from "entity/IMasterEntityRefModel";

interface IMasterEntityASICModel extends IMasterEntityRefModel {

}

export { IMasterEntityASICModel as default, IMasterEntityASICModel }