import MasterEntityRefModel from "entity/MasterEntityRefModel";
import IMasterEntityASICModel from "./IMasterEntityASICModel";

class MasterEntityASICModel extends MasterEntityRefModel implements IMasterEntityASICModel {

}

export { MasterEntityASICModel as default, MasterEntityASICModel }