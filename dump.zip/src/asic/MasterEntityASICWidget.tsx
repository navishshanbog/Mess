import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import IMasterEntityModel from "entity/IMasterEntityModel";
import MasterEntityASIC from "./component/MasterEntityASIC";
import AbstractMasterEntityWidget from "entity/AbstractMasterEntityWidget";
import MasterEntityASICModel from "./MasterEntityASICModel";

class MasterEntityASICWidget extends AbstractMasterEntityWidget {
    private _asic = new MasterEntityASICModel();
    get masterEntityRef() {
        return this._asic;
    }
    _setView() {
        this.context.setView(<MasterEntityASIC asic={this._asic} />);
    }
}

export { MasterEntityASICWidget as default, MasterEntityASICWidget }