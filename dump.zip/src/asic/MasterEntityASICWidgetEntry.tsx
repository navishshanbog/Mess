import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as ASICConstants from "./ASICConstants";
import { ASIC} from "icon/AnalystDesktopIcons";

const MasterEntityASICWidgetEntry : IWidgetEntry = {
    key: "masterEntityASICSummary",
    keyAliases: [ASICConstants.sourceSystemCode],
    name: "Master Entity ASIC Summary",
    shortName: "ASIC",
    sourceSystemCode: ASICConstants.sourceSystemCode,
    description: "Master Entity ASIC Summary",
    icon: <ASIC />,
    largeIcon: <ASIC />,
    get widgetType() {
        return import("./MasterEntityASICWidget").then(r => r.default);
    }
};

export { MasterEntityASICWidgetEntry as default, MasterEntityASICWidgetEntry };