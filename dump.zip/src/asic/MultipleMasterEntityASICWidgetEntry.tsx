import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as ASICConstants from "./ASICConstants";
import { ASIC} from "icon/AnalystDesktopIcons";

const MultipleMasterEntityASICWidgetEntry : IWidgetEntry = {
    key: "masterEntityASICSummary",
    keyAliases: [ASICConstants.sourceSystemCode + "-multiple"],
    name: "Master Entity ASIC Summary",
    shortName: "ASIC",
    sourceSystemCode: ASICConstants.sourceSystemCode,
    description: "Master Entity ASIC Summary",
    icon: <ASIC />,
    largeIcon: <ASIC />,
    get widgetType() {
        return import("./MultipleMasterEntityASICWidget").then(r => r.default);
    }
};

export { MultipleMasterEntityASICWidgetEntry as default, MultipleMasterEntityASICWidgetEntry };