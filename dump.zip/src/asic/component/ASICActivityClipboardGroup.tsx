import * as React from "react";
import IAppClipboardGroupModel from "clipboard/IAppClipboardGroupModel";
import { TextField } from 'office-ui-fabric-react/lib/TextField';

interface IASICActivityClipboardGroupProps {
    clipboardGroup: IAppClipboardGroupModel;
}

class ASICActivityClipboardGroup extends React.Component<IASICActivityClipboardGroupProps, any> {
    render() {
        return <div>
            {/* <ASICActivityList list={this.props.clipboardGroup} />   */}
                <TextField  className="user-comments"
                        placeholder='Comments'
                        multiline
                        onChanged={(newUserComments) => {this.props.clipboardGroup.userComments = newUserComments}}
                        value={this.props.clipboardGroup.userComments}
                        autoAdjustHeight />
            </div>
    }
}

export { ASICActivityClipboardGroup as default, ASICActivityClipboardGroup, IASICActivityClipboardGroupProps  }