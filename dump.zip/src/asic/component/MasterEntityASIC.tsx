import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import * as ASICConstants from "../ASICConstants";
import IMasterEntityASICModel from "../IMasterEntityASICModel";

interface IMasterEntityASICProps {
    asic: IMasterEntityASICModel;
}

@observer
class MasterEntityASIC extends React.Component<IMasterEntityASICProps, any> {
    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[ASICConstants.sourceSystemCode];
        if(source) {
            return (
                <div className="master-entity-asic-summary">
                    <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No ASIC information available</MessageBar>;
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the ASIC summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.asic}
                                    onRenderContent={this._handleRenderContent}
                                    onRenderNotLoaded={this._handleRenderNotLoaded} />;
    }
}

export { 
    MasterEntityASIC as default,
    MasterEntityASIC,
    IMasterEntityASICProps
}