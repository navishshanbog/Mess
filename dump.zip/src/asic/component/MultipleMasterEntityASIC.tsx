import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import * as ASICConstants from "../ASICConstants";
import {IMultipleMasterEntityListCompositeModel} from "entity/IMultipleMasterEntityListCompositeModel";
import {IMasterEntityModel} from "entity/IMasterEntityModel";

interface IMultipleMasterEntityASICProps {
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
}

@observer
class MultipleMasterEntityASIC extends React.Component<IMultipleMasterEntityASICProps, any> {

    render() {

        let source = [];
        if (this.props.multipleMasterEntity.getSelection() && this.props.multipleMasterEntity.getSelection().getSelection()) {

            source = (this.props.multipleMasterEntity.getSelection().getSelection() as IMasterEntityModel[]).map((item : IMasterEntityModel, index) => {
                let sourceEntry = item.sourceMap[ASICConstants.sourceSystemCode];
                return <EntityAttributes key={index} entity={sourceEntry} position={index+1} type={EntityAttributesType.secondary} />;
            });
        }

        if(source) {
            return (
                <div className="master-entity-asic-summary">
                    {source}
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No ASIC information available</MessageBar>;
    }
}

export {
    MultipleMasterEntityASIC as default,
    MultipleMasterEntityASIC,
    IMultipleMasterEntityASICProps
}