import { action } from "mobx";
import IActivityFilter from "common/IActivityFilter";
import IBAGSActivity from "./IBAGSActivity";
import IListModel from "common/IListModel";
import ISort from "common/ISort";
import * as StringUtils from "util/String";
import * as SearchUtils from "util/Search";
import * as SortUtils from "util/Sort";
import * as moment from "moment";
import * as DateUtils from "util/Date";
import * as ColumnTextHelper from "common/component/ColumnTextHelper";
import { BAGSActivityColumns, CraftMovementDate } from "./component/BAGSActivityColumns";
import BAGSServiceContext from "./BAGSServiceContext";
import { IBAGSActivitiesGetRequest } from "./IBAGSService";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IMasterEntitySource from "entity/IMasterEntitySource";
import { Data as DateDataFormats } from "common/DateFormats";
import * as BAGSConstants from "./BAGSConstants";
import IBAGSEventNotification from "bags/IBAGSEventNotification";

const textFilterItemImpl = (item: IBAGSActivity, text: string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, BAGSActivityColumns), text);
};

const textFilterItem = (item: IBAGSActivity, text: string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items: IBAGSActivity[], text: string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IBAGSActivity, test : moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.craftMovementDate), test);
};

const toFilterItem = (item: IBAGSActivity, test: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.craftMovementDate), test);
};

const rangeFilterItem = (item: IBAGSActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items: IBAGSActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items : IBAGSActivity[], activityFilter : IActivityFilter) => {
    return activityFilter ? rangeFilter(textFilter(items, activityFilter.filterText), activityFilter.filterFromDate, activityFilter.filterToDate) : items;
};

const toSortValue = (item : IBAGSActivity, field: string) => {
    if(item) {
        if(field === CraftMovementDate.fieldName) {
            return DateUtils.dateFromDataText(item.craftMovementDate);
        }
        return item[field];
    }
};

const compare = (a : IBAGSActivity, b : IBAGSActivity, sort : ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IBAGSActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const getByCompositeId = (compositeId : string) : Promise<IBAGSActivity[]> => {
    const compositeIdComponents = compositeId.split('|');
    // super poo
    const req : IBAGSActivitiesGetRequest = {
        travelDocNbr: compositeIdComponents[0],
        travelDocCntryCode: compositeIdComponents[1],
        birthDate: moment(compositeIdComponents[2], DateDataFormats.key, true).format(DateDataFormats.default),
        sexCode: compositeIdComponents[3]
    };
    return BAGSServiceContext.ref.getBAGSActivities(req);
}

const getForMasterEntitySource = (masterEntitySource : IMasterEntitySource) : Promise<IBAGSActivity[]> =>  {
    let allItems : IBAGSActivity[] = [];
    return Promise.all(masterEntitySource.sourceEntities.map((entity) => {
        if(entity.ref && entity.ref.sourceRelatedKeyValue) {
            return getByCompositeId(entity.ref.sourceRelatedKeyValue).then((items) => {
                allItems = allItems.concat(items);
            });
        }
        return Promise.resolve();
    })).then(() => {
        return Promise.resolve(allItems);
    });
};

const loadDone = action((list: IListModel<IBAGSActivity>, items: IBAGSActivity[]) => {
    list.setItems(items);
    list.sync.syncEnd();
});

const loadError = action((list:  IListModel<IBAGSActivity>, error : any) => {
    list.sync.syncError(error);
});

const getForMasterEntity = (masterEntity : IMasterEntityModel) : Promise<IBAGSActivity[]> => {
    const source = masterEntity.sourceMap[BAGSConstants.sourceSystemCode];
    return source ? getForMasterEntitySource(source) : Promise.resolve([]);
};

const loadForMasterEntity = action((list:  IListModel<IBAGSActivity>,
                                    masterEntity: IMasterEntityModel,
                                    bagsEventEventNotification: IBAGSEventNotification) : Promise<any> => {

    const syncId = masterEntity.masterEntityId;
    if(syncId !== list.sync.id) {
        list.sync.syncStart({ id: syncId });
        return getForMasterEntity(masterEntity).then((items) => {
            if(syncId === list.sync.id) {
                loadDone(list, items);

                if (bagsEventEventNotification) {
                    bagsEventEventNotification.bagsActivityDataLoaded(syncId, items);
                }
            }
        }).catch((error) => {
            if(syncId === list.sync.id) {
                loadError(list, error);
            }
        });
    }
    return Promise.resolve();
});

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getByCompositeId,
    getForMasterEntitySource,
    getForMasterEntity,
    loadForMasterEntity
};