import Context from "common/Context";
import IBAGSService from "./IBAGSService";
import RestBAGSService from "./RestBAGSService";

const BAGSServiceContext = new Context<IBAGSService>({
    ref: new RestBAGSService()
});

export { BAGSServiceContext as default, BAGSServiceContext };