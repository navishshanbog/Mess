import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as BAGSConstants from "./BAGSConstants";
import { BAGS } from "icon/AnalystDesktopIcons";

const ClipBoardBAGSWidgetEntry : IWidgetEntry = {
    key: "clipBoardBAGSSummary",
    keyAliases: [BAGSConstants.sourceSystemCode],
    name: "ClipBoard BAGS Summary",
    description: "ClipBoard BAGS Summary",
    icon: <BAGS />,
    largeIcon: <BAGS />,
    get widgetType() {
        return import("./ClipBoardBAGSWidget").then(r => r.default);
    }
};

export { ClipBoardBAGSWidgetEntry as default, ClipBoardBAGSWidgetEntry };
