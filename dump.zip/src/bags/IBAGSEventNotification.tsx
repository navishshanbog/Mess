import IBAGSActivity from "bags/IBAGSActivity";

interface IBAGSEventNotification {

    bagsActivityDataLoaded(id : string, items : IBAGSActivity[]);
}

export { IBAGSEventNotification as default, IBAGSEventNotification };