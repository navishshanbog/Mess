import IMasterEntityModel from "entity/IMasterEntityModel";
import IMasterEntityRefModel from "entity/IMasterEntityRefModel";
import IActivityListModel from "common/IActivityListModel";
import IBAGSActivity from "./IBAGSActivity";

interface IMasterEntityBAGSModel extends IMasterEntityRefModel {
    activityList: IActivityListModel<IBAGSActivity>;
}

export { IMasterEntityBAGSModel as default, IMasterEntityBAGSModel }