import { observable, action, computed } from "mobx";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IBAGSActivity from "./IBAGSActivity";
import ActivityListModel from "common/ActivityListModel";
import * as BAGSActivityHelper from "./BAGSActivityHelper";
import IBAGSEventNotification from "bags/IBAGSEventNotification";

class MasterEntityBAGSActivityListModel extends ActivityListModel<IBAGSActivity> {
    @observable masterEntity: IMasterEntityModel;

    private _BAGSEventEventNotification : IBAGSEventNotification;

    constructor(notification: IBAGSEventNotification) {
        super();
        this._BAGSEventEventNotification = notification;
    }

    set notification(value: IBAGSEventNotification) {
        this._BAGSEventEventNotification = value;
    }

    get notification() {
        return this._BAGSEventEventNotification;
    }

    @action
    setMasterEntity(masterEntity: IMasterEntityModel) : Promise<any> {
        if(masterEntity !== this.masterEntity) {
            this.masterEntity = masterEntity;
            if(masterEntity) {
                this.filter.clear();
                return BAGSActivityHelper.loadForMasterEntity(this, this.masterEntity, this._BAGSEventEventNotification);
            }
            this.clear();
        }
        return Promise.resolve();
    }

    @computed
    get itemsView() {
        const r = this.masterEntity ? 
            BAGSActivityHelper.filter(BAGSActivityHelper.filter(this.items, this.masterEntity.activityFilter), this.filter) :
            this.items.slice(0);
        return BAGSActivityHelper.sort(r, this.sort);
    }   
}

export { MasterEntityBAGSActivityListModel as default, MasterEntityBAGSActivityListModel }