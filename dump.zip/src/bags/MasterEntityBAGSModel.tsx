import { observable, action, computed } from "mobx";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IMasterEntityBAGSModel from "./IMasterEntityBAGSModel";
import MasterEntityRefModel from "entity/MasterEntityRefModel";
import MasterEntityBAGSActivityListModel from "./MasterEntityBAGSActivityListModel";
import AppMultipleMasterEntityListCompositeStore from "entity/AppMultipleMasterEntityListCompositeStore";
import { sourceSystemCode } from "./BAGSConstants";

class MasterEntityBAGSModel extends MasterEntityRefModel implements IMasterEntityBAGSModel {
    @observable activityList = new MasterEntityBAGSActivityListModel(AppMultipleMasterEntityListCompositeStore);

    @action
    setRef(ref : IMasterEntityModel) {
        super.setRef(ref);
        if(ref) {
            // NOTE: this is a temporary approach to fixing the source system caching issue
            // In reality - these 'MasterEntity<Source>Model' types aren't actually needed
            const source = ref.sourceMap[sourceSystemCode];
            if(source) {
                let activityList : MasterEntityBAGSActivityListModel = source.rel.activityList;
                if(!activityList) {
                    activityList = new MasterEntityBAGSActivityListModel(AppMultipleMasterEntityListCompositeStore);
                    source.setRel({ activityList: activityList });
                }
                this.activityList = activityList;
                return activityList.setMasterEntity(ref);
            }
        }
    }
}

export { MasterEntityBAGSModel as default, MasterEntityBAGSModel }