import * as React from "react";
import MasterEntityBAGS from "./component/MasterEntityBAGS";
import AbstractMasterEntityWidget from "entity/AbstractMasterEntityWidget";
import MasterEntityBAGSModel from "./MasterEntityBAGSModel";

class MasterEntityBAGSWidget extends AbstractMasterEntityWidget {
    private _bags = new MasterEntityBAGSModel();
    protected get masterEntityRef() {
        return this._bags;
    }
    _setView() {
        this.context.setView(<MasterEntityBAGS bags={this._bags} />);
    }
}

export { MasterEntityBAGSWidget as default, MasterEntityBAGSWidget }
