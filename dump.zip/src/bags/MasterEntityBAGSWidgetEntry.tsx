import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as BAGSConstants from "./BAGSConstants";
import { BAGS } from "icon/AnalystDesktopIcons";

const MasterEntityBAGSWidgetEntry : IWidgetEntry = {
    key: "masterEntityBAGSSummary",
    keyAliases: [BAGSConstants.sourceSystemCode],
    name: "Master Entity BAGS Summary",
    shortName: "BAGS",
    sourceSystemCode: BAGSConstants.sourceSystemCode,
    description: "Master Entity BAGS Summary",
    icon: <BAGS />,
    largeIcon: <BAGS />,
    get widgetType() {
        return import("./MasterEntityBAGSWidget").then(r => r.default);
    }
};

export { MasterEntityBAGSWidgetEntry as default, MasterEntityBAGSWidgetEntry };