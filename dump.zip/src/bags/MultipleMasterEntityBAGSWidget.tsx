import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import IMultipleMasterEntityListCompositeModel from "entity/IMultipleMasterEntityListCompositeModel";
import MultipleMasterEntityBAGS from "bags/component/MultipleMasterEntityBAGS";


class MultipleMasterEntityBAGSWidget implements IWidget {
    context: IWidgetContext;
    start() {
        const multipleMasterEntity : IMultipleMasterEntityListCompositeModel = this.context.props.multipleMasterEntity;
        this.context.setView(<MultipleMasterEntityBAGS multipleMasterEntity={multipleMasterEntity} />);
    }
}

export { MultipleMasterEntityBAGSWidget as default, MultipleMasterEntityBAGSWidget }
