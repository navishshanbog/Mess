import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IBAGSDragAndDrop }  from "./MasterEntityBAGS";
import ListContainer from "common/component/ListContainer";
import ListTotal from "common/component/ListTotal";
import Details from "common/component/Details";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import IBAGSActivity from "../IBAGSActivity";
import BAGSActivityListDetailView from "./BAGSActivityListDetailView";
import IActivityFilterModel from "common/IActivityFilterModel";
import * as ActivityFilterMenuHelper from "common/component/ActivityFilterMenuHelper";
import IMasterEntityModel from "entity/IMasterEntityModel";

interface IBAGSActivityListProps {
    // make optional
    position?: number;
    list: IListModel<IBAGSActivity>;
    entityModel?: IMasterEntityModel;
    filter?: IActivityFilterModel;
    sort?: ISortModel;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:IBAGSDragAndDrop) => void;
    enableRowSelection?: boolean;
    customClipboardRowAndHeader?: boolean;
}

class BAGSActivityListCommandBar extends React.Component<IBAGSActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.filter) {
            items.push(ActivityFilterMenuHelper.createActivityFilterItem(this.props.filter));
        }
        if(items.length > 0) {
            return <CommandBar className="bags-activity-list-command-bar" items={items} />;
        }
        return null;
    }
}

class BAGSActivityList extends React.Component<IBAGSActivityListProps, any> {
    _handleRenderItems = (items : IBAGSActivity[]) => {

        return <BAGSActivityListDetailView items={items}
                                           sort={this.props.sort}
                                           entityModel={this.props.entityModel}
                                           customClipboardRowAndHeader = {this.props.customClipboardRowAndHeader}
                                           enableRowSelection={this.props.enableRowSelection}
                                           onItemsDragStart={this.props.onItemsDragStart} />;
    }
    render() {
        return (
            <ListContainer className="bags-activity-list"
                            typeLabel="BAGS Activities"
                            list={this.props.list}
                            onRenderItems={this._handleRenderItems} />
            
        );
    }
}

class BAGSActivityListContainer extends React.Component<IBAGSActivityListProps, any> {
    _handleOpenChange = (open) => {
        this.props.list.setVisible(open);
    }
    render() {
        let positionValue;
        if (this.props.position) {
            positionValue = "(" + this.props.position + ") ";
        }

        return (
            <Details open={this.props.list.visible}
                    summary={<span>{positionValue}BAGS Activities <ListTotal list={this.props.list} /></span>}
                    onOpenChange={this._handleOpenChange}
                    controlOnHeaderClick={true}>
                <BAGSActivityListCommandBar {...this.props} />
                <BAGSActivityList {...this.props} />
            </Details>
        );
    }
}

export { BAGSActivityListContainer as default, BAGSActivityListContainer, BAGSActivityList, IBAGSActivityListProps }