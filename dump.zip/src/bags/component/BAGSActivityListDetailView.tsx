import * as React from "react";
import { observer } from "mobx-react";
import { action } from "mobx";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    ColumnActionsMode,
    Selection,
    SelectionMode,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import Error from "common/component/Error";
import IBAGSActivity from "../IBAGSActivity";
import BAGSActivityColumns from "./BAGSActivityColumns";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import { IBAGSDragAndDrop } from "./MasterEntityBAGS";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import * as BAGSConstants from "../BAGSConstants";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import "./BAGSActivityListDetailView.scss";
import { IconButton } from 'office-ui-fabric-react/lib/Button';
import {DetailsHeader} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import {IDetailsHeaderProps} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import * as BAGSActivityHelper from "../BAGSActivityHelper";
import IMasterEntityModel from "entity/IMasterEntityModel";



interface IBAGSActivityListDetailViewProps {
    items?: IBAGSActivity[];
    sort?: ISortModel;
    entityModel?: IMasterEntityModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>,dragAndDrop?: IBAGSDragAndDrop) => void;
    enableRowSelection?: boolean;
    customClipboardRowAndHeader?: boolean;
}

const DefaultBAGSActivityListDetailViewProps : IBAGSActivityListDetailViewProps = {
    clipBoard: AppClipboardStore
};

@observer
class BAGSActivityListDetailView extends React.Component<IBAGSActivityListDetailViewProps, any> {

    private _selection: Selection;
    private entityModel: IMasterEntityModel;

    public static defaultProps = DefaultBAGSActivityListDetailViewProps;

    constructor(props: IBAGSActivityListDetailViewProps) {
        super(props);
        this._selection = new Selection({
        });

        // work around as is not being copied by super class.
        this.entityModel = props.entityModel;
    }

    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.customClipboardRowAndHeader) {
            this.props.sort.toggleSort(column.fieldName);
            this.props.clipBoard.updateSortOrderForItems(BAGSActivityHelper.sort(this.props.items, this.props.sort), BAGSConstants.sourceSystemCode);
        } else  {
            this.props.sort.toggleSort(column.fieldName);
        }
    }

    private _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        let dragandDrop: IBAGSDragAndDrop = {items: this._selection.getSelection() as IBAGSActivity[], columnsToReport: BAGSActivityColumns, entityModel:this.props.entityModel};
        this.props.onItemsDragStart(e, dragandDrop);
    }

    _removeRowFromSelection(item) {
       this.props.clipBoard.removeItemFromGroup(item, BAGSConstants.sourceSystemCode);
    }

    private _onRenderRow = (props : IDetailsRowProps) => {
        var item = props.item;
        if(this.props.customClipboardRowAndHeader) {
           return (
                <div className="bags-custom-cb-row">
                    <div className="bags-custom-row-render-action">
                        <IconButton className="custom-action-red"
                                    iconProps={ { iconName: 'SkypeMinus' } }
                                    title='Delete'
                                    ariaLabel='Delete'
                                    onClick={this._removeRowFromSelection.bind(this, item)}/>
                    </div>
                    <div className="bags-custom-row">
                        <DetailsRow {...props} />
                    </div>
                </div>
           );
        }
        return (
            <div draggable={true} onDragStart={this._handleDragStart}>
                <DetailsRow {...props} />
            </div>
        );
    }

    _onRenderHeader = (props: IDetailsHeaderProps) =>{
        return (
            <div className="bags-custom-header">
                <DetailsHeader {...props} />
            </div>
        );
    }

    render() {
        // setup columns
        const columns = ColumnSortHelper.applySort(BAGSActivityColumns, this.props.sort);
        return (
            <div className="bags-activity-list-detail-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                                items={this.props.items}
                                onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                layoutMode={DetailsListLayoutMode.fixedColumns}
                                constrainMode={ConstrainMode.unconstrained}
                                onRenderRow = {this._onRenderRow}
                                onRenderDetailsHeader = {this.props.customClipboardRowAndHeader ? this._onRenderHeader: undefined}
                                selection={this._selection}
                                selectionMode={SelectionMode.multiple}
                                checkboxVisibility={this.props.enableRowSelection ? CheckboxVisibility.onHover: CheckboxVisibility.hidden} />
            </div>
        );
    }
}

export {
    BAGSActivityListDetailView as default,
    BAGSActivityListDetailView,
    IBAGSActivityListDetailViewProps
}
