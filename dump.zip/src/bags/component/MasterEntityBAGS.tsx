import * as React from "react";
import { observer } from "mobx-react";
import { action } from "mobx";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import BAGSActivityList from "./BAGSActivityList";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import * as BAGSConstants from "../BAGSConstants";
import IMasterEntityBAGSModel from "../IMasterEntityBAGSModel";
import IBAGSActivity from "../IBAGSActivity";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import {IMasterEntityModel} from "entity/IMasterEntityModel";


interface IMasterEntityBAGSProps {
    bags?: IMasterEntityBAGSModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
}

const DefaultBAGSActivityListDetailViewProps : IMasterEntityBAGSProps = {
    clipBoard: AppClipboardStore
};

interface IBAGSDragAndDrop {
    items: IBAGSActivity[];
    columnsToReport?: any[];
    entityModel?: IMasterEntityModel;
}

@observer
class MasterEntityBAGS extends React.Component<IMasterEntityBAGSProps, any> {
    public static defaultProps = DefaultBAGSActivityListDetailViewProps;
    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, dragAndDrop?:IBAGSDragAndDrop) => {
        e.stopPropagation();
        const entityRef = this.props.bags.ref;
        if(dragAndDrop.items.length > 0) {
            const transferData = {
                type: BAGSConstants.sourceSystemCode,
                items: dragAndDrop.items,
                columns: dragAndDrop.columnsToReport
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            this.props.clipBoard.openClipboard();
            this.props.clipBoard.setDraggedEntity(entityRef);
        }), 10);
    }

    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[BAGSConstants.sourceSystemCode];
        if(source) {
            return (
                <div className="master-entity-bags-summary">
                    <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                    <BAGSActivityList list={this.props.bags.activityList}
                                      sort={this.props.bags.activityList.sort}
                                      filter={this.props.bags.activityList.filter}
                                      enableRowSelection={true}
                                      onItemsDragStart={this._handleItemsDragStart} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No BAGS information available</MessageBar>;
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the BAGS summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.bags}
                                        onRenderContent={this._handleRenderContent}
                                        onRenderNotLoaded={this._handleRenderNotLoaded} />;
    }
}

export {
    MasterEntityBAGS as default,
    MasterEntityBAGS,
    IMasterEntityBAGSProps,
    IBAGSDragAndDrop
}