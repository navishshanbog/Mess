import * as React from "react";
import { observer } from "mobx-react";
import { action } from "mobx";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import BAGSActivityList from "./BAGSActivityList";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import * as BAGSConstants from "../BAGSConstants";
import IMasterEntityBAGSModel from "../IMasterEntityBAGSModel";
import IBAGSActivity from "../IBAGSActivity";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import {IMultipleMasterEntityListCompositeModel} from "entity/IMultipleMasterEntityListCompositeModel";
import {IMasterEntityModel} from "entity/IMasterEntityModel";
import {MasterEntityRefModel} from "entity/MasterEntityRefModel";
import {IBAGSDragAndDrop} from "./MasterEntityBAGS";
import IMasterEntityRefModel from "entity/IMasterEntityRefModel";


interface IMasterEntityBAGSProps {
    // bags?: IMasterEntityBAGSModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
}

/* const DefaultBAGSActivityListDetailViewProps : IMasterEntityBAGSProps = {
    clipBoard: AppClipboardStore
}; */

@observer
class MultipleMasterEntityBAGS extends React.Component<IMasterEntityBAGSProps, any> {

    // public static defaultProps = DefaultBAGSActivityListDetailViewProps;
    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, dragAndDrop?: IBAGSDragAndDrop) => {
        e.stopPropagation();
        const entityRef = dragAndDrop.entityModel;
        if(dragAndDrop.items.length > 0) {
            const transferData = {
                type: BAGSConstants.sourceSystemCode,
                items: dragAndDrop.items
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            /* this.props.clipBoard.openClipboard();
            this.props.clipBoard.setDraggedEntity(entityRef); */
            AppClipboardStore.openClipboard();
            AppClipboardStore.setDraggedEntity(entityRef);
        }), 10);
    }

    _handleRenderContent = (masterEntity) => {


        const source = masterEntity.sourceMap[BAGSConstants.sourceSystemCode];
        if(source) {

            let bags : IMasterEntityBAGSModel = this.props.multipleMasterEntity.bagsByMasterEntityId(masterEntity.masterEntityId);

            if (bags) {
                return (
                    <div className="master-entity-bags-summary">
                        <EntityAttributes position={masterEntity.position} entity={source} type={EntityAttributesType.secondary}/>
                        <BAGSActivityList position={masterEntity.position}
                                          entityModel={masterEntity}
                                          list={bags.activityList}
                                          sort={bags.activityList.sort}
                                          filter={bags.activityList.filter}
                                          enableRowSelection={true}
                                          onItemsDragStart={this._handleItemsDragStart}/>
                    </div>
                );
            }
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No BAGS information available</MessageBar>;
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the BAGS summary</MessageBar>;
    }
    render() {

        let source = [];
        if (this.props.multipleMasterEntity.getSelection() && this.props.multipleMasterEntity.getSelection().getSelection()) {

            source = (this.props.multipleMasterEntity.getSelection().getSelection() as IMasterEntityModel[]).map((masterEntityModel : IMasterEntityModel, index) => {

                let refModel : IMasterEntityRefModel = new MasterEntityRefModel();
                refModel.setRef(masterEntityModel);
                // this should only need to be done once.
                masterEntityModel.position = index+1;

                return <MasterEntityContainer key={index}
                                              masterEntityRef={refModel}
                                              onRenderContent={this._handleRenderContent}
                                              onRenderNotLoaded={this._handleRenderNotLoaded}/>;
            });
        }


        if(source) {
            return (
                <div className="master-entity-bags-summary">
                    {source}
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No BAGS information available</MessageBar>;
    }
}

export {
    MultipleMasterEntityBAGS as default,
    MultipleMasterEntityBAGS,
    IMasterEntityBAGSProps
}