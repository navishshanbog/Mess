
import IAirCargoActivity from "cargo/air/IAirCargoActivity";

interface IAirCargoEventNotification {

    airCargoLoaded(key : string, items : IAirCargoActivity[]);
}

export { IAirCargoEventNotification as default, IAirCargoEventNotification };