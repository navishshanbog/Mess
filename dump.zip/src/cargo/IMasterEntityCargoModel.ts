import IMasterEntityRefModel from "entity/IMasterEntityRefModel";
import IActivityListModel from "common/IActivityListModel";
import IAirCargoActivity from "./air/IAirCargoActivity";
import ISeaCargoActivity from "./sea/ISeaCargoActivity";

interface IMasterEntityBAGSModel extends IMasterEntityRefModel {
    airActivityList: IActivityListModel<IAirCargoActivity>;
    seaActivityList: IActivityListModel<ISeaCargoActivity>;
}

export { IMasterEntityBAGSModel as default, IMasterEntityBAGSModel }