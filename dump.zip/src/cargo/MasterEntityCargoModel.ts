import { observable, action } from "mobx";
import MasterEntityRefModel from "entity/MasterEntityRefModel";
import IMasterEntityCargoModel from "./IMasterEntityCargoModel";
import MasterEntityAirCargoActivityListModel from "./air/MasterEntityAirCargoActivityListModel";
import MasterEntitySeaCargoActivityListModel from "./sea/MasterEntitySeaCargoActivityListModel";
import IAirCargoActivity from "cargo/air/IAirCargoActivity";
import IAirCargoEventNotification from "cargo/IAirCargoEventNotification";
import { sourceSystemCode } from "./CargoConstants";

class MasterEntityEXAMSModel extends MasterEntityRefModel implements IMasterEntityCargoModel, IAirCargoEventNotification {
    // @observable airActivityList = new MasterEntityAirCargoActivityListModel();
    // @observable seaActivityList = new MasterEntitySeaCargoActivityListModel();
    @observable airActivityList;
    @observable seaActivityList;
    private _cargoEventNotification : IAirCargoEventNotification;

    constructor(cargoEventNotification?: IAirCargoEventNotification) {
        super();
        this._cargoEventNotification = cargoEventNotification;
        this.airActivityList = new MasterEntityAirCargoActivityListModel(this);
        this.seaActivityList = new MasterEntitySeaCargoActivityListModel();
    }

    airCargoLoaded(key : string, items : IAirCargoActivity[]) {
        if(this._cargoEventNotification) {
            this._cargoEventNotification.airCargoLoaded(key, items);
        }
    }


    @action
    setRef(ref) {
        super.setRef(ref);
        const p : Promise<any>[] = [];
        if(ref) {
            // NOTE: this is a temporary approach to fixing the source system caching issue
            // In reality - these 'MasterEntity<Source>Model' types aren't actually needed
            const source = ref.sourceMap[sourceSystemCode];
            if(source) {
                let airActivityList : MasterEntityAirCargoActivityListModel = source.rel.airActivityList;
                if(!airActivityList) {
                    airActivityList = new MasterEntityAirCargoActivityListModel(this);
                    source.setRel({ airActivityList: airActivityList });
                    p.push(airActivityList.setMasterEntity(ref));
                }
                this.airActivityList = airActivityList;
                let seaActivityList : MasterEntitySeaCargoActivityListModel = source.rel.seaActivityList;
                if(!seaActivityList) {
                    seaActivityList = new MasterEntitySeaCargoActivityListModel();
                    source.setRel({ seaActivityList: seaActivityList });
                    p.push(seaActivityList.setMasterEntity(ref));
                }
            }
        }
        return Promise.all(p);
    }

    @action
    setActivities(items : IAirCargoActivity[]) {
        this.airActivityList.items = items;
        //this.seaActivityList.items = items;
    }


}

export { MasterEntityEXAMSModel as default, MasterEntityEXAMSModel }