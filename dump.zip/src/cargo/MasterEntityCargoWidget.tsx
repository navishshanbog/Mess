import * as React from "react";
import AbstractMasterEntityWidget from "entity/AbstractMasterEntityWidget";
import MasterEntityCargo from "./component/MasterEntityCargo";
import MasterEntityCargoModel from "./MasterEntityCargoModel";
import AppMultipleMasterEntityListCompositeStore from "entity/AppMultipleMasterEntityListCompositeStore";

class MasterEntitySeaCargoWidget extends AbstractMasterEntityWidget {

    private _cargo = new MasterEntityCargoModel(AppMultipleMasterEntityListCompositeStore);
    protected get masterEntityRef() {
        return this._cargo;
    }
    _setView() {
        this.context.setView(<MasterEntityCargo cargo={this._cargo} />);
    }
}

export { MasterEntitySeaCargoWidget as default, MasterEntitySeaCargoWidget }