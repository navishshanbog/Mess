import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as CargoConstants from "./CargoConstants";
import { ICS } from "icon/AnalystDesktopIcons";

const MasterEntityCargoWidgetEntry : IWidgetEntry = {
    key: "masterEntityCargoSummary",
    keyAliases: [CargoConstants.sourceSystemCode],
    name: "Master Entity Cargo Summary",
    shortName: "Cargo",
    sourceSystemCode: CargoConstants.sourceSystemCode,
    description: "Master Entity Cargo Summary",
    icon: <ICS />,
    largeIcon: <ICS />,
    get widgetType() {
        return import("./MasterEntityCargoWidget").then(r => r.default);
    }
};

export { MasterEntityCargoWidgetEntry as default, MasterEntityCargoWidgetEntry };