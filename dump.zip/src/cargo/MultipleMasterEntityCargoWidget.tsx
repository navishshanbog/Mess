import * as React from "react";
import MultipleMasterEntityCargo from "cargo/component/MultipleMasterEntityCargo";
import IMultipleMasterEntityListCompositeModel from "entity/IMultipleMasterEntityListCompositeModel";
import {IWidget} from "../widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";

class MultipleMasterEntityCargoWidget implements IWidget {

    context: IWidgetContext;
    start() {
        const multipleMasterEntity : IMultipleMasterEntityListCompositeModel = this.context.props.multipleMasterEntity;
        this.context.setView(<MultipleMasterEntityCargo multipleMasterEntity={multipleMasterEntity} />);
    }
}

export { MultipleMasterEntityCargoWidget as default, MultipleMasterEntityCargoWidget }