import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as CargoConstants from "cargo/CargoConstants";
import { ICS } from "icon/AnalystDesktopIcons";

const MultipleMasterEntityCargoWidgetEntry : IWidgetEntry = {
    key: "multipleMasterEntityCargoSummary",
    keyAliases: [CargoConstants.sourceSystemCode + "-multiple"],
    name: "Multiple Master Entity Cargo Summary",
    shortName: "Cargo",
    description: "Multiple Master Entity Cargo Summary",
    icon: <ICS />,
    largeIcon: <ICS />,
    get widgetType() {
        return import("./MultipleMasterEntityCargoWidget").then(r => r.default);
    }
};

export { MultipleMasterEntityCargoWidgetEntry as default, MultipleMasterEntityCargoWidgetEntry };