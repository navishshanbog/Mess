import AirCargoActivityDetailModel from "./AirCargoActivityDetailModel";

const AirCargoActivityDetailStore = new AirCargoActivityDetailModel();

export { AirCargoActivityDetailStore as default, AirCargoActivityDetailStore };