import { action } from "mobx";
import IActivityFilter from "common/IActivityFilter";
import IAirCargoActivity from "./IAirCargoActivity";
import ISort from "common/ISort";
import IListModel from "common/IListModel";
import IMasterEntitySource from "entity/IMasterEntitySource";
import IMasterEntityModel from "entity/IMasterEntityModel";
import AirCargoServiceContext from "./AirCargoServiceContext";
import * as ColumnTextHelper from "common/component/ColumnTextHelper";
import { AirCargoActivityColumns, SearchArrivalDate } from "./component/AirCargoActivityColumns";
import * as StringUtils from "util/String";
import * as SearchUtils from "util/Search";
import * as moment from "moment";
import * as DateUtils from "util/Date";
import * as SortUtils from "util/Sort";
import * as CargoConstants from "../CargoConstants";
import IAirCargoEventNotification from "cargo/IAirCargoEventNotification";

const textFilterItemImpl = (item: IAirCargoActivity, text : string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, AirCargoActivityColumns), text);
}

const textFilterItem = (item: IAirCargoActivity, text : string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items : IAirCargoActivity[], text : string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IAirCargoActivity, from : moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.searchArrivalDate), from);
};

const toFilterItem = (item: IAirCargoActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.searchArrivalDate), to);
};

const rangeFilterItem = (item: IAirCargoActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items : IAirCargoActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items; 
};

const filter = (items : IAirCargoActivity[], activityFilter : IActivityFilter) => {
    return activityFilter ? rangeFilter(textFilter(items, activityFilter.filterText), activityFilter.filterFromDate, activityFilter.filterToDate) : items;
};

const toSortValue = (item: IAirCargoActivity, field : string) => {
    if(item) {
        if(field === SearchArrivalDate.fieldName) {
            return DateUtils.dateFromDataText(item.searchArrivalDate);
        }
        return item[field];
    }
};

const compare = (a : IAirCargoActivity, b : IAirCargoActivity, sort: ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IAirCargoActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a : IAirCargoActivity, b : IAirCargoActivity) => compare(a, b, sort)) : items;
};

const getForMasterEntitySource = (masterEntitySource : IMasterEntitySource, _airCargoEventNotification: IAirCargoEventNotification) : Promise<IAirCargoActivity[]> =>  {
    let allItems : IAirCargoActivity[] = [];
    return Promise.all(masterEntitySource.sourceEntities.map((entity) => {
        if(entity.ref && entity.ref.sourceRelatedKeyValue) {
            return AirCargoServiceContext.ref.getAirCargoActivities({ parentId: entity.ref.sourceRelatedKeyValue }).then((items) => {
                allItems = allItems.concat(items);

                if (_airCargoEventNotification) {
                    let key = masterEntitySource.masterEntityId.toString();
                    _airCargoEventNotification.airCargoLoaded(key, items);
                }
            });
        }
        return Promise.resolve();
    })).then(() => {
        return Promise.resolve(allItems);
    });
};

const getForMasterEntity = (masterEntity : IMasterEntityModel, _airCargoEventNotification : IAirCargoEventNotification) : Promise<IAirCargoActivity[]> => {
    const source = masterEntity.sourceMap[CargoConstants.sourceSystemCode];
    return source ? getForMasterEntitySource(source, _airCargoEventNotification) : Promise.resolve([]);
};

const loadForMasterEntityDone = action((list: IListModel<IAirCargoActivity>, items: IAirCargoActivity[]) => {
    list.setItems(items);
    list.sync.syncEnd();
});

const loadForMasterEntityError = action((list: IListModel<IAirCargoActivity>, error : any) => {
    list.sync.syncError(error);
});

const loadForMasterEntity = action((list: IListModel<IAirCargoActivity>, masterEntity: IMasterEntityModel, _airCargoEventNotification : IAirCargoEventNotification) : Promise<any> => {
    const syncId = masterEntity.masterEntityId;

    if(syncId !== list.sync.id) {
        list.sync.syncStart({ id: syncId });
        return getForMasterEntity(masterEntity, _airCargoEventNotification).then((items) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityDone(list, items);
            }
        }).catch((error) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityError(list, error);
            }
        });
    }
    return Promise.resolve();
});

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getForMasterEntitySource,
    getForMasterEntity,
    loadForMasterEntity
};