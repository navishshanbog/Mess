import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";

const ClipBoardAirCargoWidgetEntry : IWidgetEntry = {
    key: "clipBoardAirCargoSummary",
    keyAliases: ["ICS-AIR"],
    name: "ClipBoard Air Cargo Summary",
    description: "ClipBoard Air Cargo Summary",
    icon: <i className='ms-Icon ms-Icon--Airplane' aria-hidden='true'></i>,
    largeIcon: <i className='ms-Icon ms-Icon--Airplane' aria-hidden='true'></i>,
    get widgetType() {
        return import("./ClipBoardAirCargoWidget").then(r => r.default);
    }
};

export { ClipBoardAirCargoWidgetEntry as default, ClipBoardAirCargoWidgetEntry };
