import { observable, action, computed } from "mobx";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IAirCargoActivity from "./IAirCargoActivity";
import ActivityListModel from "common/ActivityListModel";
import * as AirCargoActivityHelper from "./AirCargoActivityHelper";
import IAirCargoEventNotification from "cargo/IAirCargoEventNotification";

class MasterEntityAirCargoActivityListModel extends ActivityListModel<IAirCargoActivity> {
    @observable masterEntity: IMasterEntityModel;

    _airCargoEventNotification : IAirCargoEventNotification;

    constructor (cargoEventNotification : IAirCargoEventNotification) {
        super();

        this._airCargoEventNotification = cargoEventNotification;
    }

    @action
    setMasterEntity(masterEntity: IMasterEntityModel) : Promise<any> {
        if(masterEntity !== this.masterEntity) {
            this.masterEntity = masterEntity;
            if(masterEntity) {
                this.filter.clear();
                return AirCargoActivityHelper.loadForMasterEntity(this, this.masterEntity, this._airCargoEventNotification);
            }
            this.clear();
        }
        return Promise.resolve();
    }

    @computed
    get itemsView() {
        const r = this.masterEntity ?
            AirCargoActivityHelper.filter(AirCargoActivityHelper.filter(this.items, this.masterEntity.activityFilter), this.filter) :
            this.items.slice(0);
        return AirCargoActivityHelper.sort(r, this.sort);
    }   
}

export { MasterEntityAirCargoActivityListModel as default, MasterEntityAirCargoActivityListModel }