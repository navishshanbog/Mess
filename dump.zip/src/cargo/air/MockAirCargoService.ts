import { IAirCargoService, IAirCargoActivitiesGetRequest } from "./IAirCargoService";
import IAirCargoActivity from "./IAirCargoActivity";
import IAirCargoActivityDetail from "./IAirCargoActivityDetail";

class MockAirCargoService implements IAirCargoService {
    recordRequests: boolean = false;
    getAirCargoActivitiesResponse: IAirCargoActivity[] = [
        {
            "originalMsgId":"2017-01-22 19:19:52.816157",
            "clientRoleType":"Consignor ",
            "clientInstanceId":"642531359192207",
            "masterBillNbr":"78429302626",
            "houseBillNbr":"S00237204",
            "airlineCode":"CZ ",
            "flightNbr":"343",
            "searchArrivalDate":"2017-01-26",
            "goodsDescr":"CLOTHING",
            "lowestBillInd":"Y",
            "parentBillNbr":"",
            "partShipmentInd":"N",
            "sacInd":"N",
            "stsCargoStatusCode":"CLEAR     ",
            "examFindResultCode":""
        }
    ];
    getAirCargoActivityDetailResponse: IAirCargoActivityDetail[] = [
        {
            "masterBillNbr" : "9624897512363",
            "subMasterBillNbr": "97387544",
            "houseBillNbr": "936239755",
            "flightNbr": "SQ197",
            "uniqueConsignmentRefNbr": "936239755",
            "specialReporterNbr": "SR863532",
            "transhipmentNbr": "T8683425",
            "arrivalDate": "2014-06-30",
            "dischargePortCode": "AUSYD",
            "destinationPortCode": "AUSYD",
            "firstAusPortCode": "AUSYD",
            "originalLoadingPortCode": "BRCPQ",
            "waybillOriginPortCode": "BRCPQ",
            "overseasRoutingPortCode": "SIN",
            "reportedBy": "4387587847385 DHL EXPRESS (AUSTRALIA)",
            "responsibleParty": "4387587847385 DHL EXPRESS (AUSTRALIA)",
            "consignee": "JOHN SMITH 6 CHAN STREET BELCONNEN ACT",
            "consignor": "SMITH JOHN 26 CHANG STREET SINGAPORE",
            "notifyParty": "",
            "goodsDescr": "DOCUMENTS",
            "nbrOfPackages": "1",
            "grossWeightQuantity": "0.5",
            "grossWeightUnit": "KG",
            "consolidatedCargoStatusCode": "HELD",
            "declaredValueOfGoods": "NDV",
            "declaredValueOfGoodsCurrencyCode": "AUD",
            "freightForwarderInd": "N",
            "freightMethodOfPayment": "PO",
            "reportableDocumentsInd": "Y",
            "selfAssessedClearanceDeclarationInd": "Y",
            "personalEffectsInd": "N",
            "partShipmentInd": "Y",
            "transitInd": "N",
            "createdPartInd": "N"
        }
    ];
    getAirCargoActivitiesRequests: IAirCargoActivitiesGetRequest[] = [];
    getAirCargoActivityDetailRequests: string[] = [];
    getAirCargoActivities(request : IAirCargoActivitiesGetRequest) : Promise<IAirCargoActivity[]> {
        if(this.recordRequests) {
            this.getAirCargoActivitiesRequests.push(request);
        }
        return Promise.resolve(this.getAirCargoActivitiesResponse);
    }
    getAirCargoActivityDetails(masterBillNbr : string) : Promise<IAirCargoActivityDetail[]> {
        if(this.recordRequests) {
            this.getAirCargoActivityDetailRequests.push(masterBillNbr);
        }
        return Promise.resolve(this.getAirCargoActivityDetailResponse);
    }
}

export { MockAirCargoService as default, MockAirCargoService }