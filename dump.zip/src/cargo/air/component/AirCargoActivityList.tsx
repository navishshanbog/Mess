import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { ListContainer } from "common/component/ListContainer";
import ListTotal from "common/component/ListTotal";
import AirCargoActivityListDetailView from "./AirCargoActivityListDetailView";
import Details from "common/component/Details";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import IAirCargoActivity from "../IAirCargoActivity";
import "./AirCargoActivityList.scss";
import IActivityFilterModel from "common/IActivityFilterModel";
import * as ActivityFilterMenuHelper from "common/component/ActivityFilterMenuHelper";
import IMasterEntityModel from "entity/IMasterEntityModel";
import {ICargoDragAndDrop} from "cargo/component/MasterEntityCargo";

interface IAirCargoActivityListProps {
    position?: number;
    list: IListModel<IAirCargoActivity>;
    entityModel?: IMasterEntityModel;
    filter?: IActivityFilterModel;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:ICargoDragAndDrop) => void;
    customClipboardRowAndHeader?: boolean;
}

class AirCargoActivityListCommandBar extends React.Component<IAirCargoActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.filter) {
            items.push(ActivityFilterMenuHelper.createActivityFilterItem(this.props.filter));
        }
        if(items.length > 0) {
            return <CommandBar className="air-cargo-activity-list-command-bar" items={items} />;
        }
        return null;
    }
}

class AirCargoActivityList extends React.Component<IAirCargoActivityListProps, any> {
    _handleRenderItems = (items : IAirCargoActivity[]) => {
        return <AirCargoActivityListDetailView
            items={items}
            entityModel={this.props.entityModel}
            sort={this.props.sort}
            enableRowSelection={this.props.enableRowSelection}
            customClipboardRowAndHeader = {this.props.customClipboardRowAndHeader}
            onItemsDragStart={this.props.onItemsDragStart}/>;
    }
    render() {
        return (
            <ListContainer 
                className="air-cargo-activity-list"
                typeLabel="Air Cargo Activities"
                list={this.props.list}
                onRenderItems={this._handleRenderItems} />
        );
    }
}

class AirCargoActivityListContainer extends React.Component<IAirCargoActivityListProps, any> {
    _handleOpenChange = (open) => {
        this.props.list.setVisible(open);
    }
    render() {

        let positionText;
        if (this.props.position) {
            positionText = "(" + this.props.position + ") ";
        }

        return (
            <Details open={this.props.list.visible}
                     summary={<span>{positionText}Air Cargo Activities <ListTotal list={this.props.list} /></span>}
                     onOpenChange={this._handleOpenChange}
                     controlOnHeaderClick={true}>
                <AirCargoActivityListCommandBar {...this.props} />
                <AirCargoActivityList {...this.props} />
            </Details>
        );
    }
}

export {
    AirCargoActivityListContainer as default,
    AirCargoActivityListContainer,
    AirCargoActivityList,
    IAirCargoActivityListProps
}