import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    Selection,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import {DetailsHeader} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import IAirCargoActivity from "../IAirCargoActivity";
import AirCargoActivityColumns from "./AirCargoActivityColumns";
import {IDetailsHeaderProps} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import ISortModel from "common/ISortModel";
import { IconButton } from 'office-ui-fabric-react/lib/Button';
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import * as AirCargoActivityHelper from "../AirCargoActivityHelper";
import AirCargoActivityDetailStore from "../AirCargoActivityDetailStore";
import AirCargoActivityDetails from "./AirCargoActivityDetail";
import IMasterEntityModel from "entity/IMasterEntityModel";
import "./AirCargoActivityListDetailView.scss";
import {ICargoDragAndDrop} from "cargo/component/MasterEntityCargo";

interface IAirCargoActivityListDetailViewProps {
    items: IAirCargoActivity[];
    entityModel?: IMasterEntityModel;
    sort?: ISortModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:ICargoDragAndDrop) => void;
    enableRowSelection?: boolean;
    customClipboardRowAndHeader?: boolean;

}

const DefaultAirCargoActivityListDetailViewProps : IAirCargoActivityListDetailViewProps = {
    items: [],
    clipBoard: AppClipboardStore
};

const ICS_AIR = "ICS-AIR";

@observer
class AirCargoActivityListDetailView extends React.Component<IAirCargoActivityListDetailViewProps, any> {
    public static defaultProps = DefaultAirCargoActivityListDetailViewProps;
    private _selection: Selection;
    private entityModel?: IMasterEntityModel;

    constructor(props:IAirCargoActivityListDetailViewProps) {
        super(props);
        this._selection = new Selection({
        });
        this.entityModel = props.entityModel;
    }

    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.customClipboardRowAndHeader) {
            this.props.sort.toggleSort(column.fieldName);
            this.props.clipBoard.updateSortOrderForItems(AirCargoActivityHelper.sort(this.props.items, this.props.sort), ICS_AIR);
        } else  {
            this.props.sort.toggleSort(column.fieldName);
        }
    }


    private _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        let dragandDrop: ICargoDragAndDrop = {items: this._selection.getSelection(), type:ICS_AIR, columnsToReport: AirCargoActivityColumns, entityModel:this.props.entityModel};
        this.props.onItemsDragStart(e, dragandDrop);
    }

    _removeRowFromSelection(item) {
        this.props.clipBoard.removeItemFromGroup(item, ICS_AIR);
    }

    private _onRenderRow = (props : IDetailsRowProps) => {
        var item = props.item;
        if(this.props.customClipboardRowAndHeader) {
            return (
                <div className="air-cargo-custom-cb-row">
                    <div className="air-cargo-custom-row-render-action">
                        <IconButton className="custom-action-red"
                                    iconProps={ { iconName: 'SkypeMinus' } }
                                    title='Delete'
                                    ariaLabel='Delete'
                                    onClick={this._removeRowFromSelection.bind(this, item)}/>
                    </div>
                    <div className="air-cargo-custom-row">
                        <DetailsRow {...props} />
                    </div>
                </div>
            );
        }
        return (
            <div draggable={true} onDragStart={this._handleDragStart}>
                <DetailsRow {...props} />
            </div>
        );
    }

    _onRenderHeader = (props: IDetailsHeaderProps) =>{
        return (
            <div className="air-cargo-custom-header">
                <DetailsHeader {...props} />
            </div>
        );
    }

    render() {
        const columns = ColumnSortHelper.applySort(AirCargoActivityColumns, this.props.sort);
        let detailsPanel;
        if (AirCargoActivityDetailStore.visible) {
            detailsPanel = <AirCargoActivityDetails model={AirCargoActivityDetailStore}/>;
        }
        return (
            <div className="air-cargo-activity-list-detail-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                             items={this.props.items}
                             onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                             layoutMode={DetailsListLayoutMode.fixedColumns}
                             constrainMode={ConstrainMode.unconstrained}
                             onRenderRow = {this._onRenderRow}
                             selection={ this._selection }
                             onRenderDetailsHeader = {this.props.customClipboardRowAndHeader ? this._onRenderHeader: undefined}
                             checkboxVisibility={this.props.enableRowSelection ? CheckboxVisibility.onHover: CheckboxVisibility.hidden} />
                {detailsPanel}
            </div>
        );
    }
}

export{ AirCargoActivityListDetailView as default, AirCargoActivityListDetailView, AirCargoActivityColumns };
