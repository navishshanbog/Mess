import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import AirCargoActivityList from "../air/component/AirCargoActivityList";
import SeaCargoActivityList from "../sea/component/SeaCargoActivityList";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import * as CargoConstants from "../CargoConstants";
import IMasterEntityCargoModel from "../IMasterEntityCargoModel";
import { action } from "mobx";
import {IMasterEntityModel} from "entity/IMasterEntityModel";

interface IMasterEntityCargoProps {
    cargo?: IMasterEntityCargoModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
}

const DefaultCargoActivityListDetailViewProps : IMasterEntityCargoProps = {
    clipBoard: AppClipboardStore
};

interface ICargoDragAndDrop {
    items: any[];
    type:string;
    columnsToReport?: any[];
    entityModel?: IMasterEntityModel;
}

@observer
class MasterEntityCargo extends React.Component<IMasterEntityCargoProps, any> {
    public static defaultProps = DefaultCargoActivityListDetailViewProps;
    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, ICargoDragAndDrop) => {
        e.stopPropagation();
        const entityRef = this.props.cargo.ref;
        if(ICargoDragAndDrop.items.length > 0) {
            const transferData = {
                type: ICargoDragAndDrop.type,
                items: ICargoDragAndDrop.items,
                columns: ICargoDragAndDrop.columnsToReport
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            this.props.clipBoard.openClipboard();
            this.props.clipBoard.setDraggedEntity(entityRef);
        }), 10);
    }

    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[CargoConstants.sourceSystemCode];
        if(source) {
            return (
                <div className="master-entity-cargo">
                    <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                    <AirCargoActivityList
                        list={this.props.cargo.airActivityList}
                        sort={this.props.cargo.airActivityList.sort}
                        filter={this.props.cargo.airActivityList.filter}
                        enableRowSelection={true}
                        onItemsDragStart={this._handleItemsDragStart}/>
                    <SeaCargoActivityList
                        list={this.props.cargo.seaActivityList}
                        sort={this.props.cargo.seaActivityList.sort}
                        filter={this.props.cargo.seaActivityList.filter}
                        enableRowSelection={true}
                        onItemsDragStart={this._handleItemsDragStart}/>
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No Cargo information available</MessageBar>;
    }
    _handlerRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the Cargo summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.cargo}
                                        onRenderContent={this._handleRenderContent}
                                        onRenderNotLoaded={this._handlerRenderNotLoaded} />;
    }
}

export {
    MasterEntityCargo as default,
    MasterEntityCargo,
    IMasterEntityCargoProps,
    ICargoDragAndDrop
}