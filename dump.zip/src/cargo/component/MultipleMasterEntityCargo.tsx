import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import AirCargoActivityList from "../air/component/AirCargoActivityList";
import SeaCargoActivityList from "../sea/component/SeaCargoActivityList";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import * as CargoConstants from "../CargoConstants";
import IMasterEntityCargoModel from "../IMasterEntityCargoModel";
import {IMultipleMasterEntityListCompositeModel} from "../../entity/IMultipleMasterEntityListCompositeModel";
import IMasterEntityModel from "entity/IMasterEntityModel";
import {MasterEntityRefModel} from "entity/MasterEntityRefModel";
import {IMasterEntityRefModel} from "entity/IMasterEntityRefModel";
import { action } from "mobx";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import {ICargoDragAndDrop} from "./MasterEntityCargo";

interface IMultipleMasterEntityCargoProps {
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
}


@observer
class MultipleMasterEntityCargo extends React.Component<IMultipleMasterEntityCargoProps, any> {

    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, dragandDrop?:ICargoDragAndDrop) => {

        e.stopPropagation();
        const entityRef = dragandDrop.entityModel;

        if(dragandDrop.items.length > 0) {
            const transferData = {
                type: dragandDrop.type,
                items: dragandDrop.items
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            AppClipboardStore.openClipboard();
            AppClipboardStore.setDraggedEntity(entityRef);
        }), 10);
    }

    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[CargoConstants.sourceSystemCode];
        if(source) {

            // lookup by masterEntityId
            let cargoModel : IMasterEntityCargoModel = this.props.multipleMasterEntity.cargoByMasterEntityId(masterEntity.masterEntityId);

            let content;
            if (cargoModel) {
                content =
                    <div className="master-entity-cargo">
                        <EntityAttributes entity={source} type={EntityAttributesType.secondary}/>
                        <AirCargoActivityList
                            position={masterEntity.position}
                            list={cargoModel.airActivityList}
                            entityModel={masterEntity}
                            sort={cargoModel.airActivityList.sort}
                            filter={cargoModel.airActivityList.filter}
                            enableRowSelection={true}
                            onItemsDragStart={this._handleItemsDragStart}/>
                        <SeaCargoActivityList
                            position={masterEntity.position}
                            list={cargoModel.seaActivityList}
                            entityModel={masterEntity}
                            sort={cargoModel.seaActivityList.sort}
                            filter={cargoModel.seaActivityList.filter}
                            enableRowSelection={true}
                            onItemsDragStart={this._handleItemsDragStart}/>
                    </div>;
            }
            else {
                content =<MessageBar messageBarType={MessageBarType.warning}>No Cargo information available</MessageBar>;;
            }
            return content;
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No Cargo information available</MessageBar>;
    }
    _handlerRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the Cargo summary</MessageBar>;
    }
    render() {

        let source = [];
        if (this.props.multipleMasterEntity.getSelection() && this.props.multipleMasterEntity.getSelection().getSelection()) {


            source = (this.props.multipleMasterEntity.getSelection().getSelection() as IMasterEntityModel[]).map((masterEntityModel : IMasterEntityModel, index) => {

                let refModel : IMasterEntityRefModel = new MasterEntityRefModel();
                refModel.setRef(masterEntityModel);
                // this should only need to be done once.
                masterEntityModel.position = index+1;

                return <MasterEntityContainer
                             key={index}
                             masterEntityRef={refModel}
                             onRenderContent={this._handleRenderContent}
                             onRenderNotLoaded={this._handlerRenderNotLoaded} />;
            });
        }

        if(source) {
            return (
                <div className="multiple-master-entity-cargo-summary">
                    {source}
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No EROLL information available</MessageBar>;
    }
}

export {
    MultipleMasterEntityCargo as default,
    MultipleMasterEntityCargo,
    IMultipleMasterEntityCargoProps
}