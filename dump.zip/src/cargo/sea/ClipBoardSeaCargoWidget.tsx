import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import AppClipboardGroup from "clipboard/component/AppClipboardGroup";
import SeaCargoActivityList from "./component/SeaCargoActivityList";

class ClipBoardSeaCargoWidget implements IWidget {
    context: IWidgetContext;
    start() {
        this.context.setView(
            <AppClipboardGroup clipboardGroup={this.context.props.clipboardGroup}>
                <SeaCargoActivityList list={this.context.props.clipboardGroup.containerItems} customClipboardRowAndHeader={true} sort={this.context.props.clipboardGroup.sort}/>
            </AppClipboardGroup>
        );
    }
}

export { ClipBoardSeaCargoWidget as default, ClipBoardSeaCargoWidget }
