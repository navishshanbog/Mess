import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { ICS } from "icon/AnalystDesktopIcons";
import * as CargoConstants from "../CargoConstants";

const ClipBoardSeaCargoWidgetEntry : IWidgetEntry = {
    key: "clipBoardSeaCargoSummary",
    keyAliases: ["ICS-SEA"],
    name: "ClipBoard Sea Cargo Summary",
    description: "ClipBoard Sea Cargo Summary",
    icon: <ICS />,
    largeIcon: <ICS />,
    get widgetType() {
        return import("./ClipBoardSeaCargoWidget").then(r => r.default);
    }
};

export { ClipBoardSeaCargoWidgetEntry as default, ClipBoardSeaCargoWidgetEntry };
