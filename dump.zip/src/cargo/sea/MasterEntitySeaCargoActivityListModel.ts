import { observable, action, computed } from "mobx";
import IMasterEntityModel from "entity/IMasterEntityModel";
import ISeaCargoActivity from "./ISeaCargoActivity";
import ActivityListModel from "common/ActivityListModel";
import * as SeaCargoActivityHelper from "./SeaCargoActivityHelper";

class MasterEntitySeaCargoActivityListModel extends ActivityListModel<ISeaCargoActivity> {
    @observable masterEntity: IMasterEntityModel;

    @action
    setMasterEntity(masterEntity: IMasterEntityModel) : Promise<any> {
        if(masterEntity !== this.masterEntity) {
            this.masterEntity = masterEntity;
            if(masterEntity) {
                this.filter.clear();
                return SeaCargoActivityHelper.loadForMasterEntity(this, this.masterEntity);
            }
            this.clear();
        }
        return Promise.resolve();
    }

    @computed
    get itemsView() {
        const r = this.masterEntity ?
            SeaCargoActivityHelper.filter(SeaCargoActivityHelper.filter(this.items, this.masterEntity.activityFilter), this.filter) :
            this.items.slice(0);
        return SeaCargoActivityHelper.sort(r, this.sort);
    }   
}

export { MasterEntitySeaCargoActivityListModel as default, MasterEntitySeaCargoActivityListModel }