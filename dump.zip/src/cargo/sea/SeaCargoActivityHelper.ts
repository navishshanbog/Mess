import { action } from "mobx";
import IActivityFilter from "common/IActivityFilter";
import ISeaCargoActivity from "./ISeaCargoActivity";
import ISort from "common/ISort";
import IListModel from "common/IListModel";
import IMasterEntitySource from "entity/IMasterEntitySource";
import IMasterEntityModel from "entity/IMasterEntityModel";
import SeaCargoServiceContext from "./SeaCargoServiceContext";
import * as ColumnTextHelper from "common/component/ColumnTextHelper";
import { SeaCargoActivityColumns, SearchArrivalDate } from "./component/SeaCargoActivityColumns";
import * as StringUtils from "util/String";
import * as SearchUtils from "util/Search";
import * as moment from "moment";
import * as DateUtils from "util/Date";
import * as SortUtils from "util/Sort";
import * as CargoConstants from "../CargoConstants";

const textFilterItemImpl = (item: ISeaCargoActivity, text : string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, SeaCargoActivityColumns), text);
}

const textFilterItem = (item: ISeaCargoActivity, text : string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items : ISeaCargoActivity[], text : string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: ISeaCargoActivity, from: moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.searchArrivalDate), from);
};

const toFilterItem = (item: ISeaCargoActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.searchArrivalDate), to);
};

const rangeFilterItem = (item: ISeaCargoActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items : ISeaCargoActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items : ISeaCargoActivity[], activityFilter : IActivityFilter) => {
    return activityFilter ? rangeFilter(textFilter(items, activityFilter.filterText), activityFilter.filterFromDate, activityFilter.filterToDate) : items;
};

const toSortValue = (item: ISeaCargoActivity, field : string) => {
    if(item) {
        if(field === SearchArrivalDate.fieldName) {
            const m = DateUtils.momentFromDataText(item.searchArrivalDate);
            return m ? m.toDate() : undefined;
        }
        return item[field];
    }
};

const compare = (a : ISeaCargoActivity, b : ISeaCargoActivity, sort : ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: ISeaCargoActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const getForMasterEntitySource = (masterEntitySource : IMasterEntitySource) : Promise<ISeaCargoActivity[]> =>  {
    let allItems : ISeaCargoActivity[] = [];
    return Promise.all(masterEntitySource.sourceEntities.map((entity) => {
        if(entity.ref && entity.ref.sourceRelatedKeyValue) {
            return SeaCargoServiceContext.ref.getSeaCargoActivities({ parentId: entity.ref.sourceRelatedKeyValue }).then((items) => {
                allItems = allItems.concat(items);
            });
        }
        return Promise.resolve();
    })).then(() => {
        return Promise.resolve(allItems);
    });
};

const getForMasterEntity = (masterEntity : IMasterEntityModel) : Promise<ISeaCargoActivity[]> => {
    const source = masterEntity.sourceMap[CargoConstants.sourceSystemCode];
    return source ? getForMasterEntitySource(source) : Promise.resolve([]);
};

const loadForMasterEntityDone = action((list: IListModel<ISeaCargoActivity>, items: ISeaCargoActivity[]) => {
    list.setItems(items);
    list.sync.syncEnd();
});

const loadForMasterEntityError = action((list: IListModel<ISeaCargoActivity>, error : any) => {
    list.sync.syncError(error);
});

const loadForMasterEntity = action((list: IListModel<ISeaCargoActivity>, masterEntity: IMasterEntityModel) : Promise<any> => {
    const syncId = masterEntity.masterEntityId;
    if(syncId !== list.sync.id) {
        list.sync.syncStart({ id: syncId });
        return getForMasterEntity(masterEntity).then((items) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityDone(list, items);
            }
        }).catch((error) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityError(list, error);
            }
        });
    }
    return Promise.resolve();
});

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getForMasterEntitySource,
    getForMasterEntity,
    loadForMasterEntity
};