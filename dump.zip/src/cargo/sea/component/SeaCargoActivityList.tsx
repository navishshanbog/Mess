import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { ListContainer } from "common/component/ListContainer";
import ListTotal from "common/component/ListTotal";
import Details from "common/component/Details";
import SeaCargoActivityListDetailView from "./SeaCargoActivityListDetailView";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import ISeaCargoActivity from "../ISeaCargoActivity";
import "./SeaCargoActivityList.scss";
import IActivityFilterModel from "common/IActivityFilterModel";
import * as ActivityFilterMenuHelper from "common/component/ActivityFilterMenuHelper";
import IMasterEntityModel from "entity/IMasterEntityModel";
import {ICargoDragAndDrop} from "cargo/component/MasterEntityCargo";

interface ISeaCargoActivityListProps {
    position?: number;
    list: IListModel<ISeaCargoActivity>;
    entityModel?: IMasterEntityModel;
    filter?: IActivityFilterModel;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    customClipboardRowAndHeader?: boolean;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:ICargoDragAndDrop) => void;
}

class SeaCargoActivityListCommandBar extends React.Component<ISeaCargoActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.filter) {
            items.push(ActivityFilterMenuHelper.createActivityFilterItem(this.props.filter));
        }
        if(items.length > 0) {
            return <CommandBar className="air-cargo-activity-list-command-bar" items={items} />;
        }
        return null;
    }
}

class SeaCargoActivityList extends React.Component<ISeaCargoActivityListProps, any> {
    _handleRenderItems = (items : ISeaCargoActivity[]) => {
        return <SeaCargoActivityListDetailView
            items={items}
            entityModel={this.props.entityModel}
            sort={this.props.sort}
            customClipboardRowAndHeader = {this.props.customClipboardRowAndHeader}
            enableRowSelection={this.props.enableRowSelection}
            onItemsDragStart={this.props.onItemsDragStart} />;
    }
    render() {
        return (
            <ListContainer 
                className="sea-cargo-activity-list"
                typeLabel="Sea Cargo Activities"
                list={this.props.list}
                onRenderItems={this._handleRenderItems} />
        );
    }
}

class SeaCargoActivityListContainer extends React.Component<ISeaCargoActivityListProps, any> {
    _handleOpenChange = (open) => {
        this.props.list.setVisible(open);
    }
    render() {

        let positionText;
        if (this.props.position) {
            positionText = "(" + this.props.position + ") ";
        }

        return (
            <Details open={this.props.list.visible}
                     summary={<span>{positionText}Sea Cargo Activities <ListTotal list={this.props.list} /></span>}
                     onOpenChange={this._handleOpenChange}
                     controlOnHeaderClick={true}>
                <SeaCargoActivityListCommandBar {...this.props} />
                <SeaCargoActivityList {...this.props} />
            </Details>
        );
    }
}

export {
    SeaCargoActivityListContainer as default,
    SeaCargoActivityListContainer,
    SeaCargoActivityList,
    ISeaCargoActivityListProps
}