import * as React from "react";
import { observer } from "mobx-react";
import ISeaCargoActivity from "../ISeaCargoActivity";
import ISortModel from "common/ISortModel";
import { IconButton } from 'office-ui-fabric-react/lib/Button';
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    Selection,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import SeaCargoActivityColumns from "./SeaCargoActivityColumns";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import {IDetailsHeaderProps} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import {DetailsHeader} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import * as SeaCargoActivityHelper from "../SeaCargoActivityHelper";
import SeaCargoActivityDetailStore from "../SeaCargoActivityDetailStore";
import SeaCargoActivityDetails from "./SeaCargoActivityDetail";
import "./SeaCargoActivityListDetailView.scss";
import IMasterEntityModel from "entity/IMasterEntityModel";
import {ICargoDragAndDrop} from "cargo/component/MasterEntityCargo";

interface ISeaCargoActivityListDetailViewProps {
    items: ISeaCargoActivity[];
    entityModel?: IMasterEntityModel;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>,dragAndDrop?:ICargoDragAndDrop) => void;
    customClipboardRowAndHeader?: boolean;
}

const DefaultSeaCargoActivityListDetailViewProps : ISeaCargoActivityListDetailViewProps = {
    items: [],
    clipBoard: AppClipboardStore
};

const ICS_SEA = "ICS-SEA";

@observer
class SeaCargoActivityListDetailView extends React.Component<ISeaCargoActivityListDetailViewProps, any> {
    private _selection: Selection;
    private entityModel?: IMasterEntityModel;

    public static defaultProps = DefaultSeaCargoActivityListDetailViewProps;
    constructor(props:ISeaCargoActivityListDetailViewProps) {
        super(props);
        this._selection = new Selection({
        });
        this.entityModel = props.entityModel;
    }

    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.customClipboardRowAndHeader) {
            this.props.sort.toggleSort(column.fieldName);
            this.props.clipBoard.updateSortOrderForItems(SeaCargoActivityHelper.sort(this.props.items, this.props.sort), ICS_SEA);
        } else  {
            this.props.sort.toggleSort(column.fieldName);
        }
    }

    private _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        let dragandDrop: ICargoDragAndDrop = {items: this._selection.getSelection(), type:ICS_SEA, columnsToReport: SeaCargoActivityColumns, entityModel:this.props.entityModel};
        this.props.onItemsDragStart(e, dragandDrop);
    }

    _removeRowFromSelection(item) {
        this.props.clipBoard.removeItemFromGroup(item, ICS_SEA);
    }

    private _onRenderRow = (props : IDetailsRowProps) => {
        var item = props.item;
        if(this.props.customClipboardRowAndHeader) {
            return (
                <div className="sea-cargo-custom-cb-row">
                    <div className="sea-cargo-custom-row-render-action">
                        <IconButton className="custom-action-red"
                                    iconProps={ { iconName: 'SkypeMinus' } }
                                    title='Delete'
                                    ariaLabel='Delete'
                                    onClick={this._removeRowFromSelection.bind(this, item)}/>
                    </div>
                    <div className="sea-cargo-custom-row">
                        <DetailsRow {...props} />
                    </div>
                </div>
            );
        }
        return (
            <div draggable={true} onDragStart={this._handleDragStart}>
                <DetailsRow {...props} />
            </div>
        );
    }
    _onRenderHeader = (props: IDetailsHeaderProps) =>{
        return (
            <div className="sea-cargo-custom-header">
                <DetailsHeader {...props} />
            </div>
        );
    }
    render() {
        const columns = ColumnSortHelper.applySort(SeaCargoActivityColumns, this.props.sort);
        let detailsPanel;
        if (SeaCargoActivityDetailStore.visible) {
            detailsPanel = <SeaCargoActivityDetails model={SeaCargoActivityDetailStore}/>;
        }
        return (
            <div className="sea-cargo-activity-list-detail-view" data-is-scrollable={true}>
                    <DetailsList columns={columns}
                                    items={this.props.items}
                                    onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                    layoutMode={DetailsListLayoutMode.fixedColumns}
                                    constrainMode={ConstrainMode.unconstrained}
                                    onRenderRow = {this._onRenderRow}
                                    onRenderDetailsHeader = {this.props.customClipboardRowAndHeader ? this._onRenderHeader: undefined}
                                    selection={ this._selection }
                                    checkboxVisibility={this.props.enableRowSelection ? CheckboxVisibility.onHover: CheckboxVisibility.hidden} />
                {detailsPanel}
            </div>
        );
    }
}


export{ SeaCargoActivityListDetailView as default, SeaCargoActivityListDetailView };
