import { observable, action } from "mobx";
import IAppClipBoardModel from "./IAppClipBoardModel";
import {IAppClipboardGroupModel} from "./IAppClipboardGroupModel";
import {AppClipboardGroupModel} from "./AppClipboardGroupModel";
import {toNISFormat} from "entity/EntityNameUtils";
import * as CustomClipBoardProps from "./CustomClipboardProps";
import { generateReport, generateRawTemplate } from "./AppClipBoardReportHelper";
import {HtmlModule, docX} from "docxtemplater";
import {saveAs} from "file-saver/FileSaver";
import {IEntityPhoto} from "entityphotos/IEntityPhoto";




class AppClipBoardModel implements IAppClipBoardModel {
    @observable open: boolean = false;
    @observable clipboardGroups: IAppClipboardGroupModel[] = [];
    @observable showReportTemplatePicker: boolean = false;
    @observable dockClipBoard?: boolean = false;
    @observable toggleClipBoard?: boolean = false;
    @observable dockCounter?: number = CustomClipBoardProps.TIME_TO_DOCK;
    @observable selectedTemplate: any = null;
    @observable masterEntityCombo: any;
    @observable primaryComments: string = undefined;
    @observable assItems:any[] = [];
    @observable assColumns:any[] = [];
    @observable entityPhotos: IEntityPhoto[] = [];

    looper: number;
    sEntity: any;
    nisName?:string;

    doDockClipBoard(): void {
        this.dockClipBoard = true;
        this.toggleClipBoard = false;
        this.shutDownCounter();
    }

    updateDockCounter = () => {
        this.dockCounter -= 1;
        if(this.dockCounter <= 0) {
            this.closeClipboard();
            this.shutDownCounter();
        }
    }

    setEntityPhotos(entityPhotos: IEntityPhoto[]) {
        this.entityPhotos = entityPhotos;
    }


    clearSelectedTemplate() {
        this.selectedTemplate = "";
    }

    shutDownCounter() {
        clearInterval(this.looper);
    }

    doToggleClipBoard = () => {
        this.dockCounter = CustomClipBoardProps.TIME_TO_DOCK;
        this.looper = setInterval(this.updateDockCounter, 1000);
        this.dockClipBoard = true;
        this.toggleClipBoard = true;
    }

    @action
    removeGroup(group : IAppClipboardGroupModel) : void {
        if(group) {
            const idx = this.clipboardGroups.indexOf(group);
            if(idx >= 0) {
                this.clipboardGroups.splice(idx, 1);
            }
        }
    }

    @action
    setOpen(open : boolean) {
        this.open = open;
        if(this.open) this.doDockClipBoard();
    }

    setDraggedEntity = (_sEntity: any) => {
        this.sEntity = _sEntity;
    }


    removeAllItems = () => {
        this.clipboardGroups = [];
        this.primaryComments = undefined;
    }

    @action
    openClipboard() {
        this.setOpen(true);
        this.doToggleClipBoard();
    }

    @action
    closeClipboard = () => {
        this.setOpen(false);
        this.dockClipBoard = false;
        this.toggleClipBoard = false;
        this.shutDownCounter();
    }

    isTypeExistsInItems(_type) {
        var itemFound: boolean = false;
        this.clipboardGroups.forEach((item) => {
            if (item.type == _type) itemFound = true;
        });
        return itemFound;
    }

    removeItemFromGroup(itemToBeRemoved: any, type:string) : void {
        this.clipboardGroups.forEach((group, idx) => {
            if (group.type == type) {
                var itemIndex = this.getIndexOfItemFromItems(group.containerItems.items, itemToBeRemoved);
                if(itemIndex >= 0) {
                    group.containerItems.items.splice(itemIndex, 1);  // removing the item from the group items
                    if(group.containerItems.items.length == 0) this.clipboardGroups.splice(idx, 1);  // removing the group from the groups
                }
            }
        });
    }

    updateSortOrderForItems(items:any[], type:string) : void {
        this.clipboardGroups.forEach((group) => {
            if (group.type == type) {
                group.items = items;
            }
        });
    }

    populateClipBoardToReport = () =>  {
        generateReport(this.selectedTemplate, this.clipboardGroups, this.sEntity, this.assItems, this.assColumns, this.primaryComments, this.entityPhotos);
        this.showReportTemplatePicker = false;
    }

    showRawTemplate = () => {
        generateRawTemplate(this.selectedTemplate);
        this.showReportTemplatePicker = false;
    }


    showTemplatePicker(): void {
        this.showReportTemplatePicker = true;
        this.selectedTemplate = null;

    }

    getIndexOfItemFromItems(allItems, toBeSearchedItem) {
        var itemIndex  = -1;
        allItems.forEach((item , idx) => {
            if(item == toBeSearchedItem) {
                itemIndex = idx;
            }
        });
        return itemIndex;
    }

    getIndexForTypeInItems(_type) {
        var itemIndex = -1;
        this.clipboardGroups.forEach((item , idx) => {
            if(item.type == _type) {
                itemIndex = idx;
            };
        });
        return itemIndex;
    }
    setSelectedTemplate(selectedTemplate:any): void {
        this.selectedTemplate = selectedTemplate;
    }
    closeTemplatePicker(): void {
        this.showReportTemplatePicker = false;
        this.selectedTemplate = null;
    }

    @action
    _handleDrop = (draggedData) => {
        var data : any = JSON.parse(draggedData);
        if(data.type.toLowerCase() != "widget") {
            this.nisName = toNISFormat(this.sEntity);
            if (data.type) {
                let group = this.clipboardGroups.find(g => g.type === data.type);
                if (!group) {
                    group = new AppClipboardGroupModel(data.type, this.nisName);
                    this.clipboardGroups.push(group);
                } else {
                    group.containerItems.clear();
                }
                group.containerColumns.addItems(data.columns)
                group.containerItems.addItems(data.items);

            }
        }
    }
}

export {AppClipBoardModel as default, AppClipBoardModel};


