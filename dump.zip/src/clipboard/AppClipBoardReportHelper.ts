import * as JSZipUtils from 'jszip-utils';
import * as Docxtemplater from "docxtemplater";
import * as JSZip from "jszip";
import * as CustomClipBoardProps from "./CustomClipboardProps";
import { nameToNISFormat, nisDOBFormat, genderToNISFormat} from "entity/EntityNameUtils";
import { formatToNISName } from "entity/EntityNameUtils";
import {saveAs} from "file-saver/FileSaver";
import NameGenderCdRef from "entity/ref/NameGenderCd";


var resultString = ``;
const ASSOCIATED_TRAVELLERS = "Associated Travellers";
const NIS_NAME= "NIS Name";
const MOVEMENTS= "Movements";

const generateReportText = (textSize:string, textAlign:string, textBold:string, textColor:string, textValue:string) => {
    resultString +=
`<w:p><w:pPr><w:jc w:val="`+textAlign+`"/></w:pPr><w:r><w:rPr><w:sz w:val="`+textSize+`"/><w:color w:val="`+textColor+`"/>`+
`<w:b w:val="`+textBold+`"/></w:rPr><w:t>`+textValue+`</w:t></w:r></w:p>`;

}

const getNISName = (sEntity: any):string => {
    var nisName: string;
    nisName = nameToNISFormat(sEntity.name);
    nisName += sEntity.gender? " ("+genderToNISFormat(sEntity.gender) +") " : "(unSpecified)";
    nisName += sEntity.dateOfBirth? nisDOBFormat(sEntity.dateOfBirth) : "";
  return nisName;
}

const mapAssoicatedItemsToReport = (assItems: any, assColumns: any) => {
    generateReportText("20", "start", "true", "E05E35", ASSOCIATED_TRAVELLERS);
    // generating table skeleton
    createTableSkeleton();
    // generate border for the above table
    createTableBorders();
    createRemainingTableSkeleton();
    createTableRow();
    assColumns.forEach((c) => {
        // Takes value and the background color to be filled in
        createNewHeaderRow(c.name, "0606E4", "11");
    });
    endTableRow();
    assItems.forEach((i) => {
        console.log("ITEM ====> ", i);
        createTableRow();
        assColumns.forEach((c) => {
             if(c.name == NIS_NAME) {
                let nisName: string = formatToNISName(i.familyName, i.givenNames, null, NameGenderCdRef[i.sexCode], i.birthDate);
                createNewColumn(nisName, "11");
            }
            else if(c.name == MOVEMENTS) {
                let movements: string = "";
                i.movements.forEach((m) => {
                    if(movements.length > 1 ) {movements += " | "; }
                    movements += m.routeId+" "+m.localScheduledDate+" "+m.directionCode;
                });
                 createNewColumn(movements, "11");
             }
            else {
                createNewColumn(i[c.fieldName] || "", "11");
            }
        });
        endTableRow();
    });
    endTableSkeleton();
}

const mapGroupToReport = (group: any) => {
    generateReportText("20", "start", "true", "A7011A", group.type);
    // generating table skeleton
    createTableSkeleton();
    // generate border for the above table
    createTableBorders();
    createRemainingTableSkeleton();
    createTableRow();

    group.containerColumns.items.forEach((i) => {
        // Takes value and the background color to be filled in
        createNewHeaderRow(i.name, "0606E4", "10");
    });
    endTableRow();



    group.containerItems.items.forEach((i) => {
        createTableRow();
        group.containerColumns.items.forEach((c) => {
            createNewColumn(i[c.fieldName] || "", "10");
        });
        endTableRow();
    });
    endTableSkeleton();
    generateReportText("16", "start", "false", "black", group.userComments);
}

const generateBiographicReport = (nisName: string, address: string, phoneNumber: string) => {
    // generating table skeleton
    createTableSkeleton();
    // generate border for the above table
    createTableBorders();
    createRemainingTableSkeleton();
    createTableRow();
    // to create parent merge column or row
    // 'hMerge' for Horizontal Merge
    // 'vMerge' for Vertical Merge
    // 'hAlign' for Horizontal Align Merge
    // 'vAlign' for Vertical Align Merge
    // Value for column or row
    createParentMergeColumnOrRow("hMerge", "hAlign", nisName, "yellow");
    createChildMergeColumnOrRow("hMerge");
    endTableRow();

    createTableRow();
    createNewColumn("Address: "+address, "14");
    createNewColumn("Phone: "+phoneNumber, "14");
    endTableRow();
    endTableSkeleton();
}

const createNewHeaderRow = (value: string, fillColor: string, textSize: string) => {
    resultString += `<w:tc><w:tcPr><w:tcW w:type="auto"/><w:shd w:val="clear" w:color="`+fillColor+`" w:fill="`+fillColor+`"/>`+
        `<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>`+
        `</w:tcPr><w:p><w:pPr><w:jc w:val="center"/><w:rPr><w:b/></w:rPr></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="`+textSize+`"/></w:rPr><w:t>`+value+`</w:t>`+
        `</w:r></w:p></w:tc>`
}

const createNewColumn = (value: string, textSize: string) => {
    resultString += `<w:tc><w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:b/><w:sz w:val="`+textSize+`"/></w:rPr><w:t>`+value +`</w:t></w:r></w:p></w:tc>`;
}

const createRemainingTableSkeleton = () => {
    resultString += `</w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="5000" w:type="pct"/><w:tblLook w:val="04A0"/><w:tblW w:w="0" w:type="auto"/></w:tblPr>`
}

const endTableSkeleton = () => {
    resultString +=`</w:tbl>`;
}

const endTableRow = () => {
    resultString +=`</w:tr>`;
}

const createChildMergeColumnOrRow = (merge:string) => {
    resultString +=`<w:tc><w:tcPr><w:tcW w:type="auto"/><w:`+merge+`/></w:tcPr><w:p/></w:tc>`;
}

const createParentMergeColumnOrRow = (merge: string, align: string, value: string, fillColor: string) => {
    resultString += `<w:tc><w:tcPr><w:tcW w:type="auto"/><w:shd w:val="clear" w:color="`+fillColor+`" w:fill="`+fillColor+`"/><w:`+merge+` w:val="restart"/>`+
        `<w:`+align+` w:val="center"/></w:tcPr><w:p><w:pPr><w:jc w:val="center"/>`+
        `<w:rPr><w:b/></w:rPr></w:pPr><w:r><w:rPr><w:b/></w:rPr><w:t>`+value+`</w:t></w:r></w:p></w:tc>`;
}

const createTableRow = () => {
    resultString += `<w:tr>`;
}

const createTableSkeleton = () => {
    resultString += `<w:tbl><w:tblPr><w:tblPr><w:tblLayout w:type="autofit"/>`;
}

const createTableBorders = () => {
    resultString += `<w:tblBorders><w:top w:val="single" w:sz="12" w:space="0" w:color="black"/><w:start w:val="single" w:sz="12" w:space="0" w:color="black"/>`+
        `<w:bottom w:val="single" w:sz="12" w:space="0" w:color="black"/><w:end w:val="single" w:sz="12" w:space="0" w:color="black"/>`+
        `<w:insideH w:val="single" w:sz="12" w:space="0" w:color="black"/><w:insideV w:val="single" w:sz="12" w:space="0" w:color="black"/></w:tblBorders>`;
}

const generateReport = (selectedTemplate, clipboardGroups, sEntity, assItems, assColumns, primaryComments, entityPhotos ) =>  {
    var content = null;
    var templateMapItems = {};

    resultString = ``;
        JSZipUtils.getBinaryContent(selectedTemplate.path, function (err, data) {
            if (err) {
                console.log("unable to get the selected path", selectedTemplate.path);  //TOFIX USE AD MESSAGE RATHER THAN TO CONSOLE
            } else {
                content = data;
                var zip = new JSZip(content);
                var doc = new Docxtemplater().loadZip(zip)

                // Todo: work needs to be done to get the image onto word.
                // Step 0: get Entity profile photos
                // console.log("Phtotos to display in the word file ---< ", entityPhotos);
                /*
                 var imageString = `/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAQEBAPEBAWEBAPEBAWFxUVEBAXEBEQFRUWFhUXFRUYHSggGBolHhUWITEhJykrLi4uFx8zODMsNygtLisBCgoKDg0OGxAQGi0mHx4tLy0rLy0tLS0tLy0tLi0tKy0tLS0tLS0tLi0tLS0tKy0tLy0tLS0tLS0tLS0tLS01Lf/AABEIASsAqAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAAAQMEBQYCBwj/xAA9EAABAwIEAwUGBQIEBwAAAAABAAIRAyEEEjFBBQZREyJhcYEycpGhsdEUI0LB8CRSM2Lh8Qc0Y3OCktL/xAAZAQEBAQEBAQAAAAAAAAAAAAAAAQIDBQT/xAAtEQEAAgIABQIEBQUAAAAAAAAAAQIDEQQSITFBE1EFImHwcYHB0eEUIzIzof/aAAwDAQACEQMRAD8A+3oiIgiIghQvShQQilEHlShRUQilQogoUoqIUKUQQvK9KER5KhelCqPKhSURGUiIo6CIiAiIghFKhQEREEIiFBCIiqIRSoSBCgqUQeVC9KFUeYRSURGQiIo6CKVCAiIiCIiCERFAUQpUIIREVQUFSoQFClQghQvShEQiIqMhERRsREQQiFEQRUVcSAY1T8QIk6FBciodi2i6o/FyZ0HimliJlnKFXSrh3gpbVBMIj2oQELzUdAlEekUMdKkoIUKSoQFBUog8oiKoyERFGxYtTFAGNVlLV8QgPQW9sSNV5ZVJzNLiBGxuFrcVjMrTbSI+6VMWAROj3t843+qkRtuuOZezTdmOuQH2uqvZ3ycwIaAIWU6qI8Fj1wMpDdStaa3ti4x7m3Z3us6RuqG4lrobdrvSFnYnHU6NNz3GGsEn+dVxH4qrjsSWU2mmwd7NpA623uula7h9OHHzxMz0iPLpfxjQMoOUg9Zn0WxwtTO09WkfHVc5juFU6LQ/NLh/cXS4yLtAO2u62HBi8MM2DnEiZzHxPwU1Gtl8deTmrLbDHAC+5gDqVmUJc3vW6LSswv5mcibWv3Qevms9mIBMTp0O3VZmHC9a+GWe7CyJWuxFYADzhZWGqyApMOE10uRVVKvRTTJKjOnsoiIIKIVKC5ERGhc5zDioqNa3VxY3yJP2XRExfouTfWz1HPI3keBmykt0jqy2juwReD8N/otaWufiWiLMYCOmpk/QLJp4mCR/cCPJe6dWAXRdlz1yjVInTrTdVmKNRhaMpdnMAtvfoZ0sFk0WODTn9o/JThcXmkC8GFVi6rjIY0ud0AldDrPyuMx2MONqGmwHsqVQh3SpUbYR1AM+sLd8NwFWm0ZGw5zwCXRDWAaxuVkcA4SKDGsiCBckd4u3lbSkL32K1NvEPpyZunJXtDExTm0/aMncnr5rAxGIqOYTTlsfqLbfHZZePcO3ym4LQfIgR+3zXuphyHMMkNgkgF2tomLQnZiuoiNsThOEqim99Ul9RwJjO7SLAHb/AFVuEo2phxIIIvLgfkbg9N1sg/K0uiY+qpwtAD855u2SBPdba5j46qbZm8zuZZtWiHMLWi40vvtda7D8RBcaJ7r6fz8PNZFGuTlMGH/usHHcIqPrDEWpkOLSY9tgHccb6jQ+Ska8sUrXrF/uW1bU0WZQFlpsK5xOU2Lc0+YEn6LaUq1rf7KTDlkrpkovLHL0suOhERUXIiKNMXilUMo1XnRrHE+ULkvxLSAQCzMPZOrTGnium4pjmMLabgCHEZpiACbfNa/jeAZ+XVAALHEQAADItPkR80dceonqwKWGc6DN+ngsuvSyscHbtgxqRuvFB11mCqC6OgCy1Mzt54VRFNjbffqS49Vn9rDwI9peSzumFQ05qvuwtalmY5tyzq1HNeLjQrCxWHcJcIMXIGq2TnwpVZraatJieHiqadRrsrgL2s71WS+kRAGh38Vm1qOhaPNY9Z0DyV7unPMoa2Gx5rV41znkUWWbq49G7AeJ/ZbIOzCButdTOUlp9smXdB4T5Kw3jjU78s/h2GdnLjamwAM6udq53lo0eR6hUcyY8UBTqPeAw5mhn6qlRxbljYAAOnzW4a3XboOgXA87cKrY7E0aVJ4b2RgzMNaSC9/p03sEr3MFYyZPmnUR3dXg5c3MRDTTm+ozBUmrldABM9NVluYKVFtMTDWNaCTcgAC/ivfDqEd86kRHQeajnuI3KaD4kutEag6lXteDYbL28WjqQvJao42naUREZXIiKNOS5io58XTpudka9odJOXM4WawEjUkfRZnEq8UaYebl9NpJ3dBv6wtTzk4/iaNRrhmovaMp0IIOb17wC1/EeY2V2toGi4vdVygU3h1TOxucuYCLxAstV6vtpjm1a67N/SUYd0uWHwzGtfIm8GZBaQfFpu0+CwsBzJhfxBw7qmWoHZBIORzugdp4X3VmOp6V5mYiOztcO+0KjJkqOPVRh6l1muYHC6j5t6ljUnFxzFZFN6watQtMdFbhX7ndGrQ2IWu4rTcGktEgi/ULPYVNQSCFHOs8s7aqi6AGnoLq7CYJoLnOGYlznfEyFRSw7nPMaD5eC2dOQLwFZl1vOu3lL3EAkCYBt1Oy0vCKZ71Q3qVSXHwnQLdG6qoUw0HYAqM1tqsx7sLF5nPZTAJAIkxYHXX4fFbEPAHgN9lj1MSAYG2v2VlJpIk2B0Hgqlu0bWs06leSqa9UscxuWWvLu8D7LokSOhgq1ohRztHlKIiMrkRFGnzLmbtH4msQD3GEwJkzcAeMgfBYvLfAcR2hxFai5jxPZjK5vZzq69w42vrZZ+O4nlxb7ZXNqGJMzlNo+dlbhuJ4nFvdJDaTS0NyiASB3pkkkzbwhYreJ7PSrN/Tiuojp1Wcc4U+vQFZryMQ0EZ29x7oJhro16X023n5piKQDZN3OnXUT+5uvrFPC1Q54bVOUUgXNIkZybEHyGmi4vi/CcRicRiOyoyKTmgtZlENgQQDE2g+ZK61tp7HwzLWkTS8xrvv2+n/AF0fIvFTWoNDjL6JDHSbkR3HHrIHxBXdUXWXxzlziH4HFZazXU6b5D8zXBwv3HZSLgGdP7ivrVDENcwOa4OBEggyCNiCpMdXmfFuE9LNzVj5bdY/V4xtFpcCXZQSBqBJ2+KsbhQNz8lpudO9gqoDS5wyQBH9w6nSJHqsblDiJ7NtIvc4RLM7pflj2STqR8wtRHTb5a4bWw+pE9p1r9XU0wW7+i1fGeLvY5jKTM73PyxIGUwSZ6228VsaQlYFek0YnNuWWtvYOj0DVI7ueLl5t2jba4doaDGpMnzKYgnK6NYMecWSkbDySsbQNSo4+XjCYynUYKjHBzSNjv0PQrAx2O/S250gdVh18Kxj6lSm3v5IAEDNl1PibrI4DTqFoqPaWF0nKYkg6E2kHwWtPomlaxzJ4Rh6hLn1W5Rm7oJBLo3PQfZbmV43UucszLhe02ncoqEb7XVdGs14zNMiSJ2XznH8Ur8Uxxw2FqObhqcBzmmAWg950+Og8BK+i4XDtpsbTaIa0AD0Uidvni3NP0WoiKtL1BUoo0+Y88cIdTxDq9O9OrLnNg5mVJuR11n4qrlzi1JlRtOpAL/YP6XE6jwM3/8AJfS8bg6dZhp1G5muHqPEHY+K+Y8wcq1cNOVhq0QZa8CXN94ayOo16L48lLY789e0931Y8kWjll1jCW1XZe9nY0mTYNaenXvFa3GcaNDiDcOKdsYKLcwIBbUlzZPUEQE4ZjSW06rLtcA0+759QbKjmqjNfD4hkF9MMeLyMzH5hI8wu1s0VrzS+mkxP+XmNfm6nimBpVWFtek2pTAuC0GI6dCtNwLDPw1NvcAoBxJgu/La4nKbzMWDjP8Am6rVY7mDHVR3Q1nVracgjxLpI9FveD8epVMPlxALHhhD2ZXFrm6WgXkbarVc9Z7SayY8OpncTPaJ7fk8c4u/osTBIHZOmIkjcX6iR6ri+WOJZWim5xLf0ujvUzM/+s/zWfGL467sqmFzFzYc0Mc1xqimRFzpAm0mVo+HVarKfbFk05y63B8umy3F+nR63A4IjDak9dz0fXcFxZpBaT+YDBaBefALIxNGq7s6gZJbM3AIBH3hcFyVVfWruqS7LTa0SYlz5tPofkvpuWWhb30eRxeKMGTUfe/DzQqi23mvVepEAausB1J/0XplMEQRotZieJ06D6hfTcW0w3vtbmyyCXW1AEAk+Kj460m86rCcVhi3EUKrgXMh7bFuSk4izjuSbj1Wze8C6xeI42k2i6q57eyDc2aQQRsQRr4LjcPxfE1hU7NrqtJjspdlhzN4yEhxgEWC1EbfRjwXzV5u0V6ff1dy6u2JkQLztC5rGcUZjm1KFJzhSPddUGYB7b5g127diQtLxGrWxjaeFoVWvpOvUyggxY5HXkC48/RdjwrhQosA0gAWA2TWu7d8OPBTd+tp7R+7E5R4JTwdN7KbR3nzmBJLgdJnpot8vNNkTAgEyvSy868xNpmBERGV6IijQoIlSiDX1uEUiHZGimXGTAgE9SP3WFjOFOeB3RI3BsR5LeqFyyYq3ryyvNLm6HA6h1DW+Z/YLQc6cm4uvSc6jiB3BakGOGckjV4d+y+houdOExU7Qj82VeF4zA1XMcCxzTeLtd4wRBC7Xhx7fD5HMaJZmFoMtMmNj0jVdzzxgGPw7q2UdpSFjF8p1HkuL5Zca5dQ1uIO4f4ef2Xz5st8eTXh9XDcTfHPSezP5GptpmqyILnAz11Xe0jsuW4bgDSrEmxcSCI/n8K6hpaG6nRfbitzV3LfFZvVvz+6zEEhpIMW16LiuYuNhrXYWk01a9XSm0S4tNy5/Qea2PMHEqwaabG5XEakafH2vLRTwqlTMOBEnX+6TrPU+KvrV5uWO68PemOd26zDkmcH4jWE1A1rWUy2nSL+7TsAC1rZGYAG+t1tMdwqvVoNDX5GsElrRGdot7XlHxXaUKN46KyhgwAW7Akeh/3XaLvoyfE7WmJ1Ea7ahpOTMEynTLmnOTEuMZoIDm6aWIsulWHw3htPDtLaYjNE3NyAALbWAWYsy83icvqZJtvv7oRERxQiKUFyIijQiIgIURBCIiDVc0CcJX9wrj+RsE1tTMNXOk/BdpzCJw1b/tu+i5/lGhBY7wK8zi5/v0j3/da+fwda+i1xkgEjfdSGgaCF6UL02Vdei14h7Q4eIlU08BSaZDAPiskqFOWJ66RAYBcBSiKgiIqIKKSoQEREFyIijQiIgIiIIRSVCDA44Jw9Yf8ATd9FzPImJc9sOtkcQuq4sPyKvuO+i5zlCmA1pA1JXncVMRnxtV8utUFSoK9FhBUKUVRCIigIiKgVCkqEBERBciIo0IiICIiAoUqEGNxIflVPcd9FzXKJOVg2krpuJf4VT3HfRc1ykBDfVeZxn+/F+Kx5dYoUqF6bKEKIqiFKhEBERAUKSoQEREFyIijQiIgIiIIUqFKDF4mfyqnuO+i5nlEjuje66Ti5ijUP+QrQcpsADesLy+L68Tij6rXy6lQpUL1GUIiKohERAREQFCkqEBERBciIo0IiICIiAiIg1/HDFCr7hWj5SboZ2W748P6er7pXPcnUyHm8gt+C87PG+Kxt0jpZ2ChSoXouYVCkqFUQilQgIiIBUKSoQEREFyIijQiIgIiICIiDWcxf8tV9w/Rcr/w1qlwqzeHEBdTzIf6ar7h+i5n/AIc4V1Nr82riT8V8Oa0RxFY9/wCWq21Ew7hQpUL7mBQpUKoKFJUICIiCCikqEBERBciIo0IiICLHOJEkRcT8p+3zUfixExaY9UXUslFV23sW9v5KDXtIH6WnXqiNdzQ/Lhqh8Fo+UMSM+Wblq2nNJz0Hs0JIHleFouUeE5H53Euc2Y/novMz0meKpMeP5I8u6Qqg4mNtp1Hj9lIr9BoCdRsSLddF6ZqVqhVmtrI0AOux/hXkYi8R036x/wDSqalcoVbq8SI08R6o6rGxNgfjMfRDSxAqfxA0jcD4mP2VyJoUKVBQEREFyIijQiIgq7ASXbmfmAP2Xn8M2Mu0z8oV6Iu1Roi3hp4afZQMONJOgG2g02VyIjRczty0SRrI+sqjlinLb7dPKFfzX/g+oXnln2SvLvaf66seNJuW5FAX1uCNt5+6diL3NwRFoiSf3ViL1F2rNMX8Wx6X+68uogkmTfysbfYK1FU2pNAHc38lJojqdPvH1ViIblT2Asb2+8q1ERNigqQoKCFKhSg//9k=`;
                 resultString += `<w:p><w:r><w:t>This is image </w:t><w:pict><w:binData></w:binData></w:pict></w:r></w:p>`;
                 */



                // Step 1: Get title of the document - "Entity Biographic Data"
                generateReportText("28", "start", "true", "0F36E7", "Entity Biographic Data");

                // Step 2: Get the NISNAME Table with address and phone
                // to get the name, DOB And gender in NISNAME Format
                var nisName = getNISName(sEntity);
                // To render the biographic table
                //TOFIX phone number WHEN WE GET THE DATA  - empty for phone number
                generateBiographicReport(nisName, sEntity.addresses[0].standardAddressValue, "")

                // Step 3: Get main header - main comments from user
                generateReportText("20", "center", "false", "040405", primaryComments || "");

                // Step 4: Get all tables (IAT, DGMS, BAGS etc)
                clipboardGroups.forEach((group) => {
                    // Step 4.1: Get header (IAT/BAGS etc)
                    // Step 4.2: Get table
                    // Step 4.3: Get user comments
                     mapGroupToReport(group)
                });


                // Step 5: Check for IAT and Draw up the table
                    // Step 5.1: check if there are multiple IAT
                    // Step 5.2: if 5.1 is true then draw up the table
                    if (assItems.length > 0) {
                        mapAssoicatedItemsToReport(assItems, assColumns);
                    }

                // Step 6: Close the document and display.

                try {
                        console.log("REsults string ", resultString);
                    doc.setData({AnDeReport:resultString});
                    doc.render();
                }
                catch (error) {
                    var e = {
                        message: error.message,
                        name: error.name,
                        stack: error.stack,
                        properties: error.properties,
                    }
                    throw error;
                } // close of catch
                var out = doc.getZip().generate({
                    type: "blob",

                    mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                }); //Output the document using Data-URI
                saveAs(out, "results.docx");
            }
        }.bind(this));
     //for else to check if there is ref
};

const generateRawTemplate = (selectedTemplate ) =>  {
    var content = null;
    var templateMapItems = {};
    templateMapItems[CustomClipBoardProps.EMPTY_BIOGRAPHIC_HANDLER] = CustomClipBoardProps.NO_ITEMS_TO_SHOW;
    templateMapItems[CustomClipBoardProps.ENTITY_MAINHEADER] = "";
    JSZipUtils.getBinaryContent(selectedTemplate.path, function (err, data) {
        if(err) {
            console.log("unable to get the selected path", selectedTemplate.path);   //TOFIX USE AD MESSAGE RATHER THAN TO CONSOLE
        }
        else {
            content = data;
            var zip = new JSZip(content);
            var doc=new Docxtemplater().loadZip(zip)
            doc.setData(templateMapItems);
            try {
                doc.render();
            }
            catch (error) {
                var e = {
                    message: error.message,
                    name: error.name,
                    stack: error.stack,
                    properties: error.properties,
                }
                throw error;
            }
            var out=doc.getZip().generate({
                type:"blob",
                mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            }) //Output the document using Data-URI
            saveAs(out,"ForViewOnly.docx")
        }
    });
};

export {
    generateReport,
    generateRawTemplate
}

