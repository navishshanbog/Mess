import {AppClipBoardModel} from "./AppClipBoardModel";

const AppClipBoardStore = new AppClipBoardModel();

export { AppClipBoardStore as default, AppClipBoardStore };