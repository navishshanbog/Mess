import IWidgetEntry from "widget/IWidgetEntry";
import ClipBoardBAGSWidgetEntry from "bags/ClipBoardBAGSWidgetEntry";
import ClipBoardAirCargoWidgetEntry from "cargo/air/ClipBoardAirCargoWidgetEntry";
import ClipBoardSeaCargoWidgetEntry from "cargo/sea/ClipBoardSeaCargoWidgetEntry";
import ClipBoardIATWidgetEntry from "iat/ClipBoardIATWidgetEntry";
import ClipBoardDGMSWidgetEntry from "dgms/ClipBoardDGMSWidgetEntry";
import ClipBoardEXAMSWidgetEntry from "exams/ClipBoardEXAMSWidgetEntry";
import ClipBoardIATAWidgetEntry from "iata/ClipBoardIATAWidgetEntry";
import ClipBoardINTCPWidgetEntry from "intcp/ClipBoardINTCPWidgetEntry";

const AppClipBoardWidgetEntries: IWidgetEntry[] = [
    ClipBoardBAGSWidgetEntry,
    ClipBoardAirCargoWidgetEntry,
    ClipBoardSeaCargoWidgetEntry,
    ClipBoardIATWidgetEntry,
    ClipBoardDGMSWidgetEntry,
    ClipBoardEXAMSWidgetEntry,
    ClipBoardIATAWidgetEntry,
    ClipBoardINTCPWidgetEntry
];

export { AppClipBoardWidgetEntries as default, AppClipBoardWidgetEntries };