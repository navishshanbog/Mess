import { observable, action } from "mobx";
import ListModel from "common/ListModel";
import IAppClipboardGroupModel from "./IAppClipboardGroupModel";
import SortModel from "common/SortModel";
import WidgetContext from "widget/WidgetContext";
import AppClipboardWidgetEntries from "./AppClipBoardWidgetEntries";
import * as KeyedItemHelper from "common/KeyedItemHelper";


class AppClipboardGroupModel extends ListModel<any> implements IAppClipboardGroupModel {
    private _type : string;
    @observable sort = new SortModel();
    @observable userComments : string = "";
    nisName?:string;
    clipboardTemplateFormattedData:any[] = [];
    private _widget = new WidgetContext();
    associatedItems: any[] = [];

    @observable containerItems = new ListModel();
    @observable containerColumns = new ListModel();

    constructor(type : string, nisName: string) {
        super();
        this._type = type;
        this._widget.setEntry(KeyedItemHelper.getItem(AppClipboardWidgetEntries, this._type));
        this.nisName = nisName;
        this._widget.setProps({ clipboardGroup: this });
    }

    get type() {
        return this._type;
    }

    get widget() {
        return this._widget;
    }

    @action
    setUserComments(userComments : string) {
        this.userComments = userComments;
    }

    addAssociatedItems(associatedItems) {
        this.associatedItems = associatedItems;
    }


    @action
    addItems(items: any[]) : void {
        if(items && items.length > 0) {
            items.forEach((item) => {
                this.items.push(item);
            });
        }
    }

    @action
    removeItems() : void {
        this.items = [];
    }
}

export { AppClipboardGroupModel as default, AppClipboardGroupModel };