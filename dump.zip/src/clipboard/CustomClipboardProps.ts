export enum DropdownMenuItemType {
  Normal = 0,
  Divider = 1,
  Header = 2
}

export const PRIMARY_NAME = "MAIN";
export const TIME_TO_DOCK = 10;
export const ENTITY = "Entity";
export const NISName = "NISName";
export const ASSOCIATED_ITEMS = "at";
export const ENTITY_ADDRESS= "Entity_Address";
export const ENTITY_PHONE = "Entity_Phone";
export const ENTITY_MAINHEADER = "Entity_MainHeader";
export const ENTITY_BIOGRAPHICDETAILS = "Entity_BioGraphicDetails";
export const EMPTY_BIOGRAPHIC_HANDLER = "emptyBiograhicHandler";
export const NO_ASSOCIATED_TRAVELLERS = "No Associated Travellers";
export const NO_ITEMS_TO_SHOW= "No items in report";
