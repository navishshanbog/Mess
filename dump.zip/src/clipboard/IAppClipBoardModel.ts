/**
 * Created by excbnl on 19/06/2017.
 */

import IAppClipboardGroupModel from "./IAppClipboardGroupModel";
import {IEntityPhoto} from "entityphotos/IEntityPhoto";

interface IAppClipBoardModel {

    // open and close panel
    open: boolean;

    dockClipBoard?: boolean;
    toggleClipBoard?: boolean;
    dockCounter?: number;
    doDockClipBoard(): void;
    doToggleClipBoard(): void;
    //Exception - to refactor later for remove the dependency;
    assItems: any[];
    assColumns: any[];


    // master comments from user
    primaryComments: string;
    // group of widgets
    clipboardGroups: IAppClipboardGroupModel[];
    // to show the template picker and the selected template
    showReportTemplatePicker: boolean;
    selectedTemplate: any;

    // methods
    setOpen(open : boolean) : void;
    openClipboard() : void;
    closeClipboard() : void;
    removeGroup(group : IAppClipboardGroupModel) : void;
    removeItemFromGroup(item: any, type:string) : void;
    updateSortOrderForItems(items:any[], type:string) : void;
    populateClipBoardToReport() : void;
    showRawTemplate() : void;
    showTemplatePicker() : void;
    getIndexForTypeInItems(type:string) : number;
    setSelectedTemplate(selectedTemplate:any) : void;
    closeTemplatePicker() : void;
    removeAllItems() : void;
    _handleDrop(draggedData: string) : void;
    setDraggedEntity(sEntity: any) : void;
    clearSelectedTemplate(): void;
    setEntityPhotos(entityPhotos: IEntityPhoto[]): void;

}
export { IAppClipBoardModel as default, IAppClipBoardModel };

