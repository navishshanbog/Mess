import IList from "common/IList";

interface IAppClipboardGroup extends IList<any> {
    type?: string;
    userComments?:string;
}

export { IAppClipboardGroup as default, IAppClipboardGroup };