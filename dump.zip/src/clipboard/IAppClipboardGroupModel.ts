/**
 * Created by excbnl on 22/06/2017.
 */
import IAppClipboardGroup from "./IAppClipboardGroup";
import IListModel from "common/IListModel";
import IWidgetContext from "widget/IWidgetContext";
import ISortModel from "common/ISortModel";

interface IAppClipboardGroupModel extends IListModel<any>, IAppClipboardGroup {
    sort: ISortModel;

    containerItems: IListModel<any>;
    containerColumns: IListModel<any>;
    setUserComments(userComments : string) : void;
    clipboardTemplateFormattedData: any[];
    widget: IWidgetContext;
    nisName?:string;
}

export { IAppClipboardGroupModel as default, IAppClipboardGroupModel }
