export const LIST_OF_TEMPLATES = [
    {text:'Entity Profile Template', key:'001', path:'report_templates/EntityProfile-template-All.docx'},
    {text:'Clipboard Export', key:'002', path:'report_templates/ClipboardExportTemplate.docx'}/*,
    {text:'Entity Search Template-AirCargo', key:'002', path:'report_templates/EntityProfile-template-AirCargo.docx'},
    {text:'Entity Search Template-BAGS', key:'003', path:'report_templates/EntityProfile-template-BAGS.docx'},
    {text:'Entity Search Template-DGMS', key:'004', path:'report_templates/EntityProfile-template-DGMS.docx'},
    {text:'Entity Search Template-EXAMS', key:'005', path:'report_templates/EntityProfile-template-EXAMS.docx'},
    {text:'Entity Search Template-IAT', key:'006', path:'report_templates/EntityProfile-template-IAT.docx'},
    {text:'Entity Search Template-SeaCargo', key:'007', path:'report_templates/EntityProfile-template-SeaCargo.docx'}*/
  ]
