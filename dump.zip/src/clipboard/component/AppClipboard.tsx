import * as React from 'react';
import { observer } from "mobx-react";
import { PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import { Panel, PanelType, IPanelProps } from 'office-ui-fabric-react/lib/Panel';
import IAppClipBoardModel from "../IAppClipBoardModel";
import AppClipBoardStore from "../AppClipBoardStore";
import "./AppClipboard.scss";
import AppClipboardWidgets from "./AppClipboardWidgets";
import AppClipboardHeader from "./AppClipboardHeader";
import IMasterEntityComboModel from "entity/IMasterEntityComboModel";
import MasterEntityComboModel from "entity/MasterEntityComboModel";

interface IAppClipboardProps {
    clipboard?: IAppClipBoardModel;
}

const DefaultAppClipboardProps : IAppClipboardProps = {
    clipboard: AppClipBoardStore
};

@observer
class ClipBoard extends React.Component<IAppClipboardProps, any> {
    public static defaultProps = DefaultAppClipboardProps;
    private _allowDrop(event) {
        event.preventDefault();
    }

     dropped(event) {
        try {
            // to avoid error when clipboard container is dragged and dropped on Clipboard itself
            JSON.parse(event.dataTransfer.getData('text'));
            var data: string = event.dataTransfer.getData('text');
            this.props.clipboard._handleDrop(data);
        } catch(error) {
            return;
        }

    }

    render() {
        return (
            <div className="app-clipboard-drop-zone-canvas1">
                <Panel
                    className="app-clipboard-panel"
                    isOpen={this.props.clipboard.open}
                    type={ PanelType.custom }
                    customWidth="35%"
                    onDismiss={ this._onClosePanel }
                    isLightDismiss={ true }>
                    <div className="app-clipboard-header-container">
                        <AppClipboardHeader clipboard={this.props.clipboard}/>
                    </div>
                    <div className="app-clipboard-drop-zone-canvas"
                         data-is-scrollable={true}  onDrop={this.dropped.bind(this)}
                         onDragOver={this._allowDrop.bind(this)}
                         onDragEnd={this.dropped.bind(this)}>
                        <AppClipboardWidgets clipBoard={this.props.clipboard} />
                    </div>
                </Panel>
            </div>
        );
    }

    private _onClosePanel = () => {
        this.props.clipboard.closeClipboard();
    }
}


export {ClipBoard as default, ClipBoard}