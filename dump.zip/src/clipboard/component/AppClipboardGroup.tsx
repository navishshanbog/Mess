import * as React from "react";
import IAppClipboardGroupModel from "clipboard/IAppClipboardGroupModel";
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { Label } from 'office-ui-fabric-react/lib/Label';
import "./AppClipboardGroup.scss";

interface IAppClipboardGroupProps {
    clipboardGroup: IAppClipboardGroupModel;
}

class AppClipboardGroup extends React.Component<IAppClipboardGroupProps, any> {
    render() {
        return (<div>
                    <Label className="nis-name-formatter">{this.props.clipboardGroup.nisName}</Label>
                    {this.props.children}
                    <TextField className="user-comments"
                               placeholder='Comments'
                               multiline
                               onChanged={(newUserComments) => {this.props.clipboardGroup.userComments = newUserComments}}
                               value={this.props.clipboardGroup.userComments}
                               autoAdjustHeight />
                </div>);
    }
}

export { AppClipboardGroup as default, AppClipboardGroup, IAppClipboardGroupProps  }