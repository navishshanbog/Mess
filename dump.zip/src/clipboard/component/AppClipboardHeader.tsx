import * as React from 'react';
import { observer } from "mobx-react";
import { PrimaryButton } from 'office-ui-fabric-react/lib/Button';
import IAppClipBoardModel from "../IAppClipBoardModel";
import AppClipBoardStore from "../AppClipBoardStore";
import "./AppClipboard.scss";
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import AppClipboardTemplatePicker from "./AppClipboardTemplatePicker";


interface IAppClipboardProps {
    clipboard?: IAppClipBoardModel;
}

const DefaultAppClipboardProps : IAppClipboardProps = {
    clipboard: AppClipBoardStore
};


@observer
class AppClipboardHeader extends React.Component<IAppClipboardProps, any> {
    public static defaultProps = DefaultAppClipboardProps;

    populateClipboardTemplates = () => {
        this.props.clipboard.clearSelectedTemplate();
        this.props.clipboard.showTemplatePicker();
    }

    clearClipboard = () => {
        this.props.clipboard.removeAllItems();
        this.props.clipboard.primaryComments = "";
    }

    keepClipBoard = () => {
        this.props.clipboard.doDockClipBoard();
    }

    render() {
        let clipBoardActions;
        let headerText = <div className="app-clipboard-header"> Clipboard </div>
        let templatePicker;
        if(this.props.clipboard.showReportTemplatePicker) {
            templatePicker = <AppClipboardTemplatePicker clipboard={this.props.clipboard} />
        }
        if(this.props.clipboard.dockClipBoard) {
            if(this.props.clipboard.toggleClipBoard) {
                clipBoardActions = <div className="app-clipboard-actions">
                    <div>
                        <PrimaryButton className="glowing-button" onClick={this.keepClipBoard}>Click to Dock in {this.props.clipboard.dockCounter} </PrimaryButton>
                    </div>
                </div>;
            } else {
                clipBoardActions = <div className="app-clipboard-actions">
                    <div >
                        <PrimaryButton text='Clear' onClick={this.clearClipboard}/>
                    </div>
                    <div>
                        <PrimaryButton text='New Product' onClick={this.populateClipboardTemplates}/>
                    </div>
                </div>;
            }
        }
        return (
            <div>
                {headerText}
                {clipBoardActions}


                <TextField  className="app-clipboard-user-comments"
                            placeholder='Comments'
                            multiline
                            value={this.props.clipboard.primaryComments}
                            onChanged={(newPrimaryComment) => {this.props.clipboard.primaryComments = newPrimaryComment}}
                            autoAdjustHeight />

                <div>
                    {templatePicker}
                </div>

            </div>
        );
    }
}

export {AppClipboardHeader as default, AppClipboardHeader}