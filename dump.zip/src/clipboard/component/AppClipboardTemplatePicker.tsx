import * as React from "react";
import { observer } from "mobx-react";
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { Dropdown  } from 'office-ui-fabric-react/lib/Dropdown';
import {LIST_OF_TEMPLATES} from '../TemplatesList';
import IAppClipBoardModel from "../IAppClipBoardModel";
import {DropdownMenuItemType} from '../CustomClipboardProps';
import { PrimaryButton, DefaultButton } from "office-ui-fabric-react/lib/Button";
import EntityPhotosStore from "entityphotos/EntityPhotosStore";
import EntityPhotosModel from "entityphotos/EntityPhotosModel";

interface IDialogProps {
    clipboard?: IAppClipBoardModel;
    photoModel?: EntityPhotosModel;
}

const DefaultTemplateViewProps : IDialogProps = {
    photoModel: EntityPhotosStore
};

@observer
class AppClipboardTemplatePicker extends React.Component<IDialogProps, any> {

    public static defaultProps = DefaultTemplateViewProps;

    constructor(props) {
        super(props);

        this.state = {
            templates: [{key: "Header", text: 'Templates from Repository', itemType: DropdownMenuItemType.Header}]
        };
    }

    _closeReportTemplatePicker = () => {
        this.props.clipboard.setSelectedTemplate(null);
        this.props.clipboard.closeTemplatePicker();
    }

    getRawTemplate = () => {
        this.props.clipboard.showRawTemplate();
    }

    populateReport = () => {
        //console.log("Photos ", this.props.photoModel.entityPhotos);
        this.props.clipboard.setEntityPhotos(this.props.photoModel.entityPhotos);
        this.props.clipboard.populateClipBoardToReport();
        this.props.clipboard.setSelectedTemplate(null);
    }

    componentWillMount() {
        var list = LIST_OF_TEMPLATES;
        var allTemplates = this.state.templates;
        list.forEach(function(template) {
            allTemplates.push(template);
        });
        this.setState({templates:allTemplates})
    }

    selectedTemplate = (item) => {
        this.props.clipboard.setSelectedTemplate(item);
    }

    render() {

        return (
            <Dialog
                isOpen={ this.props.clipboard.showReportTemplatePicker }
                type={ DialogType.largeHeader }
                onDismiss={ this._closeReportTemplatePicker.bind(this) }
                title='Create product'
                subText='Auto-populate a product with the selected data'
                isBlocking={ false }>
                <Dropdown
                    label='Selected template'
                    id='selectedTemplate'
                    ariaLabel='Selected template'
                    onChanged={ (item) => {this.selectedTemplate(item)} }
                    options={this.state.templates} />
                {/* Disabled till further advice from Business
                 <PrimaryButton disabled={this.props.clipBoardModel.selectedTemplate?false:true} onClick={this.getRawTemplate} text='View Template' />
                 */}
                <hr />
                <DialogFooter>
                    <PrimaryButton disabled={this.props.clipboard.selectedTemplate?false:true} onClick={ this.populateReport.bind(this) } text='Create' />
                    <DefaultButton onClick={this._closeReportTemplatePicker} text='Cancel' />
                </DialogFooter>
            </Dialog>
        );
    }
}

export { AppClipboardTemplatePicker as default, AppClipboardTemplatePicker };

