import * as React from 'react';
import { observer } from "mobx-react";
import { observable } from 'mobx';
import IAppClipBoardModel from "../IAppClipBoardModel";
import WidgetContextView from "widget/component/WidgetContext";
import IWidgetContext from "widget/IWidgetContext";
import WidgetContext from "widget/WidgetContext";
import ContainerEntries from "widget/ContainerEntries";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";

interface IClipBoardWidgetsProps {
    clipBoard: IAppClipBoardModel;
}

@observer
class ClipBoardWidgets extends React.Component<IClipBoardWidgetsProps, any> {
    _handleWidgetRemoved = (widget) => {
        // get the group matching the widget
        const widgetGroup = this.props.clipBoard.clipboardGroups.find(g => g.widget === widget);
        if(widgetGroup) {
            this.props.clipBoard.removeGroup(widgetGroup);
        }
    }
    _handleRenderEmpty = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>Your Clipboard is empty</MessageBar>;
    }
    render() {
        const widgets = this.props.clipBoard.clipboardGroups.map(g => g.widget);
        const container = new WidgetContext();
        container.setEntry(ContainerEntries[0]);
        container.setProps({ onRenderEmpty: this._handleRenderEmpty, onWidgetRemoved: this._handleWidgetRemoved, noAdd: true, noRemove: true, noEdit: true, noLayout: true });
        container.setChildren(widgets);

        return (
            <WidgetContextView context={container} />
        );
    }
}

export { ClipBoardWidgets as default, ClipBoardWidgets };