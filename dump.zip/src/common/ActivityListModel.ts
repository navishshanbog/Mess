import { observable, action } from "mobx";
import IActivityListModel from "./IActivityListModel";
import ActivityFilterModel from "./ActivityFilterModel";
import ListModel from "common/ListModel";
import SortModel from "common/SortModel";
import * as moment from "moment";

class ActivityListModel<T> extends ListModel<T> implements IActivityListModel<T> {
    @observable sort = new SortModel();
    @observable filter = new ActivityFilterModel();

    @action
    clear() {
        super.clear();
        this.filter.clear();
    }
}

export { ActivityListModel as default, ActivityListModel }