import IRef from "./IRef";

interface IContextOptions<T> {
    id?: string;
    ref?: T;
    factory?: () => T;
}

class Context<T> implements IRef<T> {
    private _id : string;
    private _origRef : T;
    private _ref : T;
    private _factory : () => T;
    constructor(opts: IContextOptions<T>) {
        this._id = opts.id;
        this._origRef = opts.ref;
        this._ref = opts.ref;
        this._factory = opts.factory;
    }
    get ref() : T {
        if(!this._ref) {
            if(!this._origRef) {
                this._origRef = this._factory();
            }
            this._ref = this._origRef;
        }

        return this._ref;
    }
    set ref(value : T) {
        this._ref = value;
    }
}

export { Context as default, Context, IContextOptions };