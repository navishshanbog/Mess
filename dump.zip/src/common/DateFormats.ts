const Input : string[] = [
    "DD/MM/YYYY",
    "D/M/YY",
    "D/MMM/YY",
    "D/MMMM/YY",
    "D/M/YYYY",
    "D/MMM/YYYY",
    "D/MMMM/YYYY",
    "D-M-YY",
    "D-MMM-YY",
    "D-MMMM-YY",
    "D-M-YYYY",
    "D-MMM-YYYY",
    "D-MMMM-YYYY",
    "D M YY",
    "D MMM YY",
    "D MMMM YY",
    "D M YYYY",
    "D MMM YYYY",
    "D MMMM YYYY",
    "YYYY-M-D",
    "MMM D YYYY",
    "MMM D, YYYY"
];

const Output = {
    default: "DD/MM/YYYY",
    filename: "DD-MM-YYYY",
    timestamp: "DD/MM/YYYY HH:mm:ss",
    time: "HH:mm:ss",
    nisFormat: "DMMMYYYY",
    matchEvaluation : "YYYY-MM-DD[T]HH:mm:ss"
};

const Data = {
    default: "YYYY-MM-DD",
    key: "YYYYMMDD",
    date: "YYYY-MM-DD",
    time: ["HH:mm:ss.SSS", "HH:mm:ss"],
    xmlDateTimeWithoutTimezone: "YYYY-MM-DD[T]HH:mm:ss.SSS"
};

export { Input, Output, Data };