//

import ISendAndReceiveService from "./ISendAndReceiveService";
import axios from "axios";

class DefaultSendAndReceiveService implements ISendAndReceiveService {

    sendAndReceive(url : string, content : string) : Promise<string> {

        let headers = {headers: {"Content-Type": "text/xml"}};

        return axios.post(url, content, headers).then((value) => {

            return value.data;
        });

    }
}

export { DefaultSendAndReceiveService as default, DefaultSendAndReceiveService }