
import Context from "common/Context";
import {ISendAndReceiveService} from "./ISendAndReceiveService";
import {DefaultSendAndReceiveService} from "./DefaultSendAndReceiveService";

const DefaultSendAndReceiveServiceContext = new Context<ISendAndReceiveService>({
    factory() {
        return new DefaultSendAndReceiveService();
    }
});

export { DefaultSendAndReceiveServiceContext as default, DefaultSendAndReceiveServiceContext }