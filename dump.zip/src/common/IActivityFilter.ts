import * as moment from "moment";

interface IActivityFilter {
    filterText: string;
    filterFromDate: moment.Moment;
    filterToDate: moment.Moment;
}

export { IActivityFilter as default, IActivityFilter }