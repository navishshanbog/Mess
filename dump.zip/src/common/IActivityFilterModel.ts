import * as moment from "moment";
import IActivityFilter from "./IActivityFilter";

interface IActivityFilterModel extends IActivityFilter {
    setFilterText(filterText: string) : void;
    setFilterFromDate(filterFromDate: moment.Moment) : void;
    setFilterToDate(filterToDate: moment.Moment) : void;
    clear() : void;
}

export { IActivityFilterModel as default, IActivityFilterModel }