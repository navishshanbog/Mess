import IListModel from "./IListModel";
import IActivityFilterModel from "./IActivityFilterModel";
import ISortModel from "./ISortModel";
import * as moment from "moment";

interface IMasterEntitySourceActivityListModel<T> extends IListModel<T> {
    filter: IActivityFilterModel;
    sort: ISortModel;
}

export { IMasterEntitySourceActivityListModel as default, IMasterEntitySourceActivityListModel }