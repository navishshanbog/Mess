interface IRef<T> {
    ref?: T;
}

export { IRef as default, IRef }; 