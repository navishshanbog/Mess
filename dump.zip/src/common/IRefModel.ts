import IRef from "./IRef";

interface IRefModel<T> extends IRef<T> {
    setRef(ref: T) : Promise<any> | void;
    clearRef() : void;
}

export { IRefModel as default, IRefModel };