interface ISendAndReceiveService {

    sendAndReceive(url : string, content : string) : Promise<string>;
}

export { ISendAndReceiveService as default, ISendAndReceiveService }