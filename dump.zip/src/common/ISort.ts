interface ISort {
    field: string;
    descending: boolean;
}

export { ISort as default, ISort }