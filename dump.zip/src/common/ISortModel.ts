import ISort from "./ISort";

interface ISortModel extends ISort {
    setField(field: string) : void;
    setDescending(descending: boolean) : void;
    setSort(field: string, descending?: boolean) : void;
    toggleSort(field: string) : void;
}

export { ISortModel as default, ISortModel };