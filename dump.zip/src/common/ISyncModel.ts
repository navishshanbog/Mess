import ISync from "./ISync";
import SyncType from "./SyncType";

interface ISyncStartOptions {
    id?: string;
    type?: SyncType;
}

interface ISyncModel extends ISync {
    hasSynced: boolean;
    syncStart(opts?: ISyncStartOptions) : void;
    syncEnd() : void;
    syncError(error : any) : void;
    clear() : void;
}

export { ISyncModel as default, ISyncModel, ISyncStartOptions }