import IPathTestResult from "common/IPathTestResult";
import IPathTemplate from "common/IPathTemplate";
import * as pathToRegexp from "path-to-regexp";

class PathTemplate {
    _text: string;
    _keys: any[] = [];
    _re : RegExp;
    _pf : pathToRegexp.PathFunction;
    constructor(text : string) {
        this._text = text;
        this._re = pathToRegexp(text, this._keys);
    }
    get paramNames() : string[] {
        return this._keys.map(k => k.name);
    }
    test(path : string) : IPathTestResult {
        const r : IPathTestResult = {
            match: this._re.test(path)
        };
        if(r.match) {
            const params : any = {};
            const er = this._re.exec(path);
            this._keys.forEach((key, idx) => {
                params[key.name] = er[idx + 1];
            });
            r.params = params;
        }
        return r;
    }
    toPath(params: any) : string {
        if(!this._pf) {
            this._pf = pathToRegexp.compile(this._text);
        }
        return this._pf(params);
    }
    toString() {
        return this._text;
    }
}

export { PathTemplate as default, PathTemplate };