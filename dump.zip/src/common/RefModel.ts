import { observable, action, computed } from "mobx";
import IRef from "./IRef";

class RefModel<T> implements IRef<T> {
    @observable private _ref : T;

    @computed
    get ref() {
        return this._ref;
    }
    set ref(value) {
        this.setRef(value);
    }

    @action
    setRef(ref : T) {
        this._ref = ref;
    }

    @action
    clearRef() {
        this._ref = undefined;
    }
}

export { RefModel as default, RefModel };