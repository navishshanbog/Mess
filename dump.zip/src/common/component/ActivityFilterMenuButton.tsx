import * as React from "react";
import { observer } from "mobx-react";
import IActivityFilterModel from "../IActivityFilterModel";
import { DefaultButton } from "office-ui-fabric-react/lib/Button";
import { SearchBox } from "office-ui-fabric-react/lib/SearchBox";
import { IContextualMenuItem, ContextualMenuItemType, IContextualMenuProps } from "office-ui-fabric-react/lib/ContextualMenu";
import MomentField from "common/component/MomentField";
import * as StringUtils from "util/String";
import * as DateUtils from "util/Date";
import { css } from "@uifabric/utilities/lib/css";
import "./ActivityFilterMenuButton.scss";

interface IActivityFilterMenuButtonProps {
    activityFilter: IActivityFilterModel;
    label?: string;
}

@observer
class ActivityFilterMenuButton extends React.Component<IActivityFilterMenuButtonProps, any> {
    private _menuProps : IContextualMenuProps;
    constructor(props : IActivityFilterMenuButtonProps) {
        super(props);
        this._menuProps = {
            className: "activity-filter-menu",
            items: [
                {
                    key: "textFilter",
                    onRender: this._handleRenderFilterTextItem
                },
                {
                    key: "sep",
                    name: "-",
                    itemType: ContextualMenuItemType.Divider
                },
                {
                    key: "dateFromFilter",
                    onRender: this._handleRenderFilterFromItem
                },
                {
                    key: "dateToFilter",
                    onRender: this._handleRenderFilterToItem
                }
            ]
        };
    }
    private _handleFilterTextChange = (text) => {
        this.props.activityFilter.setFilterText(text);
    };
    private _handleRenderFilterTextItem = (item) => {
        return <SearchBox onChange={this._handleFilterTextChange} value={this.props.activityFilter.filterText} key={item.key} labelText="Text Filter" className="activity-filter-menu-input-item" />
    }
    private _handleFilterFromChange = (fromDate) => {
        this.props.activityFilter.setFilterFromDate(fromDate);
    };
    private _handleRenderFilterFromItem = (item) => {
        return <MomentField onChange={this._handleFilterFromChange} value={this.props.activityFilter.filterFromDate} key={item.key} placeholder="Filter From Date " className="activity-filter-menu-input-item"/>
    }
    private _handleFilterToChange = (toDate) => {
        this.props.activityFilter.setFilterToDate(toDate);
    };
    private _handleRenderFilterToItem = (item) => {
        return <MomentField onChange={this._handleFilterToChange} value={this.props.activityFilter.filterToDate} key={item.key} placeholder="Filter To Date " className="activity-filter-menu-input-item"/>
    }
    render() {
        let itemContent = this.props.label || "Filter";
        let filterDefined = false;
        if(StringUtils.isNotBlank(this.props.activityFilter.filterText)) {
            filterDefined = true;
            itemContent += `: ${this.props.activityFilter.filterText}`;
        }
        if(this.props.activityFilter.filterFromDate && this.props.activityFilter.filterFromDate.isValid()) {
            filterDefined = true;
            itemContent += ` from ${DateUtils.momentToOutputText(this.props.activityFilter.filterFromDate)}`;
        }
        if(this.props.activityFilter.filterToDate && this.props.activityFilter.filterToDate.isValid()) {
            filterDefined = true;
            itemContent += ` to ${DateUtils.momentToOutputText(this.props.activityFilter.filterToDate)}`;
        }
        return (
            <DefaultButton className={css("activity-filter-menu-button", { "has-filter": filterDefined })} iconProps={ { iconName: "Filter" }} menuProps={this._menuProps}>{itemContent}</DefaultButton>
        );
    }
}

export { ActivityFilterMenuButton as default, ActivityFilterMenuButton }
