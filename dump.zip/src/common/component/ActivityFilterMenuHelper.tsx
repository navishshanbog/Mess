import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import IActivityFilterModel from "../IActivityFilterModel";
import ActivityFilterMenuButton from "./ActivityFilterMenuButton";

const createActivityFilterItem = (filterModel : IActivityFilterModel, name : string = "Filter") : IContextualMenuItem => {
    const handleFilterTextChange = (text) => {
        filterModel.setFilterText(text);
    };
    const handleFilterFromChange = (fromDate) => {
        filterModel.setFilterFromDate(fromDate);
    };
    const handleFilterToChange = (toDate) => {
        filterModel.setFilterToDate(toDate);
    };
    return {
        key: "activityFilter",
        name: name,
        iconProps: {
            iconName: "Filter"
        },
        onRender(item : IContextualMenuItem) {
            return <ActivityFilterMenuButton key={item.key} activityFilter={filterModel} label={item.name} />
        }
    };
};

export { createActivityFilterItem }