import * as React from "react";
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';

interface IBlockingDialogProps {
    dialogTitle: string;
    dialogText: string;
    hideDialog: boolean;
}

class BlockingDialog extends React.Component<IBlockingDialogProps, any> {

    constructor(props : IBlockingDialogProps) {
        super(props);

        this.state = {
            hideDialog: false
        };
    }

    componentWillReceiveProps(next) {

        this.state = {
            hideDialog: next.hideDialog
        };
    }

    public render() {

        return (
            <div>
                <Dialog
                    hidden={ this.state.hideDialog }
                    onDismiss={ this._closeDialog.bind(this) }
                    dialogContentProps={ {
                        type: DialogType.normal,
                        title: this.props.dialogTitle,
                        subText: this.props.dialogText
                    } }
                    modalProps={ {
                        isBlocking: true,
                        containerClassName: 'ms-dialogMainOverride'
                    } } >
                    <DialogFooter>
                        <PrimaryButton onClick={ this._closeDialog.bind(this) } text='Ok' />
                    </DialogFooter>
                </Dialog>
            </div>
        );
    }

    private _closeDialog() {
        this.setState({ hideDialog: true });
    }

}


export { BlockingDialog as default, BlockingDialog }