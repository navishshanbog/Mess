import { IColumn } from "office-ui-fabric-react/lib/DetailsList";
import { IContextualMenuItem, ContextualMenuItemType } from "office-ui-fabric-react/lib/ContextualMenu";
import ISort from "common/ISort";
import * as StringUtils from "util/String";

interface ICreateMenuItemsFromColumnsOptions {
    columns: IColumn[];
    selectedField?: string;
    onClick?(ev : React.MouseEvent<HTMLElement>, item : IContextualMenuItem) : void;
}

const createFieldItemsFromColumns = (opts?: ICreateMenuItemsFromColumnsOptions) : IContextualMenuItem[] => {
    const r : IContextualMenuItem[] = [];
    if(opts && opts.columns) {
        opts.columns.forEach((c) => {
            const selected = opts.selectedField === c.fieldName;
            r.push({
                key: c.key,
                fieldName: c.fieldName,
                name: c.name,
                ariaLabel: c.ariaLabel,
                canCheck: true,
                checked: selected,
                onClick: opts.onClick,
                style: selected ? { fontWeight: "bold" } : undefined
            });
        });
    }
    return r;
};

interface ICreateSortOrderItemsOptions {
    sortDescending: boolean;
    onClick?(ev : React.MouseEvent<HTMLElement>, item : IContextualMenuItem) : void;
}

const createSortOrderItems = (opts?: ICreateSortOrderItemsOptions) : IContextualMenuItem[] => {
    const r : IContextualMenuItem[] = [];
    r.push({
        key: "asc",
        name: "Ascending",
        ariaLabel: "Sort Ascending",
        sortDescending: false,
        canCheck: true,
        checked: !opts || !opts.sortDescending,
        onClick: opts ? opts.onClick : undefined,
        style: !opts || !opts.sortDescending ? { fontWeight: "bold" } : undefined
    });
    r.push({
        key: "desc",
        name: "Descending",
        ariaLabel: "Sort Descending",
        sortDescending: true,
        canCheck: true,
        checked: opts && opts.sortDescending,
        onClick: opts ? opts.onClick : undefined,
        style: opts && opts.sortDescending ? { fontWeight: "bold" } : undefined
    });
    return r;
}

interface ICreateSortItemsOptions {
    columns: IColumn[];
    sortField?: string;
    sortDescending?: boolean;
    onFieldClick?(ev : React.MouseEvent<HTMLElement>, item : IContextualMenuItem) : void;
    onSortOrderClick?(ev : React.MouseEvent<HTMLElement>, item : IContextualMenuItem) : void;
}

const createSortItems = (opts?: ICreateSortItemsOptions) : IContextualMenuItem[] => {
    let r : IContextualMenuItem[] = [];
    if(opts) {
        r = r.concat(createFieldItemsFromColumns({ columns: opts.columns, selectedField: opts.sortField, onClick: opts.onFieldClick }));
        if(r.length > 0) {
            r.push({
                key: "sep",
                name: "-"
            });
            r = r.concat(createSortOrderItems({ sortDescending: opts.sortDescending, onClick: opts.onSortOrderClick }));
        }
    }
    return r;
};

const createSortItem = (opts?: ICreateSortItemsOptions) : IContextualMenuItem => {
    return {
        key: "sort",
        name: "Sort",
        iconProps: { iconName: "Sort" },
        ariaLabel: "Sort",
        subMenuProps: {
            items: createSortItems(opts)
        }
    };
};

const applySort = (columns : IColumn[], sort?: ISort) : IColumn[] => {
    if(sort && StringUtils.isNotBlank(sort.field)) {
        const r = columns.map((c) => {
            return Object.assign({}, c);
        });
        if(sort.field) {
            const sortColumn = r.find((c) => {
                return c.fieldName === sort.field;
            });
            if(sortColumn) {
                sortColumn.isSorted = true;
                sortColumn.isSortedDescending = !sort.descending; // Reversed, since fabric's definition of 'descending' is 'arrow pointed down' !!!
            }
        }
        return r;
    }
    return columns;
};

export { applySort, createFieldItemsFromColumns, createSortOrderItems, createSortItems, createSortItem };