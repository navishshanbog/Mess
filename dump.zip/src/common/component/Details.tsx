import * as React from "react";
import { css } from "@uifabric/utilities/lib/css";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import { IIconProps, Icon } from "office-ui-fabric-react/lib/Icon";
import { ContextualMenu, IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { FocusZone } from "office-ui-fabric-react/lib/FocusZone";
import * as LangUtils from "util/Lang";
import * as Utilities from "office-ui-fabric-react/lib/Utilities";
import "./Details.scss";

interface IDetailsRemoveActionProps {
    onClick?: () => void;
}

interface IDetailsMenuActionProps {
    menu?: IContextualMenuItem[];
}

interface IDetailsActionProps {
    menu?: IContextualMenuItem[];
    onRemove?: () => void;
}

interface IDetailsState {
    open: boolean;
}

interface IDetailsProps extends IDetailsActionProps {
    summary?: any;
    open?: boolean;
    border?: boolean;
    controlOnHeaderClick?: boolean;
    className?: string;
    headerClassName?: string;
    bodyClassName?: string;
    ariaDescription?: string;
    onOpenChange?: (open: boolean) => void;
}

class DetailsRemoveAction extends React.Component<IDetailsRemoveActionProps, any> {
    render() {
        return (
            <IconButton className="details-action-item details-action-remove"
                        iconProps={{ iconName: "Cancel" }}
                        onClick={this.props.onClick}
                        title="Remove"
                        ariaLabel="Remove"
                        ariaDescription="Remove" />
        );
    }
}

interface IDetailsMenuActionState {
    target?: any;
    menuOpen: boolean;
}

class DetailsMenuAction extends React.Component<IDetailsMenuActionProps, IDetailsMenuActionState> {
    constructor(props : IDetailsMenuActionProps) {
        super(props);
        this.state = {
            menuOpen: false
        };
    }
    _handleClick = (e : React.MouseEvent<any>) => {
        this.setState({ target: e.target, menuOpen: !this.state.menuOpen });
    }
    _handleMenuDismiss = () => {
        this.setState({ menuOpen: false });
    }
    render() {
        return (
            <div className="details-action-item details-action-menu">
                <IconButton className="details-action-menu-toggle-button"
                                        iconProps={{ iconName: "Clear" }}
                                        onClick={this._handleClick}
                                        title="Toggle Menu"
                                        ariaLabel="Toggle Menu"
                                        ariaDescription="Toggle Menu" />
                {this.state.menuOpen && (
                    <ContextualMenu items={this.props.menu} shouldFocusOnMount={true} target={this.state.target} onDismiss={this._handleMenuDismiss} />
                )}
            </div>
        );
    }
}

class DetailsActions extends React.Component<IDetailsActionProps, any> {
    render() {
        if(this.props.onRemove || (this.props.menu && this.props.menu.length > 0)) {
            return (
                <div className="details-actions">
                    {this.props.menu && this.props.menu.length > 0 && (
                        <DetailsMenuAction menu={this.props.menu} />
                    )}
                    {this.props.onRemove && (
                        <DetailsRemoveAction onClick={this.props.onRemove} />
                    )}
                </div>
            )
        }
        return null;
    }
}

class Details extends React.Component<IDetailsProps, IDetailsState> {
    private _id : string;
    constructor(props : IDetailsProps) {
        super(props);
        this._id = Utilities.getId("ad-common-details-");
        this.state = {
            open: props.open !== undefined ? props.open : false
        };
    }
    componentWillReceiveProps(nextProps : IDetailsProps) {
        if(nextProps.open !== undefined) {
            this.setState({ open: nextProps.open });
        }
    }
    _handleToggleClick = () => {
        const open = !this.state.open;
        this.setState({ open: open });
        if(this.props.onOpenChange) {
            this.props.onOpenChange(open);
        }
    }
    render() {
        return (
            <div className={css("details", this.props.className, { "is-open": this.state.open, "is-hidden": !this.state.open, "has-border": this.props.border })}
                 aria-expanded={this.state.open}>
                <div className={css("details-header", this.props.headerClassName, this.props.controlOnHeaderClick ? "is-control" : undefined)}
                        role={this.props.controlOnHeaderClick ? "button" : undefined}
                        onClick={this.props.controlOnHeaderClick ? this._handleToggleClick : undefined}
                        aria-controls={this.props.controlOnHeaderClick ? this._id : undefined}>
                    <IconButton className="details-control"
                                iconProps={{ iconName: this.state.open ? "ChevronUp" : "ChevronDown" }}
                                onClick={this._handleToggleClick}
                                title={this.state.open ? "Hide" : "Show"}
                                ariaLabel={this.state.open ? "Hide Details" : "Show Details"}
                                ariaDescription={(this.state.open ? "Hide " : "Show ") + (this.props.ariaDescription || "Details")}
                                aria-controls={this._id} />
                    <div className="details-summary">{this.props.summary || "Details"}</div>
                    <DetailsActions onRemove={this.props.onRemove} menu={this.props.menu} />
                </div>
                <div id={this._id} className={css("details-body", this.props.bodyClassName, { "is-open": this.state.open})} hidden={!this.state.open}>
                    {this.props.children}
                </div>
            </div>
        );
    }
}

export { Details as default, Details };