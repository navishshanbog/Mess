import * as React from "react";
import { observer } from "mobx-react";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import { Overlay } from "office-ui-fabric-react/lib/Overlay";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import Error from "common/component/Error";
import IListModel from "../IListModel";
import { css } from "@uifabric/utilities/lib/css";
import "./ListContainer.scss";

interface IListViewProps {
    list: IListModel<any>;
    typeLabel?: string;
    loadingLabel?: string;
}

@observer
class ListSync extends React.Component<IListViewProps, any> {
    render() {
        if(this.props.list.sync.syncing) {
            // TODO: try and be smary about the default label here
            return <Spinner label={this.props.loadingLabel || `Loading ${this.props.typeLabel || "Items"}...`} className="list-sync" />;
        }
        return null;
    }
}

@observer
class ListError extends React.Component<IListViewProps, any> {
    render() {
        return !this.props.list.sync.syncing && this.props.list.sync.error ? <Error error={this.props.list.sync.error} /> : null;
    }
}

interface IListContainerProps extends IListViewProps {
    className?: string;
    onRenderItems: (items : any[]) => React.ReactElement<any>;
    onRenderEmpty?: () => React.ReactElement<any>;
    onRenderViewEmpty?: () => React.ReactElement<any>;
}

@observer
class ListEmpty extends React.Component<IListContainerProps, any> {
    render() {
        if(!this.props.list.sync.syncing && this.props.list.sync.hasSynced && !this.props.list.sync.error && (!this.props.list.items || this.props.list.items.length === 0)) {
            return this.props.onRenderEmpty ? 
                    this.props.onRenderEmpty() : 
                    <MessageBar messageBarType={MessageBarType.warning}>Unable to find any {this.props.typeLabel || "items"}</MessageBar>;
            
        }
        return null;
    }
}

@observer
class ListViewEmpty extends React.Component<IListContainerProps, any> {
    render() {
        if(!this.props.list.sync.syncing &&
            this.props.list.sync.hasSynced &&
            this.props.list.items &&
            this.props.list.items.length > 0 &&
            (!this.props.list.itemsView || this.props.list.itemsView.length === 0)) {
            return this.props.onRenderViewEmpty ?
                this.props.onRenderViewEmpty() :
                <MessageBar messageBarType={MessageBarType.warning}>Unable to find any matching {this.props.typeLabel || "items"}</MessageBar>;
        }
        return null;
    }
}

@observer
class ListItems extends React.Component<IListContainerProps, any> {
    render() {
        if(!this.props.list.sync.syncing && this.props.list.itemsView && this.props.list.itemsView.length > 0) {
            return this.props.onRenderItems(this.props.list.itemsView);
        }
        return null;
    }
}

class ListContainer extends React.Component<IListContainerProps, any> {
    render() {
        return (
            <div className={css("list-container", this.props.className)}>
                <ListSync list={this.props.list} typeLabel={this.props.typeLabel} loadingLabel={this.props.loadingLabel} />
                <ListError list={this.props.list} />
                <ListEmpty {...this.props} />
                <ListViewEmpty {...this.props} />
                <ListItems {...this.props} />
            </div>
        );
    }
}

export { ListContainer as default, ListContainer }