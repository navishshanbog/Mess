import * as React from "react";
import { observer } from "mobx-react";
import DefinitionList from "./DefinitionList";
import IListModel from "../IListModel";

interface IListTotalProps {
    list: IListModel<any>;
}

@observer
class ListTotal extends React.Component<IListTotalProps, any> {
    render() {
        return <DefinitionList name="Total" inline={true}>{this.props.list.total}</DefinitionList>;
    }
}

export { ListTotal as default, ListTotal };