import * as React from "react";
import { css } from "@uifabric/utilities/lib/css";
import "./Page.scss";

class PageHeader extends React.Component<any, any> {
    render() {
        if(React.Children.count(this.props.children) > 0) {
            return (
                <div className={css("page-header", this.props.className)}>
                    {this.props.children}
                </div>
            );
        }
        return null;
    }
}

class PageTitle extends React.Component<any, any> {
    render() {
        if(React.Children.count(this.props.children) > 0) {
            return (
                <div className={css("page-title", this.props.className)}>
                    {this.props.children}
                </div>
            );
        }
        return null;
    }
}

class PageSubtitle extends React.Component<any, any> {
    render() {
        if(React.Children.count(this.props.children) > 0) {
            return (
                <div className={css("page-subtitle", this.props.className)}>
                    {this.props.children}
                </div>
            );
        }
        return null;
    }
}

class PageBody extends React.Component<any, any> {
    render() {
        if(React.Children.count(this.props.children) > 0) {
            return (
                <div className={css("page-body", this.props.className)}>
                    {this.props.children}
                </div>
            );
        }
        return null;
    }
}

class Page extends React.Component<any, any> {
    render() {
        if(React.Children.count(this.props.children) > 0) {
            return (
                <div className={css("page", this.props.className)}>
                    {this.props.children}
                </div>
            );
        }
        return null;
    }
}

export { Page as default, Page, PageHeader, PageTitle, PageSubtitle, PageBody };