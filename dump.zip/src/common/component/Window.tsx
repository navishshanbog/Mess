import * as React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { IContextualMenuProps, IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import Details from "common/component/Details";
import { IconButton, IButtonProps } from "office-ui-fabric-react/lib/Button";
import { css } from "@uifabric/utilities/lib/css";
import "./Window.scss";

interface IWindowProps {
    title?: any;
    className?: string;
    contentHidden?: boolean;
    handleClassname?: string;
    bodyClassname?: string;
    draggable?: boolean;
    dragProps?: any;
    onDragStart?: (dragProps : any) => void;
    onDragEnd?: (dragProps : any) => void;
    onRenderIcon?: () => React.ReactElement<any>;
    onRemove?: () => void;
    onToggle?: (hidden : boolean) => void;
}

const DefaultWindowProps : IWindowProps = {
    contentHidden: false
};

class WindowRemoveAction extends React.Component<IWindowProps, any> {
    _handleClick = (e : React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();
        this.props.onRemove();
    }
    render() {
        if(this.props.onRemove) {
            return (
                <IconButton className="window-action window-action-remove"
                            iconProps={ { iconName: "Cancel" } }
                            title="Remove"
                            onClick={this._handleClick} />
            );
        }
        return null;
    }
}

class WindowToggleAction extends React.Component<IWindowProps, any> {
    _handleClick = (e : React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();
        this.props.onToggle(!this.props.contentHidden);
    }
    render() {
        if(this.props.onToggle) {
            return (
                <IconButton className="window-action window-toggle-action"
                            iconProps={ { iconName: this.props.contentHidden ? "ChevronDown" : "ChevronUp" } }
                            title={ this.props.contentHidden ? "Show" : "Hide" }
                            onClick={this._handleClick} />
            );
        }
        return null;
    }
}

class WindowActions extends React.Component<IWindowProps, any> {
    render() {
        return (
            <div className="window-actions">
                <WindowToggleAction {...this.props} />
                <WindowRemoveAction {...this.props} />
            </div>
        );
    }
}

class WindowControl extends React.Component<IWindowProps, any> {
    _handleToggleClick = (e : React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
        this.props.onToggle(!this.props.contentHidden);
    }
    _handleRemoveClick = (e : React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
        this.props.onRemove();
    }
    _handleClick = (e : React.MouseEvent<HTMLElement>) => {
        e.stopPropagation();
    }
    _handleRenderMenuIcon = () => {
        return this.props.onRenderIcon ? this.props.onRenderIcon() : <Icon iconName="GlobalNavButton" />;
    }
    render() {
        const menuItems : IContextualMenuItem[] = [];
        if(this.props.onToggle) {
            menuItems.push({
                key: "hidden",
                name: this.props.contentHidden ? "Show" : "Hide",
                iconProps: {
                    iconName: this.props.contentHidden ? "ChevronDown" : "ChevronUp"
                },
                onClick: this._handleToggleClick
            });
        }
        if(this.props.onRemove) {
            menuItems.push({
                key: "remove",
                name: "Remove",
                iconProps: {
                    iconName: "Cancel"
                },
                onClick: this._handleRemoveClick
            })
        }
        
        return (
            <div className="window-control" onClick={this._handleClick}>
                <IconButton className="window-control-button"
                            menuProps={menuItems.length > 0 ? { items: menuItems } : undefined }
                            onRenderMenuIcon={this._handleRenderMenuIcon} />
            </div>
        );
    }
}

class WindowTitle extends React.Component<IWindowProps, any> {
    render() {
        return (
            <div className="window-title">
                {this.props.title}
            </div>
        );
    }
}

class WindowHandle extends React.Component<IWindowProps, any> {
    _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        if(this.props.dragProps) {
            e.dataTransfer.setData("text", JSON.stringify(this.props.dragProps));
        }
        if(this.props.onDragStart) {
            this.props.onDragStart(this.props.dragProps);
        }
        e.stopPropagation();
    }
    _handleDragEnd = (e : React.DragEvent<HTMLElement>) => {
        if(this.props.onDragEnd) {
            this.props.onDragEnd(this.props.dragProps);
        }
    }
    _handleClick = () => {
        this.props.onToggle(!this.props.contentHidden);
    }
    render() {
        return (
            <div className={css("window-handle", this.props.handleClassname)}
                 draggable={this.props.onDragStart ? true : false}
                 onDragStart={this.props.onDragStart ? this._handleDragStart : undefined}
                 onDragEnd={this.props.onDragEnd ? this._handleDragEnd : undefined}
                 onClick={this.props.onToggle ? this._handleClick : undefined}>
                <WindowControl {...this.props} />
                <WindowTitle {...this.props} />
                <WindowActions {...this.props} />
            </div>
        );
    }
}

class WidgetWindow extends React.Component<IWindowProps, any> {
    public static defaultProps = DefaultWindowProps;
    render() {
        return (
            <div className={css("window", this.props.className)}>
                <WindowHandle {...this.props} />
                <div className={css("window-body", this.props.bodyClassname)} hidden={this.props.contentHidden}>
                    {this.props.children}
                </div>
            </div>
        );
    }
}

export { WidgetWindow as default, WidgetWindow };