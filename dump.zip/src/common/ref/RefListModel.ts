import { observable } from "mobx";
import IRefList from "./IRefList";
import IRefListItem from "./IRefListItem";

class RefListModel implements IRefList {
    @observable items : IRefListItem[] = [];

    constructor(items : IRefListItem[]) {
        this.items = items;
    }

    getItemByKey(key: string, defaultItem?: IRefListItem) : IRefListItem {
        const item = this.items.find((item) => {
            return item.key === key;
        });
        return item || defaultItem;
    }
}

export { RefListModel as default, RefListModel };