import IRefList from "./IRefList";
import IRefListItem from "./IRefListItem";

const getOptionalRefListItems = (refList: IRefList) : IRefListItem[] => {
    let r : IRefListItem[] = [{ key: "", text: ""}];
    if(refList.items && refList.items.length > 0) {
        r = r.concat(refList.items.slice());
    }
    return r;
};

export { getOptionalRefListItems };

