import IConfigRegistry from "./IConfigRegistry";
import defaultConfigurer from "./defaultConfigurer"

const ConfigRegistry : IConfigRegistry = {
    configurations: {
        default: () => { return import("./defaultConfigurer").then(c => c.default() )},
        mock: () => { return import("./mockConfigurer").then(c => c.default() )}
    },
    configure(configName : string) : Promise<any> {
        let config : () => Promise<any>;
        if(configName) {
            config = this.configurations[configName];
            if(!config) {
                console.log(`Configuration ${AppConfig.configName} not found - using default`);
            }
        }
        if(!config) {
            config = this.configurations.default;
        }
        return config();
    }
};

export { ConfigRegistry as default, ConfigRegistry }