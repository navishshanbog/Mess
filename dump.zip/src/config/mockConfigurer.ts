import MasterEntitySearchServiceContext from "entity/MasterEntitySearchServiceContext";
import MockMasterEntitySearchService from "entity/MockMasterEntitySearchService";
import MasterEntityDataServiceContext from "entity/MasterEntityDataServiceContext";
import MockMasterEntityDataService from "entity/MockMasterEntityDataService";
import IATServiceContext from "iat/IATServiceContext";
import MockIATService from "iat/MockIATService";
import BAGSServiceContext from "bags/BAGSServiceContext";
import MockBAGSService from "bags/MockBAGSService";
import EXAMSServiceContext from "exams/EXAMSServiceContext";
import MockEXAMSService from "exams/MockEXAMSService";
import DGMSServiceContext from "dgms/DGMSServiceContext";
import MockDGMSService from "dgms/MockDGMSService";
import AirCargoServiceContext from "cargo/air/AirCargoServiceContext";
import MockAirCargoService from "cargo/air/MockAirCargoService";
import SeaCargoServiceContext from "cargo/sea/SeaCargoServiceContext";
import MockSeaCargoService from "cargo/sea/MockSeaCargoService";
import UserProfileServiceContext from "user/UserProfileServiceContext";
import MockUserProfileService from "user/MockUserProfileService";

const mockConfigurer = () => {
    console.log("-- Mock Configurer");
    UserProfileServiceContext.ref = new MockUserProfileService();
    MasterEntitySearchServiceContext.ref = new MockMasterEntitySearchService();
    MasterEntityDataServiceContext.ref = new MockMasterEntityDataService();
    IATServiceContext.ref = new MockIATService();
    BAGSServiceContext.ref = new MockBAGSService();
    EXAMSServiceContext.ref = new MockEXAMSService();
    DGMSServiceContext.ref = new MockDGMSService();
    AirCargoServiceContext.ref = new MockAirCargoService();
    SeaCargoServiceContext.ref = new MockSeaCargoService();
};

export { mockConfigurer as default, mockConfigurer };