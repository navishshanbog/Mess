import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import AppClipboardGroup from "clipboard/component/AppClipboardGroup";
import DGMSActivityListContainer from "./component/DGMSActivityList";

class ClipBoardDGMSWidget implements IWidget {
    context: IWidgetContext;
    start() {
        this.context.setView(
            <AppClipboardGroup clipboardGroup={this.context.props.clipboardGroup}>
                <DGMSActivityListContainer list={this.context.props.clipboardGroup.containerItems} customClipboardRowAndHeader={true} sort={this.context.props.clipboardGroup.sort}/>
            </AppClipboardGroup>
        );
    }
}

export { ClipBoardDGMSWidget as default, ClipBoardDGMSWidget }
