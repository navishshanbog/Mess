import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { DGMS } from "icon/AnalystDesktopIcons";
import * as DGMSConstants from "./DGMSConstants";

const ClipBoardDGMSWidgetEntry : IWidgetEntry = {
    key: "ClipBoardDGMSSummary",
    keyAliases: [DGMSConstants.sourceSystemCode],
    name: "ClipBoard DGMS Summary",
    description: "ClipBoard DGMS Summary",
    icon: <DGMS />,
    largeIcon: <DGMS />,
    get widgetType() {
        return import("./ClipBoardDGMSWidget").then(r => r.default);
    }
};

export { ClipBoardDGMSWidgetEntry as default, ClipBoardDGMSWidgetEntry };
