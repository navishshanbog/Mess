import { action } from "mobx";
import IActivityFilter from "common/IActivityFilter";
import IDGMSActivity from "./IDGMSActivity";
import ISort from "common/ISort";
import IListModel from "common/IListModel";
import * as StringUtils from "util/String";
import * as SearchUtils from "util/Search";
import * as DateUtils from "util/Date";
import * as SortUtils from "util/Sort";
import * as moment from "moment";
import * as ColumnTextHelper from "common/component/ColumnTextHelper";
import { DGMSActivityColumns, DateDetected } from "./component/DGMSActivityColumns";
import DGMSServiceContext from "./DGMSServiceContext";
import IMasterEntitySource from "entity/IMasterEntitySource";
import IMasterEntityModel from "entity/IMasterEntityModel";
import * as DGMSConstants from "./DGMSConstants";
import IDGMSEventNotification from "dgms/IDGMSEventNotification";

const textFilterItemImpl = (item: IDGMSActivity, text : string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, DGMSActivityColumns).join(""), text);
};

const textFilterItem = (item: IDGMSActivity, text : string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items : IDGMSActivity[], text : string) => {
    return items && StringUtils.isNotBlank(text) ? items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IDGMSActivity, from: moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.dateDetected), from);
};

const toFilterItem = (item: IDGMSActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.dateDetected), to);
};

const rangeFilterItem = (item: IDGMSActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items : IDGMSActivity[], from: moment.Moment, to: moment.Moment) => {
    return items && (from || to) ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items : IDGMSActivity[], activityFilter : IActivityFilter) => {
    return activityFilter ? rangeFilter(textFilter(items, activityFilter.filterText), activityFilter.filterFromDate, activityFilter.filterToDate) : items;
};

const toSortValue = (item: IDGMSActivity, field: string) => {
    if(item) {
        if(field === DateDetected.fieldName) {
            return DateUtils.dateFromDataText(item.dateDetected);
        }
        return item[field];
    }
};

const compare = (a : IDGMSActivity, b : IDGMSActivity, sort : ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IDGMSActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const getForMasterEntitySource = (masterEntitySource : IMasterEntitySource) : Promise<IDGMSActivity[]> =>  {
    let allItems : IDGMSActivity[] = [];
    return Promise.all(masterEntitySource.sourceEntities.map((entity) => {
        if(entity.ref && entity.ref.sourceRelatedKeyValue) {
            return DGMSServiceContext.ref.getDGMSActivities({ parentId: entity.ref.sourceRelatedKeyValue }).then((items) => {
                allItems = allItems.concat(items);
            });
        }
        return Promise.resolve();
    })).then(() => {
        return Promise.resolve(allItems);
    });
};

const getForMasterEntity = (masterEntity : IMasterEntityModel) : Promise<IDGMSActivity[]> => {
    const source = masterEntity.sourceMap[DGMSConstants.sourceSystemCode];
    return source ? getForMasterEntitySource(source) : Promise.resolve([]);
};

const loadForMasterEntityDone = action((list: IListModel<IDGMSActivity>, items: IDGMSActivity[]) => {
    list.setItems(items);
    list.sync.syncEnd();
});

const loadForMasterEntityError = action((list: IListModel<IDGMSActivity>, error : any) => {
    list.sync.syncError(error);
});

const loadForMasterEntity = action((list: IListModel<IDGMSActivity>,
                                    masterEntity: IMasterEntityModel,
                                    dgmsEventNotification : IDGMSEventNotification) : Promise<any> => {
    const syncId = masterEntity.masterEntityId;
    if(syncId !== list.sync.id) {
        list.sync.syncStart({ id: syncId });
        return getForMasterEntity(masterEntity).then((items) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityDone(list, items);

                if (dgmsEventNotification) {
                    dgmsEventNotification.dgmsActivityDataLoaded(syncId, items);
                }
            }
        }).catch((error) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityError(list, error);
            }
        });
    }
    return Promise.resolve();
});

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    toSortValue,
    compare,
    sort,
    getForMasterEntitySource,
    getForMasterEntity,
    loadForMasterEntity
};