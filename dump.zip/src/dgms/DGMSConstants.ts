const sourceSystemCode = "DGMS";

export { sourceSystemCode }