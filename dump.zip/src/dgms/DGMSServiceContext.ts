import Context from "common/Context";
import IDGMSService from "./IDGMSService";
import RestDGMSService from "./RestDGMSService";

const DGMSServiceContext = new Context<IDGMSService>({
    ref: new RestDGMSService()
});

export { DGMSServiceContext as default, DGMSServiceContext };