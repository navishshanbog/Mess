import IDGMSActivity from "dgms/IDGMSActivity";

interface IDGMSEventNotification {

    dgmsActivityDataLoaded(id : string, items : IDGMSActivity[]);
}

export { IDGMSEventNotification as default, IDGMSEventNotification };