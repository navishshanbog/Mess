import IMasterEntityRefModel from "entity/IMasterEntityRefModel";
import IActivityListModel from "common/IActivityListModel";
import IDGMSActivity from "./IDGMSActivity";

interface IMasterEntityDGMSModel extends IMasterEntityRefModel {
    activityList: IActivityListModel<IDGMSActivity>;
}

export { IMasterEntityDGMSModel as default, IMasterEntityDGMSModel }