import { observable, action, computed } from "mobx";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IDGMSActivity from "./IDGMSActivity";
import ActivityListModel from "common/ActivityListModel";
import * as DGMSActivityHelper from "./DGMSActivityHelper";
import IDGMSEventNotification from "dgms/IDGMSEventNotification";

class MasterEntityDGMSActivityListModel extends ActivityListModel<IDGMSActivity> {
    @observable masterEntity: IMasterEntityModel;

    private _DGMSEventEventNotification : IDGMSEventNotification;

    constructor(notification: IDGMSEventNotification) {
        super();
        this._DGMSEventEventNotification = notification;
    }

    @action
    setMasterEntity(masterEntity: IMasterEntityModel) : Promise<any> {
        if(masterEntity !== this.masterEntity) {
            this.masterEntity = masterEntity;
            if(masterEntity) {
                this.filter.clear();
                return DGMSActivityHelper.loadForMasterEntity(this, this.masterEntity, this._DGMSEventEventNotification);
            } 
            this.clear();
        }
        return Promise.resolve();
    }

    @computed
    get itemsView() {
        const r = this.masterEntity ?
            DGMSActivityHelper.filter(DGMSActivityHelper.filter(this.items, this.masterEntity.activityFilter), this.filter) :
            this.items.slice(0);
        return DGMSActivityHelper.sort(r, this.sort);
    }   
}

export { MasterEntityDGMSActivityListModel as default, MasterEntityDGMSActivityListModel }