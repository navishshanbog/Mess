import { observable, action } from "mobx";
import MasterEntityRefModel from "entity/MasterEntityRefModel";
import IMasterEntityDGMSModel from "./IMasterEntityDGMSModel";
import MasterEntityDGMSActivityListModel from "./MasterEntityDGMSActivityListModel";
import AppMultipleMasterEntityListCompositeStore from "entity/AppMultipleMasterEntityListCompositeStore";
import { sourceSystemCode } from "./DGMSConstants";

class MasterEntityDGMSModel extends MasterEntityRefModel implements IMasterEntityDGMSModel {

    @observable activityList = new MasterEntityDGMSActivityListModel(AppMultipleMasterEntityListCompositeStore);

    @action
    setRef(ref) {
        super.setRef(ref);
        if(ref) {
            // NOTE: this is a temporary approach to fixing the source system caching issue
            // In reality - these 'MasterEntity<Source>Model' types aren't actually needed
            const source = ref.sourceMap[sourceSystemCode];
            if(source) {
                let activityList : MasterEntityDGMSActivityListModel = source.rel.activityList;
                if(!activityList) {
                    activityList = new MasterEntityDGMSActivityListModel(AppMultipleMasterEntityListCompositeStore);
                    source.setRel({ activityList: activityList });
                }
                this.activityList = activityList;
                return activityList.setMasterEntity(ref);
            }
        }
    }
}

export { MasterEntityDGMSModel as default, MasterEntityDGMSModel }