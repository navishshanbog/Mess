import * as React from "react";
import AbstractMasterEntityWidget from "entity/AbstractMasterEntityWidget";
import MasterEntityDGMS from "./component/MasterEntityDGMS";
import MasterEntityDGMSModel from "./MasterEntityDGMSModel";

class MasterEntityDGMSWidget extends AbstractMasterEntityWidget {
    private _dgms = new MasterEntityDGMSModel();
    protected get masterEntityRef() {
        return this._dgms;
    }
    _setView() {
        this.context.setView(<MasterEntityDGMS dgms={this._dgms} />);
    }
}

export { MasterEntityDGMSWidget as default, MasterEntityDGMSWidget }
