import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { DGMS } from "icon/AnalystDesktopIcons";
import * as DGMSConstants from "./DGMSConstants";

const MasterEntityDGMSWidgetEntry : IWidgetEntry = {
    key: "masterEntityDGMSSummary",
    keyAliases: [DGMSConstants.sourceSystemCode],
    name: "Master Entity DGMS Summary",
    shortName: "DGMS",
    sourceSystemCode: DGMSConstants.sourceSystemCode,
    description: "Master Entity DGMS Summary",
    icon: <DGMS />,
    largeIcon: <DGMS />,
    get widgetType() {
        return import("./MasterEntityDGMSWidget").then(r => r.default);
    }
};

export { MasterEntityDGMSWidgetEntry as default, MasterEntityDGMSWidgetEntry };