import * as React from "react";
import MultipleMasterEntityDGMS from "./component/MultipleMasterEntityDGMS";
import IWidgetContext from "widget/IWidgetContext";
import IWidget from "widget/IWidget";
import IMultipleMasterEntityListCompositeModel from "entity/IMultipleMasterEntityListCompositeModel";

class MultipleMasterEntityDGMSWidget implements IWidget {

    context: IWidgetContext;

    start() {
        const multipleMasterEntity : IMultipleMasterEntityListCompositeModel = this.context.props.multipleMasterEntity;
        this.context.setView(<MultipleMasterEntityDGMS multipleMasterEntity={multipleMasterEntity} />);
    }

}

export { MultipleMasterEntityDGMSWidget as default, MultipleMasterEntityDGMSWidget }

