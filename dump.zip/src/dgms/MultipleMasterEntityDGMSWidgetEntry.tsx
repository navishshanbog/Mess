import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { DGMS } from "icon/AnalystDesktopIcons";
import * as DGMSConstants from "./DGMSConstants";

const MultipleMasterEntityDGMSWidgetEntry : IWidgetEntry = {
    key: "multipleMasterEntityDGMSSummary",
    keyAliases: [DGMSConstants.sourceSystemCode + "-multiple"],
    name: "Master Entity DGMS Summary",
    shortName: "DGMS",
    sourceSystemCode: DGMSConstants.sourceSystemCode,
    description: "Master Entity DGMS Summary",
    icon: <DGMS />,
    largeIcon: <DGMS />,
    get widgetType() {
        return import("./MultipleMasterEntityDGMSWidget").then(r => r.default);
    }
};

export { MultipleMasterEntityDGMSWidgetEntry as default, MultipleMasterEntityDGMSWidgetEntry };