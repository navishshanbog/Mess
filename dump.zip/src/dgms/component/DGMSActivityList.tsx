import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { observer } from "mobx-react";
import { ListContainer } from "common/component/ListContainer";
import ListTotal from "common/component/ListTotal";
import Details from "common/component/Details";
import DGMSActivityListDetailView from "./DGMSActivityListDetailView";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import IDGMSActivity from "../IDGMSActivity";
import IActivityFilterModel from "common/IActivityFilterModel";
import * as ActivityFilterMenuHelper from "common/component/ActivityFilterMenuHelper";
import IMasterEntityModel from "entity/IMasterEntityModel";
import { IDGMSDragAndDrop }  from "./MasterEntityDGMS";

interface IDGMSActivityListProps {
    position? : number;
    list: IListModel<IDGMSActivity>;
    entityModel?: IMasterEntityModel
    filter?: IActivityFilterModel;
    sort?: ISortModel;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:IDGMSDragAndDrop) => void;
    customClipboardRowAndHeader?: boolean;
    enableRowSelection?: boolean;
}

class DGMSActivityListCommandBar extends React.Component<IDGMSActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.filter) {
            items.push(ActivityFilterMenuHelper.createActivityFilterItem(this.props.filter));
        }
        if(items.length > 0) {
            return <CommandBar className="dgms-activity-list-command-bar" items={items} />;
        }
        return null;
    }
}

class DGMSActivityList extends React.Component<IDGMSActivityListProps, any> {
    _handleRenderItems = (items : IDGMSActivity[]) => {
        return <DGMSActivityListDetailView
                    items={items}
                    entityModel={this.props.entityModel}
                    sort={this.props.sort}
                    customClipboardRowAndHeader = {this.props.customClipboardRowAndHeader}
                    enableRowSelection={this.props.enableRowSelection}
                    onItemsDragStart={this.props.onItemsDragStart} />;
    }
    render() {
        return (
            <ListContainer 
                className="dgms-activity-list"
                typeLabel="DGMS Activities"
                list={this.props.list}
                onRenderItems={this._handleRenderItems} />
        );
    }
}

class DGMSActivityListContainer extends React.Component<IDGMSActivityListProps, any> {
    _handleOpenChange = (open) => {
        this.props.list.setVisible(open);
    }
    render() {

        let positionText;
        if (this.props.position) {
            positionText = "(" + this.props.position.toString() + ") ";
        }

        return (
            <Details open={this.props.list.visible}
                     summary={<span>{positionText}DGMS Activities <ListTotal list={this.props.list} /></span>}
                     onOpenChange={this._handleOpenChange}
                     controlOnHeaderClick={true}>
                <DGMSActivityListCommandBar {...this.props} />
                <DGMSActivityList {...this.props} />
            </Details>
        );
    }
}

export { DGMSActivityListContainer as default, DGMSActivityListContainer, DGMSActivityList, IDGMSActivityListProps }