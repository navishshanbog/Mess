import * as React from "react";
import { observer } from "mobx-react";
import IDGMSActivity from "../IDGMSActivity";
import * as DGMSConstants from "../DGMSConstants";
import ISortModel from "common/ISortModel";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    Selection,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import DGMSActivityColumns from "./DGMSActivityColumns";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import {DetailsHeader} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import {IDetailsHeaderProps} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import { IconButton } from 'office-ui-fabric-react/lib/Button';
import * as DGMSActivityHelper from "../DGMSActivityHelper";
import IMasterEntityModel from "entity/IMasterEntityModel";
import "./DGMSActivityListDetailView.scss";
import { IDGMSDragAndDrop }  from "./MasterEntityDGMS";


interface IDGMSActivityListDetailViewProps {
    items: IDGMSActivity[];
    entityModel?: IMasterEntityModel;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:IDGMSDragAndDrop) => void;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    customClipboardRowAndHeader?: boolean;
}

const DefaultDGMSActivityListDetailViewProps : IDGMSActivityListDetailViewProps = {
    items: [],
    clipBoard: AppClipboardStore
};

@observer
class DGMSActivityListDetailView extends React.Component<IDGMSActivityListDetailViewProps, any> {
    public static defaultProps = DefaultDGMSActivityListDetailViewProps;

    private _selection: Selection;
    private entityModel?: IMasterEntityModel;

    constructor(props:IDGMSActivityListDetailViewProps) {
        super(props);
        this._selection = new Selection({
        });

        this.entityModel = props.entityModel;
    }

    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.customClipboardRowAndHeader) {
            this.props.sort.toggleSort(column.fieldName);
            this.props.clipBoard.updateSortOrderForItems(DGMSActivityHelper.sort(this.props.items, this.props.sort), DGMSConstants.sourceSystemCode);
        } else  {
            this.props.sort.toggleSort(column.fieldName);
        }
    }

    private _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        let dragandDrop: IDGMSDragAndDrop = {items: this._selection.getSelection() as IDGMSActivity[], columnsToReport: DGMSActivityColumns, entityModel:this.props.entityModel};
        this.props.onItemsDragStart(e, dragandDrop);
    }

    _removeRowFromSelection(item) {
        this.props.clipBoard.removeItemFromGroup(item, DGMSConstants.sourceSystemCode);
    }

    private _onRenderRow = (props : IDetailsRowProps) => {
        var item = props.item;
        if(this.props.customClipboardRowAndHeader) {
            return (
                <div className="dgms-custom-cb-row">
                    <div className="dgms-custom-row-render-action">
                        <IconButton className="custom-action-red"
                                    iconProps={ { iconName: 'SkypeMinus' } }
                                    title='Delete'
                                    ariaLabel='Delete'
                                    onClick={this._removeRowFromSelection.bind(this, item)}/>
                    </div>
                    <div className="dgms-custom-row">
                        <DetailsRow {...props} />
                    </div>
                </div>
            );
        }
        return (
            <div draggable={true} onDragStart={this._handleDragStart}>
                <DetailsRow {...props} />
            </div>
        );
    }

    _onRenderHeader = (props: IDetailsHeaderProps) =>{
        return (
            <div className="dgms-custom-header">
                <DetailsHeader {...props} />
            </div>
        );
    }
    render() {
        const columns = ColumnSortHelper.applySort(DGMSActivityColumns, this.props.sort);
        return (
            <div className="dgms-activity-list-detail-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                                items={this.props.items}
                                onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                layoutMode={DetailsListLayoutMode.fixedColumns}
                                constrainMode={ConstrainMode.unconstrained}
                                onRenderRow = {this._onRenderRow}
                                onRenderDetailsHeader = {this.props.customClipboardRowAndHeader ? this._onRenderHeader: undefined}
                                selection={ this._selection }
                                checkboxVisibility={this.props.enableRowSelection ? CheckboxVisibility.onHover: CheckboxVisibility.hidden} />
            </div>
        );
    }
}

export{
    DGMSActivityListDetailView as default,
    DGMSActivityListDetailView,
    IDGMSActivityListDetailViewProps
};
