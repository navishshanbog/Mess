import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import DGMSActivityList from "./DGMSActivityList";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import IDGMSActivity from "../IDGMSActivity";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IMasterEntityDGMSModel from "../IMasterEntityDGMSModel";
import * as DGMSConstants from "../DGMSConstants";
import { action } from "mobx";
import * as DGMSActivityHelper from "../DGMSActivityHelper";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";

interface IMasterEntityDGMSProps {
    dgms?: IMasterEntityDGMSModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
}

const DefaultDGMSActivityListDetailViewProps : IMasterEntityDGMSProps = {
    clipBoard: AppClipboardStore
};

interface IDGMSDragAndDrop {
    items: IDGMSActivity[];
    columnsToReport?: any[];
    entityModel?: IMasterEntityModel;
}

@observer
class MasterEntityDGMS extends React.Component<IMasterEntityDGMSProps, any> {
    public static defaultProps = DefaultDGMSActivityListDetailViewProps;

    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, dragAndDrop?:IDGMSDragAndDrop) => {
        e.stopPropagation();
        const entityRef = this.props.dgms.ref;
        if(dragAndDrop.items.length > 0) {
            const transferData = {
                type: DGMSConstants.sourceSystemCode,
                items: dragAndDrop.items,
                columns: dragAndDrop.columnsToReport
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            this.props.clipBoard.openClipboard();
            this.props.clipBoard.setDraggedEntity(entityRef);
        }), 10);
    }

    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[DGMSConstants.sourceSystemCode];
        if(source) {
            return (
                <div className="master-entity-dgms-summary">
                    <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                    <DGMSActivityList
                        list={this.props.dgms.activityList}
                        sort={this.props.dgms.activityList.sort}
                        filter={this.props.dgms.activityList.filter}
                        enableRowSelection={true}
                        onItemsDragStart={this._handleItemsDragStart} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No DGMS information available</MessageBar>;
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the DGMS summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.dgms}
                                        onRenderContent={this._handleRenderContent}
                                        onRenderNotLoaded={this._handleRenderNotLoaded} />;
    }
}

export {
    MasterEntityDGMS as default,
    MasterEntityDGMS,
    IMasterEntityDGMSProps,
    IDGMSDragAndDrop
}