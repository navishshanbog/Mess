import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import DGMSActivityList from "./DGMSActivityList";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import IDGMSActivity from "../IDGMSActivity";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IMasterEntityDGMSModel from "../IMasterEntityDGMSModel";
import * as DGMSConstants from "../DGMSConstants";
import { action } from "mobx";
import {IDGMSDragAndDrop} from "./MasterEntityDGMS";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import IMultipleMasterEntityListCompositeModel from "entity/IMultipleMasterEntityListCompositeModel";
import IMasterEntityRefModel from "entity/IMasterEntityRefModel";
import {MasterEntityRefModel} from "entity/MasterEntityRefModel";
// import AppMultipleMasterEntityListCompositeStore from "entity/AppMultipleMasterEntityListCompositeStore";


interface IMultipleMasterEntityDGMSProps {

    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
}

/* const DefaultDGMSActivityListDetailViewProps : IMultipleMasterEntityDGMSProps = {

    clipBoard: AppClipboardStore,
    multipleMasterEntity: AppMultipleMasterEntityListCompositeStore
}; */

@observer
class MultipleMasterEntityDGMS extends React.Component<IMultipleMasterEntityDGMSProps, any> {

    // public static defaultProps = DefaultDGMSActivityListDetailViewProps;

    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, dragAndDrop?:IDGMSDragAndDrop) => {
        e.stopPropagation();
        const entityRef = dragAndDrop.entityModel;

        if(dragAndDrop.items.length > 0) {
            const transferData = {
                type: DGMSConstants.sourceSystemCode,
                items: dragAndDrop.items
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            AppClipboardStore.openClipboard();
            AppClipboardStore.setDraggedEntity(entityRef);
        }), 10);
    }


    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[DGMSConstants.sourceSystemCode];
        if(source) {

            // lookup by masterEntityId
            let dgmsModel : IMasterEntityDGMSModel = this.props.multipleMasterEntity.dgmsByMasterEntityId(masterEntity.masterEntityId);

            return (
                <div className="master-entity-dgms-summary">
                    <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                    <DGMSActivityList
                        position={masterEntity.position}
                        entityModel={masterEntity}
                        list={dgmsModel.activityList}
                        sort={dgmsModel.activityList.sort}
                        filter={dgmsModel.activityList.filter}
                        enableRowSelection={true}
                        onItemsDragStart={this._handleItemsDragStart} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No DGMS information available</MessageBar>;
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the DGMS summary</MessageBar>;
    }

    _buildMultipleEntityContent() {

        let entries = (this.props.multipleMasterEntity.getSelection().getSelection() as IMasterEntityModel[]).map((thisMasterEntity : IMasterEntityModel, index : number) => {

            let refModel : IMasterEntityRefModel = new MasterEntityRefModel();
            refModel.setRef(thisMasterEntity);
            thisMasterEntity.position = index+1;

            return (
                <div key={index} className="master-entity-iat">
                    <MasterEntityContainer masterEntityRef={refModel}
                                           onRenderContent={this._handleRenderContent}
                                           onRenderNotLoaded={this._handleRenderNotLoaded} />;
                </div>);
        });


        return (
            <div className="multiple-master-entity-iat">
                {entries}
            </div>);
    }

    render() {
        /*
        return <MasterEntityContainer masterEntityRef={this.props.dgms}
                                        onRenderContent={this._handleRenderContent}
                                        onRenderNotLoaded={this._handleRenderNotLoaded} />;
        */

        let multipleDetails = this._buildMultipleEntityContent();

        return (
            <div className="multiple-master-entity-dgms">
                {multipleDetails}
            </div>
        );
    }
}

export {
    MultipleMasterEntityDGMS as default,
    MultipleMasterEntityDGMS,
    IMultipleMasterEntityDGMSProps
}