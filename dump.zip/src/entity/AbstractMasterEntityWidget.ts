import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import { autorun, IReactionDisposer } from "mobx";
import IMasterEntityModel from "./IMasterEntityModel";
import IMasterEntityRefModel from "./IMasterEntityRefModel";
import MasterEntityIdRefStore from "./MasterEntityIdRefStore";

abstract class AbstractMasterEntityWidget implements IWidget {
    context: IWidgetContext;
    private _searchResultRefAutorunDisposer : IReactionDisposer;
    private _idRefAutorunDisposer : IReactionDisposer;
    protected abstract masterEntityRef : IMasterEntityRefModel;
    protected abstract _setView() : void;
    protected _observeRefs() {
        this._idRefAutorunDisposer = autorun(() => {
            if(MasterEntityIdRefStore.ref) {
                this.masterEntityRef.loadById(MasterEntityIdRefStore.ref);
            }
        });
    }
    protected _ignoreRefs() {
        if(this._idRefAutorunDisposer) {
            this._idRefAutorunDisposer();
        }
    }
    start() {
        const masterEntity : IMasterEntityModel = this.context.props ? this.context.props.masterEntity : undefined;
        if(masterEntity) {
            this.masterEntityRef.setRef(masterEntity);
        } else {
            this._observeRefs();
        }
        this._setView();
    }
    stop() {
        this._ignoreRefs();
    }
}

export { AbstractMasterEntityWidget as default, AbstractMasterEntityWidget }