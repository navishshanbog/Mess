import MultipleMasterEntityListCompositeModel from "./MultipleMasterEntityListCompositeModel";

// this needs to moveinto a "multiple master entity package"
const AppMultipleMasterEntityListCompositeStore = new MultipleMasterEntityListCompositeModel();

export { AppMultipleMasterEntityListCompositeStore as default, AppMultipleMasterEntityListCompositeStore };