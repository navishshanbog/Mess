import IMasterEntitySourceEntityName from "./IMasterEntitySourceEntityName";
import IMasterEntitySourceModel from "./IMasterEntitySourceModel";
import { Output as DateOutputFormats } from "common/DateFormats";
import * as StringUtils from "util/String";
import { dataToOutputText, momentFromDataText } from "util/Date";
import * as moment from "moment";

const NAME_USAGE_TYPE_MAIN = "MAIN";
const MONTH_NAMES = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN","JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

const getNameScore = (name : IMasterEntitySourceEntityName, isPerson : boolean = false) : number => {
    let score = 0;
    if(name) {
        if(isPerson) {
            score += (StringUtils.isNotBlank(name.firstName) ? 1 : 0);
            score += (StringUtils.isNotBlank(name.middleName) ? 1 : 0);
            score += (StringUtils.isNotBlank(name.familyName) ? 1 : 0);   
        }
        score += (StringUtils.isNotBlank(name.standardFullName) ? 1 : 0);
    }
    return score;
};

const isMainName = (name : IMasterEntitySourceEntityName) : boolean => {
    return name && StringUtils.equalsIgnoreCase(name.usageTypeCd, NAME_USAGE_TYPE_MAIN);
};


const formatToNISName = (familyName: string, firstName: string, middleName: string, gender: string, dateOfBirth: Date | string) : string => {

    let dobDisplayValue;
    if (dateOfBirth && typeof(dateOfBirth) === 'string') {

        let dobMoment = momentFromDataText(dateOfBirth);

        dobDisplayValue = " " + moment(dobMoment).format(DateOutputFormats.nisFormat).toUpperCase();
    }
    else if (dateOfBirth) {

        dobDisplayValue = " " + moment(dateOfBirth).format(DateOutputFormats.nisFormat).toUpperCase();
    }
    else
    {
        dobDisplayValue = "";
    }


    return `${familyName}, ${firstName}`
        + (middleName ? " " + middleName : "")
        + (gender ? " (" + genderToNISFormat(gender) + ")" : "(-)")
        + dobDisplayValue;
}

const toNISFormat = (sourceEntityModel: IMasterEntitySourceModel) : string => {
   var nisDOB : string;
   var nisName : string;
   var nisGender: string;  // to cater for M/F/U etc in future;
   var nameFormatted : string;

   if(sourceEntityModel && sourceEntityModel.dateOfBirth ) {
       nisDOB = nisDOBFormat(sourceEntityModel.dateOfBirth)
   }
    if(sourceEntityModel && sourceEntityModel.name ) {
        nisName = nameToNISFormat(sourceEntityModel.name);
   }
    if(sourceEntityModel && sourceEntityModel.gender ) {
        nisGender = " ("+genderToNISFormat(sourceEntityModel.gender)+") ";
    }
    nameFormatted = nisName+nisGender+nisDOB;
    return nameFormatted;
}

const capitalizeFirstLetter = (string) => {
    return string.charAt(0).toUpperCase() + string.slice(1);
}


const genderToNISFormat = (gender: string):string => {
    var genderChar = "N";
    switch(gender.toLowerCase()) {
        case 'male': genderChar = "M"; break;
        case 'female': genderChar = "F"; break;
        case 'undeclared': genderChar = "-"; break;
        case 'unknown': genderChar = "U"; break;
        case 'indeterminate': genderChar = "X"; break;

    }
    return genderChar;
}

// takes a Name object and return <FAMILY NAME> <Middle name> <Last name> format. Note: Family name is upper case
const nameToNISFormat = (name: any): string => {
    var nisName = '';
    if(name.familyName) {
        nisName = name.familyName.toUpperCase()+", ";
    }
    if(name.middleName) {
        name.middleName = name.middleName.toLowerCase();
        nisName += capitalizeFirstLetter(name.middleName) + " ";
    }
    if(name.firstName) {
        name.firstName = name.firstName.toLowerCase();
        nisName += capitalizeFirstLetter(name.firstName);
    }
    // It is assumed that we either get firstName or given Names but never both.
    if(name.givenNames) {
        name.givenNames = name.givenNames.toLowerCase();
        nisName += capitalizeFirstLetter(name.givenNames);
    }
    return nisName;
}

// takes a date format and returns a string formatted as ddMMMYYYY
const nisDOBFormat = (dob: Date): string => {
    return moment(dob).format('DDMMMYYYY');
}

// takes a date format and returns a string formatted as dd/MMM/YYYY
const summaryDateFormat = (dob: Date): string => {
    return moment(dob).format('DD/MM/YYYY');
}

// takes a date format and returns time as string formatted as hh:mm:ss
const summaryTimeFormat = (dob: Date): string => {
    return moment(dob).format('hh:mm:ss');
}

// takes a datetime format and returns datetime as string formatted as dd/MMM/YYYY hh:mm:ss
const summaryDateTimeFormat = (dob: Date): string => {
    return (dob ? moment(dob).format('DD/MM/YYYY hh:mm:ss') : "");
}

export { getNameScore, isMainName, formatToNISName, toNISFormat, nameToNISFormat, nisDOBFormat, 
    genderToNISFormat, summaryDateFormat, summaryTimeFormat, summaryDateTimeFormat };