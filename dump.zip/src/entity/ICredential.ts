interface ICredential {
    id?: string;
    type?: string;
    value?: string;
}

export { ICredential as default, ICredential };