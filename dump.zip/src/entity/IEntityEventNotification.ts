import IMasterEntity from "entity/IMasterEntity";

interface IEntityEventNotification {

    entityLoaded(item : IMasterEntity);
}

export { IEntityEventNotification as default, IEntityEventNotification };