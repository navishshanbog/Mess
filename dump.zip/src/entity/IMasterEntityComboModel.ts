import IMasterEntitySearchRequestModel from "./IMasterEntitySearchRequestModel";
import IMasterEntityRefModel from "./IMasterEntityRefModel";
import IMasterEntitySearchResultModel from "./IMasterEntitySearchResultModel";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";

enum MasterEntityComboPlace {
    search,
    searchResult,
    masterEntity
};

interface IMasterEntityComboModel {
    place: MasterEntityComboPlace;
    searchRequest: IMasterEntitySearchRequestModel;
    searchResult: IMasterEntitySearchResultModel;
    masterEntityRef: IMasterEntityRefModel;
    submitRequest(request : IMasterEntitySearchRequest) : void;
    goToSearch() : void;
    goToSearchResults() : void;
    goToMasterEntity() : void;
}

export { IMasterEntityComboModel as default, IMasterEntityComboModel, MasterEntityComboPlace };