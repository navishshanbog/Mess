import IEntityModel from "./IEntityModel";
import IMasterEntitySourceModel from "./IMasterEntitySourceModel";
import IActivityFilterModel from "common/IActivityFilterModel";

interface IMasterEntityModel extends IEntityModel {

    // this is a leakage into the model for the view that needs to be looked at
    position?: number;

    masterEntityId: string;
    sources: IMasterEntitySourceModel[];
    sourceMap: { [key : string] : IMasterEntitySourceModel };
    sourceCodes: string[];
    activityFilter: IActivityFilterModel;
}

export { IMasterEntityModel as default, IMasterEntityModel };