import ISyncModel from "common/ISyncModel";
import IRefModel from "common/IRefModel";
import IMasterEntityModel from "./IMasterEntityModel";

interface IMasterEntityRefModel extends IRefModel<IMasterEntityModel> {
    sync: ISyncModel;
    masterEntityId: string;
    loadById(masterEntityId : string) : void;
}

export { IMasterEntityRefModel as default, IMasterEntityRefModel }