import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";

interface IMasterEntitySearchActions {
    submitRequest(request : IMasterEntitySearchRequest) : void;
}

export { IMasterEntitySearchActions as default, IMasterEntitySearchActions }