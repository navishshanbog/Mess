import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import IListModel from "common/IListModel";
import IActionContainer from "common/IActionContainer";

interface IMasterEntitySearchHistoryModel extends IListModel<IMasterEntitySearchRequestEntry> {
    selectActions : IActionContainer<IMasterEntitySearchRequestEntry>;
    load() : Promise<any>;
    addItem(item : IMasterEntitySearchRequestEntry) : Promise<any>;
    selectItem(item : IMasterEntitySearchRequestEntry) : void;
}

export { IMasterEntitySearchHistoryModel as default, IMasterEntitySearchHistoryModel };