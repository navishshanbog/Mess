import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";

interface IMasterEntitySearchResult {
    items: IMasterEntitySearchResultItem[];
}

export { IMasterEntitySearchResult as default, IMasterEntitySearchResult };