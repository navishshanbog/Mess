interface IMasterEntitySearchResultItem {
    mstrEntyId?: number;
    stdFullNm?: string;
    dtOfBrth?: string;
    sexCd?: string;
    stdAdrsVlu?: string;
    phnNbr?: string;
    crdntlTypCd?: string;
    crdntlVlu?: string;
    emailVlu?: string;
    ALL_SYST?: number;
    PNR?: number;
    ICS?: number;
    IAT?: number;
    BAGS?: number;
    INTCP?: number;
    DGMS?: number;
    ABR?: number;
    ASIC?: number;
    EROLL?: number;
    IATA?: number;
    EXAMS?: number;
}

export { IMasterEntitySearchResultItem as default, IMasterEntitySearchResultItem };