import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import ViewType from "common/ViewType";

interface IMasterEntitySearchResultModel extends IListModel<IMasterEntitySearchResultItem> {
    sort: ISortModel;
    textFilter: string;
    requestEntry: IMasterEntitySearchRequestEntry;
    search(requestEntry : IMasterEntitySearchRequestEntry);
    refresh() : Promise<any>;
    setTextFilter(textFilter : string) : void;
    openItem(item : IMasterEntitySearchResultItem) : void;
}

export { IMasterEntitySearchResultModel as default, IMasterEntitySearchResultModel };