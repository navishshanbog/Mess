import IMasterEntitySourceEntity from "./IMasterEntitySourceEntity";

interface IMasterEntitySource {
    masterEntityId?: number;
    sourceSystemCode?: string;
    sourceEntities?: IMasterEntitySourceEntity[];
}

export { IMasterEntitySource as default, IMasterEntitySource };