import IMasterEntitySourceKey from "./IMasterEntitySourceKey";

interface IMasterEntitySourceEntityCredential extends IMasterEntitySourceKey {
    sourceEntityCredentialId?: number;
    credentialTypeCd?: string;
    credentialValue?: string;
    internalIndicator?: string;
    credentialCountryCd?: string;
    issuingCountryCd?: string;
    issuingAuthorityCd?: string;
    effectiveStartDt?: string;
}

export { IMasterEntitySourceEntityCredential as default, IMasterEntitySourceEntityCredential };