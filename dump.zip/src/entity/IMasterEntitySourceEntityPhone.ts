import IMasterEntitySourceKey from "./IMasterEntitySourceKey";

interface IMasterEntitySourceEntityPhone extends IMasterEntitySourceKey {
    sourceEntityPhoneId?: number;
    usageTypeCd?: string;
    phoneValue?: string;
    australianFormatIndicator?: string;
    phoneTypeCd?: string;
    countryCd?: string;
    areaCd?: string;
    phoneNumber?: string;
    identifiedContactValue?: string;
    effectiveStartDt?: string;
}

export { IMasterEntitySourceEntityPhone as default, IMasterEntitySourceEntityPhone };