interface IMasterEntitySourceKey {
    masterEntityId?: number;
    sourceEntityId?: number;
    sourceSystemCd?: string;
}

export { IMasterEntitySourceKey as default, IMasterEntitySourceKey };