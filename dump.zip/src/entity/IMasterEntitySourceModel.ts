import IMasterEntitySource from "./IMasterEntitySource";
import IEntityModel from "./IEntityModel";
import IMasterEntitySourceRef from "./IMasterEntitySourceRef";
import IMasterEntitySourceEntityMeta from "./IMasterEntitySourceEntityMeta";

interface IMasterEntitySourceModel extends IEntityModel, IMasterEntitySource {
    rel : any;
    setRel(rel : any) : void;
}

export { IMasterEntitySourceModel as default, IMasterEntitySourceModel };