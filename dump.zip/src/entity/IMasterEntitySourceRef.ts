import IMasterEntitySourceKey from "./IMasterEntitySourceKey";

interface IMasterEntitySourceRef extends IMasterEntitySourceKey {
    masterSourceSystemCd?: string;
    masterSourceObjectTypeCd?: string;
    masterSourceKeyValue?: string;
    MDMProfileName?: string;
    masteredIndicator?: string;
    MDMMatchScorePercent?: number;
    sourceObjectTypeCd?: string;
    sourceKeyValue?: string;
    sourceRelatedKeyValue?: string;
    masterEntityNameID?: number;
    masterEntityAddressID?: number;
    masterEntityCredentialID?: number;
    masterEntityEmailID?: number;
    masterEntityPhoneID?: number;
    sourceEntityNameId?: number;
    sourceEntityAddressId?: number;
    sourceEntityCredentialId?: number;
    sourceEntityEmailId?: number;
    sourceEntityPhoneId?: number;
    masterValidStartTmstmp?: string;
    sourceValidStartTmstmp?: string;
    CDLStartTmstmp?: string;
}

export { IMasterEntitySourceRef as default, IMasterEntitySourceRef };