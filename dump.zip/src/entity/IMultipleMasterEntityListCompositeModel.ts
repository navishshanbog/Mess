import ISyncModel from "common/ISyncModel";
import IListModel from "common/IListModel";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IEntityAttributeActions from "./IEntityAttributeActions";
import { ISelection } from "office-ui-fabric-react/lib/Selection";
import IActivityFilterModel from "common/IActivityFilterModel";
import IMasterEntityIATModel from "iat/IMasterEntityIATModel";
import IMasterEntityCargoModel from "cargo/IMasterEntityCargoModel";
import IMasterEntityBAGSModel from "bags/IMasterEntityBAGSModel";
import IMasterEntityDGMSModel from "dgms/IMasterEntityDGMSModel";


interface IMultipleMasterEntityListCompositeModel extends IEntityAttributeActions, IActivityFilterModel {
    sync: ISyncModel;
    items : IListModel<IMasterEntityModel>;
    itemsView() : IMasterEntityModel[];
    requestedMasterEntityId: string;
    loadById(masterEntityId : string) : void;

    iatByMasterEntityId(masterEntityId : string) : IMasterEntityIATModel;
    cargoByMasterEntityId(masterEntityId : string) : IMasterEntityCargoModel;
    bagsByMasterEntityId(masterEntityId : string) : IMasterEntityBAGSModel;
    dgmsByMasterEntityId(masterEntityId : string) : IMasterEntityDGMSModel;

    selectedItems: ISelection;

    getSelection() : ISelection;
    setSelection(ISelection) : void;
    deleteItemByEntityId(key : string);
}

export { IMultipleMasterEntityListCompositeModel as default, IMultipleMasterEntityListCompositeModel }
