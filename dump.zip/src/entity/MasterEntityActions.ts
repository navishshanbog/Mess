import { action } from "mobx";
import MasterEntityIdRefStore from "./MasterEntityIdRefStore";

const loadById = action((id : string) => {
    MasterEntityIdRefStore.setRef(id);
});

export { loadById }