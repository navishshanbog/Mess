import * as React from "react";
import IApplet from "app/IApplet";
import IAppModel from "app/IAppModel";
import MasterEntityRefModel from "./MasterEntityRefModel";
import MasterEntityContainer from "./component/MasterEntityContainer";
import MasterEntityNav from "./component/MasterEntityNav";
import * as MasterEntitySearchHelper from "./MasterEntitySearchHelper";
import { submitRequest } from "./MasterEntitySearchActions";
import MasterEntitySearchResultRoute from "./MasterEntitySearchResultRoute";
import AppMultipleMasterEntityListCompositeStore from "./AppMultipleMasterEntityListCompositeStore";

class MasterEntityApplet implements IApplet {
    context: IAppModel;
    private _masterEntityRef : MasterEntityRefModel;

    private _searchRequestHandler = (request) => {
        submitRequest(request);
        this.context.open({ path: MasterEntitySearchResultRoute.path });
    };
    constructor() {
        this._masterEntityRef = new MasterEntityRefModel(AppMultipleMasterEntityListCompositeStore);
        this._masterEntityRef.attributeActions = {
            onSearch: (request) => {
                this._searchRequestHandler(request);
            }
        }
    }
    start() {
        this._masterEntityRef.loadById(this.context.place.params.masterEntityId);
        this.context.view.setContent({
            title: "Entity Details",
            nav: <MasterEntityNav masterEntityRef={this._masterEntityRef} />,
            main: <MasterEntityContainer masterEntityRef={this._masterEntityRef}
                                         entityEventNotification={AppMultipleMasterEntityListCompositeStore} />
        });
    }
};

export { MasterEntityApplet as default, MasterEntityApplet };