import { observable, action } from "mobx";
import { IMasterEntityComboModel, MasterEntityComboPlace } from "./IMasterEntityComboModel";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import MasterEntitySearchRequestModel from "./MasterEntitySearchRequestModel";
import MasterEntitySearchResultModel from "./MasterEntitySearchResultModel";
import MasterEntityRefModel from "./MasterEntityRefModel";
import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import * as MasterEntitySearchHelper from "./MasterEntitySearchHelper";
import { submitRequest as submitRequestAction } from "./MasterEntitySearchActions";
import AppMultipleMasterEntityListCompositeStore from "./AppMultipleMasterEntityListCompositeStore";

class MasterEntityComboModel implements IMasterEntityComboModel {
    @observable place : MasterEntityComboPlace = MasterEntityComboPlace.search;
    @observable searchRequest = new MasterEntitySearchRequestModel();
    @observable searchResult = new MasterEntitySearchResultModel();
    @observable masterEntityRef = new MasterEntityRefModel(AppMultipleMasterEntityListCompositeStore);

    constructor() {
        this.searchRequest.onSubmitRequest = this.submitRequest;
        this.searchRequest.onLoadById = this.loadById;
        this.searchResult.openItem = this.openItem;
        this.masterEntityRef.attributeActions = {
            onSearch: this.submitRequest
        };
    }

    @action
    submitRequest = (searchRequest : IMasterEntitySearchRequest) => {
        submitRequestAction(searchRequest);
        this.searchResult.search({ request: searchRequest, timestamp: new Date()});
        this.goToSearchResults();
    }

    @action
    loadById = (id : string) => {
        this.masterEntityRef.loadById(id);
        this.goToMasterEntity();
    }

    @action
    openItem = (item : IMasterEntitySearchResultItem) => {
        this.masterEntityRef.loadById(String(item.mstrEntyId));
        this.goToMasterEntity();
    }

    @action
    goToSearch() : void {
        this.place = MasterEntityComboPlace.search;
    }

    @action
    goToSearchResults() : void {
        this.place = MasterEntityComboPlace.searchResult;
    }

    @action
    goToMasterEntity() : void {
        this.place = MasterEntityComboPlace.masterEntity;
    }
}

export { MasterEntityComboModel as default, MasterEntityComboModel };