import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import MasterEntityCombo from "./component/MasterEntityCombo";
import MasterEntityComboModel from "./MasterEntityComboModel";
import AppMultipleMasterEntityListCompositeStore from "./AppMultipleMasterEntityListCompositeStore";

class MasterEntityComboWidget implements IWidget {
    context: IWidgetContext;
    private _masterEntityCombo : MasterEntityComboModel = new MasterEntityComboModel();

    start() {
        this.context.setView(<MasterEntityCombo masterEntityCombo={this._masterEntityCombo}
                                     entityEventNotification={AppMultipleMasterEntityListCompositeStore} />);
    }
};

export { MasterEntityComboWidget as default, MasterEntityComboWidget };