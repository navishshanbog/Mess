import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { Icon } from "office-ui-fabric-react/lib/Icon";

const MasterEntityComboWidgetEntry : IWidgetEntry = {
    key: "entitySearch",
    keyAliases: ["masterEntityCombo"],
    name: "Entity Search",
    icon: <Icon iconName="Search" />,
    largeIcon: <Icon iconName="Search" />,
    description: "Entity Search",
    get widgetType() {
        return import("./MasterEntityComboWidget").then(r => r.default);
    }
};

export { MasterEntityComboWidgetEntry as default, MasterEntityComboWidgetEntry };