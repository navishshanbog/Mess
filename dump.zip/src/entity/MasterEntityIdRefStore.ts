import RefModel from "common/RefModel";

const MasterEntityIdRefStore = new RefModel<string>();

export { MasterEntityIdRefStore as default, MasterEntityIdRefStore }