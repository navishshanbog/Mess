import PathTemplate from "common/PathTemplate";

const MasterEntityPathTemplate = new PathTemplate("masterEntity/:masterEntityId");

export { MasterEntityPathTemplate as default, MasterEntityPathTemplate };