import { observable, action, computed } from "mobx";
import ISyncModel from "common/ISyncModel";
import SyncModel from "common/SyncModel";
import RefModel from "common/RefModel";
import IMasterEntityRefModel from "./IMasterEntityRefModel";
import IMasterEntity from "./IMasterEntity";
import IMasterEntityModel from "./IMasterEntityModel";
import MasterEntityModel from "./MasterEntityModel";
import MasterEntityServiceContext from "./MasterEntityServiceContext";
import IEntityAttributeActions from "./IEntityAttributeActions";
import IEntityEventNotification from "entity/IEntityEventNotification";


class MasterEntityRefModel extends RefModel<IMasterEntityModel> implements IMasterEntityRefModel {
    @observable sync : ISyncModel = new SyncModel();
    @observable masterEntityId: string;
    @observable.ref private _attributeActions : IEntityAttributeActions;

    private _entityEventNotification : IEntityEventNotification;

    constructor(notification?: IEntityEventNotification) {
        super();

        this._entityEventNotification = notification;
    }

    set entityNotification(value: IEntityEventNotification) {
        this._entityEventNotification = value;
    }

    get entityNotification() {
        return this._entityEventNotification;
    }


    @action
    setData(data : IMasterEntity) {
        if(data) {
            const m = new MasterEntityModel(data);
            m.attributeActions = this.attributeActions;
            this.setRef(m);

            if (this._entityEventNotification) {

                this._entityEventNotification.entityLoaded(m);
            }
        } else {
            this.setRef(undefined);
        }
    }

    @action
    setRef(ref : IMasterEntityModel) {
        super.setRef(ref);

        this.sync.syncEnd();
    }

    @action
    setError(error : any) {
        this.setRef(undefined);
        this.sync.syncError(error);
    }

    @action
    refresh() {
        const syncId = this.masterEntityId;
        this.sync.syncStart({ id: syncId });
        MasterEntityServiceContext.ref.getMasterEntityById(this.masterEntityId).then((data) => {
            if(syncId === this.sync.id) {
                this.setData(data);
            }
        }).catch((error) => {
            if(syncId === this.sync.id) {
                this.setError(error);
            }
        });
    }

    @action
    loadById(masterEntityId : string) : void {
        if(masterEntityId !== this.masterEntityId) {
            this.masterEntityId = masterEntityId;
            this.refresh();
        }
    }

    @computed
    get attributeActions() {
        return this._attributeActions;
    }
    set attributeActions(value : IEntityAttributeActions) {
        this._attributeActions = value;
        if(this.ref) {
            this.ref.attributeActions = value;
        }
    }
}

export { MasterEntityRefModel as default, MasterEntityRefModel }
