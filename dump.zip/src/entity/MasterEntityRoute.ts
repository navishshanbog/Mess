import IAppRoute from "app/IAppRoute";
import MasterEntityPathTemplate from "./MasterEntityPathTemplate";

const MasterEntityRoute : IAppRoute = {
    key: "masterEntity",
    name: "Master Entity",
    pathTemplate: MasterEntityPathTemplate,
    get appletType() {
        return import("./MasterEntityApplet").then(r => r.default);
    }
};

export { MasterEntityRoute as default, MasterEntityRoute };