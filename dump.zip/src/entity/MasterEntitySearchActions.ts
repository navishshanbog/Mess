import { action } from "mobx";
import IMasterEntitySearchActions from "./IMasterEntitySearchActions";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import MasterEntitySearchRequestRefStore from "./MasterEntitySearchRequestRefStore";
import MasterEntitySearchHistoryStore from "./MasterEntitySearchHistoryStore";

const submitRequest = action((request : IMasterEntitySearchRequest) => {
    const e : IMasterEntitySearchRequestEntry = { request: request, timestamp: new Date() };

    MasterEntitySearchRequestRefStore.setRef(e);
    MasterEntitySearchHistoryStore.addItem(e);
});

export { submitRequest }