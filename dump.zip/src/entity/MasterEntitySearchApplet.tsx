import * as React from "react";
import IApplet from "app/IApplet";
import IAppModel from "app/IAppModel";
import MasterEntitySearchRequestModel from "./MasterEntitySearchRequestModel";
import MasterEntitySearchRequestTabs from "./component/MasterEntitySearchRequestTabs";
import MasterEntityNav from "./component/MasterEntityNav";
import MasterEntitySearchResultRoute from "./MasterEntitySearchResultRoute";
import MasterEntityRoute from "./MasterEntityRoute";
import { submitRequest as submitRequestAction } from "./MasterEntitySearchActions";
import { loadById as loadByIdAction } from "./MasterEntityActions";

class MasterEntitySearchApplet implements IApplet {
    context: IAppModel;
    private _searchRequest : MasterEntitySearchRequestModel;
    private _submitRequest = (request) => {
        submitRequestAction(request);
        this.context.open({ path: MasterEntitySearchResultRoute.path });
    }
    private _loadById = (id) => {
        loadByIdAction(id);
        this.context.open({ path: MasterEntityRoute.pathTemplate.toPath({ masterEntityId: id })});
    }
    constructor() {
        this._searchRequest = new MasterEntitySearchRequestModel();
        this._searchRequest.onSubmitRequest = this._submitRequest;
        this._searchRequest.onLoadById = this._loadById;
    }
    _handleSelectHistoryEntry = (entry) => {
        this._submitRequest(entry.request);
    }
    start() {
        this.context.view.setContent({
            title: "Entity Search",
            nav: <MasterEntityNav />,
            main: <MasterEntitySearchRequestTabs searchRequest={this._searchRequest} onSelectHistoryEntry={this._handleSelectHistoryEntry} />
        });
    }
};

export { MasterEntitySearchApplet as default, MasterEntitySearchApplet };