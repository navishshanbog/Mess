import { action } from "mobx";
import MasterEntitySearchServiceContext from "./MasterEntitySearchServiceContext";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import IMasterEntitySearchResult from "./IMasterEntitySearchResult";
import IListModel from "common/IListModel";
import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";

const searchByEntryIntoListDone = action((list : IListModel<IMasterEntitySearchResultItem>, searchResult : IMasterEntitySearchResult) => {
    list.setItems(searchResult && searchResult.items ? searchResult.items : []);
});

const searchByEntryIntoListError = action((list : IListModel<IMasterEntitySearchResultItem>, error : any) => {
    list.sync.syncError(error);
});

const searchByEntryIntoList = action((requestEntry : IMasterEntitySearchRequestEntry, list: IListModel<IMasterEntitySearchResultItem>, skipCheck : boolean = false) : Promise<void> => {
    const syncId = String(requestEntry.timestamp.getTime());
    if(skipCheck || (syncId !== list.sync.id)) {
        list.sync.syncStart({ id: syncId });
        return MasterEntitySearchServiceContext.ref.search(requestEntry.request).then((result) => {
            if(syncId === list.sync.id) {
                searchByEntryIntoListDone(list, result);
            }
        }).catch((error) => {
            if(syncId === list.sync.id) {
                searchByEntryIntoListError(list, error);
            }
        });
    }
    return Promise.resolve();
});

export {
    searchByEntryIntoList
};