import { observable, action, computed } from "mobx";
import IMasterEntitySearchHistoryModel from "./IMasterEntitySearchHistoryModel";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import StorageServiceContext from "common/StorageServiceContext";
import MasterEntitySearchRequestRefStore from "./MasterEntitySearchRequestRefStore";
import { submitRequest } from "./MasterEntitySearchActions";
import ListModel from "common/ListModel";
import ActionContainer from "common/ActionContainer";

const StorageKey = "analystdesktop-entitySearchHistory";

class MasterEntitySearchHistoryModel extends ListModel<IMasterEntitySearchRequestEntry> implements IMasterEntitySearchHistoryModel {
    private _limit : number = 100;
    private _selectActions = new ActionContainer<IMasterEntitySearchRequestEntry>();

    public get limit() {
        return this._limit;
    }
    public set limit(limit : number) {
        if(limit > 0) {
            this._limit = limit;
        }
    }

    get selectActions() {
        return this._selectActions;
    }

    @action
    addItem(item : IMasterEntitySearchRequestEntry) : Promise<any> {
        // ensure items loaded
        return this.load().then(() => {
            this.items.unshift(item);
            if(this.items.length > this.limit) {
                this.items.splice(this.items.length - 1);
            }
            return this._save();
        });
    }

    @action
    selectItem(item : IMasterEntitySearchRequestEntry) {
        this._selectActions.execute(item);
    }

    @action
    private _save() : Promise<any> {
        // ensure any history has been loaded
        return StorageServiceContext.ref.setItem(StorageKey, this.items).catch((error) => {
            console.log("Error Saving Search History");
            console.error(error);
        });
    }

    @action
    load() : Promise<any> {
        if(!this.sync.syncing && !this.sync.hasSynced) {
            this.sync.syncStart();
            return StorageServiceContext.ref.getItem(StorageKey).then((items) => {
                this.setItems(items);
            }).catch((error) => {
                this.setItems([]);
                this.sync.syncError(error);
            });
        }
        return Promise.resolve();
    }
}

export { MasterEntitySearchHistoryModel as default, MasterEntitySearchHistoryModel };