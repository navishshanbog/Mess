import MasterEntitySearchHistoryModel from "./MasterEntitySearchHistoryModel";

const MasterEntitySearchHistoryStore = new MasterEntitySearchHistoryModel();

export { MasterEntitySearchHistoryStore as default, MasterEntitySearchHistoryStore };