import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import MasterEntitySearchHistoryStore from "./MasterEntitySearchHistoryStore";
import MasterEntitySearchHistory from "./component/MasterEntitySearchHistory";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";

class MasterEntitySearchHistoryWidget implements IWidget {
    context: IWidgetContext;
    start() {
        this.context.setView(<MasterEntitySearchHistory searchHistory={MasterEntitySearchHistoryStore} />);
    }
}

export {
    MasterEntitySearchHistoryWidget as default,
    MasterEntitySearchHistoryWidget
}