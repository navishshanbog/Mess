import * as React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import IWidgetEntry from "widget/IWidgetEntry";

const MasterEntitySearchHistoryWidgetEntry : IWidgetEntry = {
    key: "masterEntitySearchHistory",
    name: "Master Entity Search History",
    description: "Master Entity Search History",
    largeIcon: <Icon iconName="History" />,
    icon: <Icon iconName="History" />,
    get widgetType() {
        return import("./MasterEntitySearchHistoryWidget").then(r => r.default);
    }
};

export { MasterEntitySearchHistoryWidgetEntry as default, MasterEntitySearchHistoryWidgetEntry };