import { observable, action, computed } from "mobx";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import IMasterEntitySearchRequestModel from "./IMasterEntitySearchRequestModel";
import MasterEntitySearchHistoryStore from "./MasterEntitySearchHistoryStore";
import MasterEntitySearchRequestRefStore from "./MasterEntitySearchRequestRefStore";
import IError from "common/IError";
import * as DateUtils from "util/Date";
import * as StringUtils from "util/String";
import * as moment from "moment";

class MasterEntitySearchRequestModel implements IMasterEntitySearchRequestModel {
    @observable validationErrors?: IError[];
    @observable id?: string;
    @observable fullName?: string;
    @observable emailAddress?: string;
    @observable credentialType?: string;
    @observable credential?: string;
    @observable firstName?: string;
    @observable middleName?: string;
    @observable familyName?: string;
    @observable dob?: moment.Moment;
    @observable gender?: string;
    @observable fullAddress?: string;
    @observable unitNumber?: string;
    @observable streetNumber?: string;
    @observable streetName?: string;
    @observable streetType?: string;
    @observable locality?: string;
    @observable state?: string;
    @observable postcode?: string;
    @observable phone?: string;

    @observable entityOn: boolean = true;
    @observable personOn: boolean = false;
    @observable credentialOn: boolean = false;
    @observable addressOn: boolean = false;
    @observable contactOn: boolean = false;

    onSubmitRequest : (request : IMasterEntitySearchRequest) => void;
    onLoadById : (id : string) => void;

    @computed
    get isValueSpecified() {
        return StringUtils.isNotBlank(this.id) ||
               StringUtils.isNotBlank(this.fullName) ||
               StringUtils.isNotBlank(this.emailAddress) ||
               StringUtils.isNotBlank(this.firstName) ||
               StringUtils.isNotBlank(this.middleName) ||
               StringUtils.isNotBlank(this.familyName) ||
               (this.dob ? true : false) ||
               StringUtils.isNotBlank(this.gender) ||
               StringUtils.isNotBlank(this.credentialType) ||
               StringUtils.isNotBlank(this.credential) ||
               StringUtils.isNotBlank(this.fullAddress) ||
               StringUtils.isNotBlank(this.unitNumber) ||
               StringUtils.isNotBlank(this.streetNumber) ||
               StringUtils.isNotBlank(this.streetName) ||
               StringUtils.isNotBlank(this.streetType) ||
               StringUtils.isNotBlank(this.locality) ||
               StringUtils.isNotBlank(this.state) ||
               StringUtils.isNotBlank(this.postcode) ||
               StringUtils.isNotBlank(this.phone);
    }

    @action
    setId(id?: string) : void {
        this.id = id;
        if(StringUtils.isNotBlank(id)) {
            this._clearDetails();
        }
    }

    @action
    setFullName(fullName?: string) : void {
        this.fullName = fullName;
        if(StringUtils.isNotBlank(fullName)) {
            this.id = undefined;
            this.firstName = undefined;
            this.middleName = undefined;
            this.familyName = undefined;
        }
    }

    @action
    setEmail(email?: string) : void {
        this.emailAddress = email;
    }

    @action
    setCredentialType(credentialType?: string) : void {
        this.credentialType = credentialType;
        if(StringUtils.isNotBlank(credentialType)) {
            this.id = undefined;
        }
    }

    @action
    setCredential(credential?: string) : void {
        this.credential = credential;
        if(StringUtils.isNotBlank(credential)) {
            this.id = undefined;
        }
    }

    @action
    setFirstName(firstName?: string) : void {
        this.firstName = firstName;
        if(StringUtils.isNotBlank(firstName)) {
            this.id = undefined;
            this.fullName = undefined;
        }
    }

    @action
    setMiddleName(middleName?: string) : void {
        this.middleName = middleName;
        if(StringUtils.isNotBlank(middleName)) {
            this.id = undefined;
            this.fullName = undefined;
        }
    }

    @action
    setFamilyName(familyName?: string) : void {
        this.familyName = familyName;
        if(StringUtils.isNotBlank(familyName)) {
            this.id = undefined;
            this.fullName = undefined;
        }
    }

    @action
    setDob(dob?: moment.Moment) : void {
        if(dob) {
            this.id = undefined;
        }
        this.dob = dob;
    }

    @action
    setGender(gender?: string) : void {
        this.gender = gender;
        if(StringUtils.isNotBlank(gender)) {
            this.id = undefined;
        }
    }

    @action
    setFullAddress(fullAddress?: string) : void {
        this.fullAddress = fullAddress;
        if(StringUtils.isNotBlank(fullAddress)) {
            this.id = undefined;
            this.unitNumber = undefined;
            this.streetNumber = undefined;
            this.streetName = undefined;
            this.streetType = undefined;
            this.locality = undefined;
            this.state = undefined;
            this.postcode = undefined;
        }
    }

    @action
    setUnitNumber(unitNumber?: string) : void {
        this.unitNumber = unitNumber;
        if(StringUtils.isNotBlank(unitNumber)) {
            this.id = undefined;
            this.fullAddress = undefined;
        }
    }

    @action
    setStreetNumber(streetNumber?: string) : void {
        this.streetNumber = streetNumber;
        if(StringUtils.isNotBlank(streetNumber)) {
            this.id = undefined;
            this.fullAddress = undefined;
        }
    }

    @action
    setStreetName(streetName?: string) : void {
        this.streetName = streetName;
        if(StringUtils.isNotBlank(streetName)) {
            this.id = undefined;
            this.fullAddress = undefined;
        }
    }

    @action
    setStreetType(streetType?: string) : void {
        this.streetType = streetType;
        if(StringUtils.isNotBlank(streetType)) {
            this.id = undefined;
            this.fullAddress = undefined;
        }
    }

    @action
    setLocality(locality?: string) : void {
        this.locality = locality;
        if(StringUtils.isNotBlank(locality)) {
            this.id = undefined;
            this.fullAddress = undefined;
        }
    }

    @action
    setState(state?: string) : void {
        this.state = state;
        if(StringUtils.isNotBlank(state)) {
            this.id = undefined;
            this.fullAddress = undefined;
        }
    }

    @action
    setPostcode(postcode?: string) : void {
        this.postcode = postcode;
        if(StringUtils.isNotBlank(postcode)) {
            this.id = undefined;
            this.fullAddress = undefined;
        }
    }

    @action
    setPhone(phone?: string) : void {
        this.phone = phone;
        if(StringUtils.isNotBlank(phone)) {
            this.id = undefined;
        }
    }

    @action
    setEntityOn(entityOn : boolean) : void {
        this.entityOn = entityOn;
    }

    @action
    setPersonOn(personOn : boolean) : void {
        this.personOn = personOn;
    }

    @action
    setCredentialOn(credentialOn : boolean) : void {
        this.credentialOn = credentialOn;
    }

    @action
    setAddressOn(addressOn : boolean) : void {
        this.addressOn = addressOn;
    }

    @action
    setContactOn(contactOn : boolean) : void {
        this.contactOn = contactOn;
    }

    @computed
    protected get searchRequest() : IMasterEntitySearchRequest {
        return {
            fullName: this.entityOn && StringUtils.isNotBlank(this.fullName) ? this.fullName : undefined,
            firstName: this.personOn && StringUtils.isNotBlank(this.firstName) ? this.firstName : undefined,
            middleName: this.personOn && StringUtils.isNotBlank(this.middleName) ? this.middleName : undefined,
            familyName: this.personOn && StringUtils.isNotBlank(this.familyName) ? this.familyName : undefined,
            dob: this.personOn && DateUtils.isNotNull(this.dob) ? DateUtils.momentToDataText(this.dob) : undefined,
            sex: this.personOn && StringUtils.isNotBlank(this.gender) ? this.gender : undefined,
            fullAddress: this.addressOn && StringUtils.isNotBlank(this.fullAddress) ? this.fullAddress : undefined,
            unitnNo: this.addressOn && StringUtils.isNotBlank(this.unitNumber) ? this.unitNumber : undefined,
            streetNo: this.addressOn && StringUtils.isNotBlank(this.streetNumber) ? this.streetNumber : undefined,
            streetName: this.addressOn && StringUtils.isNotBlank(this.streetName) ? this.streetName : undefined,
            streetType: this.addressOn && StringUtils.isNotBlank(this.streetType) ? this.streetType : undefined,
            locality: this.addressOn && StringUtils.isNotBlank(this.locality) ? this.locality : undefined,
            state: this.addressOn && StringUtils.isNotBlank(this.state) ? this.state : undefined,
            postCode: this.addressOn && StringUtils.isNotBlank(this.postcode) ? this.postcode : undefined,
            phoneNumber: this.contactOn && StringUtils.isNotBlank(this.phone) ? this.phone : undefined,
            emailAddress: this.contactOn && StringUtils.isNotBlank(this.emailAddress) ? this.emailAddress : undefined,
            credentialType: this.credentialOn && StringUtils.isNotBlank(this.credentialType) ? this.credentialType : undefined,
            credential: this.credentialOn && StringUtils.isNotBlank(this.credential) ? this.credential : undefined
        };
    }

    @action
    validate() {
        this.validationErrors = [];
        if(!this.isValueSpecified) {
            this.validationErrors.push({ message: "A value must be specified"});
        } else {
            if(StringUtils.isNotBlank(this.id) && !StringUtils.every(this.id, StringUtils.filters.isDigit)) {
                this.validationErrors.push({ prop: "id", propTitle: "ID", message: "ID must contain only numbers"});
            }

            if(this.dob && !this.dob.isValid()) {
                this.validationErrors.push({ prop: "dob", propTitle: "Date of Birth", message: "Invalid Date: " + this.dob.creationData().input });
            }

            if(StringUtils.isNotBlank(this.credential) && StringUtils.isBlank(this.credentialType)) {
                this.validationErrors.push({ props: "credentialType", propTitle: "Credential Type", message: "A credential type must be specified"});
            }
        }
    }

    @action
    submit() : void {
        this.validate();
        if(this.validationErrors.length > 0) {
            return;
        }

        if(StringUtils.isNotBlank(this.id)) {
            if(this.onLoadById) {
                this.onLoadById(this.id);
            }
        } else {
            const r = this.searchRequest;
            if(this.onSubmitRequest) {
                this.onSubmitRequest(r)
            }
        }
    }

    @action
    protected _clearDetails() {
        this.fullName = undefined;
        this.emailAddress = undefined;
        this.firstName = undefined;
        this.middleName = undefined;
        this.familyName = undefined;
        this.dob = undefined;
        this.gender = undefined;
        this.credential = undefined;
        this.credentialType = undefined;
        this.fullAddress = undefined;
        this.unitNumber = undefined;
        this.streetNumber = undefined;
        this.streetName = undefined;
        this.streetType = undefined;
        this.locality = undefined;
        this.state = undefined;
        this.postcode = undefined;
        this.phone = undefined;
    }

    @action
    clear(): void {
        this.id = undefined;
        this._clearDetails();
    }
}

export { MasterEntitySearchRequestModel as default, MasterEntitySearchRequestModel };