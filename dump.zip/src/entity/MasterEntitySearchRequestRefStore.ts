import RefModel from "common/RefModel";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";

const MasterEntitySearchRequestSpace = new RefModel<IMasterEntitySearchRequestEntry>();

export { MasterEntitySearchRequestSpace as default, MasterEntitySearchRequestSpace };