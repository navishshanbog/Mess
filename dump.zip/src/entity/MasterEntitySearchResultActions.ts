import { action } from "mobx";
import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import { loadById } from "./MasterEntityActions";

const openItem = action((item : IMasterEntitySearchResultItem) => {
    loadById(String(item.mstrEntyId));
});

export { openItem }