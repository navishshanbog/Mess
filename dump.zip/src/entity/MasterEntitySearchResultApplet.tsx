import * as React from "react";
import { action, autorun, IReactionDisposer } from "mobx";
import IApplet from "app/IApplet";
import IAppModel from "app/IAppModel";
import MasterEntityEntityNav from "./component/MasterEntityNav";
import MasterEntitySearchResultContainer from "./component/MasterEntitySearchResult";
import MasterEntitySearchRequestRefStore from "./MasterEntitySearchRequestRefStore";
import MasterEntitySearchResultModel from "./MasterEntitySearchResultModel";
import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import MasterEntityRoute from "./MasterEntityRoute";

class MasterEntitySearchResultsApplet implements IApplet {
    context: IAppModel;
    private _refAutorunDisposer : IReactionDisposer;
    private _searchResult : MasterEntitySearchResultModel;
    private _handleOpenItem = (item : IMasterEntitySearchResultItem) => {
        this.context.open({ path: MasterEntityRoute.pathTemplate.toPath({ masterEntityId: String(item.mstrEntyId) })});
    }
    constructor() {
        this._searchResult = new MasterEntitySearchResultModel();
        this._searchResult.onOpenItem = this._handleOpenItem;
    }
    start() {
        // watch search request ref
        this._refAutorunDisposer = autorun(() => {
            this._searchResult.search(MasterEntitySearchRequestRefStore.ref);
        });
        this.context.view.setContent({
            title: "Entity Search Result",
            nav: <MasterEntityEntityNav />,
            main: <MasterEntitySearchResultContainer searchResult={this._searchResult} />
        });
    }
};

export { MasterEntitySearchResultsApplet as default, MasterEntitySearchResultsApplet };