import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import ISort from "common/ISort";
import * as DateUtils from "util/Date";
import * as ColumnTextHelper from "common/component/ColumnTextHelper";
import MasterEntitySourceConfig from "./MasterEntitySourceConfig";
import MasterEntitySearchResultItemColumns from "./component/MasterEntitySearchResultItemColumns";
import * as StringUtils from "util/String";
import * as SortUtils from "util/Sort";

const getSourceSystemsText = (item : IMasterEntitySearchResultItem) : string => {
    let r = "";
    if(item) {
        Object.keys(MasterEntitySourceConfig).forEach((sourceSystemCode) => {
            const count = item[sourceSystemCode];
            if(!isNaN(count) && count > 0) {
                if(r.length > 0) {
                    r += " ";
                }
                r += sourceSystemCode + ":" + count;
            }
        });
    }
    return r;
};

const getSourceSystemCount = (item : IMasterEntitySearchResultItem) : number => {
    let count = 0;
    if(item) {
        Object.keys(MasterEntitySourceConfig).forEach((sourceSystemCode) => {
            const sourceCount = item[sourceSystemCode];
            if(!isNaN(sourceCount) && sourceCount > 0) {
                count ++;
            }
        });
    }
    return count;
};

const getCredentialText = (item : IMasterEntitySearchResultItem) : string => {
    if(item && item.crdntlVlu) {
        return item.crdntlVlu + (item.crdntlTypCd ? " (" + item.crdntlTypCd + ")" : "");
    }
    return "";
};

const textFilterItemImpl = (item : IMasterEntitySearchResultItem, text: string) : boolean => {
    return StringUtils.containsIgnoreCase(ColumnTextHelper.getRowText(item, MasterEntitySearchResultItemColumns).join(""), text);
};

const textFilterItem = (item : IMasterEntitySearchResultItem, text: string) : boolean => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilterItems = (items : IMasterEntitySearchResultItem[], text?: string) : IMasterEntitySearchResultItem[] => {
    return items && StringUtils.isNotBlank(text) ? items.filter((item) => {
        return textFilterItemImpl(item, text);
    }) : items;
};

const itemSortValue = (item : IMasterEntitySearchResultItem, field: string) : any => {
    if(item) {
        if(field === "dtOfBrth") {
            const m = DateUtils.momentFromDataText(item.dtOfBrth);
            return m ? m.toDate() : undefined;
        }
        if(field === "sources") {
            return getSourceSystemCount(item);
        }
        if(field === "crdntlVlu") {
            return getCredentialText(item);
        }
        return item[field];
    }
};

const itemCompare = (a : IMasterEntitySearchResultItem, b : IMasterEntitySearchResultItem, Sort : ISort) : number => {
    let r = SortUtils.compare(itemSortValue(a, Sort.field), itemSortValue(b, Sort.field));
    if(Sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sortItems = (items: IMasterEntitySearchResultItem[], sort : ISort) : IMasterEntitySearchResultItem[] => {
    return items && sort ? items.sort((a, b) => {
        return itemCompare(a, b, sort);
    }) : items;
};

export {
    getSourceSystemsText,
    getSourceSystemCount,
    getCredentialText,
    itemSortValue,
    itemCompare,
    textFilterItem,
    textFilterItems,
    sortItems
};