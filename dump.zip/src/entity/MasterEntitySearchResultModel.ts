import { observable, action, computed } from "mobx";
import ListModel from "common/ListModel";
import SortModel from "common/SortModel";
import IMasterEntitySearchResultModel from "./IMasterEntitySearchResultModel";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";
import { openItem } from "./MasterEntitySearchResultActions";
import * as MasterEntitySearchHelper from "./MasterEntitySearchHelper";

class MasterEntitySearchResultModel extends ListModel<IMasterEntitySearchResultItem> implements IMasterEntitySearchResultModel {
    @observable sort = new SortModel();
    @observable requestEntry : IMasterEntitySearchRequestEntry;
    @observable items: IMasterEntitySearchResultItem[] = [];
    @observable textFilter : string;
    onOpenItem: (item : IMasterEntitySearchResultItem) => void;

    @action
    refresh() : Promise<any> {
        if(this.requestEntry) {
            return MasterEntitySearchHelper.searchByEntryIntoList(this.requestEntry, this, true);
        }
        return Promise.resolve();
    }

    @action
    search(requestEntry : IMasterEntitySearchRequestEntry) : Promise<any> {
        if(requestEntry !== this.requestEntry) {
            this.requestEntry = requestEntry;
            if(requestEntry) {
                this.textFilter = undefined;
                return MasterEntitySearchHelper.searchByEntryIntoList(requestEntry, this);
            }
            this.clear();
        }
        return Promise.resolve();
    }

    @action
    setTextFilter(textFilter : string) : void {
        this.textFilter = textFilter;
    }

    @action
    openItem(item : IMasterEntitySearchResultItem) : void {
        openItem(item);
        if(this.onOpenItem) {
            this.onOpenItem(item);
        }
    }

    @action
    clear() {
        super.clear();
        this.textFilter = undefined;
    }
}

export { MasterEntitySearchResultModel as default, MasterEntitySearchResultModel };