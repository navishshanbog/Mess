import IAppRoute from "app/IAppRoute";

const MasterEntitySearchResultRoute : IAppRoute = {
    key: "masterEntitySearchResult",
    name: "Master Entity Search Result",
    path: "masterEntity/search/result",
    get appletType() {
        return import("./MasterEntitySearchResultApplet").then(r => r.default);
    }
};

export { MasterEntitySearchResultRoute as default, MasterEntitySearchResultRoute };