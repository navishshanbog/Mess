import * as React from "react";
import { action, autorun, IReactionDisposer } from "mobx";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import MasterEntitySearchResultContainer from "./component/MasterEntitySearchResult";
import MasterEntitySearchRequestRefStore from "./MasterEntitySearchRequestRefStore";
import MasterEntitySearchResultModel from "./MasterEntitySearchResultModel";
import IMasterEntitySearchRequestEntry from "./IMasterEntitySearchRequestEntry";
import IMasterEntitySearchResultItem from "./IMasterEntitySearchResultItem";

class MasterEntitySearchResultWidget implements IWidget {
    context: IWidgetContext;
    private _refAutorunDisposer : IReactionDisposer;
    private _searchResult = new MasterEntitySearchResultModel();
    start() {
        const searchRequest : IMasterEntitySearchRequestEntry = this.context.props ? this.context.props.searchRequest : undefined;
        if(searchRequest) {
            this._searchResult.search(searchRequest);
        } else {
            this._refAutorunDisposer = autorun(() => {
                this._searchResult.search(MasterEntitySearchRequestRefStore.ref);
            });
        }
        this.context.setView(<MasterEntitySearchResultContainer searchResult={this._searchResult} />);
    }
    stop() {
        if(this._refAutorunDisposer) {
            this._refAutorunDisposer();
        }
    }
};

export { MasterEntitySearchResultWidget as default, MasterEntitySearchResultWidget };