import * as React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import IWidgetEntry from "widget/IWidgetEntry";

const MasterEntitySearchResultWidgetEntry : IWidgetEntry = {
    key: "masterEntitySearchResult",
    name: "Master Entity Search Result",
    description: "Master Entity Search Result",
    largeIcon: <Icon iconName="CustomList" />,
    icon: <Icon iconName="CustomList" />,
    get widgetType() {
        return import("./MasterEntitySearchResultWidget").then(r => r.default);
    }
};

export { MasterEntitySearchResultWidgetEntry as default, MasterEntitySearchResultWidgetEntry };