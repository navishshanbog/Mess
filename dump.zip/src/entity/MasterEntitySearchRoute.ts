import IAppRoute from "app/IAppRoute";

const MasterEntitySearchRoute : IAppRoute = {
    key: "masterEntitySearch",
    name: "Master Entity Search",
    path: "masterEntity/search",
    test(place) {
        return { match: place.path === "masterEntity" || place.path === this.path }
    },
    get appletType() {
        return import("./MasterEntitySearchApplet").then(r => r.default);
    }
};

export { MasterEntitySearchRoute as default, MasterEntitySearchRoute };