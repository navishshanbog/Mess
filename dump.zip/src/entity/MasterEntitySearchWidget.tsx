import * as React from "react";
import { action } from "mobx";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import MasterEntitySearchRequestTabs from "./component/MasterEntitySearchRequestTabs";
import MasterEntitySearchRequestModel from "./MasterEntitySearchRequestModel";
import { submitRequest as submitRequestAction } from "./MasterEntitySearchActions";
import { loadById as loadByIdAction } from "./MasterEntityActions";

class MasterEntitySearchWidget implements IWidget {
    context: IWidgetContext;
    private _searchRequest : MasterEntitySearchRequestModel;
    constructor() {
        this._searchRequest = new MasterEntitySearchRequestModel();
        this._searchRequest.onSubmitRequest = submitRequestAction;
        this._searchRequest.onLoadById = loadByIdAction;
    }
    private _handleSelectHistoryEntry = (entry) => {
        submitRequestAction(entry.request);
    }
    start() {
        this.context.setView(<MasterEntitySearchRequestTabs searchRequest={this._searchRequest} onSelectHistoryEntry={this._handleSelectHistoryEntry} />);
    }
};

export { MasterEntitySearchWidget as default, MasterEntitySearchWidget };