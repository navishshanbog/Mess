import * as React from "react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import IWidgetEntry from "widget/IWidgetEntry";

const MasterEntitySearchWidgetEntry : IWidgetEntry = {
    key: "masterEntitySearch",
    name: "Master Entity Search",
    description: "Master Entity Search",
    icon: <Icon iconName="Search" />,
    largeIcon: <Icon iconName="Search" />,
    get widgetType() {
        return import("./MasterEntitySearchWidget").then(r => r.default);
    }
};

export { MasterEntitySearchWidgetEntry as default, MasterEntitySearchWidgetEntry };