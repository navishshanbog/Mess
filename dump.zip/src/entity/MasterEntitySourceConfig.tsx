import * as React from "react";
import * as Icons from "icon/AnalystDesktopIcons";

import { Icon } from "office-ui-fabric-react/lib/Icon";

interface IMasterEntitySourceConfigEntry {
    title?: string;
    description?: string;
    icon?(props?: any) : any;
}

const NullSourceSystemConfigEntry = {
    title: "Unknown",
    description: "Unknown",
    icon(props : any) {
        return <Icon iconName="Help" aria-hidden={true} />;
    }
}

interface IMasterEntitySourceConfig {
    [key: string] : IMasterEntitySourceConfigEntry;
    byCode(code : string) : IMasterEntitySourceConfigEntry;
}

const MasterEntitySourceConfig : IMasterEntitySourceConfig = {
    IAT: {
        title: "IAT",
        description: "IAT",
        icon(props? : any) {
            return <Icons.IAT {...props} />;
        }
    },
    BAGS: {
        title: "BAGS",
        description: "BAGS",
        icon(props? : any) {
            return <Icons.BAGS {...props} />;
        }
    },
    DGMS: {
        title: "DGMS",
        description: "Detained Goods Management System",
        icon(props? : any) {
            return <Icons.DGMS {...props} />;
        }
    },
    ICS: {
        title: "Cargo",
        description: "Cargo",
        icon(props? : any) {
            return <Icons.ICS {...props} />;
        }
    },
    ASIC: {
        title: "ASIC",
        description: "Australian Securities and Investments Commission",
        icon(props? : any) {
            return <Icons.ASIC {...props} />;
        }
    },
    ABR: {
        title: "ABR",
        description: "Australia Business Register",
        icon(props? : any) {
            return <Icons.ABR {...props} />;
        }
    },
    EROLL: {
        title: "Electoral Roll",
        description: "Electoral Roll",
        icon(props? : any) {
            return <Icons.EROLL {...props} />;
        }
    },
    EXAMS: {
        title: "EXAMS",
        description: "EXAMS",
        icon(props? : any) {
            return <Icons.EXAMS {...props} />;
        }
    },
    IATA: {
        title: "IATA",
        description: "IATA",
        icon(props? : any) {
            return <Icons.IATA {...props} />;
        }
    },
    INTCP: {
        title: "INTCP",
        description: "INTCP",
        icon(props? : any) {
            return <Icons.INTCP {...props} />;
        }
    },
    byCode(code : string) : IMasterEntitySourceConfigEntry {
        const e = this[code.toUpperCase()];
        return e || NullSourceSystemConfigEntry;
    }
}

export { MasterEntitySourceConfig as default, MasterEntitySourceConfig, IMasterEntitySourceConfig, IMasterEntitySourceConfigEntry };