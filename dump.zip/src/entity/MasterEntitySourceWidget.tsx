import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IContextualMenuItem, ContextualMenuItemType } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { action } from "mobx";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import WidgetContext from "widget/WidgetContext";
import ContainerEntries from "widget/ContainerEntries";
import MasterEntitySourceWidgetEntries from "./MasterEntitySourceWidgetEntries";
import WidgetContextView from "widget/component/WidgetContext";
import IMasterEntityModel from "./IMasterEntityModel";
import * as KeyedItemHelper from "common/KeyedItemHelper";
import * as moment from "moment";
import * as ActivityFilterMenuHelper from "common/component/ActivityFilterMenuHelper";
import * as WidgetMenuHelper from "widget/component/WidgetMenuHelper";

interface IMasterEntitySourceProps {
    masterEntity: IMasterEntityModel;
    sourceContext: IWidgetContext;
}

@observer
class MasterEntitySourceCommandBar extends React.Component<IMasterEntitySourceProps, any> {
    _handleSelectLayout = (layout) => {
        this.props.sourceContext.setEntry(layout);
    }
    _handleEdit = () => {
        this.props.sourceContext.setProps({ editing: true });
    }
    _handleDoneEditing = () => {
        this.props.sourceContext.setProps({ editing: false });
    }
    render() {
        const items : IContextualMenuItem[] = [];
        items.push(
            ActivityFilterMenuHelper.createActivityFilterItem(this.props.masterEntity.activityFilter, "Activity Filter")
        );
        if(!this.props.sourceContext.props.noEdit) {
            if(this.props.sourceContext.props.editing) {
                items.push({
                    key:"done",
                    name: "Done",
                    iconProps: { iconName: "CheckMark" },
                    onClick: this._handleDoneEditing
                });
            } else {
                items.push({
                    key: "edit",
                    name: "Edit",
                    iconProps: { iconName: "Edit" },
                    onClick: this._handleEdit
                });
            }
        }
        const farItems : IContextualMenuItem[] = [];
        farItems.push(
            WidgetMenuHelper.createLayoutSelectItem({
                layouts: ContainerEntries,
                selectedLayout: this.props.sourceContext.entry,
                onSelectLayout: this._handleSelectLayout
            })
        );
        return (
            <CommandBar className="master-entity-source-command-bar" items={items} farItems={farItems} />
        );
    }
}

class MasterEntitySource extends React.Component<IMasterEntitySourceProps, any> {
    render() {
        return (
            <div className="mastere-entity-source">
                <MasterEntitySourceCommandBar {...this.props} />
                <WidgetContextView context={this.props.sourceContext} />
            </div>
        )
    }
}

class MasterEntitySourceWidget implements IWidget {
    context: IWidgetContext;
    @action
    _stateLoaded = () => {
        const masterEntity : IMasterEntityModel = this.context.props.masterEntity;
        const sourceCodes = masterEntity.sourceCodes;
        const supportedSourceCodes = sourceCodes.filter(sourceCode => KeyedItemHelper.getItem(MasterEntitySourceWidgetEntries, sourceCode) !== undefined);
        if(supportedSourceCodes.length > 0) {
            let sourceContext = this.context.childCount > 0 ? this.context.children[0] : undefined;
            if(!sourceContext) {
                sourceContext = new WidgetContext();
                sourceContext.setEntry(ContainerEntries[0]);
                this.context.addChild(sourceContext);
            }
            MasterEntitySourceWidgetEntries.forEach(sourceEntry => {
                const disabled = supportedSourceCodes.indexOf(sourceEntry.sourceSystemCode) < 0
                let sourceWidget = sourceContext.children.find(c => c.entry == sourceEntry);
                if(!sourceWidget) {
                    sourceWidget = new WidgetContext();
                    sourceWidget.setEntry(sourceEntry);
                    sourceContext.addChild(sourceWidget);
                }
                sourceWidget.setName(sourceEntry.shortName);
                sourceWidget.setProps({ masterEntity: masterEntity, disabled: disabled });
            });
            sourceContext.setProps({ noAdd: true, noRemove: true, noEdit: false, noRemoveChild: true, hideCommandBar: true });
            this.context.setView(<MasterEntitySource masterEntity={masterEntity} sourceContext={sourceContext} />);
        } else {
            this.context.setView(<MessageBar messageBarType={MessageBarType.warning}>No Source System Information available</MessageBar>);
        }
                
    }
    start() {
        this.context.loadState().then(this._stateLoaded);
    }
}

export { MasterEntitySourceWidget as default, MasterEntitySourceWidget }