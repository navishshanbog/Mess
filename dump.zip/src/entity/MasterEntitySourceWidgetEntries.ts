import IWidgetEntry from "widget/IWidgetEntry";
import MasterEntityBAGSWidgetEntry from "bags/MasterEntityBAGSWidgetEntry";
import MasterEntityCargoWidgetEntry from "cargo/MasterEntityCargoWidgetEntry";
import MasterEntityIATWidgetEntry from "iat/MasterEntityIATWidgetEntry";
import MasterEntityDGMSWidgetEntry from "dgms/MasterEntityDGMSWidgetEntry";
import MasterEntityABRWidgetEntry from "abr/MasterEntityABRWidgetEntry";
import MasterEntityASICWidgetEntry from "asic/MasterEntityASICWidgetEntry";
import MasterEntityEROLLWidgetEntry from "eroll/MasterEntityEROLLWidgetEntry";
import MasterEntityEXAMSWidgetEntry from "exams/MasterEntityEXAMSWidgetEntry";
import MasterEntityIATAWidgetEntry from "iata/MasterEntityIATAWidgetEntry";
import MasterEntityINTCPWidgetEntry from "intcp/MasterEntityINTCPWidgetEntry";

const MasterEntitySourceWidgetEntries : IWidgetEntry[] = [
    MasterEntityBAGSWidgetEntry,
    MasterEntityCargoWidgetEntry,
    MasterEntityIATWidgetEntry,
    MasterEntityDGMSWidgetEntry,
    MasterEntityABRWidgetEntry,
    MasterEntityASICWidgetEntry,
    MasterEntityEROLLWidgetEntry,
    MasterEntityIATAWidgetEntry,
    MasterEntityEXAMSWidgetEntry,
    MasterEntityINTCPWidgetEntry
];

export { MasterEntitySourceWidgetEntries as default, MasterEntitySourceWidgetEntries }