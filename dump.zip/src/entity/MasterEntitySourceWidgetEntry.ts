import IWidgetEntry from "widget/IWidgetEntry";

const MasterEntitySourceWidgetEntry : IWidgetEntry = {
    key: "masterEntitySource",
    name: "Master Entity Source",
    get widgetType() {
        return import("./MasterEntitySourceWidget").then(r => r.default);
    }
}

export { MasterEntitySourceWidgetEntry as default, MasterEntitySourceWidgetEntry }