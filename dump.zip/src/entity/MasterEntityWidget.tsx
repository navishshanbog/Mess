import * as React from "react";
import AbstractMasterEntityWidget from "./AbstractMasterEntityWidget";
import MasterEntityRefModel from "./MasterEntityRefModel";
import MasterEntityContainer from "./component/MasterEntityContainer";
import * as MasterEntitySearchHelper from "./MasterEntitySearchHelper";
import { submitRequest } from "./MasterEntitySearchActions";
import AppMultipleMasterEntityListCompositeStore from "entity/AppMultipleMasterEntityListCompositeStore";

class MasterEntityWidget extends AbstractMasterEntityWidget {
    protected masterEntityRef : MasterEntityRefModel;

    constructor() {
        super();

        this.masterEntityRef = new MasterEntityRefModel(AppMultipleMasterEntityListCompositeStore);
        this.masterEntityRef.attributeActions = {
            onSearch: (request) => {
                submitRequest(request);
            }
        };
    }
    _setView() {
        this.context.setView(<MasterEntityContainer masterEntityRef={this.masterEntityRef} />);
    }
};

export { MasterEntityWidget as default, MasterEntityWidget };