import IWidgetEntry from "widget/IWidgetEntry";

const MasterEntityWidgetEntry : IWidgetEntry = {
    key: "masterEntity",
    name: "Master Entity Details",
    description: "Master Entity Details",
    get widgetType() {
        return import("./MasterEntityWidget").then(r => r.default);
    }
};

export { MasterEntityWidgetEntry as default, MasterEntityWidgetEntry }