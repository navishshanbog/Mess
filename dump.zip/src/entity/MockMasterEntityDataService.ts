import {
    IMasterEntityDataService,
    IMasterEntityServiceRequestOptions,
    IMasterEntitySourceRefResponse,
    IMasterEntitySourceEntityMetaResponse,
    IMasterEntitySourceEntityNameResponse,
    IMasterEntitySourceEntityAddressResponse,
    IMasterEntitySourceEntityPhoneResponse,
    IMasterEntitySourceEntityCredentialResponse
} from "./IMasterEntityDataService";
import IMasterEntitySourceRef from "./IMasterEntitySourceRef";
import IMasterEntitySourceEntityMeta from "./IMasterEntitySourceEntityMeta";
import IMasterEntitySourceEntityName from "./IMasterEntitySourceEntityName";
import IMasterEntitySourceEntityAddress from "./IMasterEntitySourceEntityAddress";
import IMasterEntitySourceEntityPhone from "./IMasterEntitySourceEntityPhone";
import IMasterEntitySourceEntityCredential from "./IMasterEntitySourceEntityCredential";

class MockMasterEntityDataService implements IMasterEntityDataService {
    refResponse : IMasterEntitySourceRefResponse = {
        getMasterEntitySourceResponse: [
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceSystemCd: "IAT",
                masteredIndicator: "Y",
                masterEntityAddressID: 1,
                masterEntityPhoneID: 1,
                masterEntityNameID: 1,
                masterEntityCredentialID: 1,
                sourceRelatedKeyValue: "1"
            },
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceSystemCd: "BAGS",
                masteredIndicator: "Y",
                masterEntityAddressID: 1,
                masterEntityPhoneID: 1,
                masterEntityNameID: 1,
                masterEntityCredentialID: 1,
                sourceRelatedKeyValue: "1"
            },
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceSystemCd: "DGMS",
                masteredIndicator: "Y",
                masterEntityAddressID: 1,
                masterEntityPhoneID: 1,
                masterEntityNameID: 1,
                masterEntityCredentialID: 1,
                sourceRelatedKeyValue: "1"
            },
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceSystemCd: "EXAMS",
                masteredIndicator: "Y",
                masterEntityAddressID: 1,
                masterEntityPhoneID: 1,
                masterEntityNameID: 1,
                masterEntityCredentialID: 1,
                sourceRelatedKeyValue: "1"
            },
            {
                masterEntityId: 2,
                sourceEntityId: 2,
                sourceSystemCd: "BAGS",
                masteredIndicator: "Y",
                masterEntityAddressID: 2,
                masterEntityPhoneID: 2,
                masterEntityNameID: 2,
                masterEntityCredentialID: 2,
                sourceRelatedKeyValue: "32323|AUS|01011980|M"
            },
            {
                masterEntityId: 3,
                sourceEntityId: 3,
                sourceSystemCd: "DGMS",
                masteredIndicator: "Y",
                masterEntityAddressID: 3,
                masterEntityPhoneID: 3,
                masterEntityNameID: 3,
                masterEntityCredentialID: 3,
                sourceRelatedKeyValue: "1"
            },
            {
                masterEntityId: 4,
                sourceEntityId: 4,
                sourceSystemCd: "EXAMS",
                masteredIndicator: "Y",
                masterEntityAddressID: 4,
                masterEntityPhoneID: 4,
                masterEntityNameID: 4,
                masterEntityCredentialID: 4, 
                sourceRelatedKeyValue:"8404"
            }
        ]
    }
    metaResponse : IMasterEntitySourceEntityMetaResponse = {
        getMasterEntitySourceEntityResponse: [
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceSystemCd: "IAT",
                birthCountryCd: "AU",
                birthDt: "1980-01-01",
                entityTypeCd: "IND",
                sex: "MALE"
            },
            {
                masterEntityId: 2,
                sourceEntityId: 2,
                sourceSystemCd: "BAGS",
                birthCountryCd: "AU",
                birthDt: "1981-01-01",
                entityTypeCd: "IND",
                sex: "MALE"
            },
            {
                masterEntityId: 3,
                sourceEntityId: 3,
                sourceSystemCd: "DGMS",
                birthCountryCd: "AU",
                birthDt: "1982-01-01",
                entityTypeCd: "IND",
                sex: "MALE"
            },
            {
                masterEntityId: 4,
                sourceEntityId: 4,
                sourceSystemCd: "EXAMS",
                birthCountryCd: "AU",
                birthDt: "1982-01-01",
                entityTypeCd: "IND",
                sex: "MALE"
            }
        ]
    }
    nameResponse : IMasterEntitySourceEntityNameResponse = {
        getMasterEntitySourceEntityNameResponse: [
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceEntityNameId: 1,
                sourceSystemCd: "IAT",
                familyName: "Slapper",
                firstName: "Sunburn",
                nameGenderCd: "M",
                standardFullName: "Sunburn Slapper"
            },
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceEntityNameId: 1,
                sourceSystemCd: "ASIC",
                familyName: "Slapper",
                firstName: "Sunburn",
                middleName: "Of",
                nameGenderCd: "M",
                standardFullName: "Slapper Of Sunburn"
            },
            {
                masterEntityId: 2,
                sourceEntityId: 2,
                sourceEntityNameId: 2,
                sourceSystemCd: "BAGS",
                familyName: "Injury",
                firstName: "Knee",
                nameGenderCd: "M",
                standardFullName: "Knee Injury"
            },
            {
                masterEntityId: 3,
                sourceEntityId: 3,
                sourceEntityNameId: 3,
                sourceSystemCd: "DGMS",
                familyName: "Wellington",
                firstName: "Beef",
                nameGenderCd: "M",
                standardFullName: "Beef Wellington"
            },
            {
                masterEntityId: 4,
                sourceEntityId: 4,
                sourceEntityNameId: 4,
                sourceSystemCd: "EXAMS",
                familyName: "WithExams",
                firstName: "TheGuy",
                nameGenderCd: "M",
                standardFullName: "TheGuy WithExams"
            }
        ]
    }
    addressResponse : IMasterEntitySourceEntityAddressResponse = {
        getMasterEntitySourceEntityAddressResponse: [
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceEntityAddressId: 1,
                sourceSystemCd: "IAT",
                standardAddressValue: "10 Some Drive Lismore NSW 2480"
            },
            {
                masterEntityId: 2,
                sourceEntityId: 2,
                sourceEntityAddressId: 2,
                sourceSystemCd: "BAGS",
                standardAddressValue: "11 Some Drive Lismore NSW 2480"
            },
            {
                masterEntityId: 3,
                sourceEntityId: 3,
                sourceEntityAddressId: 3,
                sourceSystemCd: "DGMS",
                standardAddressValue: "12 Some Drive Lismore NSW 2480"
            },
            {
                masterEntityId: 4,
                sourceEntityId: 4,
                sourceEntityAddressId: 4,
                sourceSystemCd: "EXAMS",
                standardAddressValue: "12 Some Drive Lismore NSW 2480"
            }
        ]
    }
    phoneResponse : IMasterEntitySourceEntityPhoneResponse = {
        getMasterEntitySourceEntityPhoneResponse: [
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceEntityPhoneId: 1,
                sourceSystemCd: "IAT",
                phoneNumber: "938838292",
                phoneValue: "938838292"
            },
            {
                masterEntityId: 2,
                sourceEntityId: 2,
                sourceEntityPhoneId: 2,
                sourceSystemCd: "BAGS",
                phoneNumber: "938838293",
                phoneValue: "938838293"
            },
            {
                masterEntityId: 3,
                sourceEntityId: 3,
                sourceEntityPhoneId: 3,
                sourceSystemCd: "DGMS",
                phoneNumber: "938843293",
                phoneValue: "938843293"
            },
            {
                masterEntityId: 4,
                sourceEntityId: 4,
                sourceEntityPhoneId: 4,
                sourceSystemCd: "EXAMS",
                phoneNumber: "938843293",
                phoneValue: "938843293"
            }
        ]
    }
    credentialResponse : IMasterEntitySourceEntityCredentialResponse = {
        getMasterEntitySourceEntityCredentialResponse: [
            {
                masterEntityId: 1,
                sourceEntityId: 1,
                sourceEntityCredentialId: 1,
                sourceSystemCd: "IAT",
                credentialTypeCd: "TD",
                credentialValue: "234234234"
            },
            {
                masterEntityId: 2,
                sourceEntityId: 2,
                sourceEntityCredentialId: 2,
                sourceSystemCd: "BAGS",
                credentialTypeCd: "TD",
                credentialValue: "234234222"
            },
            {
                masterEntityId: 3,
                sourceEntityId: 3,
                sourceEntityCredentialId: 3,
                sourceSystemCd: "DGMS",
                credentialTypeCd: "TD",
                credentialValue: "222234222"
            },
            {
                masterEntityId: 4,
                sourceEntityId: 4,
                sourceEntityCredentialId: 4,
                sourceSystemCd: "EXAMS",
                credentialTypeCd: "TD",
                credentialValue: "222234222"
            }
        ]
    }
    getMasterEntitySourceRef(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceRefResponse> {
        return Promise.resolve({
            getMasterEntitySourceResponse: this.refResponse.getMasterEntitySourceResponse.filter((item) => {
                return String(item.masterEntityId) === masterEntityId;
            })
        });
    }
    getMasterEntitySourceEntityMeta(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityMetaResponse> {
        return Promise.resolve({
            getMasterEntitySourceEntityResponse: this.metaResponse.getMasterEntitySourceEntityResponse.filter((item) => {
                return String(item.masterEntityId) === masterEntityId;
            })
        });
    }
    getMasterEntitySourceEntityName(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityNameResponse> {
        return Promise.resolve({
            getMasterEntitySourceEntityNameResponse: this.nameResponse.getMasterEntitySourceEntityNameResponse.filter((item) => {
                return String(item.masterEntityId) === masterEntityId;
            })
        });
    }
    getMasterEntitySourceEntityAddress(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityAddressResponse> {
        return Promise.resolve({
            getMasterEntitySourceEntityAddressResponse: this.addressResponse.getMasterEntitySourceEntityAddressResponse.filter((item) => {
                return String(item.masterEntityId) === masterEntityId;
            })
        });
    }
    getMasterEntitySourceEntityPhone(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityPhoneResponse> {
        return Promise.resolve({
            getMasterEntitySourceEntityPhoneResponse: this.phoneResponse.getMasterEntitySourceEntityPhoneResponse.filter((item) => {
                return String(item.masterEntityId) === masterEntityId;
            })
        });
    }
    getMasterEntitySourceEntityCredential(masterEntityId: string, opts?: IMasterEntityServiceRequestOptions) : Promise<IMasterEntitySourceEntityCredentialResponse> {
        return Promise.resolve({
            getMasterEntitySourceEntityCredentialResponse: this.credentialResponse.getMasterEntitySourceEntityCredentialResponse.filter((item) => {
                return String(item.masterEntityId) === masterEntityId;
            })
        });
    }
}

export { MockMasterEntityDataService as default, MockMasterEntityDataService };

