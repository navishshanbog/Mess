import IMasterEntitySearchService from "./IMasterEntitySearchService";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import IMasterEntitySearchResult from "./IMasterEntitySearchResult";

class MockMasterEntitySearchDataService implements IMasterEntitySearchService {
    response : IMasterEntitySearchResult = {
        items: [
            {
                mstrEntyId: 1,
                stdFullNm: "Sunburn Slapper",
                dtOfBrth: "1980-01-01",
                sexCd: "MALE",
                stdAdrsVlu: "10 Some Drive Lismore NSW 2480 AU",
                phnNbr: "938838292",
                crdntlTypCd: "TD",
                crdntlVlu: "234234234",
                IAT: 1,
                ASIC: 1,
                BAGS: 1,
                DGMS: 1,
                EXAMS: 1
            },
            {
                mstrEntyId: 2,
                stdFullNm: "Knee Injury",
                dtOfBrth: "1981-01-01",
                sexCd: "MALE",
                stdAdrsVlu: "11 Some Drive Lismore NSW 2480 AU",
                phnNbr: "938838293",
                crdntlTypCd: "TD",
                crdntlVlu: "234234222",
                BAGS: 1
            },
            {
                mstrEntyId: 3,
                stdFullNm: "Beef Wellington",
                dtOfBrth: "1982-01-01",
                sexCd: "MALE",
                stdAdrsVlu: "12 Some Drive Lismore NSW 2480 AU",
                phnNbr: "938843293",
                crdntlTypCd: "TD",
                crdntlVlu: "222234222",
                DGMS: 1
            },
            {
                mstrEntyId: 4,
                stdFullNm: "TheGuy WithExams",
                dtOfBrth: "1982-01-01",
                sexCd: "MALE",
                stdAdrsVlu: "12 Some Drive Lismore NSW 2480 AU",
                phnNbr: "938843293",
                crdntlTypCd: "TD",
                crdntlVlu: "222234222",
                DGMS: 1
            }
        ]
    };
    search(request : IMasterEntitySearchRequest) : Promise<IMasterEntitySearchResult> {
        return Promise.resolve(this.response);
    }
}

export { MockMasterEntitySearchDataService as default, MockMasterEntitySearchDataService };