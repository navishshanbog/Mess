import * as React from "react";
import IApplet from "app/IApplet";
import IAppModel from "app/IAppModel";
import AppMultipleMasterEntityListCompositeStore from "./AppMultipleMasterEntityListCompositeStore";
import MultipleMasterEntityTabContainer from "./component/MultipleEntityTabContainer";
import MultipleMasterEntityNav from "./component/MultipleMasterEntityNav";

class MultipleMasterEntityApplet implements IApplet {

    context: IAppModel;
    start() {
        var entityIds = this.context.place.params.masterEntityId.split(",");
        entityIds.forEach((entityId) => {

            AppMultipleMasterEntityListCompositeStore.loadById(entityId.trim());
        });

        this.context.view.setContent({
            nav: <MultipleMasterEntityNav multipleMasterEntityList={AppMultipleMasterEntityListCompositeStore} />,
            main: <MultipleMasterEntityTabContainer multipleMasterEntityList={AppMultipleMasterEntityListCompositeStore} />
        });
    }
}

export { MultipleMasterEntityApplet as default, MultipleMasterEntityApplet };