import { observable, action } from "mobx";
import ISyncModel from "common/ISyncModel";
import SyncModel from "common/SyncModel";
import ListModel from "common/ListModel";
import IListModel from "common/IListModel";
import IMasterEntityModel from "./IMasterEntityModel";
import MasterEntityModel from "./MasterEntityModel";
import IMasterEntity from "./IMasterEntity";
import MasterEntityServiceContext from "entity/MasterEntityServiceContext";
import IEntityAttributeActions from "entity/IEntityAttributeActions";
import {IMultipleMasterEntityListCompositeModel} from "entity/IMultipleMasterEntityListCompositeModel";
import { ISelection } from "office-ui-fabric-react/lib/Selection";
import * as moment from "moment";
import IEntityEventNotification from "entity/IEntityEventNotification";
import IMasterEntityIATModel from "iat/IMasterEntityIATModel";
import IIATEventNotification from "iat/IIATEventNotification";
import IIATAlias from "iat/IIATAlias";
import IIATMovement from "iat/IIATMovement";
import * as IATMovementHelper from "iat/IATMovementHelper";
import * as DGMSActivityHelper from "dgms/DGMSActivityHelper";
import {ActivityListModel} from "../common/ActivityListModel";
import IActivityListModel from "common/IActivityListModel";
import MasterEntityIATModel from "iat/MasterEntityIATModel";
import IMasterEntityCargoModel from "cargo/IMasterEntityCargoModel";
import IAirCargoEventNotification from "cargo/IAirCargoEventNotification";
import IAirCargoActivity from "cargo/air/IAirCargoActivity";
import MasterEntityCargoModel from "cargo/MasterEntityCargoModel";
import IMasterEntityBAGSModel from "bags/IMasterEntityBAGSModel";
import IMasterEntitySearchRequest from "./IMasterEntitySearchRequest";
import * as AirCargoActivityHelper from "cargo/air/AirCargoActivityHelper";
import IBAGSEventNotification from "bags/IBAGSEventNotification";
import IBAGSActivity from "bags/IBAGSActivity";
import MasterEntityBAGSModel from "bags/MasterEntityBAGSModel";
import * as BAGSActivityHelper from "bags/BAGSActivityHelper";
import IMasterEntityDGMSModel from "dgms/IMasterEntityDGMSModel";
import IDGMSEventNotification from "dgms/IDGMSEventNotification";
import IDGMSActivity from "dgms/IDGMSActivity";
import MasterEntityDGMSModel from "dgms/MasterEntityDGMSModel";

// need to move this to somewhere localised
/*
import {enableLogging} from 'mobx-logger';

const mobXLogConfig = {

    action: true,
    reaction: true,
    transaction: true,
    compute: true
};
enableLogging(mobXLogConfig);
 */


class MultipleMasterEntityListCompositeModel
            implements IMultipleMasterEntityListCompositeModel, IEntityEventNotification, IIATEventNotification, IAirCargoEventNotification,
                IBAGSEventNotification, IDGMSEventNotification, IEntityAttributeActions {

    @observable sync : ISyncModel = new SyncModel();
    @observable requestedMasterEntityId: string;
    attributeActions : IEntityAttributeActions;

    @observable
    items: IListModel<IMasterEntityModel>;

    @observable
    localTotal : number;

    @observable filterText: string;
    @observable filterFromDate: moment.Moment;
    @observable filterToDate: moment.Moment;

    @observable
    selectedItems: ISelection;

    @observable
    iatItems : IListModel<IMasterEntityIATModel>;

    @observable
    cargoItems : IListModel<IMasterEntityCargoModel>;

    @observable
    bagsItems : IListModel<IMasterEntityBAGSModel>;

    @observable
    dgmsItems : IListModel<IMasterEntityDGMSModel>;
    
    @action
    onSearch = (request : IMasterEntitySearchRequest) => {
        if(this.attributeActions) {
            this.attributeActions.onSearch(request);
        }
    }

    @action
    dgmsByMasterEntityId(masterEntityId : string) : IMasterEntityDGMSModel {

        if (this.dgmsItems == null) {
            return null;
        }

        if (this.dgmsItems.items == null)  {
            return null;
        }

        let res  = this.dgmsItems.items.find((item : IMasterEntityDGMSModel) => {

            return (item.masterEntityId == masterEntityId);
        });

        return res;
    }

    @action
    bagsByMasterEntityId(masterEntityId : string) : IMasterEntityBAGSModel {

        if (this.bagsItems == null) {
            return null;
        }

        if (this.bagsItems.items == null)  {
            return null;
        }

        let res  = this.bagsItems.items.find((item : IMasterEntityBAGSModel) => {

            return (item.masterEntityId == masterEntityId);
        });

        return res;
    }

    @action
    iatByMasterEntityId(masterEntityId : string) : IMasterEntityIATModel {

        if (this.iatItems == null) {
            return null;
        }
        if (this.iatItems.items == null)  {
            return null;
        }

        let res  = this.iatItems.items.find((item : IMasterEntityIATModel) => {

            return (item.masterEntityId == masterEntityId);
        });

        return res;
    }

    @action
    cargoByMasterEntityId(masterEntityId : string) : IMasterEntityCargoModel {

        if (this.cargoItems == null) {
            return null;
        }
        if (this.cargoItems.items == null)  {
            return null;
        }

        let res  = this.cargoItems.items.find((item : IMasterEntityCargoModel) => {

            return (item.masterEntityId == masterEntityId);
        });

        return res;
    }

    @action
    clear() : void {

        this.items.clear();
        this.selectedItems.setItems([], true);
    }


    @observable
    itemsView(): IMasterEntityModel[] {

        return this.items.itemsView;
    }


    @action
    deleteItemByEntityId(key : string) : void {

        // TODO need to make sure we delte the cargo and IAT data as well
        let newArray = new Array<IMasterEntityModel>();

        this.items.items.forEach((ele: IMasterEntityModel, index) => {

            if (ele.masterEntityId != key) {

                newArray.push(ele);
            }
        });

        this.items.items = newArray;
    }


    @action
    setSelection(data : ISelection) {
        this.selectedItems = data;
    }

    getSelection() : ISelection {
        return this.selectedItems;
    }

    @action
    entityLoaded(item : IMasterEntity) {
        this.setData(item);
    }


    @action
    dgmsActivityDataLoaded(id : string, items : IDGMSActivity[]) {

        let dgmsModel: IMasterEntityDGMSModel = new MasterEntityDGMSModel();
        dgmsModel.activityList.setItems(items);

        if (!dgmsModel.masterEntityId) {

            dgmsModel.masterEntityId = id;
        }

        if (this.dgmsItems) {

            this.dgmsItems.addItem(dgmsModel);
        } else {
            this.dgmsItems = new ListModel<IMasterEntityDGMSModel>();
            this.dgmsItems.addItem(dgmsModel);
        }
    }

    @action
    bagsActivityDataLoaded(id : string, items : IBAGSActivity[]) {

        let bagsModel: IMasterEntityBAGSModel = new MasterEntityBAGSModel();
        bagsModel.activityList.setItems(items);

        if (!bagsModel.masterEntityId) {

            bagsModel.masterEntityId = id;
        }

        if (this.bagsItems) {

            this.bagsItems.addItem(bagsModel);
        } else {
            this.bagsItems = new ListModel<IMasterEntityBAGSModel>();
            this.bagsItems.addItem(bagsModel);
        }
    }

    @action
    airCargoLoaded(key: string, items : IAirCargoActivity[]) {


        let activityList: IActivityListModel<IAirCargoActivity> = new ActivityListModel();
        activityList.setItems(items, items.length);

        let masterEntityCargoModel = new MasterEntityCargoModel(this);
        masterEntityCargoModel.setActivities(items);

        if (!masterEntityCargoModel.masterEntityId) {

            masterEntityCargoModel.masterEntityId = key;
        }

        if (this.cargoItems) {

            this.cargoItems.addItem(masterEntityCargoModel);
        } else {
            this.cargoItems = new ListModel<IMasterEntityCargoModel>();
            this.cargoItems.addItem(masterEntityCargoModel);
        }
    }

    @action
    iatMovementsDataLoaded(key : string, items : IIATMovement[]) {

        let activityList: IActivityListModel<IIATMovement> = new ActivityListModel();
        activityList.setItems(items, items.length);

        let masterEntityIATModel = new MasterEntityIATModel(this);
        masterEntityIATModel.activityList = activityList;

        if (!masterEntityIATModel.masterEntityId) {

            masterEntityIATModel.masterEntityId = key;
        }

        if (this.iatItems) {

            this.iatItems.addItem(masterEntityIATModel);
        } else {
            this.iatItems = new ListModel<IMasterEntityIATModel>();
            this.iatItems.addItem(masterEntityIATModel);
        }
    }


    @action
    setData(data : IMasterEntity) {

        if(data) {

            const m = new MasterEntityModel(data);
            m.attributeActions = this;

            var dataItems = new Array();
            dataItems.push(m);

            this.addItems(dataItems);
        } else {

            var emptyDataItems = new Array();

            this.addItems(emptyDataItems);
        }
    }

    @action
    setItems(items: IMasterEntityModel[], total?: number) : void {
        this.localTotal = total;

        this.items = new ListModel<IMasterEntityModel>(items);
        // ensure sync end is called when items are set
        this.sync.syncEnd();
    }

    @action
    addItems(items: IMasterEntityModel[], total?: number) : void {

        if (this.items) {

            items.forEach((thisItem) => {

                this.items.items.push(thisItem);
            });

            let copyOfItems : IMasterEntityModel[] = new Array();

            this.items.items.forEach((item : IMasterEntityModel) => {

                copyOfItems.push(item);
            });

            this.localTotal = this.items.items.length;
            // hack and create new array as only new arrays seems to trigger refersh
            this.items = new ListModel<IMasterEntityModel>(copyOfItems);
        } else {

            this.items = new ListModel<IMasterEntityModel>(items);
            this.localTotal = total;
        }


        // ensure sync end is called when items are set
        this.sync.syncEnd();
    }

    @action
    setError(error : any) {

        console.log("setError called");
        console.log("setError error:" + error);

        var emptyItems = new Array();

        this.localTotal = 0;
        this.items = new ListModel<IMasterEntityModel>(emptyItems);

        this.sync.syncError(error);
    }


    @action
    refresh() {
        const syncId = this.requestedMasterEntityId;
        this.sync.syncStart({ id: syncId });
        MasterEntityServiceContext.ref.getMasterEntityById(this.requestedMasterEntityId).then((data) => {

            this.setData(data);

            // look to force IAT Details to load
            // just for testing
            const masterEntityModel = new MasterEntityModel(data);

            let iatList: IListModel<IIATMovement> = new ListModel<IIATMovement>();
            IATMovementHelper.loadForMasterEntity(iatList, masterEntityModel, this);

            let cargoList: IListModel<IAirCargoActivity> = new ListModel<IAirCargoActivity>();
            AirCargoActivityHelper.loadForMasterEntity(cargoList, masterEntityModel, this);

            let bagsList : IListModel<IBAGSActivity> = new ListModel<IBAGSActivity>();
            BAGSActivityHelper.loadForMasterEntity(bagsList, masterEntityModel, this);

            let dgmsList : IListModel<IDGMSActivity> = new ListModel<IDGMSActivity>();
            DGMSActivityHelper.loadForMasterEntity(dgmsList, masterEntityModel, this);

        }).catch((error) => {
            if(syncId === this.sync.id) {
                this.setError(error);
            }
        });

    }

    @action
    loadById(masterEntityId : string) : void {

        if(masterEntityId !== this.requestedMasterEntityId) {
            this.requestedMasterEntityId = masterEntityId;
            this.refresh();
        }
    }

    @action
    setFilterText(filterText : string) {
        this.filterText = filterText;
    }

    @action
    setFilterFromDate(filterFromDate : moment.Moment) {
        this.filterFromDate = filterFromDate;
    }

    @action
    setFilterToDate(filterToDate : moment.Moment) {
        this.filterToDate = filterToDate;
    }

    @action
    clearFilter() : void {
        this.filterText = undefined;
        this.filterFromDate = undefined;
        this.filterToDate = undefined;
    }

}

export { MultipleMasterEntityListCompositeModel as default, MultipleMasterEntityListCompositeModel }
