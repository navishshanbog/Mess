import PathTemplate from "common/PathTemplate";


// allows them to be done one at a time ?
const MultipleMasterEntityPathTemplate = new PathTemplate("multipleMasterEntity/:masterEntityId");

export { MultipleMasterEntityPathTemplate as default, MultipleMasterEntityPathTemplate };