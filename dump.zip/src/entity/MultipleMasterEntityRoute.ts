import IAppRoute from "app/IAppRoute";
import MultipleMasterEntityPathTemplate from "./MultipleMasterEntityPathTemplate";

// http://localhost:3000/analystdesktop/widget/site/multipleMasterEntity/1234567890,23456789,3456789

const MultiupleMasterEntityRoute : IAppRoute = {
    key: "multipleMasterEntity",
    name: "Multiple Master Entity",
    pathTemplate: MultipleMasterEntityPathTemplate,
    get appletType() {
        return import("./MultipleMasterEntityApplet").then(r => r.default);
    }
};

export { MultiupleMasterEntityRoute as default, MultiupleMasterEntityRoute };