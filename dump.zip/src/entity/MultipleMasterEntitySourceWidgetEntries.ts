import IWidgetEntry from "widget/IWidgetEntry";
import MultipleMasterEntityABRWidgetEntry from "abr/MultipleMasterEntityABRWidgetEntry";
import MultipleMasterEntityAsicWidgetEntry from "asic/MultipleMasterEntityASICWidgetEntry";
import MultipleMasterEntityEROLLWidgetEntry from "eroll/MultipleMasterEntityEROLLWidgetEntry";
import {MultipleMasterEntityIATWidgetEntry} from "../iat/MultipleMasterEntityIATWidgetEntry";
import {MultipleMasterEntityCargoWidgetEntry} from "../cargo/MultipleMasterEntityCargoWidgetEntry";
import {MultipleMasterEntityBAGSWidgetEntry} from "../bags/MultipleMasterEntityBAGSWidgetEntry";
import {MultipleMasterEntityDGMSWidgetEntry} from "../dgms/MultipleMasterEntityDGMSWidgetEntry";


const MultipleMasterEntitySourceWidgetEntries : IWidgetEntry[] = [
    MultipleMasterEntityEROLLWidgetEntry,
    MultipleMasterEntityABRWidgetEntry,
    MultipleMasterEntityAsicWidgetEntry,
    MultipleMasterEntityIATWidgetEntry,
    MultipleMasterEntityCargoWidgetEntry,
    MultipleMasterEntityBAGSWidgetEntry,
    MultipleMasterEntityDGMSWidgetEntry

];

export { MultipleMasterEntitySourceWidgetEntries as default, MultipleMasterEntitySourceWidgetEntries }