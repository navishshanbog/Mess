import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";

import AppMultipleMasterEntityListCompositeStore from "entity/AppMultipleMasterEntityListCompositeStore";
import MultipleMasterEntityTabContainer from "./component/MultipleEntityTabContainer";


class MultipleMasterEntityWidget implements IWidget {
    context: IWidgetContext;
    start() {
        this.context.setView(
            <MultipleMasterEntityTabContainer
                multipleMasterEntityList={AppMultipleMasterEntityListCompositeStore}/>
        );
    }
}

export { MultipleMasterEntityWidget as default, MultipleMasterEntityWidget }
