import IWidgetEntry from "widget/IWidgetEntry";

const MultipleMasterEntityWidgetEntry : IWidgetEntry = {
    key: "multipleMasterEntity",
    name: "Multiple Master Entity",
    description: "Multiple Master Entity",
    get widgetType() {
        return import("./MultipleMasterEntityWidget").then(r => r.default);
    }
};

export { MultipleMasterEntityWidgetEntry as default, MultipleMasterEntityWidgetEntry }