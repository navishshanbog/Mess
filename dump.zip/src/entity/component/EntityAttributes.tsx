import * as React from "react";
import IEntityModel from "../IEntityModel";
import IMasterEntitySearchRequest from "../IMasterEntitySearchRequest";
import IMasterEntitySourceEntityName from "../IMasterEntitySourceEntityName";
import IMasterEntitySourceEntityAddress from "../IMasterEntitySourceEntityAddress";
import IMasterEntitySourceEntityCredential from "../IMasterEntitySourceEntityCredential";
import MasterEntitySourceEntityName from "./MasterEntitySourceEntityName";
import MasterEntitySourceEntityAddress from "./MasterEntitySourceEntityAddress";
import MasterEntitySourceEntityPhone from "./MasterEntitySourceEntityPhone";
import MasterEntitySourceEntityCredential from "./MasterEntitySourceEntityCredential";
import * as moment from "moment";
import { Output as DateOutputFormat } from "common/DateFormats";
import GenderRefList from "common/ref/GenderRefList";
import * as StringUtils from "util/String";
import * as MasterEntitySearchHelper from "../MasterEntitySearchHelper";
import { css } from "office-ui-fabric-react/lib/Utilities";
import "./EntityAttributes.scss";

interface IEntityAttributeProps {
    label?: any;
}

class EntityAttribute extends React.Component<IEntityAttributeProps, any> {
    render() {
        return (
            <dl className="entity-attribute">
                {this.props.label && (
                    <dt className="label">{this.props.label}</dt>
                )}
                <dd className="value">{this.props.children}</dd>
            </dl>
        )
    }
}

enum EntityAttributesType {
    primary,
    secondary
}

interface IEntityAttributesProps {
    entity: IEntityModel;
    type?: EntityAttributesType;
    position?: number;
}

const DefaultEntityAttributesProps : IEntityAttributesProps = {
    entity: null,
    type: EntityAttributesType.primary,
    position: null
}

class EntityAttributes extends React.Component<IEntityAttributesProps, any> {
    public static defaultProps = DefaultEntityAttributesProps;
    render() {
        let positionDescription;
        let names;
        let addresses;
        let phones;
        let credentials;
        let dob;
        let gender;

        if(this.props.position) {
            positionDescription = <EntityAttribute>({this.props.position})</EntityAttribute>;
        }

        if(this.props.entity && this.props.entity.names && this.props.entity.names.length > 0) {
            const nameItems = this.props.entity.names.map((name) => {
                return <MasterEntitySourceEntityName className="entity-attribute-value" key={name.sourceSystemCd + name.sourceEntityNameId} name={name} onClick={this.props.entity.attributeActions ? this.props.entity.attributeActions.onSearch : undefined} />;
            });
            names = <EntityAttribute label="Names">{nameItems}</EntityAttribute>;
        }
        if(this.props.entity && this.props.entity.addresses && this.props.entity.addresses.length > 0) {
            const addressItems = this.props.entity.addresses.map((address) => {
                return <MasterEntitySourceEntityAddress className="entity-attribute-value" key={address.sourceSystemCd + address.sourceEntityAddressId} address={address} onClick={this.props.entity.attributeActions ? this.props.entity.attributeActions.onSearch : undefined} />;
            });
            addresses = <EntityAttribute label="Addresses">{addressItems}</EntityAttribute>;
        }
        if(this.props.entity && this.props.entity.phones && this.props.entity.phones.length > 0) {
            const phoneItems = this.props.entity.phones.map((phone) => {
                return <MasterEntitySourceEntityPhone className="entity-attribute-value" key={phone.sourceSystemCd + phone.sourceEntityPhoneId} phone={phone} onClick={this.props.entity.attributeActions ? this.props.entity.attributeActions.onSearch : undefined} />;
            });
            phones = <EntityAttribute label="Phones">{phoneItems}</EntityAttribute>;
        }
        if(this.props.entity && this.props.entity.credentials && this.props.entity.credentials.length > 0) {
            const credentialItems = this.props.entity.credentials.map((credential) => {
                return <MasterEntitySourceEntityCredential
                            className="entity-attribute-value" 
                            key={credential.sourceSystemCd + credential.sourceEntityCredentialId}
                            credential={credential}
                            onClick={this.props.entity.attributeActions ? this.props.entity.attributeActions.onSearch : undefined} />
            });
            credentials = <EntityAttribute label="Credentials">{credentialItems}</EntityAttribute>;
        }
        if(this.props.entity && this.props.entity.dateOfBirth) {
            dob = <EntityAttribute label="Date of Birth">{moment(this.props.entity.dateOfBirth).format(DateOutputFormat.default)}</EntityAttribute>
        }
        if(this.props.entity && this.props.entity.gender) {
            const genderRefListItem = GenderRefList.getItemByKey(this.props.entity.gender);
            if(genderRefListItem) {
                gender = <EntityAttribute label="Gender">{genderRefListItem.text}</EntityAttribute>
            }
        }
        if(names || dob || gender || addresses || phones || credentials) {
            return (
                <div className={css("entity-attributes", { "primary": this.props.type === EntityAttributesType.primary, "secondary": this.props.type === EntityAttributesType.secondary })}>
                    {positionDescription}
                    {names}
                    {dob}
                    {gender}
                    {addresses}
                    {phones}
                    {credentials}
                </div>
            );
        }
        return null;
    }
}

export { EntityAttributes as default, EntityAttributes, IEntityAttributesProps, EntityAttributesType };