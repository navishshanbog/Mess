import * as React from "react";
import { observer } from "mobx-react";
import { FocusZone } from "office-ui-fabric-react/lib/FocusZone";
import { SearchBox } from "office-ui-fabric-react/lib/SearchBox";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Page, PageHeader, PageTitle, PageSubtitle, PageBody } from "common/component/Page";
import MomentField from "common/component/MomentField";
import IMasterEntityModel from "../IMasterEntityModel";
import IMasterEntityRefModel from "../IMasterEntityRefModel";
import MasterEntitySourceEntityNISName from "./MasterEntitySourceEntityNISName";
import MasterEntitySourceEntityName from "./MasterEntitySourceEntityName";
import IMasterEntitySourceEntityName from "../IMasterEntitySourceEntityName";
import IMasterEntitySourceEntityAddress from "../IMasterEntitySourceEntityAddress";
import IMasterEntitySourceEntityCredential from "../IMasterEntitySourceEntityCredential";
import EntityAttributes from "./EntityAttributes";
import MasterEntitySourceContainer from "./MasterEntitySourceContainer";
import "./MasterEntity.scss";
import ImageGalleryContainer from "entityphotos/component/ImageGalleryContainer";
import {EntityPhotosStore} from "entityphotos/EntityPhotosStore";
import EntityPhotos from "entityphotos/component/EntityPhotos";

interface IMasterEntityProps {
    masterEntity: IMasterEntityModel;
}

class MasterEntityPersonTitle extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <div className="master-entity-title master-entity-person-title">
                <Icon className="master-entity-title-icon" iconName="Contact" aria-label="Person" aria-hidden={true} />
                <MasterEntitySourceEntityNISName dateOfBirth={this.props.masterEntity.dateOfBirth} name={this.props.masterEntity.name} />
            </div>
        );
    }
}

class MasterEntityOrgTitle extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <div className="master-entity-title master-entity-org-title">
                <Icon className="master-entity-title-icon" iconName="Org" aria-label="Org" aria-hidden={true} />
                <MasterEntitySourceEntityName name={this.props.masterEntity.name} />
            </div>
        );
    }
}

@observer
class MasterEntityTitle extends React.Component<IMasterEntityProps, any> {
    render() {
        let title;
        if(this.props.masterEntity.isPerson) {
            title = <MasterEntityPersonTitle masterEntity={this.props.masterEntity} />;
        } else if(this.props.masterEntity.isOrganisation) {
            title = <MasterEntityOrgTitle masterEntity={this.props.masterEntity} />;
        } else {
            title = <MasterEntitySourceEntityName name={this.props.masterEntity.name} />;
        }
        return <PageTitle>{title}</PageTitle>;
    }
}

class MasterEntitySubtitle extends React.Component<IMasterEntityProps, any> {
    render() {
        return <PageSubtitle><EntityAttributes entity={this.props.masterEntity} /></PageSubtitle>;
    }
}

class MasterEntityPhotos extends React.Component<IMasterEntityProps, any> {
    render() {
        return <EntityPhotos model={EntityPhotosStore} />
    }
}

class MasterEntityHeader extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <PageHeader>
                <div className="page-header-child"> 
                    <div className="title-group">
                    <MasterEntityTitle {...this.props} />
                    <MasterEntitySubtitle {...this.props} />
                    </div>
                    <div className="image-group">
                        <MasterEntityPhotos {...this.props} />
                    </div>
                </div>
            </PageHeader>
        );
    }
}

class MasterEntityBody extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <PageBody className="master-entity-body">
                <MasterEntitySourceContainer masterEntity={this.props.masterEntity} />
            </PageBody>
        )
    }
}

class MasterEntity extends React.Component<IMasterEntityProps, any> {
    render() {
        return (
            <Page className="master-entity">
                <MasterEntityHeader {...this.props} />
                <MasterEntityBody {...this.props} />
            </Page>
        );
    }
}

export {
    MasterEntity as default,
    MasterEntity,
    IMasterEntityProps,
    MasterEntityPersonTitle,
    MasterEntityOrgTitle
};