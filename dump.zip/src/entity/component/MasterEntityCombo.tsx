import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { Breadcrumb, IBreadcrumbItem } from "office-ui-fabric-react/lib/Breadcrumb";
import { MasterEntityComboPlace } from "../IMasterEntityComboModel";
import MasterEntitySearchRequestTabs from "./MasterEntitySearchRequestTabs";
import MasterEntitySearchResult from "./MasterEntitySearchResult";
import MasterEntityContainer from "./MasterEntityContainer";
import IMasterEntityComboModel from "../IMasterEntityComboModel";
import IMasterEntitySearchRequestEntry from "../IMasterEntitySearchRequestEntry";
import "./MasterEntityCombo.scss";
import IEntityEventNotification from "entity/IEntityEventNotification";

interface IMasterEntityComboProps {
    masterEntityCombo: IMasterEntityComboModel;
    entityEventNotification? : IEntityEventNotification;
}

@observer
class MasterEntityComboBreadcrumb extends React.Component<IMasterEntityComboProps, any> {
    _handleSearchClick = () => {
        this.props.masterEntityCombo.goToSearch();
    }
    _handleSearchResultsClick = () => {
        this.props.masterEntityCombo.goToSearchResults();
    }
    _handleMasterEntityClick = () => {
        this.props.masterEntityCombo.goToMasterEntity();
    }
    render() {
        const items : IBreadcrumbItem[] = [
            {
                key: "search",
                text: "Search",
                onClick: this.props.masterEntityCombo.place !== MasterEntityComboPlace.search ? this._handleSearchClick : undefined
            }
        ];
        if(this.props.masterEntityCombo.searchResult.requestEntry) {
            items.push({
                key: "searchResults",
                text: "Search Results",
                onClick: this.props.masterEntityCombo.place !== MasterEntityComboPlace.searchResult ? this._handleSearchResultsClick : undefined
            });
        }
        if(this.props.masterEntityCombo.place === MasterEntityComboPlace.masterEntity || this.props.masterEntityCombo.masterEntityRef.masterEntityId) {
            let name;
            if(this.props.masterEntityCombo.masterEntityRef.sync.syncing) {
                name = "Loading...";
            } else if(this.props.masterEntityCombo.masterEntityRef.sync.error) {
                name = "Error";
            } else {
                name = this.props.masterEntityCombo.masterEntityRef.ref.name.standardFullName;
            }
            items.push({
                key: "masterEntity",
                text: name,
                onClick: this.props.masterEntityCombo.place !== MasterEntityComboPlace.masterEntity ? this._handleMasterEntityClick : undefined
            })
        }

        return <Breadcrumb className="master-entity-combo-breadcrumb" items={items} />;
    }
}

@observer
class MasterEntityComboContent extends React.Component<IMasterEntityComboProps, any> {
    _handleSelectHistoryEntry = (entry : IMasterEntitySearchRequestEntry) => {
        this.props.masterEntityCombo.submitRequest(entry.request);
    }
    render() {
        let content;
        switch(this.props.masterEntityCombo.place) {
            case MasterEntityComboPlace.search:
                content = <MasterEntitySearchRequestTabs searchRequest={this.props.masterEntityCombo.searchRequest} onSelectHistoryEntry={this._handleSelectHistoryEntry} />;
                break;
            case MasterEntityComboPlace.searchResult:
                content = <MasterEntitySearchResult searchResult={this.props.masterEntityCombo.searchResult} />;
                break;
            case MasterEntityComboPlace.masterEntity:
                content = <MasterEntityContainer masterEntityRef={this.props.masterEntityCombo.masterEntityRef}
                                                 entityEventNotification={this.props.entityEventNotification} />
                break;
            default:
                content = <MessageBar messageBarType={MessageBarType.error}>Oops: this is an invalid place</MessageBar>;
        }
        return content;
    }
}

class MasterEntityCombo extends React.Component<IMasterEntityComboProps, any> {
    render() {
        return (
            <div className="master-entity-combo">
                <MasterEntityComboBreadcrumb masterEntityCombo={this.props.masterEntityCombo}
                                             entityEventNotification={this.props.entityEventNotification} />
                <MasterEntityComboContent masterEntityCombo={this.props.masterEntityCombo}
                                          entityEventNotification={this.props.entityEventNotification}  />
            </div>
        );
    }
}

export { MasterEntityCombo as default, MasterEntityCombo };