import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Error from "common/component/Error";
import MasterEntity from "./MasterEntity";
import IMasterEntityModel from "../IMasterEntityModel";
import IMasterEntityRefModel from "../IMasterEntityRefModel";
import { css } from "office-ui-fabric-react/lib/Utilities";
import "./MasterEntityContainer.scss";
import IEntityEventNotification from "entity/IEntityEventNotification";

interface IMasterEntityRefProps {
    position? : number;
    masterEntityRef: IMasterEntityRefModel;
    entityEventNotification? : IEntityEventNotification;
    className?: string;
    onRenderContent?: (masterEntity : IMasterEntityModel) => React.ReactElement<any>;
    onRenderNotLoaded?: () => React.ReactElement<any>;
}

@observer
class MasterEntityRefSyncError extends React.Component<IMasterEntityRefProps, any> {
    render() {
        if(!this.props.masterEntityRef.sync.syncing && this.props.masterEntityRef.sync.error) {
            if(this.props.masterEntityRef.sync.error.status === 404 || this.props.masterEntityRef.sync.error.code === "NOT_FOUND") {
                return <MessageBar messageBarType={MessageBarType.warning}>{this.props.masterEntityRef.sync.error.message}</MessageBar>;
            }
            return <Error className="master-entity-error" error={this.props.masterEntityRef.sync.error} />;
        }
        return null;
    }
}

@observer
class MasterEntityRefSync extends React.Component<IMasterEntityRefProps, any> {
    render() {
        if(this.props.masterEntityRef.sync.syncing) {
            return <Spinner className="master-entity-sync" label="Loading Master Entity..." />;
        }
        return null;
    }
}

@observer
class MasterEntityContent extends React.Component<IMasterEntityRefProps, any> {
    render() {
        if(!this.props.masterEntityRef.sync.syncing && this.props.masterEntityRef.sync.hasSynced && this.props.masterEntityRef.ref) {
            return this.props.onRenderContent ?
                this.props.onRenderContent(this.props.masterEntityRef.ref) :
                <MasterEntity masterEntity={this.props.masterEntityRef.ref} />;
        }
        return null;
    }
}

@observer
class MasterEntityNotLoaded extends React.Component<IMasterEntityRefProps, any> {
    render() {
        if(!this.props.masterEntityRef.sync.syncing && !this.props.masterEntityRef.sync.hasSynced) {
            return this.props.onRenderNotLoaded ?
                this.props.onRenderNotLoaded() :
                <MessageBar messageBarType={MessageBarType.warning}>Master Entity has not been loaded</MessageBar>;
        }
        return null;
    }
}

class MasterEntityContainer extends React.Component<IMasterEntityRefProps, any> {
    render() {
        return (
            <div className={css("master-entity-container", this.props.className)}>
                <MasterEntityRefSync masterEntityRef={this.props.masterEntityRef} entityEventNotification={this.props.entityEventNotification} />
                <MasterEntityRefSyncError masterEntityRef={this.props.masterEntityRef} entityEventNotification={this.props.entityEventNotification} />
                <MasterEntityNotLoaded {...this.props} />
                <MasterEntityContent {...this.props} />
            </div>
        );
    }
}

export { MasterEntityContainer as default, MasterEntityContainer, IMasterEntityRefProps }