import * as React from "react";
import { observer } from "mobx-react";
import { Nav, INavLink } from "office-ui-fabric-react/lib/Nav";
import AppStore from "app/AppStore";
import IMasterEntitySearchResultModel from "../IMasterEntitySearchResultModel";
import IMasterEntityRefModel from "../IMasterEntityRefModel";
import MasterEntitySearchRoute from "../MasterEntitySearchRoute";
import MasterEntitySearchResultRoute from "../MasterEntitySearchResultRoute";
import MasterEntityRoute from "../MasterEntityRoute";

interface IMasterEntityNavProps {
    masterEntityRef?: IMasterEntityRefModel;
}

@observer
class MasterEntityNav extends React.Component<any, any> {
    render() {
        const links : INavLink[] = [];
        links.push({
            key: MasterEntitySearchRoute.key,
            name: "Search",
            url: AppStore.createUrl({ path: MasterEntitySearchRoute.path }),
            onClick: (e : React.MouseEvent<HTMLElement>) => {
                e.preventDefault();
                AppStore.open({ path: MasterEntitySearchRoute.path })
            }
        });
        links.push({
            key: MasterEntitySearchResultRoute.key,
            name: "Search Results",
            url: AppStore.createUrl({ path: MasterEntitySearchResultRoute.path }),
            onClick: (e : React.MouseEvent<HTMLElement>) => {
                e.preventDefault();
                AppStore.open({ path: MasterEntitySearchResultRoute.path })
            }
        });
        
        if(this.props.masterEntityRef && this.props.masterEntityRef.masterEntityId) {
            let subLinks : INavLink[];
            let name;
            if(this.props.masterEntityRef.sync.syncing) {
                name = "Loading...";
            } else if(this.props.masterEntityRef.sync.error) {
                name = "Error";
            } else {
                const e = this.props.masterEntityRef.ref;
                name = e.name.standardFullName;
                if(e.sources.length > 0) {
                    subLinks = [];
                    e.sources.forEach((s) => {
                        subLinks.push({
                            key: s.sourceSystemCode,
                            name: s.sourceSystemCode,
                            url: `#${s.sourceSystemCode}`
                        });
                    });
                }
            }
            const path = MasterEntityRoute.pathTemplate.toPath({ masterEntityId: this.props.masterEntityRef.masterEntityId });
            links.push({
                key: MasterEntityRoute.key,
                name: name,
                url: AppStore.createUrl({ path: path }),
                onClick: (e : React.MouseEvent<HTMLElement>) => {
                    e.preventDefault();
                    AppStore.open({ path: path })
                },
                links: subLinks,
                isExpanded: subLinks && subLinks.length > 0 ? true : false
            });
        }
        const selectedKey = AppStore.activeRoute ? AppStore.activeRoute.key : undefined;
        return (
            <Nav groups={[
                {
                    name: "Master Entity",
                    links: links
                }
            ]} selectedKey={selectedKey} />
        );
    }
}

export { MasterEntityNav as default, MasterEntityNav };