import * as React from "react";
import { observer } from "mobx-react";
import ListContainer from "common/component/ListContainer";
import IMasterEntitySearchHistoryModel from "../IMasterEntitySearchHistoryModel";
import MasterEntitySearchHistoryStore from "../MasterEntitySearchHistoryStore";
import IMasterEntitySearchRequestEntry from "../IMasterEntitySearchRequestEntry";
import MasterEntitySearchHistoryDetailView from "./MasterEntitySearchHistoryDetailView";
import IAction from "common/IAction";

interface IMasterEntitySearchHistoryProps {
    searchHistory?: IMasterEntitySearchHistoryModel;
    onSelectEntry?: IAction<IMasterEntitySearchRequestEntry>;
}

const DefaultMasterEntitySearchHistoryProps : IMasterEntitySearchHistoryProps = {
    searchHistory : MasterEntitySearchHistoryStore
};

class MasterEntitySearchHistory extends React.Component<IMasterEntitySearchHistoryProps, any> {
    public static defaultProps = DefaultMasterEntitySearchHistoryProps;
    _handleItemSelected = (item) => {
        this.props.searchHistory.selectItem(item);
    }
    _handleRenderItems = (items : IMasterEntitySearchRequestEntry[]) => {
        return <MasterEntitySearchHistoryDetailView items={items} onItemSelected={this._handleItemSelected} />
    }
    componentDidMount() {
        this.props.searchHistory.selectActions.addAction(this.props.onSelectEntry);
        this.props.searchHistory.load();
    }
    componentWillUnmount() {
        this.props.searchHistory.selectActions.removeAction(this.props.onSelectEntry);
    }
    render() {
        return (
            <ListContainer list={this.props.searchHistory}
                            onRenderItems={this._handleRenderItems}
                            typeLabel="Master Entity Search Requests" />
        );
    }
}

export { MasterEntitySearchHistory as default, MasterEntitySearchHistory, IMasterEntitySearchHistoryProps }