import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList, 
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    ColumnActionsMode,
    Selection,
    SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { css } from "@uifabric/utilities/lib/css";
import IMasterEntitySearchRequestEntry from "../IMasterEntitySearchRequestEntry";
import * as DateUtils from "util/Date";
import * as moment from "moment";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import ISortModel from "common/ISortModel";
import MasterEntitySearchRequestSummary from "./MasterEntitySearchRequestSummary";
import "./MasterEntitySearchHistoryDetailView.scss";

interface IMasterEntitySearchHistoryDetailViewProps {
    items: IMasterEntitySearchRequestEntry[];
    sort?: ISortModel;
    onItemSelected?: (item : IMasterEntitySearchRequestEntry) => void;
}

const Columns : IColumn[] = [
    {
        key: "timestamp",
        ariaLabel: "When",
        name: "When",
        fieldName: "timestamp",
        columnActionsMode:ColumnActionsMode.clickable,
        isResizable: true,
        isMultiline: true,
        minWidth: 40,
        maxWidth: 200,
        onRender: (item :  IMasterEntitySearchRequestEntry) => {
            return moment(item.timestamp).from(moment());
        }
    },
    {
        key: "request",
        ariaLabel: "Request",
        name: "Request",
        fieldName: "request",
        columnActionsMode:ColumnActionsMode.clickable,
        isResizable: true,
        isMultiline: true,
        minWidth: 100,
        maxWidth: 500,
        onRender: (item : IMasterEntitySearchRequestEntry) => {
            return <MasterEntitySearchRequestSummary requestEntry={item} />
        }
    }
];

class MasterEntitySearchHistoryDetailView extends React.Component<any, any> {
    private _selection : Selection;
    constructor(props : IMasterEntitySearchHistoryDetailViewProps) {
        super(props);
        this._selection = new Selection({
            onSelectionChanged: this._handleSelectionChange
        });
    }
    private _handleSelectionChange = () => {
        if(this._selection.getSelectedCount() > 0 && this.props.onItemSelected) {
            const item = this._selection.getSelection()[0] as IMasterEntitySearchRequestEntry;
            this.props.onItemSelected(item);
        }
    }
    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.sort) {
            this.props.sort.toggleSort(column.fieldName);
        }
    }
    render() {
        // setup columns
        const columns = ColumnSortHelper.applySort(Columns, this.props.sort);
        return (
            <div className="master-entity-search-history-detail-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                                items={this.props.items}
                                selection={this._selection}
                                selectionMode={SelectionMode.single}
                                onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                layoutMode={DetailsListLayoutMode.fixedColumns}
                                constrainMode={ConstrainMode.unconstrained}
                                checkboxVisibility={CheckboxVisibility.hidden} />
            </div>
        );            
    }
}

export { MasterEntitySearchHistoryDetailView as default, MasterEntitySearchHistoryDetailView }