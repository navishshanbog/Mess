import * as React from "react";
import { observer } from "mobx-react";
import IMasterEntitySearchRequest from "../IMasterEntitySearchRequest";
import IMasterEntitySearchRequestModel from "../IMasterEntitySearchRequestModel";
import { DialogFooter } from "office-ui-fabric-react/lib/Dialog";
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import "./MasterEntitySearchRequestActions.scss";

interface IMasterEntitySearchRequestActionsProps {
    searchRequest: IMasterEntitySearchRequestModel;
}

@observer
class MasterEntitySearchRequestActions extends React.Component<IMasterEntitySearchRequestActionsProps, any> {
    _handleSubmit = () => {
        this.props.searchRequest.submit();
    }
    _handleClear = () => {
        this.props.searchRequest.clear();
    }
    render() {
        return (
            <div className="master-entity-search-request-actions">
                <PrimaryButton
                    className="master-entity-search-request-action"
                    disabled={!this.props.searchRequest.isValueSpecified}
                    onClick={this._handleSubmit}
                    iconProps={{ iconName: "Search" }}>Search</PrimaryButton>
                <PrimaryButton
                    className="master-entity-search-request-action"
                    onClick={this._handleClear}
                    disabled={!this.props.searchRequest.isValueSpecified}
                    iconProps={{ iconName: "Clear" }}>Clear</PrimaryButton>
            </div>
        );
    }
}

export { MasterEntitySearchRequestActions as default, MasterEntitySearchRequestActions };