import * as React from "react";
import MasterEntitySearchRequestEditor from "./MasterEntitySearchRequestEditor";
import MasterEntitySearchRequestActions from "./MasterEntitySearchRequestActions";
import IMasterEntitySearchRequestModel from "../IMasterEntitySearchRequestModel";
import { KeyCodes } from "office-ui-fabric-react/lib/Utilities";

interface IMasterEntitySearchRequestContainerProps {
    searchRequest: IMasterEntitySearchRequestModel;
}

class MasterEntitySearchRequestContainer extends React.Component<IMasterEntitySearchRequestContainerProps, any> {
    _handleKeyDown = (e : React.KeyboardEvent<HTMLElement>) => {
        if(e.which === KeyCodes.enter) {
            this.props.searchRequest.submit();
        }
    }
    render() {
        return (
            <div className="master-entity-search-request-container" onKeyDown={this._handleKeyDown}>
                <MasterEntitySearchRequestEditor searchRequest={this.props.searchRequest} />
                <MasterEntitySearchRequestActions searchRequest={this.props.searchRequest} />
            </div>
        );
    }
}

export {
    MasterEntitySearchRequestContainer as default,
    MasterEntitySearchRequestContainer,
    IMasterEntitySearchRequestContainerProps
};