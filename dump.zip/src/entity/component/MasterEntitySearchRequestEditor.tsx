import * as React from "react";
import { observer } from "mobx-react";
import IMasterEntitySearchRequestModel from "../IMasterEntitySearchRequestModel";
import { TextField } from "office-ui-fabric-react/lib/TextField";
import { Dropdown, IDropdownOption } from "office-ui-fabric-react/lib/Dropdown";
import { ISelectableOption } from "office-ui-fabric-react/lib/utilities/selectableOption/SelectableOption.Props";
/*
import { ComboBox } from "office-ui-fabric-react/lib/ComboBox";
*/
/*
import { Dropdown } from "office-ui-fabric-react/lib/Dropdown";
*/
import { Checkbox  } from "office-ui-fabric-react/lib/Checkbox";
import { MessageBar } from "office-ui-fabric-react/lib/MessageBar";
import { Icon, IIconProps } from "office-ui-fabric-react/lib/Icon";
import { IconButton } from "office-ui-fabric-react/lib/Button";
import { FocusZone } from "office-ui-fabric-react/lib/FocusZone";
import { FocusTrapZone } from "office-ui-fabric-react/lib/FocusTrapZone";
import { css } from "@uifabric/utilities/lib/css";
import MomentField from "common/component/MomentField";
import ComboBox from "common/component/ComboBox";
import Details from "common/component/Details";
import IRefListItem from "common/ref/IRefListItem";
import GenderRefList from "common/ref/GenderRefList";
import CredentialTypeRefList from "common/ref/CredentialTypeRefList";
import StreetTypeRefList from "common/ref/StreetTypeRefList";
import StateRefList from "common/ref/StateRefList";
import ValidationErrors from "common/component/ValidationErrors";
import IKeyedTextItem from "common/IKeyedTextItem";
import * as RefListUtils from "common/ref/RefListUtils";
import * as moment from "moment";

interface IMasterEntitySearchRequestEditorProps {
    searchRequest: IMasterEntitySearchRequestModel;
}

@observer
class MasterEntityStreetTypeEditor extends React.Component<IMasterEntitySearchRequestEditorProps, any> {
    _handleStreetTypeChanged = (value : any, item : IKeyedTextItem) => {
        this.props.searchRequest.setStreetType(item ? item.key : value);
    }
    render() {
        const streetTypeOptions = StreetTypeRefList.items;
        return <ComboBox label="Street Type"
                         value={this.props.searchRequest.streetType || ""}
                         onChanged={this._handleStreetTypeChanged}
                         options={streetTypeOptions} />;
    }
}

@observer
class MasterEntitySearchRequestEditor extends React.Component<IMasterEntitySearchRequestEditorProps, any> {
    _handleIdChange = (value : string) => {
        this.props.searchRequest.setId(value);
    }
    _handleFullNameChange = (value : string) => {
        this.props.searchRequest.setFullName(value);
    }
    _handleEmailChange = (value : string) => {
        this.props.searchRequest.setEmail(value);
    }
    _handleFirstNameChange = (value : string) => {
        this.props.searchRequest.setFirstName(value);
    }
    _handleMiddleNameChange = (value : string) => {
        this.props.searchRequest.setMiddleName(value);
    }
    _handleFamilyNameChange = (value : string) => {
        this.props.searchRequest.setFamilyName(value);
    }
    _handleDobChange = (value : moment.Moment) => {
        this.props.searchRequest.setDob(value);
    }
    _handleGenderChange = (item : IDropdownOption ) => {
        this.props.searchRequest.setGender(String(item.key));
    }
    _handleCredentialTypeChanged = (option : IDropdownOption) => {
        this.props.searchRequest.setCredentialType(String(option.key));
    }
    _handleCredentialChanged = (value : string) => {
        this.props.searchRequest.setCredential(value);
    }
    _handlePhoneChanged = (value : string) => {
        this.props.searchRequest.setPhone(value);
    }
    _handleFullAddressChanged = (value : string) => {
        this.props.searchRequest.setFullAddress(value);
    }
    _handleUnitNumberChanged = (text : string) => {
        this.props.searchRequest.setUnitNumber(text);
    }
    _handleStreetNumberChanged = (text : string) => {
        this.props.searchRequest.setStreetNumber(text);
    }
    _handleStreetNameChanged = (text : string) => {
        this.props.searchRequest.setStreetName(text);
    }
    _handleLocalityChanged = (text : string) => {
        this.props.searchRequest.setLocality(text);
    }
    _handleStateChanged = (option : IDropdownOption) => {
        this.props.searchRequest.setState(String(option.key));
    }
    _handlePostcodeChanged = (text : string) => {
        this.props.searchRequest.setPostcode(text);
    }
    _handleEntitySectionChange = (visible : boolean) => {
        this.props.searchRequest.setEntityOn(visible);
    }
    _handlePersonSectionChange = (visible : boolean) => {
        this.props.searchRequest.setPersonOn(visible);
    }
    _handleAddressSectionChange = (visible : boolean) => {
        this.props.searchRequest.setAddressOn(visible);
    }
    _handleCredentialSectionChange = (visible : boolean) => {
        this.props.searchRequest.setCredentialOn(visible);
    }
    _handleContactSectionChange = (visible : boolean) => {
        this.props.searchRequest.setContactOn(visible);
    }
    render() {
        const genderOptions = RefListUtils.getOptionalRefListItems(GenderRefList);
        const stateOptions = RefListUtils.getOptionalRefListItems(StateRefList);
        const credentialTypeOptions = RefListUtils.getOptionalRefListItems(CredentialTypeRefList);
        return (
            <div className="master-entity-search-editor">
                <ValidationErrors errors={this.props.searchRequest.validationErrors} />
                <Details summary="Entity"
                        controlOnHeaderClick={true}
                        open={this.props.searchRequest.entityOn}
                        onOpenChange={this._handleEntitySectionChange}>
                    <div className="ms-Grid">
                        {/*
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12">
                                <TextField label="Master Entity ID" onChanged={this._handleIdChange} value={this.props.searchRequest.id || ""}  data-selenium-id="masterEntitySearchEntityEntityId" />
                            </div>
                        </div>
                        */}
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12">
                                <TextField label="Name" onChanged={this._handleFullNameChange} value={this.props.searchRequest.fullName || ""} data-selenium-id="masterEntitySearchEntityFullName" />
                            </div>
                        </div>
                    </div>
                </Details>
                <Details summary={<div><Icon iconName="Contact" aria-hidden={true} /> Person</div>}
                        controlOnHeaderClick={true}
                        onOpenChange={this._handlePersonSectionChange}
                        open={this.props.searchRequest.personOn}>
                    <div className="ms-Grid" >
                        <div className="ms-Grid-row" >
                            <div className="ms-Grid-col ms-sm12 ms-md4" >
                                <TextField label="First Name" onChanged={this._handleFirstNameChange} value={this.props.searchRequest.firstName || ""} data-selenium-id="masterEntitySearchPersonFirstName" />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md4">
                                <TextField label="Middle Name" onChanged={this._handleMiddleNameChange} value={this.props.searchRequest.middleName || ""} data-selenium-id="masterEntitySearchPersonMiddleName" />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md4">
                                <TextField label="Last Name" onChanged={this._handleFamilyNameChange} value={this.props.searchRequest.familyName || ""} data-selenium-id="masterEntitySearchPersonSurname" />
                            </div>
                        </div>
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12 ms-md4 ms-lg4">
                                <MomentField label="Date of Birth" onChange={this._handleDobChange} value={this.props.searchRequest.dob} />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md4 ms-lg4">
                                <Dropdown label="Gender" options={genderOptions} onChanged={this._handleGenderChange} selectedKey={this.props.searchRequest.gender || ""} />
                            </div>
                        </div>
                    </div>
                </Details>
                <Details summary={<div><Icon iconName="ContactCard" aria-hidden={true} /> Credential</div>} 
                        controlOnHeaderClick={true}
                        onOpenChange={this._handleCredentialSectionChange}
                        open={this.props.searchRequest.credentialOn}>
                    <div className="ms-Grid" >
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12 ms-md4 ms-lg4">
                                <Dropdown label="Type" options={credentialTypeOptions} onChanged={this._handleCredentialTypeChanged} selectedKey={this.props.searchRequest.credentialType || ""} />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md8 ms-lg8">
                                <TextField label="Value" onChanged={this._handleCredentialChanged} value={this.props.searchRequest.credential || ""} />
                            </div>
                        </div>
                    </div>
                </Details>
                <Details summary={<div><Icon iconName="Home" aria-hidden={true} /> Address</div>}
                        controlOnHeaderClick={true}
                        onOpenChange={this._handleAddressSectionChange}
                        open={this.props.searchRequest.addressOn}>
                    <div className="ms-Grid" >
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12">
                                <TextField label="Full Address" onChanged={this._handleFullAddressChanged} value={this.props.searchRequest.fullAddress || ""} />
                            </div>
                        </div>
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12 ms-md2">
                                <TextField label="Unit Number" onChanged={this._handleUnitNumberChanged} value={this.props.searchRequest.unitNumber || ""} />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md2">
                                <TextField label="Street Number" onChanged={this._handleStreetNumberChanged} value={this.props.searchRequest.streetNumber || ""} />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md6">
                                <TextField label="Street Name" onChanged={this._handleStreetNameChanged} value={this.props.searchRequest.streetName || ""} />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md2">
                                <MasterEntityStreetTypeEditor {...this.props} />
                            </div>
                        </div>
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12 ms-md6">
                                <TextField label="Locality" onChanged={this._handleLocalityChanged} value={this.props.searchRequest.locality || ""} />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md2">
                                <Dropdown label="State" options={stateOptions} onChanged={this._handleStateChanged} selectedKey={this.props.searchRequest.state || ""} />
                            </div>
                            <div className="ms-Grid-col ms-sm12 ms-md2">
                                <TextField label="Postcode" onChanged={this._handlePostcodeChanged} value={this.props.searchRequest.postcode || ""} />
                            </div>
                        </div>
                    </div>
                </Details>
                <Details summary={<div><Icon iconName="ContactInfo" aria-hidden={true} /> Contact</div>}
                        controlOnHeaderClick={true}
                        onOpenChange={this._handleContactSectionChange}
                        open={this.props.searchRequest.contactOn}>
                    <div className="ms-Grid" >
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12">
                                <TextField label="Email" onChanged={this._handleEmailChange} value={this.props.searchRequest.emailAddress || ""} data-selenium-id="masterEntitySearchEntityEmail" />
                            </div>
                        </div>
                        <div className="ms-Grid-row">
                            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                                <TextField label="Phone" onChanged={this._handlePhoneChanged} value={this.props.searchRequest.phone || ""} data-selenium-id="masterEntitySearchEntityPhone" />
                            </div>
                        </div>
                    </div>
                </Details>
            </div>
        );
    }
}

export {
    MasterEntitySearchRequestEditor as default,
    MasterEntitySearchRequestEditor,
    IMasterEntitySearchRequestEditorProps
};