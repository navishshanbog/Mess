import * as React from "react";
import IMasterEntitySearchRequestEntry from "../IMasterEntitySearchRequestEntry";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import CredentialTypeRefList from "common/ref/CredentialTypeRefList";
import GenderRefList from "common/ref/GenderRefList";
import StreetTypeRefList from "common/ref/StreetTypeRefList";
import StateRefList from "common/ref/StateRefList";
import * as StringUtils from "util/String";
import * as DateUtils from "util/Date";
import DefinitionList from "common/component/DefinitionList";
import "./MasterEntitySearchRequestSummary.scss";

interface IMasterEntitySearchRequestSummaryItemProps {
    name: string;
}

class MasterEntitySearchRequestSummaryItem extends React.Component<IMasterEntitySearchRequestSummaryItemProps, any> {
    render() {
        return <DefinitionList inline={true} className="master-entity-search-request-summary-item" name={this.props.name}>{this.props.children}</DefinitionList>;
    }
}

interface IMasterEntitySearchRequestSummaryProps {
    requestEntry: IMasterEntitySearchRequestEntry;
}

class MasterEntitySearchRequestSummary extends React.Component<IMasterEntitySearchRequestSummaryProps, any> {
    render() {
        if(this.props.requestEntry && this.props.requestEntry.request) {
            const r = this.props.requestEntry.request;
            return (
                <div className="master-entity-search-request-summary" aria-label="Entity Search Request Summary">
                    {StringUtils.isNotBlank(r.fullName) && (
                        <MasterEntitySearchRequestSummaryItem name="Name">{r.fullName}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.emailAddress) && (
                        <MasterEntitySearchRequestSummaryItem name="Email">{r.emailAddress}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.firstName) && (
                        <MasterEntitySearchRequestSummaryItem name="First Name">{r.firstName}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.middleName) && (
                        <MasterEntitySearchRequestSummaryItem name="Middle Name">{r.middleName}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.familyName) && (
                        <MasterEntitySearchRequestSummaryItem name="Last Name">{r.familyName}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.dob) && (
                        <MasterEntitySearchRequestSummaryItem name="Date of Birth">{DateUtils.dataToOutputText(r.dob)}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.sex) && (
                        <MasterEntitySearchRequestSummaryItem name="Gender">{GenderRefList.getItemByKey(r.sex, { key: null, text: "" }).text}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.credentialType) && (
                        <MasterEntitySearchRequestSummaryItem name={CredentialTypeRefList.getItemByKey(r.credentialType, { key: null, text: "" }).text}>
                            {r.credential}
                        </MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.fullAddress) && (
                        <MasterEntitySearchRequestSummaryItem name="Address">{r.fullAddress}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.unitnNo) && (
                        <MasterEntitySearchRequestSummaryItem name="Unit Number">{r.unitnNo}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.streetNo) && (
                        <MasterEntitySearchRequestSummaryItem name="Street Number">{r.streetNo}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.streetName) && (
                        <MasterEntitySearchRequestSummaryItem name="Street Name">{r.streetName}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.streetType) && (
                        <MasterEntitySearchRequestSummaryItem name="Street Type">{StreetTypeRefList.getItemByKey(r.streetType, { key: null, text: r.streetType || "" }).text}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.locality) && (
                        <MasterEntitySearchRequestSummaryItem name="Locality">{r.locality}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.state) && (
                        <MasterEntitySearchRequestSummaryItem name="State">{StateRefList.getItemByKey(r.state, { key: null, text: "" }).text}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.postCode) && (
                        <MasterEntitySearchRequestSummaryItem name="Postcode">{r.postCode}</MasterEntitySearchRequestSummaryItem>
                    )}
                    {StringUtils.isNotBlank(r.phoneNumber) && (
                        <MasterEntitySearchRequestSummaryItem name="Phone">{r.phoneNumber}</MasterEntitySearchRequestSummaryItem>
                    )}
                </div>
            );
        }
        return null;
    }
}

export { MasterEntitySearchRequestSummary as default, MasterEntitySearchRequestSummary };