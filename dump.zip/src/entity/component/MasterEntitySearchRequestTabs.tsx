import * as React from "react";
import { observer } from "mobx-react";
import { Pivot, PivotItem, IPivotItemProps, PivotLinkFormat } from "office-ui-fabric-react/lib/Pivot";
import IMasterEntitySearchRequestModel from "../IMasterEntitySearchRequestModel";
import IMasterEntitySearchRequestEntry from "../IMasterEntitySearchRequestEntry";
import MasterEntitySearchRequestContainer from "./MasterEntitySearchRequestContainer";
import MasterEntitySearchHistory from "./MasterEntitySearchHistory";
import IAction from "common/IAction";

interface IMasterEntitySearchRequestTabsProps {
    searchRequest: IMasterEntitySearchRequestModel;
    onSelectHistoryEntry?: IAction<IMasterEntitySearchRequestEntry>;
}

class MasterEntitySearchRequestTabs extends React.Component<IMasterEntitySearchRequestTabsProps, any> {
    render() {
        return (
            <Pivot>
                <PivotItem key="search" linkText="Search">
                    <MasterEntitySearchRequestContainer searchRequest={this.props.searchRequest} />
                </PivotItem>
                <PivotItem key="history" linkText="History">
                    <MasterEntitySearchHistory onSelectEntry={this.props.onSelectHistoryEntry} />
                </PivotItem>
            </Pivot>
        );
    }
}

export { MasterEntitySearchRequestTabs as default, MasterEntitySearchRequestTabs }