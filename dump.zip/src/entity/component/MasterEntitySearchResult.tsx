import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { SearchBox } from "office-ui-fabric-react/lib/SearchBox";
import { Output as DateOutputFormats } from "common/DateFormats";
import * as moment from "moment";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import MasterEntitySearchRequestSummary from "./MasterEntitySearchRequestSummary";
import MasterEntitySearchResultSummary from "./MasterEntitySearchResultSummary";
import * as MasterEntitySearchResultHelper from "../MasterEntitySearchResultHelper";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import * as ColumnTextHelper from "common/component/ColumnTextHelper";
import IMasterEntitySearchResultModel from "../IMasterEntitySearchResultModel";
import MasterEntitySearchResultDetailView from "./MasterEntitySearchResultDetailView";
import MasterEntitySearchResultItemColumns from "./MasterEntitySearchResultItemColumns";
import ListContainer from "common/component/ListContainer";
import "./MasterEntitySearchResult.scss";

interface IMasterEntitySearchResultProps {
    searchResult: IMasterEntitySearchResultModel;
    onRenderItems?: (items : IMasterEntitySearchResultItem[]) => React.ReactElement<any>;
    onItemSelected?: (item : IMasterEntitySearchResultItem) => void;
}

@observer
class MasterEntitySearchResultMenu extends React.Component<IMasterEntitySearchResultProps, any> {
    private _downloadCsvLinkRef : any;
    private _cleanupDownloadBlobRef() {
        if(this._downloadCsvLinkRef && this._downloadCsvLinkRef.href) {
            try {
                URL.revokeObjectURL(this._downloadCsvLinkRef.href);
            } catch(e) {}
        }
    }
    componentWillUnmount() {
        // cleanup any download link ref
        this._cleanupDownloadBlobRef();
    }
    _handleCSVDownloadLinkRef = (ref) => {
        this._downloadCsvLinkRef = ref;
    }
    _handleCSVDownloadLinkClick = (e : React.MouseEvent<HTMLAnchorElement>) => {
        e.stopPropagation();
    }
    _handleDownloadCSVClick = () => {
        const blob = new Blob([ColumnTextHelper.getCSV(this.props.searchResult.items, MasterEntitySearchResultItemColumns)], { type: "text/csv" });
        const name = "MasteredEntitySearchResult-" +  moment(this.props.searchResult.sync.endDate).format(DateOutputFormats.filename) + ".csv";

        if(window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob, name);
        } else if(this._downloadCsvLinkRef) {
            this._cleanupDownloadBlobRef();
            var url = URL.createObjectURL(blob);
            this._downloadCsvLinkRef.href = url;
            this._downloadCsvLinkRef.download = name;
            this._downloadCsvLinkRef.click();
        }
    }
    _handleRefresh = () => {
        this.props.searchResult.refresh();
    }
    _handleSortFieldItemClick = (e : React.MouseEvent<HTMLElement>, item: IContextualMenuItem) => {
        this.props.searchResult.sort.setField(item.fieldName);
    }
    _handleSortOrderItemClick = (e : React.MouseEvent<HTMLElement>, item: IContextualMenuItem) => {
        this.props.searchResult.sort.setDescending(item.sortDescending);
    }
    /*
    _handleViewTypeClick = (e : React.MouseEvent<HTMLElement>, item: IContextualMenuItem) => {
        this.props.result.setViewType(item.viewType);
    }
    */
    _handleTextFilterChange = (text : string) => {
        this.props.searchResult.setTextFilter(text);
    }
    render() {
        if(this.props.searchResult.sync.hasSynced && !this.props.searchResult.sync.error && this.props.searchResult.items.length > 0) {
            const self = this;
            const menuItems : IContextualMenuItem[] = [
                {
                    key: "filter",
                    name: "Filter",
                    iconProps: {
                        iconName: "Filter"
                    },
                    subMenuProps: {
                        className: "master-entity-search-result-filter-menu",
                        items: [
                            {
                                key: "textFilter",
                                onRender(item) {
                                    return (
                                        <SearchBox key={item.key} value={self.props.searchResult.textFilter}
                                                   labelText="Filter Search Results"
                                                   className="master-entity-search-result-filter-menu-input-item"
                                                   onChange={self._handleTextFilterChange} />
                                    );
                                }
                            }
                        ]
                    }
                },
                {
                    key: "refresh",
                    name: "Refresh",
                    iconProps: { iconName: "Refresh" },
                    ariaLabel: "Refresh Search Result",
                    onClick: this._handleRefresh
                }
            ];
            const farMenuItems : IContextualMenuItem[] = [];
            const downloadCSVLinkRef = <a href="#" hidden={true} ref={this._handleCSVDownloadLinkRef} onClick={this._handleCSVDownloadLinkClick}>Download CSV</a>;
            farMenuItems.push(ColumnSortHelper.createSortItem({
                columns: MasterEntitySearchResultItemColumns,
                sortField: this.props.searchResult.sort.field,
                sortDescending: this.props.searchResult.sort.descending,
                onFieldClick: this._handleSortFieldItemClick,
                onSortOrderClick: this._handleSortOrderItemClick
            }));
            farMenuItems.push({
                key: "download",
                name: "Download as CSV",
                iconProps: { iconName: "Download" },
                ariaLabel: "Download as CSV",
                onClick: this._handleDownloadCSVClick
            });

            return (
                <div className="master-entity-search-result-menu">
                    {downloadCSVLinkRef}
                    <CommandBar items={menuItems} farItems={farMenuItems} />
                </div>
            );
        }
        return null;
    }
}

@observer
class MasterEntitySearchResult extends React.Component<IMasterEntitySearchResultProps, any> {
    _handleItemSelected = (item : IMasterEntitySearchResultItem) => {

        this.props.searchResult.openItem(item);
        if(this.props.onItemSelected) {
            this.props.onItemSelected(item);
        }
    }
    _handleRenderItems = (items : IMasterEntitySearchResultItem[]) => {
        let r = MasterEntitySearchResultHelper.textFilterItems(items, this.props.searchResult.textFilter);
        r = MasterEntitySearchResultHelper.sortItems(r, this.props.searchResult.sort);
        if(r && r.length > 0) {
            return this.props.onRenderItems ?
                        this.props.onRenderItems(r) :
                        <MasterEntitySearchResultDetailView items={r} sort={this.props.searchResult.sort} onItemSelected={this._handleItemSelected} />;
        }
        return <MessageBar messageBarType={MessageBarType.warning}>There are no search results matching the specified filter</MessageBar>;
    }
    render() {
        return (
            <ListContainer className="master-entity-search-result" list={this.props.searchResult} onRenderItems={this._handleRenderItems} typeLabel="Master Entity Search Results" loadingLabel="Searching Master Entities..." />
        );
    }
}

@observer
class MasterEntitySearchResultContainer extends React.Component<IMasterEntitySearchResultProps, any> {
    _handleOpenChange = (open : boolean) => {
        this.props.searchResult.setVisible(open);
    }
    render() {
        if(this.props.searchResult.requestEntry) {
            return (
                <div className="master-entity-search-result-container">
                    <div className="master-entity-search-result-container-summary">
                        <MasterEntitySearchRequestSummary requestEntry={this.props.searchResult.requestEntry} />
                        <MasterEntitySearchResultSummary searchResult={this.props.searchResult} />
                    </div>
                    <MasterEntitySearchResultMenu {...this.props} />
                    <MasterEntitySearchResult {...this.props} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to perform a search to see anything here</MessageBar>;
    }
}

export { MasterEntitySearchResultContainer as default, MasterEntitySearchResultContainer };