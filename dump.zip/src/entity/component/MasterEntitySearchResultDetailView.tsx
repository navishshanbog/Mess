import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList, 
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    ColumnActionsMode,
    DetailsRow,
    IDetailsRowProps,
    Selection,
    SelectionMode
} from "office-ui-fabric-react/lib/DetailsList";
import { css } from "@uifabric/utilities/lib/css";
import { Output as DateOutputFormats } from "common/DateFormats";
import Error from "common/component/Error";
import * as moment from "moment";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import * as SortUtils from "util/Sort";
import * as SearchUtils from "util/Search";
import * as StringUtils from "util/String";
import * as DateUtils from "util/Date";
import * as MasterEntitySearchResultHelper from "../MasterEntitySearchResultHelper";
import MasterEntitySearchResultItemColumns from "./MasterEntitySearchResultItemColumns";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import ISortModel from "common/ISortModel";
import MasterEntitySourceSummary from "./MasterEntitySourceSummary";
import "./MasterEntitySearchResult.scss";

interface IMasterEntitySearchResultDetailViewProps {
    items: IMasterEntitySearchResultItem[];
    sort?: ISortModel;
    onItemSelected?: (item : IMasterEntitySearchResultItem) => void;
}

@observer
class MasterEntitySearchResultDetailView extends React.Component<IMasterEntitySearchResultDetailViewProps, any> {
    private _selection : Selection;
    constructor(props : IMasterEntitySearchResultDetailViewProps) {
        super(props);
        this._selection = new Selection({
            onSelectionChanged: this._handleSelectionChange
        });
    }


    private _handleSelectionChange = () => {
        if(this._selection.getSelectedCount() > 0 && this.props.onItemSelected) {
            const item = this._selection.getSelection()[0] as IMasterEntitySearchResultItem;
            this.props.onItemSelected(item);
        }
    }
    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.sort) {
            this.props.sort.toggleSort(column.fieldName);
        }
    }
    render() {

        const columns = ColumnSortHelper.applySort(MasterEntitySearchResultItemColumns, this.props.sort);

        return (
            <div className="master-entity-search-result-detail-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                                items={this.props.items}
                                selection={this._selection}
                                selectionMode={SelectionMode.single}
                                onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                layoutMode={DetailsListLayoutMode.fixedColumns}
                                constrainMode={ConstrainMode.unconstrained}
                                checkboxVisibility={CheckboxVisibility.hidden} />
            </div>
        );            
    }
}



export {
    MasterEntitySearchResultDetailView as default,
    MasterEntitySearchResultDetailView,
    IMasterEntitySearchResultDetailViewProps
};