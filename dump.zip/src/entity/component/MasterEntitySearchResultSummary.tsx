import * as React from "react";
import { observer } from "mobx-react";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import IListModel from "common/IListModel";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import * as StringUtils from "util/String";
import * as moment from "moment";
import { Output as DateOutputFormats } from "common/DateFormats";
import "./MasterEntitySearchResultSummary.scss";

interface IMasterEntitySearchResultSummaryProps {
    searchResult: IListModel<IMasterEntitySearchResultItem>
}

@observer
class MasterEntitySearchResultSummary extends React.Component<IMasterEntitySearchResultSummaryProps, any> {
    render() {
        if(this.props.searchResult.sync.startDate) {
            return (
                <div className="master-entity-search-result-summary">
                    <div className="master-entity-search-result-group search-start-result-group" aria-label="Search Summary">
                        <Icon className="master-entity-search-result-group-icon" iconName="Clock" aria-hidden="true" />
                        <dl className="master-entity-search-result-item">
                            <dt>Start</dt>
                            <dd>{moment(this.props.searchResult.sync.startDate).format(DateOutputFormats.timestamp)}</dd>
                        </dl>
                        {this.props.searchResult.sync.endDate && (
                            <dl className="master-entity-search-result-item">
                                <dt>End</dt>
                                <dd>{moment(this.props.searchResult.sync.endDate).format(DateOutputFormats.timestamp)}</dd>
                            </dl>
                        )}
                        {this.props.searchResult.sync.endDate && (
                            <dl className="master-entity-search-result-item">
                                <dt>Duration</dt>
                                <dd>{moment(this.props.searchResult.sync.endDate).diff(this.props.searchResult.sync.startDate)} ms</dd>
                            </dl>
                        )}
                        {this.props.searchResult.sync.endDate && (
                            <dl className="master-entity-search-result-item">
                                <dt>Total Records</dt>
                                <dd>{this.props.searchResult.items ? this.props.searchResult.items.length : 0}</dd>
                            </dl>
                        )}
                    </div>
                </div>
            );
        }
        return null;
    }
}

export { MasterEntitySearchResultSummary as default, MasterEntitySearchResultSummary };