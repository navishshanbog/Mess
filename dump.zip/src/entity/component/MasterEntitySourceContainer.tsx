import * as React from "react";
import IMasterEntityModel from "../IMasterEntityModel";
import WidgetContext from "widget/WidgetContext";
import MasterEntitySourceWidgetEntry from "../MasterEntitySourceWidgetEntry";
import WidgetContextContainer from "widget/component/WidgetContext";

interface IMasterEntitySourceContainerProps {
    masterEntity: IMasterEntityModel;
}

class MasterEntitySourceContainer extends React.Component<IMasterEntitySourceContainerProps, any> {
    render() {
        const context = new WidgetContext();
        context.setEntry(MasterEntitySourceWidgetEntry);
        context.setProps({ masterEntity: this.props.masterEntity });
        return <WidgetContextContainer context={context} />;
    }
}

export { MasterEntitySourceContainer as default, MasterEntitySourceContainer, IMasterEntitySourceContainerProps };