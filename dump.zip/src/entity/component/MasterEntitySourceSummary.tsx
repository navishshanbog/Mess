import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import IMasterEntitySearchResultItem from "../IMasterEntitySearchResultItem";
import MasterEntitySourceConfig from "entity/MasterEntitySourceConfig";


interface IMasterEntitySourceSummaryProps {
    masterEntity: IMasterEntitySearchResultItem;
}

interface IMasterEntitySourceSummaryItemProps extends IMasterEntitySourceSummaryProps {
    sourceSystemCode: string;
    count: number;
}

class MasterEntitySourceSystemSummaryItem extends React.Component<IMasterEntitySourceSummaryItemProps, any> {
    render() {
        const configEntry = MasterEntitySourceConfig[this.props.sourceSystemCode];
        return (
            <div className="master-entity-source-summary-item" aria-label={this.props.sourceSystemCode + ": " + this.props.count} title={this.props.sourceSystemCode + ": " + this.props.count}>
                {configEntry ? configEntry.icon() : this.props.sourceSystemCode}
            </div>
        );
    }
}

class MasterEntitySourceSummary extends React.Component<IMasterEntitySourceSummaryProps, any> {
    render() {
        const items : any[] = [];
        Object.keys(MasterEntitySourceConfig).forEach((key) => {
            const count = this.props.masterEntity[key];
            if(!isNaN(count) && count > 0) {
                items.push(
                    <MasterEntitySourceSystemSummaryItem key={key} masterEntity={this.props.masterEntity} sourceSystemCode={key} count={count} />
                );
            }
        });
        if(items.length > 0) {
            return <div className="master-entity-source-summary">{items}</div>;
        }
        return <MessageBar messageBarType={MessageBarType.info}>No Source System data available</MessageBar>;
    }
}

export { MasterEntitySourceSummary as default, MasterEntitySourceSummary, IMasterEntitySourceSummaryProps }