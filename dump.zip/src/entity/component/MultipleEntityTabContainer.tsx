import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Error from "common/component/Error";
import IMasterEntityModel from "../IMasterEntityModel";
import { css } from "office-ui-fabric-react/lib/Utilities";
import "./MasterEntityContainer.scss";
import { Pivot, PivotItem } from 'office-ui-fabric-react/lib/Pivot';
import Details from "common/component/Details";
import IMasterEntity from "entity/IMasterEntity";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import { ISelection, IObjectWithKey } from "office-ui-fabric-react/lib/Selection";
import { ListContainer } from "common/component/ListContainer";
import {MultipleMasterEntityListCompositeModel} from "../MultipleMasterEntityListCompositeModel";
import {IMultipleMasterEntityListCompositeModel} from "entity/IMultipleMasterEntityListCompositeModel";
import {MultipleMasterEntityDetailListView} from "./MultipleMasterEntityListDetailView";
import {MultipleMasterEntity} from "entity/component/MultipleMasterEntity";
import {action} from "mobx";
import { IconButton } from 'office-ui-fabric-react/lib/Button';

interface ImultipleMasterEntityListProps {

    className?: string;
    multipleMasterEntityList : IMultipleMasterEntityListCompositeModel;
}

interface IEntityListProps {
    className?: string;
    list: IListModel<IMasterEntityModel>;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    rowSelectionListener?: (selection: ISelection) => void;
}

@observer
class MasterEntityRefSyncError extends React.Component<ImultipleMasterEntityListProps, any> {
    render() {

        if(!this.props.multipleMasterEntityList.sync.syncing && this.props.multipleMasterEntityList.sync.error) {
            if(this.props.multipleMasterEntityList.sync.error.status === 404 || this.props.multipleMasterEntityList.sync.error.code === "NOT_FOUND") {
                return <MessageBar messageBarType={MessageBarType.warning}>{this.props.multipleMasterEntityList.sync.error.message}</MessageBar>;
            }
            return <Error className="master-entity-error" error={this.props.multipleMasterEntityList.sync.error} />;
        }
        return null;
    }
}

@observer
class MasterEntityRefSync extends React.Component<ImultipleMasterEntityListProps, any> {
    render() {

        if(this.props.multipleMasterEntityList.sync.syncing) {
            return <Spinner className="master-entity-sync" label="Loading Master Entity..." />;
        }
        return null;
    }
}

interface IMasterEntityContainerProps extends ImultipleMasterEntityListProps {
    className?: string;
}


@observer
class MultipleMasterEntityTabContainer extends React.Component<ImultipleMasterEntityListProps, any> {

    @action
    _handleRowSelection = (selection: ISelection) => {

        this.props.multipleMasterEntityList.setSelection(selection);
    }

    @action
    _handleClearItem = () => {

        if (this.props.multipleMasterEntityList.getSelection())
        {
            if (this.props.multipleMasterEntityList.getSelection().getSelection())
            {
                this.props.multipleMasterEntityList.getSelection().getSelection().forEach((item) => {
                    const owk = item as IMasterEntityModel;
                    let entityIdToDelete = owk.masterEntityId;
                    this.props.multipleMasterEntityList.deleteItemByEntityId(entityIdToDelete);
                });
            }
        }
    }

    render() {

        var listContainer;

        if (this.props.multipleMasterEntityList.items) {
            // need to add back sorting
            // sort={this.props.multipleMasterEntityList.items.sort}
            listContainer = (<MultipleMasterEntityListContainer list={this.props.multipleMasterEntityList.items}
                                                                enableRowSelection={true}
                                                                rowSelectionListener={this._handleRowSelection} />);
        }

        let disabled = true;
        if (this.props.multipleMasterEntityList.getSelection()) {

            if (this.props.multipleMasterEntityList.getSelection().getSelection().length > 0) {

                disabled = false;
            }
        }

        return (

            <div>
                <Pivot>
                    <PivotItem linkText={'Please select entities'} key={'multipleEntityDetails'}>
                        <div className={css("master-entity-container", this.props.className)}>
                            <MasterEntityRefSync multipleMasterEntityList={this.props.multipleMasterEntityList} />
                            <MasterEntityRefSyncError multipleMasterEntityList={this.props.multipleMasterEntityList} />

                            {listContainer}
                            <div className="multiple-entity-clear">
                                <IconButton
                                    iconProps={ { iconName: 'RecycleBin' } }
                                    title='Remove entity'
                                    ariaLabel='Remove entity'
                                    disabled={disabled}
                                    onClick={this._handleClearItem} />
                            </div>
                        </div>
                    </PivotItem>
                    <PivotItem linkText={'Combined multiple entity details'} key={'multipleEntityDetails'}>
                        <div className={css("master-entity-container", this.props.className)}>
                            <MultipleMasterEntity multipleMasterEntity={this.props.multipleMasterEntityList} />
                        </div>
                    </PivotItem>
                </Pivot>
            </div>
        );
    }
}


@observer
class MultipleMasterEntityListContainer extends React.Component<IEntityListProps, any> {

    _handleOpenChange = (open) => {

        this.props.list.setVisible(open);
    }

    _handleRenderItems = (items : IMasterEntity[]) => {

        return <MultipleMasterEntityDetailListView list={this.props.list}
                                                   sort={this.props.sort}
                                                   enableRowSelection={this.props.enableRowSelection}
                                                   rowSelectionListener={this.props.rowSelectionListener} />;
    }

    render() {

        return (
            <div className={css("master-entity-container", this.props.className)}>

                <Details open={true}
                         summary={<span>Entities</span>}
                         onOpenChange={this._handleOpenChange}
                         controlOnHeaderClick={false}>
                       <ListContainer
                            className="entities-list"
                            typeLabel="Entities"
                            list={this.props.list}
                            onRenderItems={this._handleRenderItems} />
                </Details>
            </div>
        );
    }
}

export { MultipleMasterEntityTabContainer as default, MultipleMasterEntityTabContainer, IMasterEntityContainerProps }