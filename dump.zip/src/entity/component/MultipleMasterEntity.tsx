import * as React from "react";
import { observer } from "mobx-react";
import { SearchBox } from "office-ui-fabric-react/lib/SearchBox";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IContextualMenuItem, ContextualMenuItemType } from "office-ui-fabric-react/lib/ContextualMenu";
import { Icon } from "office-ui-fabric-react/lib/Icon";
import { Page, PageHeader, PageTitle, PageSubtitle, PageBody } from "common/component/Page";
import MomentField from "common/component/MomentField";
import IMasterEntityModel from "../IMasterEntityModel";
import MasterEntitySourceEntityNISName from "./MasterEntitySourceEntityNISName";
import MultipleMasterEntitySources from "./MultipleMasterEntitySources";
import * as moment from "moment";
import "./MasterEntity.scss";
import {IMultipleMasterEntityListCompositeModel} from "../IMultipleMasterEntityListCompositeModel";

interface IMultipleMasterEntityProps {
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
}


@observer
class MasterEntityCommandBar extends React.Component<IMultipleMasterEntityProps, any> {

    _handleTextFilterChange = (text : string) => {
        this.props.multipleMasterEntity.setFilterText(text);
    }
    _handleFilterFromDateChange = (value : moment.Moment) => {
        this.props.multipleMasterEntity.setFilterFromDate(value);
    }
    _handleFilterToDateChange = (value : moment.Moment) => {
        this.props.multipleMasterEntity.setFilterToDate(value);
    }
    render() {

        const self = this;
        const items : IContextualMenuItem[] = [
            {
                key: "filter",
                name: "Filter",
                iconProps: {
                    iconName: "Filter"
                },
                subMenuProps: {
                    className: "master-entity-filter-menu",
                    items: [
                        {
                            key: "textFilter",
                            onRender(item) {
                                return <SearchBox onChange={self._handleTextFilterChange} value={self.props.multipleMasterEntity.filterText} key={item.key} labelText="Text Filter" className="master-entity-filter-menu-input-item" />
                            }
                        },
                        {
                            key: "sep",
                            name: "-",
                            itemType: ContextualMenuItemType.Divider
                        },
                        {
                            key: "dateFromFilter",
                            onRender(item) {
                                return <MomentField onChange={self._handleFilterFromDateChange} value={self.props.multipleMasterEntity.filterFromDate} key={item.key} placeholder="Filter From Date " className="master-entity-filter-menu-input-item"/>
                            }
                        },
                        {
                            key: "dateToFilter",
                            onRender(item) {
                                return <MomentField onChange={self._handleFilterToDateChange} value={self.props.multipleMasterEntity.filterToDate} key={item.key} placeholder="Filter To Date " className="master-entity-filter-menu-input-item"/>
                            }
                        }
                    ]
                }
            }
        ];

        return (
            <CommandBar className="master-entity-command-bar" items={items} />
        );
    }
}

class MultipleMasterEntityPersonTitle extends React.Component<IMultipleMasterEntityProps, any> {

    render() {
        let titles = this.props.multipleMasterEntity.getSelection().getSelection().map((item, index) => {
            const masterEntity = item as IMasterEntityModel;
            return (
                <div className="master-entity-title master-entity-person-title" key={index}>
                    ({index+1})
                    <Icon className="master-entity-title-icon" iconName="Contact" aria-label="Person" aria-hidden={true} />
                    <MasterEntitySourceEntityNISName dateOfBirth={masterEntity.dateOfBirth} name={masterEntity.name}/>
                </div>
            );
        });

        return (
            <div className="page-header-child">
                <span>
                {titles}
                </span>
            </div>
        );
    }
}

class MasterEntityOrgTitle extends React.Component<IMultipleMasterEntityProps, any> {
    render() {
        return (
            <div />
    )};
}

@observer
class MultipleMasterEntity extends React.Component<IMultipleMasterEntityProps, any> {
    render() {

        let title;
        let entityCommandBar;
        let entitySources;
        if (this.props.multipleMasterEntity.getSelection()) {
            if (this.props.multipleMasterEntity.getSelection().getSelection().length > 0) {
                title = <MultipleMasterEntityPersonTitle multipleMasterEntity={this.props.multipleMasterEntity} />;
                entityCommandBar = <MasterEntityCommandBar multipleMasterEntity={this.props.multipleMasterEntity} />;
                entitySources = <MultipleMasterEntitySources multipleMasterEntity={this.props.multipleMasterEntity} />;
            }
        }

        if (!title)
        {
            return (
                <Page className="master-entity">
                <PageHeader>
                    <div className="page-header-child">
                        Please select the entities that you wish to view
                    </div>
                </PageHeader>
                <PageBody className="master-entity-body">
                    {entityCommandBar}
                    {entitySources}
                </PageBody>
            </Page>);
        }

        return (
            <Page className="master-entity">
                <PageHeader>
                    {title}
                </PageHeader>
                <PageBody className="master-entity-body">
                    {entityCommandBar}
                    {entitySources}
                </PageBody>
            </Page>
        );
    }
}

export {
    MultipleMasterEntity as default,
    MultipleMasterEntity,
    IMultipleMasterEntityProps,
    MultipleMasterEntityPersonTitle,
    MasterEntityOrgTitle
};