import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    ColumnActionsMode,
    Selection,
    SelectionMode,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import ISortModel from "common/ISortModel";
import IListModel from "common/IListModel";
import { ISelection } from "office-ui-fabric-react/lib/Selection";
import {IMasterEntityModel} from "../IMasterEntityModel";


const Columns : IColumn[] = [
    {
        key: "masterEntityId",
        ariaLabel: "Entity ID",
        name: "Master Entity ID",
        fieldName: "masterEntityId",
        columnActionsMode:ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 40,
        maxWidth: 100
    },
    {
        key: "firstName",
        ariaLabel: "First Name",
        name: "First Name",
        fieldName: "firstName",
        columnActionsMode:ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 40,
        maxWidth: 100,
        data: {
            getText: (item : IMasterEntityModel) => {
                return item.name.firstName;
            }
        },
        onRender: (item :  IMasterEntityModel) => {
            return item.name.firstName;
        }
    },
    {
        key: "familyName",
        ariaLabel: "Family Name",
        name: "Family Name",
        fieldName: "familyName",
        columnActionsMode:ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 40,
        maxWidth: 100,
        data: {
            getText: (item : IMasterEntityModel) => {
                return item.name.familyName;
            }
        },
        onRender: (item :  IMasterEntityModel) => {
            return item.name.familyName;
        }
    },
    {
        key: "name",
        ariaLabel: "Name",
        name: "Organisation Name",
        fieldName: "organisationName",
        columnActionsMode:ColumnActionsMode.clickable,
        isResizable: true,
        minWidth: 40,
        maxWidth: 100,
        data: {
            getText: (item : IMasterEntityModel) => {
                return item.name.organisationName;
            }
        },
        onRender: (item :  IMasterEntityModel) => {
            return item.name.organisationName;
        }
    }
];


interface IMultipleMasterEntityDetailsListViewProps {
    list: IListModel<IMasterEntityModel>;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    rowSelectionListener?: (selection : ISelection) => void;
}

@observer
class MultipleMasterEntityDetailListView extends React.Component<IMultipleMasterEntityDetailsListViewProps, any> {

    private _selection : Selection;
    constructor(props : IMultipleMasterEntityDetailsListViewProps) {
        super(props);
        this._selection = new Selection({
            onSelectionChanged: this._handleSelectionChange
        });
    }

    private getKey(_item, _number) {
    }

    private _handleSelectionChange = () => {
        let listener = this.props.rowSelectionListener;
        if (listener) {
            listener(this._selection);
        }
    }

    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.sort) {
            this.props.sort.toggleSort(column.fieldName);
        }
    }


    private _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        e.stopPropagation();
        const items = this._selection.getItems();
        if(items.length > 0) {
            const transferData = {
                type: "Entity",
                items: this._selection.getSelection()
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
    }

    private _onRenderRow = (props : IDetailsRowProps) => {
        return (
            <div draggable={true} onDragStart={this._handleDragStart}>
                <DetailsRow {...props} />
            </div>
        );
    }

    render() {
        const columns = ColumnSortHelper.applySort(Columns, this.props.sort);

        return (
            <div className="multiple-entity-summary-list-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                                items={this.props.list.items}
                                selection={this._selection}
                                selectionMode={SelectionMode.multiple}
                                onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                layoutMode={DetailsListLayoutMode.fixedColumns}
                                constrainMode={ConstrainMode.unconstrained}
                                onRenderRow={this._onRenderRow}
                                checkboxVisibility={CheckboxVisibility.onHover} />

            </div>
        );

    }
}

export{ MultipleMasterEntityDetailListView as default, MultipleMasterEntityDetailListView, Columns };
