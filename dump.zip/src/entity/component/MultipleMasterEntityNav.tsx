import * as React from "react";
import { observer } from "mobx-react";
import { Nav, INavLink } from "office-ui-fabric-react/lib/Nav";
import AppStore from "app/AppStore";
import IMultipleMasterEntityListCompositeModel from "../IMultipleMasterEntityListCompositeModel";
import MasterEntitySearchRoute from "../MasterEntitySearchRoute";
import MasterEntitySearchResultRoute from "../MasterEntitySearchResultRoute";
import MasterEntityRoute from "../MasterEntityRoute";

interface IMasterEntityNavProps {

    multipleMasterEntityList?: IMultipleMasterEntityListCompositeModel;
}

@observer
class MultipleMasterEntityNav extends React.Component<any, any> {
    render() {
        const links : INavLink[] = [];
        links.push({
            key: MasterEntitySearchRoute.key,
            name: "Search",
            url: AppStore.createUrl({ path: MasterEntitySearchRoute.path }),
            onClick: (e : React.MouseEvent<HTMLElement>) => {
                e.preventDefault();
                AppStore.open({ path: MasterEntitySearchRoute.path })
            }
        });

        links.push({
            key: MasterEntitySearchResultRoute.key,
            name: "Search Results",
            url: AppStore.createUrl({ path: MasterEntitySearchResultRoute.path }),
            onClick: (e : React.MouseEvent<HTMLElement>) => {
                e.preventDefault();
                AppStore.open({ path: MasterEntitySearchResultRoute.path })
            }
        });

        if(this.props.multipleMasterEntityList && this.props.multipleMasterEntityList.requestedMasterEntityId) {
            let subLinks : INavLink[];
            let name;

            if(this.props.multipleMasterEntityList.sync.syncing) {
                name = "Loading...";
            } else if(this.props.multipleMasterEntityList.sync.error) {
                name = "Error";
            } else if (!this.props.multipleMasterEntityList.items) {
                name = "No enetities";
            } else {
                const firstElement = this.props.multipleMasterEntityList.items.items[0];

                // const e = this.props.multipleMasterEntityList.ref;
                name = firstElement.name.standardFullName;

                if(firstElement.sources.length > 0) {
                    subLinks = [];
                    firstElement.sources.forEach((s) => {
                        subLinks.push({
                            key: s.sourceSystemCode,
                            name: s.sourceSystemCode,
                            url: `#${s.sourceSystemCode}`
                        });
                    });
                }
            }

            const path = MasterEntityRoute.pathTemplate.toPath({ masterEntityId: this.props.multipleMasterEntityList.requestedMasterEntityId });
            links.push({
                key: MasterEntityRoute.key,
                name: name,
                url: AppStore.createUrl({ path: path }),
                onClick: (e : React.MouseEvent<HTMLElement>) => {
                    e.preventDefault();
                    AppStore.open({ path: path })
                },
                links: subLinks,
                isExpanded: subLinks && subLinks.length > 0 ? true : false
            });
        }

        const selectedKey = AppStore.activeRoute ? AppStore.activeRoute.key : undefined;

        return (
            <Nav groups={[
                {
                    name: "Master Entity",
                    links: links
                }
            ]} selectedKey={selectedKey} />
        );
    }
}

export { MultipleMasterEntityNav as default, MultipleMasterEntityNav };