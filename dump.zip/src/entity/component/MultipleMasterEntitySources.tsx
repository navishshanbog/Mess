import * as React from "react";
import { observer } from "mobx-react";
import IMultipleMasterEntityListCompositeModel from "../IMultipleMasterEntityListCompositeModel";
import WidgetContext from "widget/WidgetContext";
import WidgetContextView from "widget/component/WidgetContext";
import MultipleMasterEntitySourceWidgetEntries from "../MultipleMasterEntitySourceWidgetEntries";
import * as KeyedItemHelper from "common/KeyedItemHelper";
import ContainerEntries from "widget/ContainerEntries";
import * as ABRConstants from "abr/ABRConstants";
import * as EROLLConstants from "eroll/EROLLConstants";
import * as ASICConstants from "asic/ASICConstants";
import * as IATConstants from "iat/IATConstants";
import * as CargoConstants from "cargo/CargoConstants";
import * as DGMSConstants from "dgms/DGMSConstants";
import * as BAGSConstants from "bags/BAGSConstants";


interface IMultipleMasterEntitySourcesProps {
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
}

@observer
class MultipleMasterEntitySources extends React.Component<IMultipleMasterEntitySourcesProps, any> {
    private _sourceDashboard : WidgetContext;
    constructor(props : IMultipleMasterEntitySourcesProps) {
        super(props);
        this._sourceDashboard = new WidgetContext();
        this._sourceDashboard.setConfig({ noRemove: true, noRemoveChild: true, noAdd: true, noEdit: true });
    }

    _refreshDashboard(masterEntity : IMultipleMasterEntityListCompositeModel) {
        const sourceWidgets : WidgetContext[] = [];

        // could do with s loop over MultipleMasterEntitySourceWidgetEntries
        // handle EROLL
        const erollSourceCode = EROLLConstants.sourceSystemCode + "-multiple";
        const erollWidget = KeyedItemHelper.getItem(MultipleMasterEntitySourceWidgetEntries, erollSourceCode);

        if (erollWidget) {
            const w = new WidgetContext();
            w.setProps({multipleMasterEntity: this.props.multipleMasterEntity});
            w.setEntry(erollWidget);
            w.setName(erollWidget.shortName);
            w.setDescription(erollWidget.description);
            sourceWidgets.push(w);
        }

        // handle abr
        const abrSourceCode = ABRConstants.sourceSystemCode + "-multiple";
        const abrWidget = KeyedItemHelper.getItem(MultipleMasterEntitySourceWidgetEntries, abrSourceCode);

        if (abrWidget) {
            const w = new WidgetContext();
            w.setProps({multipleMasterEntity: this.props.multipleMasterEntity });
            w.setEntry(abrWidget);
            w.setName(abrWidget.shortName);
            w.setDescription(abrWidget.description);
            sourceWidgets.push(w);
        }

        // handle IAT
        // const iatSourceCode = "IAT";
        const iatSourceCode = IATConstants.sourceSystemCode + "-multiple";
        const iatWidget = KeyedItemHelper.getItem(MultipleMasterEntitySourceWidgetEntries, iatSourceCode);

        if (iatWidget) {
            const w = new WidgetContext();
            w.setProps({multipleMasterEntity: this.props.multipleMasterEntity});
            w.setEntry(iatWidget);
            w.setName(iatWidget.shortName);
            w.setDescription(iatWidget.description);
            sourceWidgets.push(w);
        }


        // handle ASIC
        const asicSourceCode = ASICConstants.sourceSystemCode + "-multiple";
        const asicWidget = KeyedItemHelper.getItem(MultipleMasterEntitySourceWidgetEntries, asicSourceCode);

        if (asicWidget) {
            const w = new WidgetContext();
            w.setProps({multipleMasterEntity: this.props.multipleMasterEntity});
            w.setEntry(asicWidget);
            w.setName(asicWidget.shortName);
            w.setDescription(asicWidget.description);
            sourceWidgets.push(w);
        }

        // handle Cargo
        const cargoSourceCode = CargoConstants.sourceSystemCode + "-multiple";
        const cargoWidget = KeyedItemHelper.getItem(MultipleMasterEntitySourceWidgetEntries, cargoSourceCode);

        if (cargoWidget) {
            const w = new WidgetContext();
            w.setProps({multipleMasterEntity: this.props.multipleMasterEntity});
            w.setEntry(cargoWidget);
            w.setName(cargoWidget.shortName);
            w.setDescription(cargoWidget.description);
            sourceWidgets.push(w);
        }

        // handle BAGS
        const bagsSourceCode = BAGSConstants.sourceSystemCode + "-multiple";
        const bagsWidget = KeyedItemHelper.getItem(MultipleMasterEntitySourceWidgetEntries, bagsSourceCode);

        if (bagsWidget) {
            const w = new WidgetContext();
            w.setProps({multipleMasterEntity: this.props.multipleMasterEntity});
            w.setEntry(bagsWidget);
            w.setName(bagsWidget.shortName);
            w.setDescription(bagsWidget.description);
            sourceWidgets.push(w);
        }

        // handle DGMS
        const dgmsSourceCode = DGMSConstants.sourceSystemCode + "-multiple";
        const dgmsWidget = KeyedItemHelper.getItem(MultipleMasterEntitySourceWidgetEntries, dgmsSourceCode);

        if (dgmsWidget) {
            const w = new WidgetContext();
            w.setProps({multipleMasterEntity: this.props.multipleMasterEntity});
            w.setEntry(dgmsWidget);
            w.setName(dgmsWidget.shortName);
            w.setDescription(dgmsWidget.description);
            sourceWidgets.push(w);
        }

        this._sourceDashboard.setChildren(sourceWidgets);
        this._sourceDashboard.setEntry(ContainerEntries[0]);
    }

    componentWillMount() {
        this._refreshDashboard(this.props.multipleMasterEntity);
    }
    componentWillReceiveProps(nextProps : IMultipleMasterEntitySourcesProps) {
        this._refreshDashboard(nextProps.multipleMasterEntity);
    }


    render() {
        return <WidgetContextView context={this._sourceDashboard} />
    }

}

export { MultipleMasterEntitySources as default, MultipleMasterEntitySources };