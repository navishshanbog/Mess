import Context from "common/Context";
import IEntityPhotosService from "./IEntityPhotosService";
import RestEntityPhotosService from "./RestEntityPhotosService";

const EntityPhotosServiceContext = new Context<IEntityPhotosService>({
    ref: new RestEntityPhotosService()
});

export { EntityPhotosServiceContext as default, EntityPhotosServiceContext };