import EntityPhotosModel from "./EntityPhotosModel";

const EntityPhotosStore = new EntityPhotosModel();

export { EntityPhotosStore as default, EntityPhotosStore };


