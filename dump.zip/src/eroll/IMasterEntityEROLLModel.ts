import IMasterEntityRefModel from "entity/IMasterEntityRefModel";

interface IMasterEntityEROLLModel extends IMasterEntityRefModel {

}

export { IMasterEntityEROLLModel as default, IMasterEntityEROLLModel }