import MasterEntityRefModel from "entity/MasterEntityRefModel";
import IMasterEntityEROLLModel from "./IMasterEntityEROLLModel";

class MasterEntityEROLLModel extends MasterEntityRefModel implements IMasterEntityEROLLModel {

}

export { MasterEntityEROLLModel as default, MasterEntityEROLLModel }