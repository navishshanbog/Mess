import * as React from "react";
import IWidgetContext from "widget/IWidgetContext";
import MasterEntityEROLL from "./component/MasterEntityEROLL";
import AbstractMasterEntityWidget from "entity/AbstractMasterEntityWidget";
import MasterEntityEROLLModel from "./MasterEntityEROLLModel";

class MasterEntityEROLLWidget extends AbstractMasterEntityWidget {
    model: IWidgetContext;
    private _eroll = new MasterEntityEROLLModel();
    get masterEntityRef() {
        return this._eroll;
    }
    _setView() {
        this.context.setView(<MasterEntityEROLL eroll={this._eroll} />);
    }
}

export { MasterEntityEROLLWidget as default, MasterEntityEROLLWidget }