import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as EROLLConstants from "./EROLLConstants";
import { EROLL } from "icon/AnalystDesktopIcons";

const MasterEntityEROLLWidgetEntry : IWidgetEntry = {
    key: "masterEntityEROLLSummary",
    keyAliases: [EROLLConstants.sourceSystemCode],
    name: "Master Entity EROLL Summary",
    shortName: "EROLL",
    sourceSystemCode: EROLLConstants.sourceSystemCode,
    description: "Master Entity EROLL Summary",
    icon: <EROLL />,
    largeIcon: <EROLL />,
    get widgetType() {
        return import("./MasterEntityEROLLWidget").then(r => r.default);
    }
};

export { MasterEntityEROLLWidgetEntry as default, MasterEntityEROLLWidgetEntry };