import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as EROLLConstants from "./EROLLConstants";
import { EROLL } from "icon/AnalystDesktopIcons";

const MultipleMasterEntityEROLLWidgetEntry : IWidgetEntry = {
    key: "masterEntityEROLLSummary",
    keyAliases: [EROLLConstants.sourceSystemCode + "-multiple"],
    name: "Master Entity EROLL Summary",
    shortName: "EROLL",
    description: "Master Entity EROLL Summary",
    icon: <EROLL />,
    largeIcon: <EROLL />,
    get widgetType() {
        return import("./MultipleMasterEntityEROLLWidget").then(r => r.default);
    }
};

export { MultipleMasterEntityEROLLWidgetEntry as default, MultipleMasterEntityEROLLWidgetEntry };