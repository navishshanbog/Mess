import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import * as EROLLConstants from "../EROLLConstants";
import IMasterEntityEROLLModel from "../IMasterEntityEROLLModel";

interface IMasterEntityEROLLProps {
    eroll: IMasterEntityEROLLModel;
}

@observer
class MasterEntityEROLL extends React.Component<IMasterEntityEROLLProps, any> {
    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[EROLLConstants.sourceSystemCode];
        if(source) {
            return (
                <div className="master-entity-asic-summary">
                    <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No EROLL information available</MessageBar>;
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the EROLL summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.eroll}
                                    onRenderContent={this._handleRenderContent}
                                    onRenderNotLoaded={this._handleRenderNotLoaded} />;
    }
}

export { 
    MasterEntityEROLL as default,
    MasterEntityEROLL,
    IMasterEntityEROLLProps
}