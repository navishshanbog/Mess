import * as React from "react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import * as EROLLConstants from "../EROLLConstants";
import IMasterEntityModel from "entity/IMasterEntityModel";
import {IMultipleMasterEntityListCompositeModel} from "../../entity/IMultipleMasterEntityListCompositeModel";

interface IMasterEntityEROLLSummaryProps {
    multipleMasterEntity: IMultipleMasterEntityListCompositeModel;
}

class MultipleMasterEntityEROLLSummary extends React.Component<IMasterEntityEROLLSummaryProps, any> {

    render() {

        let source = [];
        if (this.props.multipleMasterEntity.getSelection() && this.props.multipleMasterEntity.getSelection().getSelection()) {

            source = (this.props.multipleMasterEntity.getSelection().getSelection() as IMasterEntityModel[]).map((item : IMasterEntityModel, index) => {

                    let sourceEntry = item.sourceMap[EROLLConstants.sourceSystemCode];
                    return <EntityAttributes key={index} entity={sourceEntry} position={index+1} type={EntityAttributesType.secondary} />;
            });
        }

        if(source) {
            return (
                <div className="master-entity-eroll-summary">
                    {source}
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No EROLL information available</MessageBar>;
    }
}

export {
    MultipleMasterEntityEROLLSummary as default
}