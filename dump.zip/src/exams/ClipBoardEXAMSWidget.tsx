import * as React from "react";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import AppClipboardGroup from "clipboard/component/AppClipboardGroup";
import EXAMSActivityList from "./component/EXAMSActivityList";

class ClipBoardEXAMSWidget implements IWidget {
    context: IWidgetContext;
    start() {
        this.context.setView(
            <AppClipboardGroup clipboardGroup={this.context.props.clipboardGroup}>
                <EXAMSActivityList list={this.context.props.clipboardGroup.containerItems} customClipboardRowAndHeader={true} sort={this.context.props.clipboardGroup.sort}/>
            </AppClipboardGroup>
        );
    }
}

export { ClipBoardEXAMSWidget as default, ClipBoardEXAMSWidget }
