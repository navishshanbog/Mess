import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import { EXAMS } from "icon/AnalystDesktopIcons";
import * as EXAMSConstants from "./EXAMSConstants";

const ClipBoardEXAMSWidgetEntry : IWidgetEntry = {
    key: "ClipBoardEXAMSSummary",
    keyAliases: [EXAMSConstants.sourceSystemCode],
    name: "ClipBoard EXAMS Summary",
    description: "ClipBoard EXAMS Summary",
    icon: <EXAMS />,
    largeIcon: <EXAMS />,
    get widgetType() {
        return import("./ClipBoardEXAMSWidget").then(r => r.default);
    }
};

export { ClipBoardEXAMSWidgetEntry as default, ClipBoardEXAMSWidgetEntry };
