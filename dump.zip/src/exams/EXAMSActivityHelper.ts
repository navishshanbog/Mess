import { action } from "mobx";
import IActivityFilter from "common/IActivityFilter";
import IEXAMSActivity from "./IEXAMSActivity";
import IListModel from "common/IListModel";
import IListResult from "common/IListResult";
import ISort from "common/ISort";
import * as StringUtils from "util/String";
import * as SearchUtils from "util/Search";
import * as SortUtils from "util/Sort";
import * as moment from "moment";
import * as DateUtils from "util/Date";
import * as ColumnTextHelper from "common/component/ColumnTextHelper";
import { EXAMSActivityColumns, CurrentDate } from "./component/EXAMSActivityColumns";
import EXAMSServiceContext from "./EXAMSServiceContext";
import * as  EXAMSConstants from "./EXAMSConstants";
import { IEXAMSActivityGetRequest } from "./IEXAMSService";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IMasterEntitySource from "entity/IMasterEntitySource";
import { Data as DateDataFormats } from "common/DateFormats";

const textFilterItemImpl = (item: IEXAMSActivity, text: string) => {
    return SearchUtils.containsText(ColumnTextHelper.getRowText(item, EXAMSActivityColumns), text);
};

const textFilterItem = (item: IEXAMSActivity, text: string) => {
    return StringUtils.isNotBlank(text) ? textFilterItemImpl(item, text) : true;
};

const textFilter = (items: IEXAMSActivity[], text: string) => {
    return items && StringUtils.isNotBlank(text) ?
        items.filter(item => textFilterItemImpl(item, text)) : items;
};

const fromFilterItem = (item: IEXAMSActivity, from : moment.Moment) => {
    return DateUtils.isMomentAfter(DateUtils.momentFromDataText(item.currentDate), from);
};

const toFilterItem = (item: IEXAMSActivity, to: moment.Moment) => {
    return DateUtils.isMomentBefore(DateUtils.momentFromDataText(item.currentDate), to);
};

const rangeFilterItem = (item: IEXAMSActivity, from: moment.Moment, to: moment.Moment) => {
    return fromFilterItem(item, from) && toFilterItem(item, to);
};

const rangeFilter = (items: IEXAMSActivity[], from: moment.Moment, to: moment.Moment) => {
    return items ? items.filter(item => rangeFilterItem(item, from, to)) : items;
};

const filter = (items : IEXAMSActivity[], activityFilter : IActivityFilter) => {
    return activityFilter ? rangeFilter(textFilter(items, activityFilter.filterText), activityFilter.filterFromDate, activityFilter.filterToDate) : items;
};

const toSortValue = (item : IEXAMSActivity, field: string) => {
    if(item) {
        if(field === CurrentDate.fieldName) {
            return DateUtils.dateFromDataText(item.currentDate);
        }
        return item[field];
    }
};

const compare = (a : IEXAMSActivity, b : IEXAMSActivity, sort : ISort) => {
    let r = SortUtils.compare(toSortValue(a, sort.field), toSortValue(b, sort.field));
    if(sort.descending) {
        r = 0 - r;
    }
    return r;
};

const sort = (items: IEXAMSActivity[], sort: ISort) => {
    return items && sort && StringUtils.isNotBlank(sort.field) ? items.sort((a, b) => compare(a, b, sort)) : items;
};

const getForMasterEntity = (masterEntity : IMasterEntityModel) : Promise<IListResult<IEXAMSActivity>> => {
    const source = masterEntity.sourceMap[EXAMSConstants.sourceSystemCode];
    return source ? EXAMSServiceContext.ref.getEXAMSActivities({ masterEntityID: masterEntity.masterEntityId }) : Promise.resolve({ total: 0, items: [] });
};

const loadForMasterEntityDone = action((list: IListModel<IEXAMSActivity>, result: IListResult<IEXAMSActivity>) => {
    const items = result ? result.items : [];
    const total = result ? result.total : undefined;
    list.setItems(items, total);
});

const loadForMasterEntityError = action((list:  IListModel<IEXAMSActivity>, error : any) => {
    list.sync.syncError(error);
});

const loadForMasterEntity = action((list:  IListModel<IEXAMSActivity>, masterEntity: IMasterEntityModel) : Promise<any> => {
    const syncId = masterEntity.masterEntityId;
    if(syncId !== list.sync.id) {
        list.sync.syncStart({ id: syncId });
        return getForMasterEntity(masterEntity).then((result) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityDone(list, result);
            }
        }).catch((error) => {
            if(syncId === list.sync.id) {
                loadForMasterEntityError(list, error);
            }
        });
    }
    return Promise.resolve();
});

export {
    textFilterItem,
    textFilter,
    fromFilterItem,
    toFilterItem,
    rangeFilterItem,
    rangeFilter,
    filter,
    compare,
    toSortValue,
    sort,
    getForMasterEntity,
    loadForMasterEntity
};