import Context from "common/Context";
import IEXAMSService from "./IEXAMSService";
import RestEXAMSService from "./RestEXAMSService";

const EXAMSServiceContext = new Context<IEXAMSService>({
    ref: new RestEXAMSService()
});

export { EXAMSServiceContext as default, EXAMSServiceContext };