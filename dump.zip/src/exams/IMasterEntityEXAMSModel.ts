import IMasterEntityRefModel from "entity/IMasterEntityRefModel";
import IActivityListModel from "common/IActivityListModel";
import IEXAMSActivity from "./IEXAMSActivity";

interface IMasterEntityEXAMSModel extends IMasterEntityRefModel {
    activityList: IActivityListModel<IEXAMSActivity>;
}

export { IMasterEntityEXAMSModel as default, IMasterEntityEXAMSModel }