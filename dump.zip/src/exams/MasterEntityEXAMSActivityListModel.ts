import { observable, action, computed } from "mobx";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IEXAMSActivity from "./IEXAMSActivity";
import ActivityListModel from "common/ActivityListModel";
import * as EXAMSActivityHelper from "./EXAMSActivityHelper";

class MasterEntityEXAMSActivityListModel extends ActivityListModel<IEXAMSActivity> {
    @observable masterEntity: IMasterEntityModel;

    @action
    setMasterEntity(masterEntity: IMasterEntityModel) : void {
        if(masterEntity !== this.masterEntity) {
            this.masterEntity = masterEntity;
            if(masterEntity) {
                this.filter.clear();
                EXAMSActivityHelper.loadForMasterEntity(this, this.masterEntity);
            } else {
                this.clear();
            }
        }
    }

    @computed
    get itemsView() {
        const r = this.masterEntity ? 
            EXAMSActivityHelper.filter(EXAMSActivityHelper.filter(this.items, this.masterEntity.activityFilter), this.filter) :
            this.items.slice(0);
        return EXAMSActivityHelper.sort(r, this.sort);
    }   
}

export { MasterEntityEXAMSActivityListModel as default, MasterEntityEXAMSActivityListModel }