import { observable, action } from "mobx";
import MasterEntityRefModel from "entity/MasterEntityRefModel";
import IMasterEntityEXAMSModel from "./IMasterEntityEXAMSModel";
import MasterEntityEXAMSActivityListModel from "./MasterEntityEXAMSActivityListModel";
import { sourceSystemCode } from "./EXAMSConstants";

class MasterEntityEXAMSModel extends MasterEntityRefModel implements IMasterEntityEXAMSModel {
    @observable activityList = new MasterEntityEXAMSActivityListModel();

    @action
    setRef(ref) {
        super.setRef(ref);
        if(ref) {
            // NOTE: this is a temporary approach to fixing the source system caching issue
            // In reality - these 'MasterEntity<Source>Model' types aren't actually needed
            const source = ref.sourceMap[sourceSystemCode];
            if(source) {
                let activityList : MasterEntityEXAMSActivityListModel = source.rel.activityList;
                if(!activityList) {
                    activityList = new MasterEntityEXAMSActivityListModel();
                    source.setRel({ activityList: activityList });
                }
                this.activityList = activityList;
                return activityList.setMasterEntity(ref);
            }
        }
    }
}

export { MasterEntityEXAMSModel as default, MasterEntityEXAMSModel }