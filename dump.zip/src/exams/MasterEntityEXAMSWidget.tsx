import * as React from "react";
import AbstractMasterEntityWidget from "entity/AbstractMasterEntityWidget";
import IWidget from "widget/IWidget";
import IWidgetContext from "widget/IWidgetContext";
import IMasterEntityModel from "entity/IMasterEntityModel";
import MasterEntityEXAMS from "./component/MasterEntityEXAMS";
import MasterEntityEXAMSModel from "./MasterEntityEXAMSModel";

class MasterEntityEXAMSWidget extends AbstractMasterEntityWidget {
    private _exams = new MasterEntityEXAMSModel();
    protected get masterEntityRef() {
        return this._exams;
    }
    _setView() {
        this.context.setView(<MasterEntityEXAMS exams={this._exams} />);
    }
}

export { MasterEntityEXAMSWidget as default, MasterEntityEXAMSWidget }
