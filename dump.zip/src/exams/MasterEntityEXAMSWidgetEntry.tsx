import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as EXAMSConstants from "./EXAMSConstants";
import { EXAMS } from "icon/AnalystDesktopIcons";

const MasterEntityEXAMSWidgetEntry : IWidgetEntry = {
    key: "masterEntityEXAMSSummary",
    keyAliases: [EXAMSConstants.sourceSystemCode],
    name: "Master Entity EXAMS Summary",
    shortName: "EXAMS",
    sourceSystemCode: EXAMSConstants.sourceSystemCode,
    description: "Master Entity EXAMS Summary",
    icon: <EXAMS />,
    largeIcon: <EXAMS />,
    get widgetType() {
        return import("./MasterEntityEXAMSWidget").then(r => r.default);
    }
};

export { MasterEntityEXAMSWidgetEntry as default, MasterEntityEXAMSWidgetEntry };