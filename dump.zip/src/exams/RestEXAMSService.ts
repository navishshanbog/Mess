import axios from "axios";
import { IEXAMSService, IEXAMSActivityGetRequest } from "./IEXAMSService";
import IEXAMSActivity from "./IEXAMSActivity";
import IListResult from "common/IListResult";
import { AbstractRestDataService, NoResultErrorCode } from "common/AbstractRestDataService";

const DEFAULT_MAX_NO_RECORDS = 2000;

interface GetExamsRestResponse {
    errors?: any;
    CargoExamsSummaryResponse?: IEXAMSActivity[];
    total?: number;
}

class RestEXAMSService extends AbstractRestDataService implements IEXAMSService {
    getEXAMSActivities(request : IEXAMSActivityGetRequest) : Promise<IListResult<IEXAMSActivity>> {
        const internalRequest = Object.assign({}, request);
        if(isNaN(internalRequest.maxNumberOfRecords) || internalRequest.maxNumberOfRecords <= 0) {
            internalRequest.maxNumberOfRecords = DEFAULT_MAX_NO_RECORDS;
        }
        return axios.post(`${this.config.baseUrl}/CargoExamsService/resources/CargoExamsSummary`, internalRequest).then((value) => {
            const response = value.data as GetExamsRestResponse;
            if(response.errors) {
                if(response.errors.code !== NoResultErrorCode) {
                   throw response.errors;
                }
                return { items: [], total: 0 };
            }
            return { items: response.CargoExamsSummaryResponse, total: response.total };
        });
    }
}

export { RestEXAMSService as default, RestEXAMSService }