import * as React from "react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { IEXAMSDragAndDrop }  from "./MasterEntityEXAMS";
import ListContainer from "common/component/ListContainer";
import ListTotal from "common/component/ListTotal";
import Details from "common/component/Details";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import IEXAMSActivity from "../IEXAMSActivity";
import EXAMSActivityListDetailView from "./EXAMSActivityListDetailView";
import IActivityFilterModel from "common/IActivityFilterModel";
import * as ActivityFilterMenuHelper from "common/component/ActivityFilterMenuHelper";

interface IEXAMSActivityListProps {
    list: IListModel<IEXAMSActivity>;
    filter?: IActivityFilterModel;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:IEXAMSDragAndDrop) => void;
    customClipboardRowAndHeader?: boolean;
}

class EXAMSActivityListCommandBar extends React.Component<IEXAMSActivityListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.filter) {
            items.push(ActivityFilterMenuHelper.createActivityFilterItem(this.props.filter));
        }
        if(items.length > 0) {
            return <CommandBar className="exams-activity-list-command-bar" items={items} />;
        }
        return null;
    }
}

class EXAMSActivityList extends React.Component<IEXAMSActivityListProps, any> {
    _handleRenderItems = (items : IEXAMSActivity[]) => {
        return <EXAMSActivityListDetailView
            items={items}
            sort={this.props.sort}
            customClipboardRowAndHeader = {this.props.customClipboardRowAndHeader}
            enableRowSelection={this.props.enableRowSelection}
            onItemsDragStart={this.props.onItemsDragStart} />;
    }
    render() {
        return (
            <ListContainer className="exam-activity-list"
                            typeLabel="EXAMS Activities"
                            list={this.props.list}
                            onRenderItems={this._handleRenderItems} />
        );
    }
}

class EXAMSActivityListContainer extends React.Component<IEXAMSActivityListProps, any> {
     _handleOpenChange = (open) => {
        this.props.list.setVisible(open);
    }
    render() {
        return (
            <Details open={this.props.list.visible}
                    summary={<span>EXAMS Activities <ListTotal list={this.props.list} /></span>}
                    onOpenChange={this._handleOpenChange}
                    controlOnHeaderClick={true}>
                <EXAMSActivityListCommandBar {...this.props} />
                <EXAMSActivityList {...this.props} />
            </Details>
        );
    }
}

export { EXAMSActivityListContainer as default, EXAMSActivityListContainer, EXAMSActivityList, IEXAMSActivityListProps }