import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    ColumnActionsMode,
    Selection,
    SelectionMode,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import { action } from "mobx";
import IEXAMSActivity from "../IEXAMSActivity";
import EXAMSActivityColumns from "./EXAMSActivityColumns";
import { IEXAMSDragAndDrop }  from "./MasterEntityEXAMS";
import ISortModel from "common/ISortModel";
import * as EXAMSConstants from "../EXAMSConstants";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import { IconButton } from 'office-ui-fabric-react/lib/Button';
import {DetailsHeader} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import {IDetailsHeaderProps} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import * as EXAMSActivityHelper from "../EXAMSActivityHelper";
import "./EXAMSActivityListDetailView.scss";


interface IEXAMSActivityListDetailViewProps {
    items: IEXAMSActivity[];
    sort?: ISortModel;
    enableRowSelection?: boolean;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:IEXAMSDragAndDrop) => void;
    customClipboardRowAndHeader?: boolean;
}

const DefaultEXAMSActivityListDetailViewProps : IEXAMSActivityListDetailViewProps = {
    items: [],
    clipBoard: AppClipboardStore
};

@observer
class EXAMSActivityListDetailView extends React.Component<IEXAMSActivityListDetailViewProps, any> {
    private _selection: Selection;
    public static defaultProps = DefaultEXAMSActivityListDetailViewProps;
    constructor(props: IEXAMSActivityListDetailViewProps) {
        super(props);
        this._selection = new Selection({
        });
    }

    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.customClipboardRowAndHeader) {
            this.props.sort.toggleSort(column.fieldName);
            this.props.clipBoard.updateSortOrderForItems(EXAMSActivityHelper.sort(this.props.items, this.props.sort), EXAMSConstants.sourceSystemCode);
        } else  {
            this.props.sort.toggleSort(column.fieldName);
        }
    }

    private _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        let dragandDrop: IEXAMSDragAndDrop = {items: this._selection.getSelection() as IEXAMSActivity[], columnsToReport: EXAMSActivityColumns};
        this.props.onItemsDragStart(e, dragandDrop);
    }
    _removeRowFromSelection(item) {
        this.props.clipBoard.removeItemFromGroup(item, EXAMSConstants.sourceSystemCode);
    }
    private _onRenderRow = (props : IDetailsRowProps) => {
        var item = props.item;
        if(this.props.customClipboardRowAndHeader) {
            return (
                <div className="exams-custom-cb-row">
                    <div className="exams-custom-row-render-action">
                        <IconButton className="custom-action-red"
                                    iconProps={ { iconName: 'SkypeMinus' } }
                                    title='Delete'
                                    ariaLabel='Delete'
                                    onClick={this._removeRowFromSelection.bind(this, item)}/>
                    </div>
                    <div className="exams-custom-row">
                        <DetailsRow {...props} />
                    </div>
                </div>
            );
        }
        return (
            <div draggable={true} onDragStart={this._handleDragStart}>
                <DetailsRow {...props} />
            </div>
        );
    }
    _onRenderHeader = (props: IDetailsHeaderProps) =>{
        return (
            <div className="exams-custom-header">
                <DetailsHeader {...props} />
            </div>
        );
    }
    render() {
        // setup columns
        const columns = ColumnSortHelper.applySort(EXAMSActivityColumns, this.props.sort);
        return (
            <div className="exams-activity-list-detail-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                                items={this.props.items}
                                onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                layoutMode={DetailsListLayoutMode.fixedColumns}
                                constrainMode={ConstrainMode.unconstrained}
                                onRenderRow = {this._onRenderRow}
                                onRenderDetailsHeader = {this.props.customClipboardRowAndHeader ? this._onRenderHeader: undefined}
                                selection={this._selection}
                                selectionMode={SelectionMode.multiple}
                                checkboxVisibility={this.props.enableRowSelection ? CheckboxVisibility.onHover: CheckboxVisibility.hidden} />
            </div>
        );
    }
}

export {
    EXAMSActivityListDetailView as default,
    EXAMSActivityListDetailView,
    IEXAMSActivityListDetailViewProps
}
