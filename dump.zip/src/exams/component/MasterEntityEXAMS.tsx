import * as React from "react";
import { observer } from "mobx-react";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import Details from "common/component/Details";
import EXAMSActivityList from "./EXAMSActivityList";
import EXAMSActivityListDetailView from "./EXAMSActivityListDetailView";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import * as EXAMSConstants from "../EXAMSConstants";
import * as EXAMSActivityHelper from "../EXAMSActivityHelper";
import IMasterEntityRefModel from "entity/IMasterEntityRefModel";
import IMasterEntityModel from "entity/IMasterEntityModel";
import IEXAMSActivity from "../IEXAMSActivity";
import IMasterEntityEXAMSModel from "../IMasterEntityEXAMSModel";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import { action } from "mobx";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";

interface IMasterEntityEXAMSProps {
    exams?: IMasterEntityEXAMSModel;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
}

const DefaultEXAMSActivityListDetailViewProps : IMasterEntityEXAMSProps = {
    clipBoard: AppClipboardStore
};

interface IEXAMSDragAndDrop {
    items: IEXAMSActivity[];
    columnsToReport?: any[];
    entityModel?: IMasterEntityModel;
}


@observer
class MasterEntityEXAMS extends React.Component<IMasterEntityEXAMSProps, any> {
    public static defaultProps = DefaultEXAMSActivityListDetailViewProps;
    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, dragAndDrop?:IEXAMSDragAndDrop) => {
        e.stopPropagation();
        const entityRef = this.props.exams.ref;
        if(dragAndDrop.items.length > 0) {
            const transferData = {
                type: EXAMSConstants.sourceSystemCode,
                items: dragAndDrop.items,
                columns: dragAndDrop.columnsToReport
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            this.props.clipBoard.openClipboard();
            this.props.clipBoard.setDraggedEntity(entityRef);
        }), 10);
    }
    _handleRenderContent = (masterEntity) => {
        const source = masterEntity.sourceMap[EXAMSConstants.sourceSystemCode];
        if(source) {
            return (
                <div className="master-entity-exams">
                    <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                    <EXAMSActivityList list={this.props.exams.activityList}
                                       sort={this.props.exams.activityList.sort}
                                       filter={this.props.exams.activityList.filter}
                                       enableRowSelection={true}
                                       onItemsDragStart={this._handleItemsDragStart} />
                </div>
            );
        }
        return <MessageBar messageBarType={MessageBarType.warning}>No EXAMS summary information available</MessageBar>;
    }
    _handlerRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the EXAMS summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.exams}
                                        onRenderContent={this._handleRenderContent}
                                        onRenderNotLoaded={this._handlerRenderNotLoaded} />;
    }
}

export {
    MasterEntityEXAMS as default,
    MasterEntityEXAMS,
    IMasterEntityEXAMSProps,
    IEXAMSDragAndDrop
}