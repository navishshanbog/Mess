import * as React from "react";
import IWidgetEntry from "widget/IWidgetEntry";
import * as IATConstants from "./IATConstants";
import { IAT } from "icon/AnalystDesktopIcons";

const ClipBoardIATWidgetEntry : IWidgetEntry = {
    key: "clipBoardIATSummary",
    keyAliases: [IATConstants.sourceSystemCode],
    name: "ClipBoard IAT Summary",
    description: "ClipBoard IAT Summary",
    icon: <IAT />,
    largeIcon: <IAT />,
    get widgetType() {
        return import("./ClipBoardIATWidget").then(r => r.default);
    }
};

export { ClipBoardIATWidgetEntry as default, ClipBoardIATWidgetEntry };
