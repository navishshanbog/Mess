const sourceSystemCode = "IAT";

export { sourceSystemCode }