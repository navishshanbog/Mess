import { observable } from "mobx";
import { IObjectWithKey } from "office-ui-fabric-react/lib/DetailsList";
import IIATEntityActionsModel from "./IIATEntityActionsModel";

class IATEntityActionsModel implements IIATEntityActionsModel {
    @observable selectedItems: IObjectWithKey[] = [];
}

export { IATEntityActionsModel as default, IATEntityActionsModel };