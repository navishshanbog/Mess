import IATEntityActionsModel from "./IATEntityActionsModel";

const IATEntityActionsStore = new IATEntityActionsModel();

export { IATEntityActionsStore as default, IATEntityActionsStore };