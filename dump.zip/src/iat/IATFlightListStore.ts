import IATFlightListModel from "./IATFlightListModel";

const IATFlightListStore = new IATFlightListModel();

export { IATFlightListStore as default, IATFlightListStore };