import { IColumn } from "office-ui-fabric-react/lib/DetailsList";


const nisName : IColumn = {
    key: "nisName",
    ariaLabel: "NIS Name",
    name: "NIS Name",
    fieldName: "nisName",
    minWidth: 40
};

const givenNames : IColumn = {
    key: "givenNames",
    ariaLabel: "Given Names",
    name: "Given Names",
    fieldName: "givenNames",
    minWidth: 40
};

const familyName : IColumn = {
    key: "familyName",
    ariaLabel: "Family Name",
    name: "Family Name",
    fieldName: "familyName",
    minWidth: 40
};

const gender : IColumn = {
    key: "sexCode",
    ariaLabel: "Gender",
    name: "Gender",
    fieldName: "sexCode",
    minWidth: 40
};

const birthDate : IColumn = {
    key: "birthDate",
    ariaLabel: "Date of Birth",
    name: "Date of Birth",
    fieldName: "birthDate",
    minWidth: 40
};


const travelDocumentId : IColumn = {
    key: "travelDocumentId",
    ariaLabel: "Passport",
    name: "Passport",
    fieldName: "travelDocumentId",
    minWidth: 40
};

const travelDocCountryCode : IColumn = {
    key: "travelDocCountryCode",
    ariaLabel: "Passport Country",
    name: "Passport Country",
    fieldName: "travelDocCountryCode",
    minWidth: 40
};

const movementRaceID : IColumn = {
    key: "movementRaceID",
    ariaLabel: "Race ID",
    name: "Race ID",
    fieldName: "movementRaceID",
    minWidth: 40
};

const movements : IColumn = {
    key: "movements",
    ariaLabel: "Movements",
    name: "Movements",
    fieldName: "movements",
    minWidth: 40
};



const IATAssociatedActivityColumns : IColumn[] = [
    nisName,
    givenNames,
    familyName,
    gender,
    birthDate,
    travelDocumentId,
    travelDocCountryCode,
    movementRaceID,
    movements
];

export {IATAssociatedActivityColumns as default, IATAssociatedActivityColumns}