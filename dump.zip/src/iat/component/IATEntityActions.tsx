import * as React from "react";
import { observer } from "mobx-react";
import { DefaultButton, IButtonProps } from 'office-ui-fabric-react/lib/Button';
import IMasterEntityModel from "entity/IMasterEntityModel";
import IATMovementDetailStore from "../IATMovementDetailStore";
import IATMovementDetails from "./IATMovementDetail";
import IATMovementAliases from "./IATMovementAliases";
import IIATEntityActionsModel from "../IIATEntityActionsModel";
import IATMovementAliasesStore from "../IATMovementAliasesStore";
import IATFlightListStore from "../IATFlightListStore";
import IATFlightList from "./IATFlightList";
import IIATMovement from "../IIATMovement";
import * as IATConstants from "../IATConstants";
import "./IATEntitySummary.scss";
import { css } from "office-ui-fabric-react/lib/Utilities";

interface IIATEntityActionsProps {
    masterEntity: IMasterEntityModel;
    model: IIATEntityActionsModel;
}

@observer
class IATEntityActions extends React.Component<IIATEntityActionsProps, any> {
    _handleMovementDetailsButtonClick = () => {
        IATMovementDetailStore.loadForMovement(this.props.model.selectedItems[0] as IIATMovement);
        IATMovementDetailStore.setVisible(true);
    }
    _handleAliasesButtonClick = () => {
        const iatSourceEntity = this.props.masterEntity.sourceMap[IATConstants.sourceSystemCode];
        if (iatSourceEntity) {
            IATMovementAliasesStore.loadForEntity(iatSourceEntity);
            IATMovementAliasesStore.setVisible(true);
        }
    }
    _handleFlightListButtonClick = () => {
        IATFlightListStore.loadForMovements(this.props.masterEntity, this.props.model.selectedItems as IIATMovement[]);
        IATFlightListStore.setVisible(true);
    }
    render() {
        let detailsPanel;
        let selectedMovementsSize = this.props.model.selectedItems ? this.props.model.selectedItems.length : 0;
        let aliasesButton = <DefaultButton iconProps={{iconName: 'PeopleAlert'}} text="Aliases" onClick={this._handleAliasesButtonClick}/>;
        let movementDetailsButton = <DefaultButton disabled={selectedMovementsSize != 1} iconProps={{iconName: 'ZoomIn'}}
                                                   text="Movement Details" onClick={this._handleMovementDetailsButtonClick}/>;
        let flightListButton = <DefaultButton disabled={selectedMovementsSize == 0} iconProps={{iconName: 'Airplane'}}
                                              text={"Flight List" + (selectedMovementsSize == 0 ? "" : ` (${selectedMovementsSize})`)}
                                              onClick={this._handleFlightListButtonClick}/>;
        if (IATMovementAliasesStore.visible) {
            detailsPanel = <IATMovementAliases model={IATMovementAliasesStore}/>;
        } else if (IATMovementDetailStore.visible) {
            detailsPanel = <IATMovementDetails model={IATMovementDetailStore}/>;
        } else if (IATFlightListStore.visible) {
            detailsPanel = <IATFlightList model={IATFlightListStore} masterEntity={this.props.masterEntity}/>;
        }
        return (
            <div className={css("iat-entity-actions")}>
                {aliasesButton}
                {movementDetailsButton}
                {flightListButton}
                {detailsPanel}
            </div>
        );
    }
}

export { IATEntityActions as default, IATEntityActions }