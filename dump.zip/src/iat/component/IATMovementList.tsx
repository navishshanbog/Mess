import * as React from "react";
import { observer } from "mobx-react";
import { IContextualMenuItem } from "office-ui-fabric-react/lib/ContextualMenu";
import { CommandBar } from "office-ui-fabric-react/lib/CommandBar";
import { ListContainer } from "common/component/ListContainer";
import ListTotal from "common/component/ListTotal";
import Details from "common/component/Details";
import IATMovementListDetailView from "./IATMovementListDetailView";
import IListModel from "common/IListModel";
import ISortModel from "common/ISortModel";
import IIATMovement from "../IIATMovement";
import { IObjectWithKey } from "office-ui-fabric-react/lib/Selection";
import IActivityFilterModel from "common/IActivityFilterModel";
import * as ActivityFilterMenuHelper from "common/component/ActivityFilterMenuHelper";
import "./IATMovementList.scss";
import IATMovementColumns from "./IATMovementColumns";
import { createViewPreferencesMenuItem } from "common/component/ViewPreferencesMenuItem";
import ViewPreferencesModel from "common/ViewPreferencesModel";
import IMasterEntityModel from "entity/IMasterEntityModel";
import { IIATDragAndDrop }  from "./MasterEntityIAT";


interface IIATMovementListProps {
    position? : number;
    list: IListModel<IIATMovement>;
    entityModel?: IMasterEntityModel;
    filter?: IActivityFilterModel;
    sort?: ISortModel;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:IIATDragAndDrop) => void;
    enableRowSelection?: boolean;
    rowSelectionListener?: (selectedItems: IObjectWithKey[]) => void;
    customClipboardRowAndHeader?: boolean;
}

class IATMovementListCommandBar extends React.Component<IIATMovementListProps, any> {
    render() {
        const items : IContextualMenuItem[] = [];
        if(this.props.filter) {
            items.push(ActivityFilterMenuHelper.createActivityFilterItem(this.props.filter));
        }
        if(items.length > 0) {
            return <CommandBar className="iat-movement-list-command-bar" items={items} farItems={[createViewPreferencesMenuItem(IATMovementsViewPrefsStore, IATMovementColumns)]} />;
        }
        return null;
    }
}

const IATMovementsViewPrefsStore = new ViewPreferencesModel();
IATMovementsViewPrefsStore.rootKey = "iatMovements";

@observer
class IATMovementList extends React.Component<IIATMovementListProps, any> {
    _handleRenderItems = (items : IIATMovement[]) => {
        let columns = IATMovementColumns.filter((column: any) => IATMovementsViewPrefsStore.isFieldVisible(column.key));
        return <IATMovementListDetailView
            columns={columns}
            items={items}
            entityModel={this.props.entityModel}
            sort={this.props.sort}
            customClipboardRowAndHeader = {this.props.customClipboardRowAndHeader}
            enableRowSelection={this.props.enableRowSelection} rowSelectionListener={this.props.rowSelectionListener}
            onItemsDragStart={this.props.onItemsDragStart} />;
    }
    render() {

        return (
            <ListContainer
                    className="iat-movement-list"
                    typeLabel="IAT Movements"
                    list={this.props.list}
                    onRenderItems={this._handleRenderItems} />
        );
    }
}

class IATMovementListContainer extends React.Component<IIATMovementListProps, any> {
    _handleOpenChange = (open) => {
        this.props.list.setVisible(open);
    }
    render() {
        let positionValue = "";
        if (this.props.position) {
            positionValue = "(" + this.props.position + ") ";
        }

        return (

            <Details open={this.props.list.visible}
                        summary={<span>{positionValue}IAT Movements <ListTotal list={this.props.list} /></span>}
                        onOpenChange={this._handleOpenChange}
                        controlOnHeaderClick={true}>
                <IATMovementListCommandBar {...this.props} />
                <IATMovementList {...this.props} />
            </Details>
        );
    }
}

export { IATMovementListContainer as default, IATMovementListContainer, IATMovementList }