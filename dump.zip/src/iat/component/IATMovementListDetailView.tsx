import * as React from "react";
import { observer } from "mobx-react";
import {
    DetailsList,
    DetailsListLayoutMode,
    ConstrainMode,
    CheckboxVisibility,
    IColumn,
    Selection,
    SelectionMode,
    DetailsRow,
    IDetailsRowProps
} from "office-ui-fabric-react/lib/DetailsList";
import IIATMovement from "../IIATMovement";
import IATMovementVisasStore from "../IATMovementVisasStore";
import IATMovementPassportsStore from "../IATMovementPassportsStore";
import IATMovementColumns from "./IATMovementColumns";
import * as ColumnSortHelper from "common/component/ColumnSortHelper";
import * as IATConstants from "../IATConstants";
import { action } from "mobx";
import IATMovementPassports from "./IATMovementPassports";
import IATMovementVisas from "./IATMovementVisas";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import ISortModel from "common/ISortModel";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import { IObjectWithKey } from "office-ui-fabric-react/lib/Selection";
import { IconButton } from 'office-ui-fabric-react/lib/Button';
import {DetailsHeader} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import {IDetailsHeaderProps} from "office-ui-fabric-react/lib/components/DetailsList/DetailsHeader";
import * as IATMovementHelper from "../IATMovementHelper";
import IMasterEntityModel from "entity/IMasterEntityModel";
import "./IATMovementListDetailView.scss";
import { IIATDragAndDrop }  from "./MasterEntityIAT";
import * as SortUtils from "util/Sort";

interface IIATMovementDetailsListViewProps {
    columns: IColumn[];
    items: IIATMovement[];
    entityModel?: IMasterEntityModel;
    sort?: ISortModel;
    enableRowSelection?: boolean;
    clipBoard?: IAppClipBoardModel;  // For individual testing if required
    rowSelectionListener?: (selectedItems : IObjectWithKey[]) => void;
    onItemsDragStart?: (e : React.DragEvent<HTMLElement>, dragAndDrop?:IIATDragAndDrop) => void;
    customClipboardRowAndHeader?: boolean;
}

const DefaultIATActivityListDetailViewProps : IIATMovementDetailsListViewProps = {
    columns: IATMovementColumns,
    clipBoard: AppClipboardStore,
    items: []
};

@observer
class IATMovementDetailListView extends React.Component<IIATMovementDetailsListViewProps, any> {
    private _selection : Selection;
    private entityModel?: IMasterEntityModel;

    public static defaultProps = DefaultIATActivityListDetailViewProps;
    constructor(props : IIATMovementDetailsListViewProps) {
        super(props);
        this._selection = new Selection({
            onSelectionChanged: () => {
                if (this.props.rowSelectionListener) {
                    this.props.rowSelectionListener(this._selection.getSelection());
                }
            }
        });
    }

    componentWillMount() {
        if (this.props.rowSelectionListener) {
            this.props.rowSelectionListener([] as IObjectWithKey[]);
        }
    }

    private getKey(_item, _number) {
    }

    private _handleColumnHeaderClick = (e : React.MouseEvent<HTMLElement>, column: IColumn) => {
        if(this.props.customClipboardRowAndHeader) {
            this.props.sort.toggleSort(column.fieldName);
            this.props.clipBoard.updateSortOrderForItems(SortUtils.sort(this.props.items, this.props.sort), IATConstants.sourceSystemCode);
        } else  {
            this.props.sort.toggleSort(column.fieldName);
        }
    }

    private _handleDragStart = (e : React.DragEvent<HTMLElement>) => {
        let dragandDrop: IIATDragAndDrop = {items: this._selection.getSelection() as IIATMovement[], columnsToReport: this.props.columns, entityModel:this.props.entityModel};
        this.props.onItemsDragStart(e, dragandDrop);

    }

    _removeRowFromSelection(item) {
        this.props.clipBoard.removeItemFromGroup(item, IATConstants.sourceSystemCode);
    }

    private _onRenderRow = (props : IDetailsRowProps) => {
        var item = props.item;
        if(this.props.customClipboardRowAndHeader) {
            return (
                <div className="iat-custom-cb-row">
                    <div className="iat-custom-row-render-action">
                        <IconButton className="custom-action-red"
                                    iconProps={ { iconName: 'SkypeMinus' } }
                                    title='Delete'
                                    ariaLabel='Delete'
                                    onClick={this._removeRowFromSelection.bind(this, item)}/>
                    </div>
                    <div className="iat-custom-row">
                        <DetailsRow {...props} />
                    </div>
                </div>
            );
        }
        return (
            <div draggable={true} onDragStart={this._handleDragStart}>
                <DetailsRow {...props} />
            </div>
        );
    }

    _onRenderHeader = (props: IDetailsHeaderProps) =>{
        return (
            <div className="iat-custom-header">
                <DetailsHeader {...props} />
            </div>
        );
    }

    render() {
        const columns = ColumnSortHelper.applySort(this.props.columns, this.props.sort);
        let detailsPanel;
        if (IATMovementPassportsStore.visible) {
            detailsPanel = <IATMovementPassports model={IATMovementPassportsStore}/>;
        }
        if (IATMovementVisasStore.visible) {
            detailsPanel = <IATMovementVisas model={IATMovementVisasStore}/>;
        }
        return (
            <div className="iat-movement-list-detail-view" data-is-scrollable={true}>
                <DetailsList columns={columns}
                                items={this.props.items}
                                selection={this._selection}
                                selectionMode={SelectionMode.multiple}
                                onColumnHeaderClick={this.props.sort ? this._handleColumnHeaderClick : undefined}
                                layoutMode={DetailsListLayoutMode.fixedColumns}
                                constrainMode={ConstrainMode.unconstrained}
                                onRenderRow={this._onRenderRow}
                                onRenderDetailsHeader = {this.props.customClipboardRowAndHeader ? this._onRenderHeader: undefined}
                                checkboxVisibility={this.props.enableRowSelection ? CheckboxVisibility.onHover: CheckboxVisibility.hidden} />
                {detailsPanel}
            </div>
        );
    }
}

export{ IATMovementDetailListView as default, IATMovementDetailListView };
