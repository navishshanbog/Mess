import * as React from "react";
import { observer } from "mobx-react";
import { action } from "mobx";
import { MessageBar, MessageBarType } from "office-ui-fabric-react/lib/MessageBar";
import { IObjectWithKey } from "office-ui-fabric-react/lib/Selection";
import IATMovementList from "./IATMovementList";
import { EntityAttributes, EntityAttributesType } from "entity/component/EntityAttributes";
import MasterEntityContainer from "entity/component/MasterEntityContainer";
import IIATMovement from "../IIATMovement";
import IATEntityActions from "./IATEntityActions";
import IATEntityActionsStore from "../IATEntityActionsStore";
import { Spinner } from "office-ui-fabric-react/lib/Spinner";
import Error from "common/component/Error";
import * as IATConstants from "../IATConstants";
import "./IATEntitySummary.scss";
import IMasterEntityIATModel from "../IMasterEntityIATModel";
import IIATFlightListModel from "../IIATFlightListModel";
import {IAppClipBoardModel} from "clipboard/IAppClipBoardModel";
import AppClipboardStore from "clipboard/AppClipBoardStore";
import IATFlightListStore from "../IATFlightListStore";
import IATAssociatedActivityColumnsList from "./IATAssociatedActivityColumnsList";
import {IMasterEntityModel} from "../../entity/IMasterEntityModel";


interface IMasterEntityIATProps {
    iat?: IMasterEntityIATModel;
    flightListModel?: IIATFlightListModel;
    clipBoard?: IAppClipBoardModel;
}
const DefaultIATMovementListDetailViewProps : IMasterEntityIATProps = {
    clipBoard: AppClipboardStore
};

interface IIATDragAndDrop {
    items: IIATMovement[];
    columnsToReport?: any[];
    entityModel?: IMasterEntityModel;
}

@observer
class MasterEntityIAT extends React.Component<IMasterEntityIATProps, any> {
    public static defaultProps = DefaultIATMovementListDetailViewProps;


    // _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, items: IIATMovement[], columnsToReport?: any[] ) => {
    _handleItemsDragStart = (e : React.DragEvent<HTMLElement>, dragAndDrop?: IIATDragAndDrop ) => {
        console.log("Columns to display ", dragAndDrop.columnsToReport);
        e.stopPropagation();
        const entityRef = this.props.iat.ref;
        if(dragAndDrop.items.length > 0) {
            const transferData = {
                type: IATConstants.sourceSystemCode,
                items: dragAndDrop.items,
                columns: dragAndDrop.columnsToReport
            };
            e.dataTransfer.setData("text", JSON.stringify(transferData));
        } else {
            e.preventDefault();
        }
        window.setTimeout(action(() => {
            this.props.clipBoard.openClipboard();
            this.props.clipBoard.setDraggedEntity(entityRef);
        }), 1);

        if(dragAndDrop.items.length > 1) {
            this.getAssociatedTravllers(this.props.iat.ref, dragAndDrop.items);
        }
    }

    getAssociatedTravllers(ref, items) {
        var aTravellers = Promise.resolve(IATFlightListStore.loadForMovements(ref, items));

        aTravellers.then(() => {
            var assItems = IATFlightListStore.associatedTravellers || [];
            this.props.clipBoard.assItems = assItems;
            this.props.clipBoard.assColumns = IATAssociatedActivityColumnsList;
        });
    }

    _handleRowSelection = (selectedItems: IObjectWithKey[]) => {
        IATEntityActionsStore.selectedItems = selectedItems;
    }
    _handleRenderContent = (masterEntity) => {
        let content;
        let entitySummary;

        const source = masterEntity.sourceMap[IATConstants.sourceSystemCode]; 
        if(source) {
            entitySummary = <div className="master-entity-iat-entity-summary">
                                <EntityAttributes entity={source} type={EntityAttributesType.secondary} />
                                <IATEntityActions model={IATEntityActionsStore} masterEntity={this.props.iat.ref}/>
                            </div>
            if (this.props.iat.activityList.sync.hasSynced && !this.props.iat.activityList.sync.error
                && this.props.iat.activityList.total == 0) {
                if(this.props.iat.aliases.sync.syncing) {
                    content = <Spinner label="No Movements Found. Checking Aliases..." className="load-spinner" />;
                } else if(this.props.iat.aliases.sync.error) {
                    content = <Error error={this.props.iat.aliases.sync.error} />
                } else if(this.props.iat.aliases.sync.hasSynced && this.props.iat.aliases.total > 0) {
                    content = <MessageBar messageBarType={MessageBarType.warning}>Traveller exists in IAT system, but has no movements</MessageBar>;
                } else {
                    content =<MessageBar messageBarType={MessageBarType.error}>There are no IAT details available for the selected Master Entity</MessageBar>;
                }
            } else {

                content =<IATMovementList list={this.props.iat.activityList} sort={this.props.iat.activityList.sort}
                                          filter={this.props.iat.activityList.filter} enableRowSelection={true}
                                          onItemsDragStart={this._handleItemsDragStart}
                                          rowSelectionListener={this._handleRowSelection}/>;
                console.log("Enter handle render content", content )
            }
        } else {
            content =<MessageBar messageBarType={MessageBarType.warning}>There are no IAT details available for the selected Master Entity</MessageBar>;
        }
        return (
            <div className="master-entity-iat">
                {entitySummary}
                {content}
            </div>
        );
    }
    _handleRenderNotLoaded = () => {
        return <MessageBar messageBarType={MessageBarType.warning}>You'll have to load a Master Entity to see the IAT summary</MessageBar>;
    }
    render() {
        return <MasterEntityContainer masterEntityRef={this.props.iat}
                                        onRenderContent={this._handleRenderContent}
                                        onRenderNotLoaded={this._handleRenderNotLoaded} />;
    }
}

export {
    MasterEntityIAT as default,
    MasterEntityIAT,
    IMasterEntityIATProps,
    IIATDragAndDrop
}