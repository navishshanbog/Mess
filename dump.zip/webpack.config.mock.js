const webpack = require("webpack");
const webpackBaseConfig = require("./webpack.config.base.js");

const webpackMockConfig = Object.assign({}, webpackBaseConfig);

const publicPath = "/analystdesktop/widget/site/";
webpackMockConfig.output.publicPath = publicPath;

webpackMockConfig.plugins.push(
    new webpack.DefinePlugin({
        "process.env.NODE_ENV": JSON.stringify("development"),
        "AppConfig": JSON.stringify({
            production: false,
            configName: "mock",
            basePath: publicPath
        })
    })
);

module.exports = webpackMockConfig;