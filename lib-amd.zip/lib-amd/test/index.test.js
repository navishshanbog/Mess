/// <reference types="mocha" />
define(["require", "exports", "chai", "./../index"], function (require, exports, chai_1, index_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    describe('detokenize', function () {
        it('handles colors', function () {
            chai_1.expect(index_1.detokenize('"[theme:name, default: #FFF]"')).to.equal('#FFF');
            chai_1.expect(index_1.detokenize('"[theme: name, default: #FFF]"')).to.equal('#FFF');
            chai_1.expect(index_1.detokenize('"[theme: name , default: #FFF  ]"')).to.equal('#FFF');
        });
        it('handles rgba', function () {
            chai_1.expect(index_1.detokenize('"[theme:name, default: rgba(255,255,255,.5)]"')).to.equal('rgba(255,255,255,.5)');
        });
        it('handles fonts', function () {
            chai_1.expect(index_1.detokenize('"[theme:name, default: "Segoe UI"]"')).to.equal('"Segoe UI"');
        });
        it('respects theme', function () {
            index_1.loadTheme({
                color: 'red'
            });
            try {
                chai_1.expect(index_1.detokenize('"[theme:color, default: #FFF]"')).to.equal('red');
                chai_1.expect(index_1.detokenize('"[theme: color , default: #FFF]"')).to.equal('red');
            }
            finally {
                index_1.loadTheme(undefined);
            }
        });
        it('ignores malformed themes', function () {
            chai_1.expect(index_1.detokenize('"[theme:name, default: "Segoe UI"]')).to.equal('"[theme:name, default: "Segoe UI"]');
            chai_1.expect(index_1.detokenize('"[theme:]"')).to.equal('"[theme:]"');
        });
        it('translates missing themes', function () {
            chai_1.expect(index_1.detokenize('"[theme:name]"')).to.equal('inherit');
        });
        it('splits non-themable CSS', function () {
            var cssString = '.sampleClass\n{\n color: #FF0000;\n}\n';
            var arr = index_1.splitStyles(cssString);
            chai_1.expect(arr.length).to.equal(1);
            chai_1.expect(arr[0].rawString).to.equal(cssString);
        });
        it('splits themable CSS', function () {
            var arr = index_1.splitStyles('.firstClass { color: "[theme: firstColor ]";}\n' +
                ' .secondClass { color: "[theme:secondColor, default: #AAA]";}\n .coach { color: #333; }');
            chai_1.expect(arr.length).to.equal(5);
            for (var i = 0; i < arr.length; i++) {
                if (i % 2 === 0) {
                    chai_1.expect(typeof arr[i].rawString).to.equal('string');
                }
                else {
                    chai_1.expect(typeof arr[i].theme).to.equal('string');
                }
            }
        });
        it('passes the styles to loadStyles override callback', function () {
            var expected = 'xxx.foo { color: #FFF }xxx';
            var subject = undefined;
            var callback = function (str) {
                subject = 'xxx' + str + 'xxx';
            };
            index_1.configureLoadStyles(callback);
            index_1.loadStyles('.foo { color: "[theme:fooColor, default: #FFF]" }');
            chai_1.expect(subject).to.equal(expected);
            index_1.configureLoadStyles(undefined);
        });
    });
});

//# sourceMappingURL=index.test.js.map
