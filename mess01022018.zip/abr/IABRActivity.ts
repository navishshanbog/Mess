interface IABRActivity {
    pid?: string;
    abn?: string;
    entityType?: string;
    eEntityOrganisationName?: string;
    entityNameTitle?: string;
    entityNameGivenName?: string;
    entityNameOtherGivenNames?: string;
    entityNameFamilyName?: string;
    entityNameSuffix?: string;
    abnRegDOE?: string;
    abnCanDOE?: string;
    mainTradingName?: string;
    sONAddressLine1?: string;
    sONAddressLine2?: string /*;
    sONAddressSuburb?: string;
    sONAddressStateCd?: string;
    sONAddressPostcode?: string;
    sONAddressCountryCd?: string;
    sONAddressDPID?: string;
    bUSAddressLine1?: string;
    bUSAddressLine2?: string;
    bUSAddressSuburb?: string;
    bUSAddressStateCd?: string;
    bUSAddressPostcode?: string;
    bUSAddressCountryCd?: string;
    bUSAddressDPID?: string;
    email?: string;
    partyID?: string;
    gstRegDOE?: string;
    gstCanDOE?: string;
    anzSIC?: string;
    anzSICdescription?: string;
    asicNumber?: string;
    suppressionInd?: string;
    crtd_RUN_ID?: string;
    crtd_TMSTMP?: string;  */

}

export { IABRActivity as default, IABRActivity };