import IABRActivity from "./IABRActivity";

interface IABRActivitiesGetOptions {
    maxNumberOfRecords?: number;
}

interface IABRActivitiesGetRequest extends IABRActivitiesGetOptions {
    abrNumber: string,
}

interface IABRService {
    getABRActivities(request : IABRActivitiesGetRequest) : Promise<IABRActivity[]>;
}

export { IABRService as default, IABRService, IABRActivitiesGetRequest };