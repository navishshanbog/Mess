import { IColumn, ColumnActionsMode } from "office-ui-fabric-react/lib/DetailsList";
import IABRActivity from "abr/IABRActivity";
import * as DateUtils from "util/Date";

const pid : IColumn = {
    key: "pid",
    ariaLabel: "PID",
    name: "PID",
    fieldName: "pid",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    minWidth: 40,
    maxWidth: 100
};

const abn : IColumn = {
    key: "abn",
    ariaLabel: "ABN",
    name: "ABN",
    fieldName: "abn",
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true,
    minWidth: 40,
    maxWidth: 100
};

const entityType : IColumn = {
    key: "entityType",
    ariaLabel: "Type",
    name: "Type",
    fieldName: "entityType",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    isMultiline: true
};

const eEntityOrganisationName : IColumn = {
    key: "eEntityOrganisationName",
    ariaLabel: "Org Name",
    name: "Org Name",
    fieldName: "eEntityOrganisationName",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const entityNameTitle : IColumn = {
    key: "entityNameTitle",
    ariaLabel: "Title",
    name: "Title",
    fieldName: "entityNameTitle",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const entityNameGivenName : IColumn = {
    key: "entityNameGivenName",
    ariaLabel: "Given Name",
    name: "Given Name",
    fieldName: "entityNameGivenName",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const entityNameOtherGivenNames : IColumn = {
    key: "entityNameOtherGivenNames",
    ariaLabel: "Other Given Names",
    name: "Other Given Names",
    fieldName: "entityNameOtherGivenNames",
    minWidth: 40,
    maxWidth: 100,
    isResizable: true,
    isMultiline: true,
    columnActionsMode:ColumnActionsMode.clickable
};

const entityNameFamilyName : IColumn = {
    key: "entityNameFamilyName",
    ariaLabel: "Family Name",
    name: "Family Name",
    fieldName: "entityNameFamilyName",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const entityNameSuffix : IColumn = {
    key: "entityNameSuffix",
    ariaLabel: "Name Suffix",
    name: "Name Suffix",
    fieldName: "entityNameSuffix",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const abnRegDOE : IColumn = {
    key: "abnRegDOE",
    ariaLabel: "Reg DOE",
    name: "Reg DOE",
    fieldName: "abnRegDOE",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: (item : IABRActivity) => {
            return DateUtils.dataToOutputText(item.abnRegDOE);
        }
    },
    onRender: (item :  IABRActivity) => {
        return DateUtils.dataToOutputText(item.abnRegDOE);
    }
};

const abnCanDOE : IColumn = {
    key: "abnCanDOE",
    ariaLabel: "Can DOE",
    name: "Can DOE",
    fieldName: "abnCanDOE",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true,
    data: {
        getText: (item : IABRActivity) => {
            return DateUtils.dataToOutputText(item.abnCanDOE);
        }
    },
    onRender: (item :  IABRActivity) => {
        return DateUtils.dataToOutputText(item.abnCanDOE);
    }
};

const mainTradingName : IColumn = {
    key: "mainTradingName",
    ariaLabel: "Trading Name",
    name: "Trading Name",
    fieldName: "mainTradingName",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const sONAddressLine1 : IColumn = {
    key: "sONAddressLine1",
    ariaLabel: "Address Line 1",
    name: "Address Line 1",
    fieldName: "sONAddressLine1",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const sONAddressLine2 : IColumn = {
    key: "sONAddressLine2",
    ariaLabel: "Address Line 2",
    name: "Address Line 2",
    fieldName: "sONAddressLine2",
    minWidth: 40,
    maxWidth: 100,
    columnActionsMode:ColumnActionsMode.clickable,
    isResizable: true
};

const ABRActivityColumns : IColumn[] = [
    pid,
    abn,
    entityType,
    eEntityOrganisationName,
    entityNameTitle,
    entityNameGivenName,
    entityNameOtherGivenNames,
    entityNameFamilyName,
    entityNameSuffix,
    abnRegDOE,
    abnCanDOE,
    mainTradingName,
    sONAddressLine1,
    sONAddressLine2 /*,
    sONAddressSuburb,
    sONAddressStateCd,
    sONAddressPostcode,
    sONAddressCountryCd,
    sONAddressDPID,
    bUSAddressLine1,
    bUSAddressLine2,
    bUSAddressSuburb,
    bUSAddressStateCd,
    bUSAddressPostcode,
    bUSAddressCountryCd,
    bUSAddressDPID,
    email,
    partyID,
    gstRegDOE,
    gstCanDOE,
    anzSIC,
    anzSICdescription,
    asicNumber,
    suppressionInd,
    crtd_RUN_ID,
    crtd_TMSTMP */
];

export {
    ABRActivityColumns as default,
    ABRActivityColumns,
    pid,
    abn,
    entityType,
    eEntityOrganisationName,
    entityNameTitle,
    entityNameGivenName,
    entityNameOtherGivenNames,
    entityNameFamilyName,
    entityNameSuffix,
    abnRegDOE,
    abnCanDOE,
    mainTradingName,
    sONAddressLine1,
    sONAddressLine2 /*,
    sONAddressSuburb,
    sONAddressStateCd,
    sONAddressPostcode,
    sONAddressCountryCd,
    sONAddressDPID,
    bUSAddressLine1,
    bUSAddressLine2,
    bUSAddressSuburb,
    bUSAddressStateCd,
    bUSAddressPostcode,
    bUSAddressCountryCd,
    bUSAddressDPID,
    email,
    partyID,
    gstRegDOE,
    gstCanDOE,
    anzSIC,
    anzSICdescription,
    asicNumber,
    suppressionInd,
    crtd_RUN_ID,
    crtd_TMSTMP  */
}