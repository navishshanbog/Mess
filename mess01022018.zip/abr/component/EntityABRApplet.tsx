import * as React from "react";
import EntityAppWrapper from "entity/component/EntityAppWrapper";
import IEntityAppletProps from "entity/component/IEntityAppletProps";
import EntityABRContainer from "./EntityABR";
import "./EntityABRApplet.scss";

class EntityABRApplet extends React.Component<IEntityAppletProps, any> {
    private _onRenderContent = (entityHandle) => {
        return <EntityABRContainer entityHandle={entityHandle} />;
    }
    render() {
       return <EntityAppWrapper entityId={this.props.entityId}
                                host={this.props.host}
                                title="ABR"
                                onRenderContent={this._onRenderContent} />
    }
}

export { EntityABRApplet as default, EntityABRApplet }