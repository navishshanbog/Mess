//
//     Copyright © 2011-2018 Cambridge Intelligence Limited.
//     All rights reserved.
//
//     Sample Code
//
//!    Explore the source and distribution of ransomware attacks over time.

var chart;
var timebar;

// Used in closed combos, links and open combo borders
var ransomwareColours = {
  TeslaCrypt: '#FF5964',
  CryptoWall: '#00BFFF',
  Locky: '#A5DF00'
};

// Paler versions for the open combo backgrounds
var ocRansomwareColours = {
  TeslaCrypt: '#FFEEF0',
  CryptoWall: '#E6F9FF',
  Locky: '#F6FCE6'
};

// Scale the closed combo sizes at slightly less than the square root of their
// node count so that the larger combos (e.g. USA) don't dominate too much
// and the smaller combos aren't too tiny
var scalePower = 0.4;

var currentPlaying;

var comboCriteria = {
  ip: function (item) {
    if (isCombo(item.id) || !item.d.country) {
      return { ok: false };
    }
    return { ok: true, key: item.d.country, data: item.d.host };
  },
  host: function (item) {
    if (isCombo(item.id) || !item.d.ransomware) {
      return { ok: false };
    }
    return { ok: true, key: item.d.ransomware, data: item.d.from };
  }
};
var comboDef = {
  ip: function (name, def) {
    def.d.country = name;
    def.style.u = 'images/flags/' + name + '.png';
    def.glyph = null;
  },
  host: function (name, def) {
    def.d.ransomware = name;
    def.style.u = 'images/ransomware/virus.png';
    def.style.c = ransomwareColours[name];
    def.openStyle.c = ocRansomwareColours[name];
    def.openStyle.b = ransomwareColours[name];
    def.glyph = null;
  }
};

function isCombo(ids) {
  return chart.combo().isCombo(ids, { type: 'node' });
}

function uncombineAction() {
  chart.combo().uncombine(chart.selection(), { animate: false, select: false }, function () {
    // run the filter of ransomware
    filterRansomware();
    // Enable the combine button
    enableButton('combine', true);
  });
}

function combineAction() {
  function groupNodesBy() {
    var groups = {};
    var lookup = {};

    chart.each({ type: 'node', items: 'toplevel' }, function (item) {
      var result = comboCriteria[item.d.type](item);
      if (result.ok) {
        // Groups are per node type (ips or ransomwares)
        groups[item.d.type] = groups[item.d.type] || {};
        // For each type create an object with the possible values:
        // ip -> country names
        // ransomware -> name
        groups[item.d.type][result.key] = groups[item.d.type][result.key] || [];
        // Then create a list of items
        groups[item.d.type][result.key].push(item.id);

        if (result.data) {
          // Here we prepare a lookup structure for fast queries of items in a combo
          lookup[item.d.type] = lookup[item.d.type] || {};
          lookup[item.d.type][result.key] = lookup[item.d.type][result.key] || {};
          if (Array.isArray(result.data)) {
            lookup[item.d.type][result.key][item.id] = result.data;
          } else {
            lookup[item.d.type][result.key][result.data] =
              lookup[item.d.type][result.key][result.data] || [];
            lookup[item.d.type][result.key][result.data].push(item.id);
          }
        }
      }
    });
    return { ids: groups, lookup: lookup };
  }

  // Set the widths of the combo links once they've been created
  function styleComboLinks() {
    var props = [];
    chart.each({ type: 'link', items: 'toplevel' }, function (link) {
      props.push({ id: link.id, w: 10 });
    });
    chart.setProperties(props);
  }

  var groups = groupNodesBy();
  var combineOptions = { animate: false, select: false, arrange: 'concentric' };
  var combineArray = [];
  Object.keys(groups.ids).forEach(function (type) {
    Object.keys(groups.ids[type]).forEach(function (g) {
      var ids = groups.ids[type][g];

      var combineIds = {
        ids: ids,
        label: g,
        style: { e: Math.pow(ids.length, scalePower) },
        openStyle: { bw: 10 },
        d: { type: type }
      };

      if (groups.lookup[type] && groups.lookup[type][g]) {
        combineIds.d.lookup = groups.lookup[type][g];
      }

      comboDef[type](g, combineIds); // Add specific def for the type of node
      combineArray.push(combineIds); // Add the current definition
    });
  });
  chart.combo().combine(combineArray, combineOptions, function () {
    styleComboLinks();
    // run the filter of ransomware
    filterRansomware();
    // Disable the combine button
    enableButton('combine', false);
  });
}

function layout() {
  var layoutType = $('#layoutType').val();
  chart.layout(layoutType);
}

function timebarChange(callback) {
  function timebarFilterCriteria(item) {
    // If the ransomware is not checked
    if (item.d.ransomware && !showRansomware(item)) {
      return false;
    }
    if (item.d.type === 'ip') {
      var hosts = item.d.host;
      return hosts.some(function (host) {
        return timebar.inRange(host);
      });
    }
    if (item.d.type === 'host') {
      return timebar.inRange(item.id);
    }
    return false; // Other cases should return false
  }

  // filter the chart to show only items in the new range
  chart.filter(timebarFilterCriteria, { type: 'node', animate: false, hideSingletons: true }, function (changes) {
    // update the size of the combo based on the changes object returned by the filter
    var visualProperties = changes.combos.nodes.map(function (comboInfo) {
      return { id: comboInfo.id, e: Math.pow(comboInfo.nodes.length, scalePower) };
    });

    // When playing the timebar sometimes it can be helpful to overwrite previous animations
    // => queue: false
    chart.animateProperties(visualProperties, { time: 300, queue: false }, callback);
  });
}

function isOnlyCombos(items) {
  return items.length && items.every(function (item) { return isCombo(item.id); });
}

function chartSelectionChange() {
  var tbSelection;
  // Reset the previous timebar selection
  timebar.selection([]);
  // Get only the nodes within the selection
  var selection = chart.getItem(chart.selection());
  // Enable or disable the uncombine button
  enableButton('uncombine', isOnlyCombos(selection));

  function isOnlyTypeSelected(type, items) {
    return items.every(function (item) { return item.d.type === type; });
  }

  function ransomwareSelection(nodes, countrySelected, subsetHost) {
    var index = 0;
    var ransomwareGroups = groupByRansomware(nodes);

    _.each(ransomwareGroups, function (group, name) {
      var ids;
      var firstItem = group[0];
      if (isCombo(firstItem.id)) {
        if (countrySelected) {
          ids = firstItem.d.lookup[countrySelected].filter(function (id) {
            return subsetHost ? _.contains(subsetHost, id) : true;
          });
        } else {
          ids = getHostIds(firstItem.d.lookup);
        }
      } else {
        ids = _.map(group, function (item) { return item.id; });
      }
      tbSelection.push({ id: ids, index: index++, c: ransomwareColours[name] });
    });
  }

  if (selection.length > 0) {
    tbSelection = []; // The new selection of the timebar

    // show the trend of the ransomwares for the country combo and ip nodes
    if (isOnlyTypeSelected('ip', selection)) {
      var neighbours = {};
      var hosts = {};

      for (var i = 0; i < selection.length; i++) {
        var ip = selection[i];

        if (isCombo(ip.id) && selection.length > 1) {
          return; // exit without select anything on the timebar
        }

        neighbours[ip.d.country] = neighbours[ip.d.country] || [];
        neighbours[ip.d.country] =
          neighbours[ip.d.country].concat(chart.graph().neighbours(ip.id).nodes);

        if (ip.d.host) {
          hosts[ip.d.country] = hosts[ip.d.country] || [];
          hosts[ip.d.country] = hosts[ip.d.country].concat(ip.d.host);
        }
      }

      _.each(neighbours, function (nodes, country) {
        ransomwareSelection(chart.getItem(nodes), country, hosts[country]);
      });
    }

    // Show the trend for the ransomware combos and host nodes
    if (isOnlyTypeSelected('host', selection)) {
      ransomwareSelection(selection);
    }

    timebar.selection(tbSelection); // Set the new selection to the timebar
  }
}

function getHostIds(lookup) {
  return _.flatten(_.values(lookup));
}

function groupByRansomware(items) {
  return _.groupBy(items, function (item) { return item.d.ransomware; });
}

function showRansomware(item) {
  var checked = $('input[name="ransomware"]:checked');
  // checked is a jQuery object, so do not use the native .some here
  return _.some(checked, function (c) { return item.d.ransomware === c.id; });
}

function filterRansomware() {
  timebarChange(selectionChangeAndLayout);
}

function selectionChangeAndLayout() {
  chartSelectionChange();
  layout();
}

function enableButton(type, enable) {
  $('#' + type + 'Run').attr('disabled', !enable);
}

function registerPlayAction(playType) {
  currentPlaying = playType;
}

function registerPauseAction() {
  currentPlaying = null;
}

function dataEndHandler(endType) {
  if (endType === 'data') {
    if (currentPlaying === 'extend') {
      timebar.pause();
    }
  }
}

// Make underlying nodes and the backgrounds of their labels transparent
function applyExtraStyling(data) {
  data.items.forEach(function (item) {
    if (item.type === 'node') {
      item.fbc = 'transparent';
      item.c = 'transparent';
      if (item.d && item.d.type === 'host') {
        item.fi = { t: KeyLines.getFontIcon('fa-server'), c: '#444' };
      }
    }
  });
}

function klReady(err, components) {
  chart = components[0];
  timebar = components[1];

  applyExtraStyling(data);

  timebar.load(data, function () {
    timebar.zoom('fit', { animate: false });
  });
  chart.load(data, combineAction);

  chart.bind('selectionchange', chartSelectionChange); // Align the chart selection to the timebar

  timebar.bind('change', timebarChange); // Filter the nodes to match the timebar range
  timebar.bind('play', registerPlayAction); // Register the type of play mode the user clicked
  timebar.bind('pause', registerPauseAction); // Register the Pause action
  timebar.bind('end', dataEndHandler); // Handler to be executed on the "end data" event

  $('#layoutRun').click(layout); // Run the layout
  $('#layoutType').on('change', layout); // Run the layout when choosing a layout
  $('#combineRun').click(combineAction); // Combine all the nodes
  $('#uncombineRun').click(uncombineAction); // Uncombine selected nodes
  $('input[name="ransomware"]').on('change keyup', filterRansomware); // Filter the ransomwares
}

function startKeyLines() {

  KeyLines.paths({ assets: 'assets/' });

  var timebarOpts = { showExtend: true };
  var chartOpts = {
    logo: 'assets/Logo.png',
    hover: 100,
    marqueeLinkSelection: 'off',
    selectedNode: {
      fb: true,
      ha0: {
        c: '#555',
        r: '31',
        w: '3'
      },
      oc: { bw: 20 }
    },
    iconFontFamily: 'FontAwesome',
    handMode: true
  };

  var kl = { id: 'kl', type: 'chart', options: chartOpts };
  var tl = { id: 'tl', type: 'timebar', options: timebarOpts };
  KeyLines.create([kl, tl], klReady);
}

$(function () {
  WebFont.load({
    custom: {
      families: ['FontAwesome']
    },
    active: startKeyLines,
    inactive: startKeyLines,
    timeout: 3000
  });
});
