# resite
Complete site built on require and react.

Kick of using 'npm start' or 'node app.js --port={port | 3000} --publish (to publish) --watch (to publish when changes occur)
