"use strict";
const express = require("express");
const path = require("path");
const opts = require("./sup/opts");
const tasks = require("./tasks");
const app = express();

const contentDir = path.join(__dirname, "dist");
const jsDir = path.join(contentDir, "/js");
const cssDir = path.join(contentDir, "/css");
const imgDir = path.join(contentDir, "/img");
const fontDir = path.join(contentDir, "/fonts");

app.use("/js", express.static(jsDir));
app.use("/img", express.static(imgDir));
app.use("/css", express.static(cssDir));
app.use("/fonts", express.static(fontDir));

app.use(function(req, res, next) {
    if(req.path.indexOf("/api") >= 0) {
        console.log("-- API Request");
    } else {
        next();
    }
});

app.use(function(req, res, next) {
    var ext = path.extname(req.path);
    if(!ext || ext === ".html") {
        res.sendFile("index.html", { root: contentDir });
    } else {
        next();
    }
});

const startServer = () => {
    app.listen(opts.port || 3000, function () {
        console.log("Server Started");
    });
};

if(opts.publish) {
    console.log("Publishing Resources");
    tasks.publishAll().then(() => {
        console.log("Publishing Complete");
        startServer();
    }).catch((err) => {
        console.log("Publishing Error");
        console.error(err);
        startServer();
    });
} else {
    startServer();
}

if(opts.watch) {
    tasks.watch();
}


