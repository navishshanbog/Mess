const tasks = require("./tasks");
const opts = require("./sup/opts");

const run = (taskId) => {
    var task = tasks[taskId];
    if(!task) {
        console.error("Unable to find task: " + taskId);
    } else {
        task.call(tasks).then(() => {
            console.info("Build Completed");
        }).catch((err) => {
            console.info("Build Failed");
            console.error(err);  
        });
    }
};

run(opts.task || "default");
