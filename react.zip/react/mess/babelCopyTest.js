const fsService = require("../fsService");
const path = require("path");
const babel = require("babel-core");

const babelOpts = {
    presets: ["es2015", "react"],
    plugins: ["transform-es2015-modules-amd"]
};

const babelDataMap = function(data) {
    return babel.transform(data.toString("utf8"), babelOpts).code;
};

const src = path.join(__dirname, "src/es6");
const dest = path.join(__dirname, "public/js");
const copyOpts = {
    dataMap: babelDataMap
};

fsService.copy(src, dest, copyOpts).then(function() {
    console.log("-- Successfully Copied");
}).catch(function(err) {
    console.log("-- Error Copying");
    console.error(err);
});