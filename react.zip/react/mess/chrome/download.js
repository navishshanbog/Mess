const cri = require("chrome-remote-interface");

cri((chrome) => {
    chrome.on("event", (message) => {
        console.log("-- Method: " + message.method);
        if(message.method === "Network.responseReceived") {
            chrome.Network.getResponseBody({ requestId: message.params.requestId }, (responseBody) => {
                console.log("-- Response Body: " + JSON.stringify(responseBody));
                chrome.close();
            });
        } else if(message.method === "Network.dataReceived") {
            console.log("-- Params: " + JSON.stringify(message.params));
        } else if(message.method === "Network.loadingFinished") {
            console.log("-- Loading Finished: " + message.params.requestId);
            chrome.Network.getResponseBody({ requestId: message.params.requestId }, (responseBody) => {
                console.log("-- Response Body: " + JSON.stringify(responseBody));
                chrome.close();
            });
        }
    });
    chrome.Network.enable();
    chrome.Page.enable();
    chrome.Page.navigate({ url: "https://pypi.python.org/packages/79/ce/b0801d6f3d9d93d1612669c6b2f5a179f4ebc92ea823a3e61e90bd6049ff/Pillow-3.4.1-cp26-cp26m-win32.whl#md5=41f5eca4c62791d1c1f3fb2507b2232f" });
});