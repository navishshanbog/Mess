const fsUtil = require("../fs");
const pathUtil = require("path");
const less = require("less");

const lessDataMap = function(data) {
    return less.render(data.toString("utf8")).then(function(out) {
        return out.css;
    });
};

const src = pathUtil.join(__dirname, "src/less");
const dest = pathUtil.join(__dirname, "public/css");
const copyOpts = {
    dataMap: lessDataMap,
    extension: ".css"
};

fsUtil.copy(src, dest, copyOpts).then(function() {
    console.log("-- Successfully Transformed");
}).catch(function(err) {
    console.log("-- Error: " + err);
});