const fsUtil = require("../fs");
const path = require("path");

const src = path.join(__dirname, "src/js");
const dest = path.join(__dirname, "public/js");

fsUtil.copy(src, dest).then(function() {
    console.log("-- Successfully Copied");
}).catch(function(err) {
    console.log("-- Error: " + err);
});