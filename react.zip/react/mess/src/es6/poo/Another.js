(function() {
    define(["test/Sample"], function(Sample) {
        class Another extends Sample {
            get woo() {
                return "WOO!";
            }
        }
    });
})();