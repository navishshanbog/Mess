(function() {
    define(function() {
        class Sample {
            constructor() {
                console.log("Woo");
            }
        }
        return Sample;
    });
})();