import React from "react";

class Sample extends React.Component {
    render() {
        return
        <div>
            <h3>What the hell is this?</h3>
            <p>An esx component</p>
        </div>
    }
}

export { Sample as default, Sample as Sample };