(function() {
    define(function() {
        var Mongrel = function() {
            console.log("Mongrel!");
        };

        return Mongrel;
    });
})();