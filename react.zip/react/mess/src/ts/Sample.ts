import SampleView = require("poo/view/Sample");

interface Person {
    firstName: string;
    lastName: string;
}

function poo(p : Person) {
    let v = new SampleView();
}

export = poo;
