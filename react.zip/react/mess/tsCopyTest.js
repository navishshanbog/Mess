const fsUtil = require("../fs");
const path = require("path");
const ts = require("typescript");

const tsDataMap = function(data) {
    let result = ts.transpileModule(data.toString("utf8"), { compilerOptions: { module: ts.ModuleKind.AMD } });
    console.log("-- Result: " + JSON.stringify(result));
    return result.outputText;
};

const tsPathMap = fsUtil.createExtensionPathMap(".js");

const src = path.join(__dirname, "src/ts");
const dest = path.join(__dirname, "public/js");
const copyOpts = {
    dataMap: tsDataMap,
    pathMap: tsPathMap
};

fsUtil.copy(src, dest, copyOpts).then(function() {
    console.log("-- Successfully Copied");
}).catch(function(err) {
    console.log("-- Error: " + err);
});