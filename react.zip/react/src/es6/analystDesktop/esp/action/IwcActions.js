// note, this is just to ensure ozp iwc is imported - due to the nature of the libary, it doesn't' actually provided a export/response (via amd)
import IwcClient from "iwc/Client";
import promiseUtils from "util/promise";
import config from "../config";
import EntityService from "../service/EntityService";

class IwcActions {
    constructor(iwcUrl) {
        this.iwcUrl = iwcUrl;
    }
    get iwcUrl() {
        if(!this._iwcUrl) {
            this._iwcUrl = config.iwcUrl;
        }
        return this._iwcUrl;
    }
    set iwcUrl(value) {
        this._iwcUrl = value;
    }
    get client() {
        if(!this._client) {
            this._client = new IwcClient(this.iwcUrl);
        }
        return this._client;
    }
    get searchIntentRef() {
        if(!this._searchIntentRef) {
            this._searchIntentRef = this.client.getIntentReference("/application/analystDesktop/search");
        }
        return this._searchIntentRef;
    }
    get searchDataRef() {
        if(!this._searchDataRef) {
            this._searchDataRef = this.client.getDataReference("/analystDesktop/entities/search");
        }
        return this._searchDataRef;
    }
    _searchWithIntentImmediate(request) {
        return this.searchIntentRef.invoke(request);
    }
    _searchWithIntent(request) {
        return promiseUtils.invokeWithRetry(() => {
            return this._searchWithIntentImmediate(request);
        }, { period: 500, timeout: 5000 }).then(() => {
            console.log("-- IWC Search Intent Invoked");  
        });
    }
    _searchWithData(request) {
        const busRequest = Object.assign({}, request);
        delete busRequest.userConfig;
        this.searchDataRef.set({ request: busRequest, done: false });
        return EntityService.search(request).then((result) => {
            this.searchDataRef.set({ request: busRequest, result: result, done: true });
        }).catch((err) => {
            this.searchDataRef.set({ request: busRequest, error: err, done: true });
        });
    }
    search(request) {
        return this._searchWithData(request);
    }
}

export default IwcActions;