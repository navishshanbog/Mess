import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class AddressSearchCriteria extends BaseSearchCriteria {
    get fullAddress() {
        return this.get("fullAddress");
    }
    set fullAddress(value) {
        this.set("fullAddress", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get postcode() {
        return this.get("postcode");
    }
    set postcode(value) {
        this.set("postcode", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get unitNumber() {
        return this.get("unitNumber");
    }
    set unitNumber(value) {
        this.set("unitNumber", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get streetNumber() {
        return this.get("streetNumber");
    }
    set streetNumber(value) {
        this.set("streetNumber", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get streetName() {
        return this.get("streetName");
    }
    set streetName(value) {
        this.set("streetName", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get streetType() {
        return this.get("streetType");
    }
    set streetType(value) {
        this.set("streetType", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get locality() {
        return this.get("locality");
    }
    set locality(value) {
        this.set("locality", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get state() {
        return this.get("state");
    }
    set state(value) {
        this.set("state", value).notify();
        if(this.get("addressChecked")) {
            this.validateAddress();
        }
    }
    get addressError() {
        return this.get("addressError");
    }
    get hasError() {
        return this.addressError ? true : false;
    }
    validateAddress() {
        return this.set({
            addressChecked: true,
            addressError: this.specified ? undefined : "Please specify at least one value"
        }).notify();
        return this.set("addressError", ).notify();
    }
    validate() {
        return this.validateAddress();
    }
    get specified() {
        return stringUtils.isNotBlank(this.fullAddress)
            || stringUtils.isNotBlank(this.postcode)
            || stringUtils.isNotBlank(this.unitNumber)
            || stringUtils.isNotBlank(this.streetNumber)
            || stringUtils.isNotBlank(this.streetName)
            || stringUtils.isNotBlank(this.streetType)
            || stringUtils.isNotBlank(this.locality)
            || stringUtils.isNotBlank(this.state);
    }
}

export default AddressSearchCriteria;