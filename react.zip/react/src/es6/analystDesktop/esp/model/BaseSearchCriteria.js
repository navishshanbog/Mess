import Model from "util/Model";

class BaseSearchCriteria extends Model {
    get params() {
        return this.get();
    }
    clear() {
        this.reset().notify();
    }
    toJSON() {
        return this.params;
    }
}

export default BaseSearchCriteria;