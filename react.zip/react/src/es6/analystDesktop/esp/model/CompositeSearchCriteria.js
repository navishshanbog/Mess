import BaseSearchCriteria from "./BaseSearchCriteria";

class CompositeSearchCriteria extends BaseSearchCriteria {
    constructor() {
        super();

        this._componentObserver = () => {
            this._setChanged().notify();
        };
    }
    get actions() {
        if(!this._actions) {
            this._actions = actions;
        }
        return this._actions;
    }
    set actions(value) {
        this._actions = value;
    }
    criteriaId() {
        let ids = [];
        if(this._components) {
            this._components.forEach((c) => {
                if(c.specified) {
                    ids.push(c.criteriaId);
                }
            });
        }
        return "entityComposite";
    }
    contains(criteria) {
        return this.indexOf(criteria) >= 0;
    }
    indexOf(criteria) {
        return this._components ? this._components.indexOf(criteria) : -1;
    }
    get components() {
        return this._components || [];
    }
    add(criteria) {
        if(criteria && !this.contains(criteria)) {
            criteria.observe(this._componentObserver);
            if(!this._components) {
                this._components = [];
            }
            this._components.push(criteria);
            this._setPropChanged("components").notify();
        }
    }
    remove(criteria) {
        let idx = this.indexOf(criteria);
        if(idx >= 0) {
            criteria.forget(this._componentObserver);
            criteria.clear();
            this._components.splice(idx, 1);
            if(this._components.length === 0) {
                delete this._components;
            }
            this._setPropChanged("components").notify();
        }
    }
    params() {
        let params = {};
        if(this._components) {
            this._components.forEach((c) => {
                if(c.specified) {
                    params[c.criteriaId] = c.params;
                }
            });
        }
        return params;
    }
    clear() {
        if(this._components) {
            this._components.forEach((c) => {
                c.clear();
            });
        }
    }
    get searching() {
        return this.get("searching");
    }
    get searchError() {
        return this.get("searchError");
    }
    search() {
        this.set({
            searching: true,
            searchError: undefined
        }).notify();
        return this.actions.search(this.params).then(() => {
            this.set("searching", false).notify();
        }).catch((err) => {
            this.set({
                searching: false,
                searchError: err
            }).notify();
        });
    }
    toJSON() {
        return this.params;
    }
}

export default CompositeSearchCriteria;