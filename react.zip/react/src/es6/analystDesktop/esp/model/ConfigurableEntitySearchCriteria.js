import EntitySearchCriteria from "./EntitySearchCriteria";
import lang from "util/lang";

class ConfigurableEntitySearchCriteria extends EntitySearchCriteria {
    constructor() {
        super();
        this._selected = [];
    }
    get selected() {
        return this._selected;
    }
    isSelected(criteria) {
        return this._selected.indexOf(criteria) >= 0;
    }
    setSelected(criteria) {
        if(criteria && !this.isSelected(criteria)) {
            if(criteria.id === "system") {
                this._selected = [criteria];
            } else {
                if(this._selected.length === 1 && this._selected[0].id === "system") {
                    this._selected = [criteria];
                } else {
                    this._selected.push(criteria);
                }
            }
            this._setPropChanged("selected").notify();
        }
    }
    setUnselected(criteria) {
        if(criteria && this.isSelected(criteria)) {
            const idx = this._selected.indexOf(criteria);
            this._selected.splice(idx, 1);
            this._setPropChanged("selected").notify();
        }
    }
    toggleSelected(criteria) {
        if(this.isSelected(criteria)) {
            this.setUnselected(criteria);
        } else {
            this.setSelected(criteria);
        }
    }
    validateSelected() {
        this.set("selectedError", this.selected.length === 0 ? "Please specify a value" : undefined).notify();
    }
    get hasError() {
        const selectedError = this.get("selectedError") ? true : false;
        if(selectedError) {
            return true;
        }
        return this._components.some((c) => {
            if(this.isSelected(c)) {
                return c.model.hasError;
            }
            return false;
        });
    }
    validate() {
        this.validateSelected();
        this._components.forEach((c) => {
            if(this.isSelected(c) && lang.isFunction(c.model.validate)) {
                c.model.validate();
            } else if(!this.isSelected(c)) {
                c.model.clear();
            }
        });
        return this;
    }
    clear() {
        super.clear();
        this._selected = [];
        this._setPropChanged("selected").notify();
    }
}

export default ConfigurableEntitySearchCriteria;