import Model from "util/Model";

class DataModel extends Model {
    defaultProps() {
        return { loading: false };
    }
    get loading() {
        return this.get("loading");
    }
    get lastLoadDate() {
        return this.get("lastLoadDate");
    }
    get request() {
        return this.get("request");
    }
    get error() {
        return this.get("error");
    }
    get data() {
        return this.get("data");
    }
    loadData(data) {
        this.set("data", data).notify();
    }
    loadStart(request) {
        this.set({
            data: undefined,
            error: undefined,
            loading: true,
            request: request
        }).notify();
    }
    loadError(error) {
        this.set({
            data: undefined,
            lastLoadDate: new Date(),
            error: error,
            loading: false
        }).notify();
    }
    loadComplete(data) {
        this.set({
            lastLoadDate: new Date(),
            loading: false
        });
        this.loadData(data);
    }
}

export default DataModel;