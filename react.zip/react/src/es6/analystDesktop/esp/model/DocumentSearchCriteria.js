import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class DocumentSearchCriteria extends BaseSearchCriteria {
    get documentId() {
        return this.get("documentId");
    }
    set documentId(value) {
        this.set("documentId", value).notify();
    }
    get documentType() {
        return this.get("documentType");
    }
    set documentType(value) {
        this.set("documentType", value).notify();
    }
    get documentIssueCountry() {
        return this.get("documentIssueCountry");
    }
    set documentIssueCountry(value) {
        this.set("documentIssueCountry", value).notify();
    }
    get specified() {
        return stringUtils.isNotBlank(this.documentId)
            || stringUtils.isNotBlank(this.documentType)
            || stringUtils.isNotBlank(this.documentIssueCountry);
    }
}

export default DocumentSearchCriteria;