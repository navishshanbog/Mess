import Model from "util/Model";
import EntityDetails from "./EntityDetails";

class Entity extends Model {
    constructor(props) {
        super(props);
        this.details = new EntityDetails();
    }
}

export default Entity;