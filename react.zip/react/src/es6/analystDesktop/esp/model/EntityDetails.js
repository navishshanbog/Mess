import DataModel from "./DataModel";

class EntityDetails extends DataModel {}

export default EntityDetails;