import DataModel from "./DataModel";

class EntityList extends DataModel {}

export default EntityList;