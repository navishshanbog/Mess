import Model from "util/Model";
import PartialEntitySearchCriteria from "./PartialEntitySearchCriteria";
import EntityList from "./EntityList";

class EntitySearch extends Model {
    defaultProps() {
        return { active: "criteria" };
    }
    constructor() {
        super();
        this.criteria = new PartialEntitySearchCriteria();
        this.list = new EntityList();
    }
    get active() {
        return this.get("active");
    }
    search(params) {
        this.list.search(params);
        this.activateList();
    }
    activateList() {
        this.set("active", "list").notify();
    }
    activateCriteria() {
        this.set("active", "criteria").notify();
    }
}

export default EntitySearch;