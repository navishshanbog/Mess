import BaseSearchCriteria from "./BaseSearchCriteria";
import PersonSearchCriteria from "./PersonSearchCriteria";
import AddressSearchCriteria from "./AddressSearchCriteria";
import OrgSearchCriteria from "./OrgSearchCriteria";
import PhoneSearchCriteria from "./PhoneSearchCriteria";
import TextSearchCriteria from "./TextSearchCriteria";
import stringUtils from "util/string";
import langUtils from "util/lang";

class EntitySearchCriteria extends BaseSearchCriteria {
    constructor() {
        super();
        this._components = [];
        this._components.push({ id: "person", model: new PersonSearchCriteria() });
        this._components.push({ id: "org", model: new OrgSearchCriteria() });
        this._components.push({ id: "address", model: new AddressSearchCriteria() });
        this._components.push({ id: "phone", model: new PhoneSearchCriteria() });
        this._components.push({ id: "text", model: new TextSearchCriteria() });
        const componentObserver = (o) => {
            this._setChanged().notify();
        };
        this._components.forEach((c) => {
            c.model.observe(componentObserver);
        });
    }
    get components() {
        return [].concat(this._components);
    }
    get specified() {
        return this._components.some((c) => {
            return c.model.specified;
        });
    }
    get params() {
        let params = {};
        this._components.forEach((c) => {
            if(c.model.specified) {
                params[c.id] = c.model.params;
            }
        });
        return params;
    }
    get hasError() {
        return this._components.some((c) => {
            return c.model.hasError;
        });
    }
    validate() {
        this._components.forEach((c) => {
            if(lang.isFunction(c.model.validate)) {
                c.model.validate();
            }
        });
        return this;
    }
    clear() {
        this._components.forEach((c) => {
            c.model.clear();
        });
        return this;
    }
}

export default EntitySearchCriteria;