import BoundComponent from "common/view/BoundComponent";
import stringUtils from "util/string";

class EntitySearchParamSummary extends BoundComponent {
    get modelState() {
        return { params: this.model ? this.model.params : {} };
    }
    _modelChanged() {
        if(this.model.isPropChanged("params")) {
            this.setStateFromModel();
        }
    }
    render() {
        const params = this.state.params;

    }
}

export default EntitySearchParamSummary;