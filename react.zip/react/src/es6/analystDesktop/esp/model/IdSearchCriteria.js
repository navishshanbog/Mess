import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class IdSearchCriteria extends BaseSearchCriteria {
    get id() {
        return this.get("id");
    }
    set id(value) {
        this.set("id", value).notify();
    }
    clear() {
        this.reset();
    }
    get specified() {
        return stringUtils.isNotBlank(this.id);
    }
}

export default IdSearchCriteria;