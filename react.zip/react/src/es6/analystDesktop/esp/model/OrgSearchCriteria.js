import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class OrgSearchCriteria extends BaseSearchCriteria {
    get abn() {
        return this.get("abn");
    }
    set abn(value) {
        this.set("abn", value).notify();
        if(this.get("orgChecked")) {
            this.validateOrg();
        }
    }
    get name() {
        return this.get("name");
    }
    set name(value) {
        this.set("name", value).notify();
        if(this.get("orgChecked")) {
            this.validateOrg();
        }
    }
    get hasError() {
        return this.orgError ? true : false;
    }
    get orgError() {
        return this.get("orgError");
    }
    validateOrg() {
        return this.set({
            orgChecked: true,
            orgError: this.specified ? undefined : "Please specify a value"
        }).notify();
    }
    validate() {
        return this.validateOrg();
    }
    get specified() {
        return stringUtils.isNotBlank(this.abn)
            || stringUtils.isNotBlank(this.name);
    }
}

export default OrgSearchCriteria;