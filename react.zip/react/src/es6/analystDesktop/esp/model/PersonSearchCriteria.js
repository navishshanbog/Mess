import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class PersonSearchCriteria extends BaseSearchCriteria {
    get fullName() {
        return this.get("fullName");
    }
    set fullName(value) {
        this.set("fullName", value).notify();
        this.revalidatePerson();
    }

    get firstName() {
        return this.get("firstName");
    }
    set firstName(value) {
        this.set("firstName", value).notify();
        this.revalidatePerson();
    }
    get middleName() {
        return this.get("middleName");
    }
    set middleName(value) {
        this.set("middleName", value).notify();
        this.revalidatePerson();
    }
    get lastName() {
        return this.get("lastName");
    }
    set lastName(value) {
        this.set("lastName", value).notify();
        this.revalidatePerson();
    }
    get dob() {
        return this.get("dob");
    }
    set dob(value) {
        this.set("dob", value).notify();
        this.revalidatePerson();
    }
    get passport() {
        return this.get("passport");
    }
    set passport(value) {
        this.set("passport", value).notify();
        this.revalidatePerson();
    }
    get gender() {
        return this.get("gender");
    }
    set gender(value) {
        this.set("gender", value).notify();
        this.revalidatePerson();
    }
    get personError() {
        return this.get("personError");
    }
    get hasError() {
        return this.personError ? true : false;
    }
    revalidatePerson() {
        if(this.get("personChecked")) {
            this.validatePerson();
        }
    }
    validatePerson() {
        return this.set({
            personChecked: true,
            personError: this.specified ? undefined : "Please specify a value"
        }).notify();
    }
    validate() {
        return this.validatePerson();
    }
    get specified() {
        return stringUtils.isNotBlank(this.fullName)
            || stringUtils.isNotBlank(this.firstName)
            || stringUtils.isNotBlank(this.lastName)
            || stringUtils.isNotBlank(this.middleName)
            || stringUtils.isNotBlank(this.dob)
            || stringUtils.isNotBlank(this.gender)
            || stringUtils.isNotBlank(this.passport);
    }
}

export default PersonSearchCriteria;