import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class PhoneSearchCriteria extends BaseSearchCriteria {
    get phone() {
        return this.get("phone");
    }
    set phone(value) {
        this.set("phone", value).notify();
        this.revalidatePhone();
    }
    get mobile() {
        return this.get("mobile");
    }
    set mobile(value) {
        this.set("mobile", value).notify();
        this.revalidatePhone();
    }
    get home() {
        return this.get("home");
    }
    set home(value) {
        this.set("home", value).notify();
        this.revalidatePhone();
    }
    get work() {
        return this.get("work");
    }
    set work(value) {
        this.set("work", value).notify();
        this.revalidatePhone();
    }
    get business() {
        return this.get("business");
    }
    set business(value) {
        this.set("business", value).notify();
        this.revalidatePhone();
    }
    get other() {
        return this.get("other");
    }
    set other(value) {
        this.set("other", value).notify();
        this.revalidatePhone();
    }
    get phoneError() {
        return this.get("phoneError");
    }
    get hasError() {
        return this.phoneError ? true : false;
    }
    validatePhone() {
        return this.set({
            phoneChecked: true,
            phoneError: this.specified ? undefined : "Please specify at least one Phone Number" 
        }).notify();
    }
    revalidatePhone() {
        if(this.get("phoneChecked")) {
            this.validatePhone();
        }
    }
    validate() {
        return this.validatePhone();
    }
    get specified() {
        return stringUtils.isNotBlank(this.phone)
            || stringUtils.isNotBlank(this.mobile)
            || stringUtils.isNotBlank(this.home)
            || stringUtils.isNotBlank(this.work)
            || stringUtils.isNotBlank(this.business)
            || stringUtils.isNotBlank(this.other);
    }
}

export default PhoneSearchCriteria;