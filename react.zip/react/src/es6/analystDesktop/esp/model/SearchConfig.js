import Model from "util/Model";

class SearchConfig extends Model {
    defaultProps() {
        return { includePnr: true };
    }
    get includePnr() {
        return this.get("includePnr");
    }
    set includePnr(value) {
        this.set("includePnr", value).notify();
    }
}

export default SearchConfig;