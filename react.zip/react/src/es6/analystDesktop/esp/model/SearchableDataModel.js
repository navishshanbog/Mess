import DataModel from "./DataModel";
import stringUtils from "util/string";

class SearchableDataModel extends DataModel {
    constructor(source) {
        super();
        this._sourceObserver = this._sourceChanged.bind(this);
        this.source = source;
    }
    get source() {
        return this._source;
    }
    set source(value) {
        if(value !== this._source) {
            if(this._source) {
                this._source.forget(this._sourceObserver);
            }
            this._source = value;
            if(this._source) {
                this._source.observe(this._sourceObserver);
            }
            this._sourceChanged();
        }
    }
    _sourceChanged() {
        this.set({
            loading: this.source ? this.source.loading : false,
            lastLoadDate: this.source ? this.source.lastLoadDate : undefined,
            error: this.source ? this.source.error : undefined
        });
        this._setDataFromSource();
        this.notify();
    }
    get filter() {
        return this.get("filter");
    }
    set filter(value) {
        this.set("filter", value);
        this._setDataFromSource();
        this.notify();
    }
    get searchText() {
        return this.get("searchText");
    }
    set searchText(value) {
        this.set("searchText", value);
        // filter existing data and update
        this._setDataFromSource();
        this.notify();
    }
    _setDataFromSource() {
        if(this.source) {
            const filter = this.filter;
            const searchText = this.searchText;
            if(filter && searchText) {
                const data = [];
                if(this.source.data) {
                    this.source.data.forEach((r) => {
                        if(filter(r, searchText)) {
                            data.push(r);
                        }
                    })
                }
                this.set("data", data);
            } else {
                this.set("data", this.source.data);
            }
        } else {
            this.set("data", []);
        }
    }
    loadData(data) {
        this.source.loadData(data);
    }
    loadStart(request) {
        this.source.loadStart(request);
    }
    loadError(error) {
        this.source.loadError(error);
    }
    loadComplete(data) {
        this.source.loadComplete(data);
    }
};

export default SearchableDataModel;