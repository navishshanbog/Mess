import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class SystemSearchCriteria extends BaseSearchCriteria {
    get clientId() {
        return this.get("clientId");
    }
    set clientId(value) {
        this.set("clientId", value).notify();
        if(this.get("clientIdChecked")) {
            this.validateClientId();
        }
    }
    get clientIdError() {
        return this.get("clientIdError");
    }
    validateClientId() {
        return this.set({
            clientIdChecked: true,
            clientIdError: stringUtils.isBlank(this.clientId) ? "Please specify a Client ID" : undefined
        }).notify();
    }
    get systemCodes() {
        return this.get("systemCodes");
    }
    set systemCodes(value) {
        this.set("systemCodes", value).notify();
    }
    get hasError() {
        return this.clientIdError ? true : false;
    }
    validate() {
        return this.validateClientId();
    }
    get specified() {
        return stringUtils.isNotBlank(this.clientId);
    }
}

export default SystemSearchCriteria;