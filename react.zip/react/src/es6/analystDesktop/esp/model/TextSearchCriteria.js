import BaseSearchCriteria from "./BaseSearchCriteria";
import stringUtils from "util/string";

class TextSearchCriteria extends BaseSearchCriteria {
    get text() {
        return this.get("text");
    }
    set text(value) {
        this.set("text", value).notify();
    }
    get specified() {
        return stringUtils.isNotBlank(this.text);
    }
}

export default TextSearchCriteria;