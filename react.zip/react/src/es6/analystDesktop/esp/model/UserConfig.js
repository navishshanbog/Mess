import Model from "util/Model";
import stringUtils from "util/string";

class UserConfig extends Model {
    constructor(props) {
        super(props);
    }
    get username() {
        return this.get("username");
    }
    set username(value) {
        this.set("username", value).notify();
        if(this.get("usernameChecked")) {
            this.validateUsername();
        }
    }
    get usernameError() {
        return this.get("usernameError");
    }
    get password() {
        return this.get("password");
    }
    set password(value) {
        this.set("password", value).notify();
        if(this.get("passwordChecked")) {
            this.validatePassword();
        }
    }
    get passwordError() {
        return this.get("passwordError");
    }
    validateUsername() {
        return this.set({
            usernameChecked: true,
            usernameError: stringUtils.isBlank(this.username) ? "Please provide a username" : undefined
        }).notify();
    }
    validatePassword() {
        return this.set({
            passwordChecked: true,
            passwordError: stringUtils.isBlank(this.password) ? "Please provide a password" : undefined
        }).notify();
    }
    get hasError() {
        return this.usernameError || this.passwordError;
    }
    validate() {
        return this.validateUsername().validatePassword();
    }
}

export default UserConfig;