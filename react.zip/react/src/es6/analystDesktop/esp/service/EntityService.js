import PromiseProxy from "util/PromiseProxy";
import TDQueryEntityService from "./impl/TDQueryEntityService";

const EntityService = new PromiseProxy();
EntityService.methods = [
    "search",
    "getMasteredDetails",
    "getMasteredRefDetails",
    "getSourceSystemDetails",
    "getIATTravellerPhoto",
    "getIATTravellerMovement",
    "getBAGSExams",
    "getPNRTravellerMovement",
    "getCargoAirReport",
    "getCargoSeaReport",
    "getDGMSActivities"
];
// TODO: Base on application config etc
EntityService.target = new TDQueryEntityService();
export default EntityService;