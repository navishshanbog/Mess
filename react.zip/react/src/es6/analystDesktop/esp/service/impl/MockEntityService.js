import promiseUtils from "util/promise";

class Mock {
    get searchResult() {
        if (!this._searchResult) {
            this._searchResult = {
                data: [
                    {
                        "MSTR_ENTY_ID": 760637166,
                        "MDM_PRFL_NM": "LEFTOVER - NEW ROW",
                        "MSTRD_IND": "Y",
                        "NAME": "MICHAEL TRUSSLER",
                        "DT_OF_BRTH": "1972-02-03",
                        "SEX": "MALE",
                        "ADDRESS": null,
                        "PHONE": null,
                        "CRDNTL": "0870110486872670129951301000(VISA)",
                        "PNR": 0,
                        "ICS": 0,
                        "IAT": 1,
                        "BAGS": 0,
                        "INTCP": 0,
                        "DGMS": 0,
                        "RFRNC": 0,
                        "ALL_SYST": 1
                    },
                    {
                        "MSTR_ENTY_ID": 760637166,
                        "MDM_PRFL_NM": "LEFTOVER - NEW ROW",
                        "MSTRD_IND": "Y",
                        "NAME": "MICHAEL TRUSSLER",
                        "DT_OF_BRTH": "1972-02-03",
                        "SEX": "MALE",
                        "ADDRESS": null,
                        "PHONE": null,
                        "CRDNTL": "0870110486872670129951301000(VISA)",
                        "PNR": 0,
                        "ICS": 0,
                        "IAT": 1,
                        "BAGS": 0,
                        "INTCP": 0,
                        "DGMS": 0,
                        "RFRNC": 0,
                        "ALL_SYST": 1
                    },
                    {
                        "MSTR_ENTY_ID": 328665107,
                        "MDM_PRFL_NM": "LEFTOVER - NEW ROW",
                        "MSTRD_IND": "Y",
                        "NAME": "MICHAEL TRUSSLER",
                        "DT_OF_BRTH": null,
                        "SEX": null,
                        "ADDRESS": "19 PANT STREET TOOWOOMBA REGIONAL QLD AU",
                        "PHONE": null,
                        "CRDNTL": null,
                        "PNR": 0,
                        "ICS": 1,
                        "IAT": 0,
                        "BAGS": 0,
                        "INTCP": 0,
                        "DGMS": 0,
                        "RFRNC": 0,
                        "ALL_SYST": 1
                    }
                ],
                rowLimitExceeded: false
            };
        }
        return this._searchResult;
    }
    set searchResult(value) {
        this._searchResult = value;
    }
    search(params) {
        return promiseUtils.invokeDelayed(() => {
            return this.searchResult;
        }, { delay: 500 });
    }
    get masteredDetails() {
        if (!this._masteredDetails) {
            this._masteredDetails = [
                { "MSTR_ENTY_ID": 328665107, "ENTY_NM_ID": 499147586, "NAME": "MICHAEL TRUSSLER", "DT_OF_BRTH": null, "SEX": null, "ENTY_ADRS_ID": 380799448, "ADDRESS": "19 PANT STREET TOOWOOMBA REGIONAL QLD AU", "ENTY_PHN_ID": null, "PHONE": null, "ENTY_CRDNTL_ID": null, "CRDNTL": null }
            ];
        }
        return this._masteredDetails;
    }
    set masteredDetails(value) {
        this._masteredDetails = value;
    }
    getMasteredDetails(params) {
        return promiseUtils.invokeDelayed(() => {
            return [].concat(this.masteredDetails);
        }, { delay: 500 });
    }
    get sourceSystemDetails() {
        if(!this._sourceSystemDetails) {
            this._sourceSystemDetails = [

            ]
        }
        return this._sourceSystemDetails;
    }
    set sourceSystemDetails(value) {
        this._sourceSystemDetails = value;
    }
    getSourceSystemDetails(params) {
        return promiseUtils.invokeDelayed(() => {
            return [].concat(this.sourceSystemDetails);
        }, { delay: 500 });
    }
    get masteredRefDetails() {
        if (!this._masteredRefDetails) {
            this._masteredRefDetails = [{"MSTR_ENTY_ID":328665107,"MDM_PRFL_NM":"LEFTOVER - NEW ROW","MSTRD_IND":"Y","SRC_SYST_CD":"ICS","SRC_RLTD_KY_VLU":"952683745177922","SRC_ENTY_ID":328665107,"CLIENT_CREATED_DT":"2012-10-23","SEX_CD":"NA","DT_OF_BRTH":null,"NAME":"MICHAEL TRUSSLER","STD_ADRS_GEO_VLU":"QLD AU","PHN_NBR":null,"CRDNTL":null}
            ];
        }
        return this._masteredDetails;
    }
    set masteredRefDetails(value) {
        this._masteredRefDetails = value;
    }
    getMasteredRefDetails(params) {
        return promiseUtils.invokeDelayed(() => {
            return [].concat(this.masteredRefDetails);
        }, { delay: 500 });
    }
}

export default Mock;