import pathUtils from "util/path";
import stringUtils from "util/string";
import lang from "util/lang";
import TDQueryService from "./TDQueryService";

class TDQueryEntityService {
    constructor(queryService) {
        this.queryService = queryService;
    }
    get queryService() {
        if(!this._queryService) {
            this._queryService = new TDQueryService();
        }
        return this._queryService;
    }
    set queryService(value) {
        this._queryService = value;
    }
    _getResult(response) {
        let data = [];
        let rowLimitExceeded = false;
        if(response && response.results && response.results.length > 0) {
            response.results.forEach((result) => {
                if(result && result.data) {
                    data = data.concat(result.data);
                    if(result.rowLimitExceeded) {
                        rowLimitExceeded = true;
                    }
                }
            });
        }
        return { data: data, rowLimitExceeded: rowLimitExceeded };
    }
    createSearchQueryArgs(request) {
        let queryArgs = {
            REQUEST_TYPE: "MASTER_SEARCH",
            includePnr: request.includePnr
        };
        if(request.system) {
            queryArgs.SRC_KY_VLU = request.system.clientId;
        }
        if(request.person) {
            queryArgs.ORG_NM = request.person.fullName;
            queryArgs.FRST_NM = request.person.firstName;
            queryArgs.MDL_NM = request.person.middleName;
            queryArgs.FMLY_NM = request.person.lastName;
            queryArgs.DT_OF_BRTH = request.person.dob;
            queryArgs.SEX_CD = request.person.gender;
            queryArgs.CRDNTL_VLU_PP = request.person.passport;
        }
        
        if(request.address) {
            queryArgs.STD_ADRS_VLU = request.contact.fullAddress;
            queryArgs.UNIT_ID = request.contact.unitNumber;
            queryArgs.RD_FRST_ID = request.contact.streetNumber;
            queryArgs.RD_NM = request.contact.streetName;
            queryArgs.RD_TYP_ABRVTN = request.contact.streetType;
            queryArgs.LCLTY_NM = request.contact.locality;
            queryArgs.STE_CD = request.contact.state;
            queryArgs.PST_CD = request.contact.postcode;
        }
        if(request.phone) {
            queryArgs.PHN_NBR = request.phone.phone;
        }
        if(request.org) {
            queryArgs.ORG_NM = request.org.name;
            queryArgs.CRDNTL_VLU_ABN = request.org.abn;
        }
        return queryArgs;
    }
    search(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createSearchQueryArgs(request),
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    createMasteredDetailsQueryArgs(request) {
        return {
            REQUEST_TYPE: "MSTR_DETAIL",
            MSTR_ENTY_ID: request.id
        };
    }
    getMasteredDetails(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createMasteredDetailsQueryArgs(request),
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    createMasteredRefDetailsQueryArgs(request) {
        return {
            REQUEST_TYPE: "REF_DETAIL",
            includePnr: request.includePnr,
            MSTR_ENTY_ID: request.id
        }
    }
    getMasteredRefDetails(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createMasteredRefDetailsQueryArgs(request),
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    createSourceSystemDetailsQueryArgs(request) {
        return {
            REQUEST_TYPE: "MSTR_LINEAGE",
            MSTR_ENTY_ID: request.id
        };
    }
    getSourceSystemDetails(request) {
       const query = {
            name: "SB_EntitySearchPortal_DB.ESP_Search_Request_MDM",
            args: this.createSourceSystemDetailsQueryArgs(request),
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getIATTravellerPhoto(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_IAT",
            args: [
                {
                    IAT_TRAVELLER_ID: request.id,
                    sqlRequestType: "PHOTO"
                },
                "executedSqlStmt"
            ],
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getIATTravellerMovement(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_IAT",
            args: [
                {
                    sqlRequestType: "MVMT-ALL"
                },
                "executedSqlStmt"
            ],
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getBAGSExams(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_BAGS",
            args: [
                { sqlRequestType: "EXM-All" },
                "executedSqlStmt"
            ],
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getPNRTravellerMovement(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_PNR",
            args: [
                {
                    sqlRequestType: "MVMT-ALL"
                },
                "executedSqlStmt"
            ],
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getCargoAirReport(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_Cargo",
            args: [
                {
                    sqlRequestType: "ACR-ALL"
                },
                "executedSqlStmt"
            ],
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getCargoSeaReport(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_Cargo",
            args: [
                {
                    sqlRequestType: "SCR-ALL"
                },
                "executedSqlStmt"
            ],
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        });
    }
    getDGMSActivities(request) {
        const query = {
            name: "SB_EntitySearchPortal_DB.ds_DGMS",
            args: [
                {
                    sqlRequestType: "DTN-ALL"
                },
                "executedSqlStmt"
            ],
            userConfig: request.userConfig
        };
        return this.queryService.callQuery(query).then((response) => {
            return this._getResult(response);
        }); 
    }
}

export default TDQueryEntityService;