import * as React from "react";
import testRunner from "test/runner";
import TDQueryEntityService from "./TDQueryEntityService";
import EntitySearchConfig from "../../model/EntitySearchConfig";
import EntitySearchConfigEditor from "../../view/EntitySearchConfigEditor";
import PersonSearchCriteria from "../../model/PersonSearchCriteria";
import PersonSearchEditor from "../../view/PersonSearchEditor";
import IdSearchCriteria from "../../model/IdSearchCriteria";
import IdSearchEditor from "../../view/IdSearchEditor";
import css from "util/css";

const testService = new TDQueryEntityService();

const configModel = new EntitySearchConfig();
const personModel = new PersonSearchCriteria();
const entityIdModel = new IdSearchCriteria();
const travellerIdModel = new IdSearchCriteria();
const configEditor = <EntitySearchConfigEditor model={configModel} />;
const personEditor = <PersonSearchEditor model={personModel} />;
const entityIdEditor = <IdSearchEditor model={entityIdModel} label="Entity ID" />;
const travellerIdEditor = <IdSearchEditor model={travellerIdModel} label="Traveller ID" />;

const suite = {
    title: "Teradata Search Service Implementation Test",
    testSearchConfig(ctx) {
        configModel.clear();
        ctx.view(configEditor);
    },
    testPersonSearch(ctx) {
        personModel.clear();
        ctx.view(personEditor);
        const searchAction = () => {
            const request = {
                includePnr: configModel.includePnr,
                person: personModel.params,
                userConfig: {
                    username: configModel.user.username,
                    password: configModel.user.password
                }
            };
            ctx.message("Searching:", request);
            return testService.search(request).then((result) => {
                ctx.message("Search Result:", result);
            }).catch((err) => {
                ctx.error(err);  
            });
        };
        ctx.action(searchAction, "Search");
    },
    testIdSearch(ctx) {
        entityIdModel.clear();
        ctx.view(entityIdEditor);
        const loadAction = () => {
            const request = {
                id: entityIdModel.id,
                includePnr: configModel.includePnr,
                userConfig: {
                    username: configModel.user.username,
                    password: configModel.user.password
                }
            };
            ctx.message("Loading Mastered Details for Entity:", request);
            const masteredDetailsPromise = testService.getMasteredDetails(request).then((result) => {
                ctx.message("Mastered Details:", result);
            }).catch((err) => {
                ctx.error(err);
            });

            ctx.message("Loading Mastered Ref Details for Entity:", request);
            const masteredRefDetailsPromise = testService.getMasteredRefDetails(request).then((result) => {
                ctx.message("Mastered Ref Details", result);
            }).catch((err) => {
                ctx.error(err);  
            });

            ctx.message("Loading Source System Details for Entity:", request);
            const sourceSystemDetailsPromise = testService.getSourceSystemDetails(request).then((result) => {
                ctx.message("Source System Details", result);
            }).catch((err) => {
                ctx.error(err);  
            });

            return Promise.all([masteredDetailsPromise, masteredRefDetailsPromise, sourceSystemDetailsPromise]);
        };
        ctx.action(loadAction, "Load Entity");
    },
    testIATTravellerDetails(ctx) {
        travellerIdModel.clear();
        ctx.view(travellerIdEditor);
        const loadAction = () => {
            const request = {
                id: travellerIdModel.id,
                userConfig: {
                    username: configModel.user.username,
                    password: configModel.user.password
                }
            };

            ctx.message("Loading IAT Traveller Photo");
            const iatTravellerPhotoPromise = testService.getIATTravellerPhoto(request).then((result) => {
                ctx.message("Traveller Photo Result", result);
            }).catch((err) => {
                ctx.error(err);
                return Promise.reject(err);
            });

            ctx.message("Loading IAT Traveller Movement");
            const iatTravellerMovementPromise = testService.getIATTravellerMovement(request).then((result) => {
                ctx.message("Traveller Movement Result", result);
            }).catch((err) => {
                ctx.error(err);
                return Promise.reject(err);
            });

            ctx.message("Loading BAGS Examinations");
            const bagsExamsPromise = testService.getBAGSExams(request).then((result) => {
                ctx.message("BAGS Exams Result", result);
            }).catch((err) => {
                ctx.error(err);
                return Promise.reject(err);  
            });

            ctx.message("Loading PNR Traveller Movement");
            const pnrTravellerMovementPromise = testService.getPNRTravellerMovement(request).then((result) => {
                ctx.message("PNR Movement Result", result);
            }).catch((err) => {
                ctx.error(err);
                return Promise.reject(err);  
            });
            
            ctx.message("Loading AIR Cargo Report");
            const airCargoReportPromise = testService.getCargoAirReport(request).then((result) => {
                ctx.message("AIR Cargo Report Result", result);
            }).catch((err) => {
                ctx.error(err);
                return Promise.reject(err);  
            });

            ctx.message("Loading SEA Cargo Report");
            const seaCargoReportPromise = testService.getCargoSeaReport(request).then((result) => {
                ctx.message("SEA Cargo Report Result", result);
            }).catch((err) => {
                ctx.error(err);
                return Promise.reject(err);  
            });

            ctx.message("Loading DGMS Activities");
            const dgmsActivitiesPromise = testService.getDGMSActivities(request).then((result) => {
                ctx.message("DGMS Activities Result", result);
            }).catch((err) => {
                ctx.error(err);
                return Promise.reject(err);
            });

            return Promise.all([
                iatTravellerPhotoPromise,
                iatTravellerMovementPromise,
                bagsExamsPromise,
                pnrTravellerMovementPromise,
                airCargoReportPromise,
                seaCargoReportPromise,
                dgmsActivitiesPromise
            ]);
        };
        ctx.action(loadAction, "Load Traveller Details");
    }
};

export default () => {
    testRunner({
        suite: suite
    });
};