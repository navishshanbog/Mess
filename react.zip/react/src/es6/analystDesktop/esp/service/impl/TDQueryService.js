import pathUtils from "util/path";
import stringUtils from "util/string";
import lang from "util/lang";
import config from "../../config";

class TDQueryService {
    get baseUrl() {
        if(!this._baseUrl) {
            this._baseUrl = config.tdQueryBaseUrl;
        }
        return this._baseUrl;
    }
    set baseUrl(value) {
        this._baseUrl = value;
        delete this._queryUrl;
        delete this._sessionUrl;
    }
    get queryUrl() {
        if(!this._queryUrl) {
            this._queryUrl = this.baseUrl + "/tdrest/systems/PTD1/queries";
        }
        return this._queryUrl;
    }
    get sessionUrl() {
        if(!this._sessionUrl) {
            this._sessionUrl = this.baseUrl + "/tdrest/systems/PTD1/sessions";
        }
        return this._sessionUrl;
    }
    createSessionPayload() {
        return {
            logMech: "LDAP",
            queryBands: {
                ApplicationName: "ESP"
            }
        };
    }
    _resolveResponse(xhr) {
        if(lang.isString(xhr.response)) {
            try {
                return JSON.parse(xhr.response);
            } catch(e) {
                return xhr.response;
            }
        }
        return xhr.response;
    }
    _createSession(userConfig) {
        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", this.sessionUrl);
            xhr.responseType = "json";
            let basicAuth = btoa(userConfig.username + ":" + userConfig.password);
            xhr.setRequestHeader("Authorization", "Basic " + basicAuth);
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.onload = (e) => {
                if(xhr.status >= 200 && xhr.status < 300) {
                    resolve(this._resolveResponse(xhr));
                } else {
                    reject(this._resolveResponse(xhr));
                }
            };

            xhr.onerror = (e) => {
                reject(e);
            };

            xhr.send(JSON.stringify(this.createSessionPayload()));
        });
    }
    _ensureSession(userConfig) {
        console.log("-- Ensure Session: " + JSON.stringify(userConfig));
        if(userConfig && userConfig.username) {
            const username = userConfig.username;
            
            if(this._sessions && this._sessions[username]) {
                console.log("-- Using Existing Session for " + username);
                return Promise.resolve(this._sessions[username]);
            }

            if(!this._sessionCreatePromises) {
                this._sessionCreatePromises = {};
            }

            if(this._sessionCreatePromises[username]) {
                return this._sessionCreatePromises[username];
            }

            const sessionCreatePromise = this._createSession(userConfig).then((session) => {
                if(!this._sessions) {
                    this._sessions = {};
                }
                this._sessions[username] = session;
                delete this._sessionCreatePromises[username];
                session.userConfig = userConfig;
                return session;
            }).catch((err) => {
                delete this._sessionCreatePromises[username];
                return Promise.reject(err);
            });

            this._sessionCreatePromises[username] = sessionCreatePromise;

            return sessionCreatePromise;
        }
        return Promise.reject("No User Credentials Specified");
    }
    _callQueryInternal(query, session) {
        const args = query.args;
        const argStrings = [];
        if(lang.isArray(args)) {
            args.forEach((arg) => {
                if(lang.isObject(arg) && arg !== null) {
                    argStrings.push(`'${JSON.stringify(arg)}'`);
                } else if(lang.isString(arg)) {
                    argStrings.push(arg);
                }
            });
        } else if(lang.isObject(args)) {
            argStrings.push(`'${JSON.stringify(args)}'`);
        } else if(lang.isString(args)) {
            argStrings.push(args);
        }
        const argString = argStrings.join(",");
        let queryString = `CALL ${query.name}(${argString});`;
        let request = {
            format: "object",
            includeColumns: query.includeColumns ? true : false,
            logMech: "LDAP",
            query: queryString,
            queryBands: {
                ApplicationName: "ESP"
            },
            rowLimit: !isNaN(query.rowLimit) && query.rowLimit > 0 ? query.rowLimit : 1000,
            session: session.sessionId
        };

        return new Promise((resolve, reject) => {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", this.queryUrl);
            xhr.responseType = "json";
            let userConfig = session.userConfig;
            let basicAuth = btoa(userConfig.username + ":" + userConfig.password);
            xhr.setRequestHeader("Authorization", "Basic " + basicAuth);
            xhr.setRequestHeader("Content-Type", "application/json");

            xhr.onload = (e) => {
                if(xhr.status >= 200 && xhr.status < 300) {
                    resolve(this._resolveResponse(xhr));
                } else {
                    const response = this._resolveResponse(xhr);
                    if(response) {
                        response.statusCode = xhr.status;
                    }
                    reject(response);
                }
            };

            xhr.onerror = (e) => {
                reject(e);
            };

            xhr.send(JSON.stringify(request));
        });
    }
    isSessionNotFoundError(err) {
        return err && err.statusCode === 404 && stringUtils.containsIgnoreCase(err.message, "Session not found");
    }
    _deleteSession(userConfig) {
        if(userConfig && userConfig.username) {
            delete this._sessions[userConfig.username];
        }
    }
    callQueryNewSession(query) {
        this._deleteSession(query.userConfig);
        return this.callQuery(query);
    }
    callQuery(query) {
        return this._ensureSession(query.userConfig).then((session) => {
            console.log(`Session: ${JSON.stringify(session)}`);
            return this._callQueryInternal(query, session).catch((err) => {
                if(this.isSessionNotFoundError(err)) {
                    return this.callQueryNewSession(query);
                }
            });
        });
    }
}

export default TDQueryService;