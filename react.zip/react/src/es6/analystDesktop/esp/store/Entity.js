import Entity from "../model/Entity";

export default new Entity();