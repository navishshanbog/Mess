import EntityList from "../model/EntityList";

export default new EntityList();