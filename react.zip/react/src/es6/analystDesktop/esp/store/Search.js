import ConfigurableEntitySearchCriteria from "../model/ConfigurableEntitySearchCriteria";

export default new ConfigurableEntitySearchCriteria();