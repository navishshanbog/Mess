import SearchConfig from "../model/SearchConfig";

export default new SearchConfig();