import UserConfig from "../model/UserConfig";

export default new UserConfig();