import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundSelect from "form/view/BoundSelect";
import BoundFormGroup from "form/view/BoundFormGroup";
import BoundAlert from "form/view/BoundAlert";
import idUtils from "util/id";

class AddressSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        
        this.ids = {
            fullAddress: idUtils.next("fullAddress"),
            unitNumber: idUtils.next("unitNumber"),
            streetNumber: idUtils.next("streetNumber"),
            streetName: idUtils.next("streetName"),
            streetType: idUtils.next("streetType"),
            locality: idUtils.next("locality"),
            state: idUtils.next("state"),
            postcode: idUtils.next("postcode"),
            helpId: idUtils.next("nameHelp")
        }
    }
    render() {
        return (
            <div className="address-search-editor">
                <BoundAlert id={this.ids.helpId} model={this.props.model} name="addressError" className="alert-danger">
                    <span className="glyphicon glyphicon-info-sign"></span>
                </BoundAlert>
                <BoundFormGroup className="form-group full-address-group" model={this.props.model} errorName="addressError">
                    <label htmlFor={this.ids.fullAddress}>Full Address</label>
                    <BoundInput type="text" id={this.ids.fullAddress} className="form-control" model={this.props.model} name="fullAddress" placeholder="Full Address" />
                </BoundFormGroup>
                <BoundFormGroup className="unit-number-group" model={this.props.model} name="unitNumber" errorName="addressError">
                    <label htmlFor={this.ids.unitNumber}>Unit Number</label>
                    <BoundInput type="text" id={this.ids.unitNumber} className="form-control" model={this.props.model} name="unitNumber" placeholder="Unit Number" />
                </BoundFormGroup>
                <BoundFormGroup className="street-number-group" model={this.props.model} errorName="addressError">
                    <label htmlFor={this.ids.streetNumber}>Street Number</label>
                    <BoundInput type="text" id={this.ids.streetNumber} className="form-control" model={this.props.model} name="streetNumber" placeholder="Street Number" />
                </BoundFormGroup>
                <BoundFormGroup className="street-name-group" model={this.props.model} errorName="addressError">
                    <label htmlFor={this.ids.streetName}>Street Name</label>
                    <BoundInput type="text" id={this.ids.streetName} className="form-control" model={this.props.model} name="streetName" placeholder="Street Name" />
                </BoundFormGroup>
                <BoundFormGroup className="street-type-group" model={this.props.model} errorName="addressError">
                    <label htmlFor={this.ids.streetType}>Street Type</label>
                    <BoundSelect id={this.ids.streetType} className="form-control" model={this.props.model} name="streetType" placeholder="Street Type">
                        <option value="">Street Type...</option>
                        <option value="STREET">Street</option>
                        <option value="ROAD">Road</option>
                    </BoundSelect>
                </BoundFormGroup>
                <BoundFormGroup className="locality-group" model={this.props.model} errorName="addressError">
                    <label htmlFor={this.ids.locality}>Locality</label>
                    <BoundInput id={this.ids.locality} type="text" className="form-control" model={this.props.model} name="locality" placeholder="Locality" />
                </BoundFormGroup>
                <BoundFormGroup className="state-group" model={this.props.model} errorName="addressError">
                    <label htmlFor={this.ids.state}>State</label>
                    <BoundSelect id={this.ids.state} className="form-control" model={this.props.model} name="state" placeholder="State">
                        <option value="">State...</option>
                        <option value="NSW">New South Wales</option>
                        <option value="VIC">Victoria</option>
                        <option value="ACT">ACT</option>
                        <option value="QLD">Queensland</option>
                        <option value="WA">Western Australia</option>
                        <option value="SA">South Australia</option>
                        <option value="NT">Northern Territory</option>
                        <option value="TAS">Victoria</option>
                    </BoundSelect>
                </BoundFormGroup>
                <BoundFormGroup className="postcode-group" model={this.props.model} errorName="addressError">
                    <label htmlFor={this.ids.postcode}>Postcode</label>
                    <BoundInput id={this.ids.postcode} type="text" className="form-control" model={this.props.model} name="postcode" placeholder="Postcode" />
                </BoundFormGroup>
            </div>
        );
    }
}

export default AddressSearchEditor;