import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundFormGroup from "form/view/BoundFormGroup";
import BoundHelpBlock from "form/view/BoundHelpBlock";
import idUtils from "util/id";

class BirthSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            dob: idUtils.next("dob")
        }
    }
    render() {
        return (
            <div className="birth-search-editor">
                <BoundFormGroup className="dob-group" model={this.props.model} errorName="dobError">
                    <label htmlFor={this.ids.dob}>Date of Birth</label>
                    <BoundInput id={this.ids.dob} type="text" className="form-control dob" model={this.props.model} name="dob" placeholder="Date of Birth" />
                    <BoundHelpBlock model={this.props.model} name="dobError" />
                </BoundFormGroup>
            </div>
        );
    }
}

export default BirthSearchEditor;