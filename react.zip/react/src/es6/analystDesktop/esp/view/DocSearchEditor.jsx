import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundSelect from "form/view/BoundSelect";
import idUtils from "util/id";

class DocSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            documentType: idUtils.next("docType"),
            documentNumber: idUtils.next("docNumber"),
            issueCountry: idUtils.next("docIssueCountry")
        }
    }
    render() {
        return (
            <div className="doc-search-editor">
                <div className="form-group doc-type-group">
                    <label htmlFor={this.ids.docType}>Credential Type</label>
                    <BoundSelect id={this.ids.docType} className="form-control doc-type" model={this.props.model} name="documentType" placeholder="Document Type">
                        <option value="">Document Type...</option>
                        <option value="PASSPORT">Passport</option>
                        <option value="DRIVERLICENCE">Driver Licence</option>
                    </BoundSelect>
                </div>
                <div className="form-group doc-number-group">
                    <label htmlFor={this.ids.docNumber}>Credential Number</label>
                    <BoundInput id={this.ids.docNumber} type="text" className="form-control doc-number" model={this.props.model} name="documentNumber" placeholder="Document Number" />
                </div>
                <div className="form-group doc-issue-country-group">
                    <label htmlFor={this.ids.docIssueCountry}>Credential Issue Country</label>
                    <BoundSelect id={this.ids.docIssueCountry} className="form-control doc-issue-country" model={this.props.model} name="documentIssueCountry" placeholder="Issue Country" title="Issue Country">
                        <option value="">Issue Country...</option>
                        <option value="Australia">Australia</option>
                        <option value="New Zealand">New Zealand</option>
                    </BoundSelect>
                </div>
            </div>
        );
    }
}

export default DocSearchEditor;