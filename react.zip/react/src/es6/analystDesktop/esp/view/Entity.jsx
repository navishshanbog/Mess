import * as React from "react";
import EntityDetails from "./EntityDetails";

class Entity extends React.Component {
    render() {
        return (
            <EntityDetails model={this.props.model.details} />
        );
    }
}

export default Entity;