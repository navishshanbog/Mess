import * as React from "react";

class EntityActivityList extends React.Component {

}

export default EntityActivityList;