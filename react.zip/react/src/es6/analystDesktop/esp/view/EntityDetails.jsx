import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class EntityDetails extends BoundComponent {
    get modelState() {
        return { loading: this.model.loading, error: this.model.error, data: this.model.data };
    }
    _modelChanged() {
        if(this.model.isPropChanged("data") || this.model.isPropChanged("loading") || this.model.isPropChanged("error")) {
            this.setStateFromModel();
        }
    }
    render() {
        return (
            <div>
                <pre>{JSON.stringify(this.state, null, "\t")}</pre>
            </div>
        );
    }
}

export default EntityDetails;