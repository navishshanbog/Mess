import * as React from "react";
import stringUtils from "util/string";
import EntityListItem from "./EntityListItem";
import idUtils from "util/id";

class EntityList extends React.Component {
    render() {
        let items;
        let data = this.props.data;
        if(data && data.length > 0) {
            let idMap = {};
            items = data.map((item, idx) => {
                return <EntityListItem key={idx} item={item} actions={this.props.actions} />;
            });
        } else {
            items = <tr><td colSpan="9" style={ { textAlign: "center" } }>No matching Entities Found</td></tr>;
        }
        return (
            <table className="table table-bordered table-hover" ref={(input) => this._tableRef = input}>
                <thead>
                    <tr>
                        <th>Mastered</th>
                        <th>Name</th>
                        <th>Date of Birth</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Credential (Type)</th>
                        <th>Source Systems</th>
                    </tr>
                </thead>
                <tbody>
                    {items}
                </tbody>
            </table>
        );
    }
}

export default EntityList;