import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import Error from "common/view/Error";
import EntityList from "./EntityList";

class EntityListContainer extends BoundComponent {
    get modelState() {
        return this.model ? {
            loading: this.model.loading,
            params: this.model.params,
            data: this.model.data || [],
            error: this.model.error,
            lastLoadDate: this.model.lastLoadDate
        } : {};
    }
    _modelChanged() {
        if(this.model.isPropChanged("loading") ||
           this.model.isPropChanged("params") || 
           this.model.isPropChanged("data") ||
           this.model.isPropChanged("error") ||
           this.model.isPropChanged("lastLoadDate")) {
            this.setStateFromModel();
        }
    }
    render() {
        let content;
        if(this.state.loading) {
            content =
                <div className="container">
                    <div className="alert alert-info">
                        <span className="glyphicon glyphicon-refresh spin"></span> Searching...
                    </div>
                </div>;
        } else if(this.state.error) {
            content = 
                <div className="container">
                    <Error error={this.state.error} />
                </div>
        } else if(this.state.lastLoadDate) {
            content = 
                <div className="container-fluid">
                    <EntityList data={this.state.data} actions={this.props.actions} />
                </div>;
        } else {
            content =
                <div className="container">
                    <div className="alert alert-info">
                        <span className="glyphicon glyphicon-info-sign"></span> <strong>You'll have to perform a search to see anything here</strong>
                    </div>
                </div>;
        }
        return content;
    }
}

export default EntityListContainer;