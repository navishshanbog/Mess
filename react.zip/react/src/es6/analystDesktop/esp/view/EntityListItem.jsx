import * as React from "react";
import stringUtils from "util/string";

class SystemHitCount extends React.Component {
    render() {
        if(this.props.count > 0) {
            return <span className="nowrap label label-success">{this.props.label}: {this.props.count}</span>
        }
        return false;
    }
}

class EntityListItem extends React.Component {
    constructor(props) {
        super(props);
        this._handleItemClick = this._handleItemClick.bind(this);
    }
    _handleItemClick(e) {
        if(this.props.actions && this.props.actions.selectEntity) {
            this.props.actions.selectEntity(this.props.item);
        }
    }
    render() {
        let item = this.props.item;
        return (
            <tr onClick={this._handleItemClick}>
                <td style={ { textAlign: "center" } }>
                    <span className={item.MSTR_ENTY_ID ? "label label-default" : undefined }>{item.MSTR_ENTY_ID || ""}</span>
                </td>
                <td>
                    {item.NAME || ""}
                </td>
                <td>
                    {item.DT_OF_BRTH || ""}
                </td>
                <td>
                    {item.SEX || ""}
                </td>
                <td>
                    {item.ADDRESS || ""}
                </td>
                <td>
                    {item.PHONE || ""}
                </td>
                <td>
                    {item.CRDNTL || ""}
                </td>
                <td>
                    <SystemHitCount key="ICS" label="ICS" count={item.ICS} />
                    {" "}
                    <SystemHitCount key="PNR" label="PNR" count={item.PNR} />
                    {" "}
                    <SystemHitCount key="IAT" label="IAT" count={item.IAT} />
                    {" "}
                    <SystemHitCount key="BAGS" label="BAGS" count={item.BAGS} />
                    {" "}
                    <SystemHitCount key="INTCP" label="INTCP" count={item.INTCP} />
                    {" "}
                    <SystemHitCount key="DGMS" label="DGMS" count={item.DGMS} />
                    {" "}
                    <SystemHitCount key="RFRNC" label="RFRNC" count={item.RFRNC} />
                </td>
            </tr>
        );
    }
}

export default EntityListItem;