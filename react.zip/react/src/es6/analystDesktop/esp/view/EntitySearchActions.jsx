import * as React from "react";

class EntitySearchActions extends React.Component {
    constructor(props) {
        super(props);
        this._handleClearClick = this._handleClearClick.bind(this);
        this._handleSearchClick = this._handleSearchClick.bind(this);
    }
    _handleClearClick(e) {
        e.stopPropagation();
        if(this.props.actions) {
            this.props.actions.clearSearch(e);
        }
    }
    _handleSearchClick(e) {
        e.stopPropagation();
        if(this.props.actions) {
            const result = this.props.actions.search();
        }
    }
    render() {
        return (
            <div className="actions entity-search-actions">
                <div className="actions-previous">
                    <button type="button" className="btn btn-primary action action-clear" title="Clear Search Criteria" onClick={this._handleClearClick}>
                        <span className="glyphicon glyphicon-remove"></span> Clear
                    </button>
                </div>
                <div className="actions-next">
                    <button type="button" className="btn btn-primary action action-search" title="Search Entities" onClick={this._handleSearchClick}>
                        <span className="glyphicon glyphicon-search"></span> Search
                    </button>
                </div>
            </div>
        );
    }
}

export default EntitySearchActions;