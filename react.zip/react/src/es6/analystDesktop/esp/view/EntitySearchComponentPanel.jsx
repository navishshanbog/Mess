import * as React from "react";
import SearchViewRegistry from "./SearchViewRegistry";
import lang from "util/lang";

class EntitySearchComponentPanel extends React.Component {
    render() {
        const c = this.props.component;
        if(c) {
            const reg = SearchViewRegistry[c.id];
            if(reg) {
                const editor = reg.editor(c.model);
                if(editor) {
                    const icon = lang.isString(reg.icon) ? <span className={"glyphicon glyphicon-" + reg.icon}></span> : reg.icon;
                    return (
                        <div key={c.id} className={"panel panel-primary editor-component-panel-" + c.id}>
                            <div className="panel-heading">
                                {icon} {reg.title}
                            </div>
                            <div className="panel-body">
                                {editor}
                            </div>
                        </div>
                    );
                }
            }
        }
        return false;
    }
}

export default EntitySearchComponentPanel;
