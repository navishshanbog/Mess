import * as React from "react";
import SearchComponentSelectAction from "./SearchComponentSelectAction";
import SearchViewRegistry from "./SearchViewRegistry";
import lang from "util/lang";

class EntitySearchComponentSelector extends React.Component {
    render() {
        const items = this.props.model.components.map((c) => {
            const reg = SearchViewRegistry[c.id];
            if(reg) {
                const icon = lang.isString(reg.icon) ? <span className={"glyphicon glyphicon-" + reg.icon}></span> : reg.icon;
                return (
                    <SearchComponentSelectAction key={c.id} model={this.props.model} criteria={c} title={reg.title}>
                        {icon} {reg.title}
                    </SearchComponentSelectAction>
                );
            }
        });

        return (
           <ul className="nav nav-pills entity-search-component-selector" role="group" aria-label="Search Criteria Selector">
                {items}
           </ul>
       );
    }
}

export default EntitySearchComponentSelector;