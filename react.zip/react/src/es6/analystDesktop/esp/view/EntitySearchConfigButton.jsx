import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import css from "util/css";

class EntitySearchUserConfigButton extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        return { active: this.model ? this.model.active : false };
    }
    _modelChanged() {
        if(this.model.isPropChanged("active")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
        if(this.model) {
            this.model.toggleActive();
        }
    }
    render() {
        const viewProps = Object.assign({}, this.props);
        delete viewProps.type;
        delete viewProps.onClick;
        delete viewProps.className;
        delete viewProps.model;
        return (
            <button {...viewProps} type="button" title="Configure" className={css.className(this.props.className, "search-criteria-select-action", "btn", "btn-default", this.state.active ? "active" : undefined)} onClick={this._handleClick}>
                <span className="glyphicon glyphicon-cog"></span>
            </button>
        );
    }
}

export default EntitySearchUserConfigButton;