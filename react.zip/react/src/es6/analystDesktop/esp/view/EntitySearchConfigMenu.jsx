import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import EntitySearchConfigEditor from "./EntitySearchConfigEditor";

class EntitySearchConfigMenu extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleCloseClick = this._handleCloseClick.bind(this);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        return { active: this.model ? this.model.active : false };
    }
    _modelChanged() {
        if(this.model.isPropChanged("active")) {
            this.setStateFromModel();
        }
    }
    _handleCloseClick() {
        if(this.model) {
            this.model.active = false;
        }
    }
    _handleClick(e) {
        e.stopPropagation();
    }
    render() {
        return (
            <div className={"entity-search-config-menu" + (this.state.active ? " active" : "")} onClick={this._handleClick}>
                <div className="container-fluid">
                    <EntitySearchConfigEditor model={this.model} />
                </div>
                <div className="container-fluid">
                    <button type="button" className="btn btn-default" onClick={this._handleCloseClick}>
                        <span className="glyphicon glyphicon-remove"></span> Close</button>
                </div>
            </div>
        );
    }
}

export default EntitySearchConfigMenu;