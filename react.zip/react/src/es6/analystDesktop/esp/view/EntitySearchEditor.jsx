import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import SearchViewRegistry from "./SearchViewRegistry";
import EntitySearchComponentPanel from "./EntitySearchComponentPanel";

class EntitySearchEditor extends BoundComponent {
    constructor(props) {
        super(props);
    }
    get modelState() {
        return { components: this.model ? this.model.components : [], selected: this.model ? this.model.selected : [] };
    }
    _modelChanged() {
        if(this.model.isPropChanged("selected")) {
            this.setStateFromModel();
        }
    }
    render() {
        let content = [];
        let selected = this.state.selected;
        if(selected.length > 0) {
            this.state.components.forEach((c) => {
                if(selected.indexOf(c) >= 0) {
                    content.push(<EntitySearchComponentPanel key={c.id} model={this.model} component={c} />);
                }
            });
        } else {
            content =
                <div className="alert alert-info">
                    <span className="glyphicon glyphicon-info-sign"></span> Please select criteria to search on.
                </div>;
        }
        return (
            <div className="entity-search-editor configurable-entity-search-editor">
                <div>{content}</div>
            </div>
        );
    }
}

export default EntitySearchEditor;