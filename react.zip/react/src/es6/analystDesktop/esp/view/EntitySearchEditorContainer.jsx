import * as React from "react";
import EntitySearchComponentSelector from "./EntitySearchComponentSelector";
import EntitySearchEditor from "./EntitySearchEditor";
import EntitySearchActions from "./EntitySearchActions";
import css from "util/css";

class EntitySearchEditorContainer extends React.Component {
    componentWillMount() {
        css.addSheets("analystDesktop/entitySearch");
    }
    render() {
        return (
            <div className="entity-search-editor-container container">
                <div className="header">
                    <EntitySearchComponentSelector model={this.props.model} />
                </div>
                <div className="body">
                    <EntitySearchEditor model={this.props.model} />
                </div>
                <div className="footer">
                    <EntitySearchActions actions={this.props.actions} />
                </div>
            </div>
        );
    }
};

export default EntitySearchEditorContainer;