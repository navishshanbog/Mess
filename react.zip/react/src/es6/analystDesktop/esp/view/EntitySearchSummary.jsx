import * as React from "react";

class EntitySearchSummary extends React.Component {
    constructor(props) {
        super(props);
        this.state = this.modelState;
        this._modelChanged = this._modelChanged.bind(this);
    }
    get modelState() {
        return this.props.model ? this.props.model.params : {};
    }
    componentDidMount() {
        if(this.props.model) {
            this.props.model.observe(this._modelChanged);
        }
    }
    componentWillUnmount() {
        if(this.props.model) {
            this.props.model.forget(this._modelChanged);
        }
    }
    _modelChanged() {
        this.setState(this.modelState);
    }
    render() {
        return (
            <div className="entity-search-summary">
                <pre>{JSON.stringify(this.state)}</pre>
            </div>
        );
    }
}

export default EntitySearchSummary;