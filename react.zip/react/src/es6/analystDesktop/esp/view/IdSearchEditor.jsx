import * as React from "react";
import BoundInput from "form/view/BoundInput";
import idUtils from "util/id";

class IdSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            id: idUtils.next("id")
        };
    }
    render() {
        return (
            <div className="id-search-editor">
                <div className="form-group">
                    <label htmlFor={this.ids.id}>{this.props.label || "ID"}</label>
                    <BoundInput id={this.ids.id} type="text" className="form-control" model={this.props.model} name={this.props.name || "id"} placeholder={this.props.label || "ID"} />
                </div>
            </div>
        );
    }
}

export default IdSearchEditor;