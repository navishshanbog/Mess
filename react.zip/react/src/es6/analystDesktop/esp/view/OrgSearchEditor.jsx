import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundSelect from "form/view/BoundSelect";
import BoundFormGroup from "form/view/BoundFormGroup";
import BoundAlert from "form/view/BoundAlert";
import idUtils from "util/id";

class OrgSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            abn: idUtils.next("abn"),
            name: idUtils.next("name")
        };
    }
    render() {
        return (
            <div className="org-search-editor">
                <BoundAlert id={this.ids.helpId} model={this.props.model} name="orgError" className="alert-danger">
                    <span className="glyphicon glyphicon-info-sign"></span>
                </BoundAlert>
                <BoundFormGroup className="name-group" model={this.props.model} errorName="orgError">
                    <label htmlFor={this.ids.name}>Name</label>
                    <BoundInput id={this.ids.name} type="text" className="form-control" model={this.props.model} name="name" placeholder="Name" />
                </BoundFormGroup>
                <BoundFormGroup className="abn-group" model={this.props.model} errorName="orgError">
                    <label htmlFor={this.ids.abn}>ABN</label>
                    <BoundInput id={this.ids.abn} type="text" className="form-control" model={this.props.model} name="abn" placeholder="ABN" />
                </BoundFormGroup>
            </div>
        );
    }
}

export default OrgSearchEditor;