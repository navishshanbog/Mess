import * as React from "react";
import idUtils from "util/id";
import BoundInput from "form/view/BoundInput";
import BoundSelect from "form/view/BoundSelect";
import BoundFormGroup from "form/view/BoundFormGroup";
import BoundAlert from "form/view/BoundAlert";

class PersonSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            fullName: idUtils.next("fullName"),
            firstName: idUtils.next("firstName"),
            middleName: idUtils.next("middleName"),
            lastName: idUtils.next("lastName"),
            dob: idUtils.next("dob"),
            gender: idUtils.next("gender"),
            passport: idUtils.next("passport"),
            helpId: idUtils.next("nameHelp")
        };
    }
    render() {
        return (
            <div className="name-search-editor">
                <BoundAlert id={this.ids.helpId} model={this.props.model} name="personError" className="alert-danger">
                    <span className="glyphicon glyphicon-info-sign"></span>
                </BoundAlert>
                <BoundFormGroup className="full-name-group" model={this.props.model} errorName="personError">
                    <label htmlFor={this.ids.fullName}>Full Name</label>
                    <BoundInput id={this.ids.fullName} type="text" className="form-control full-name" model={this.props.model} name="fullName" errorName="personError" placeholder="Full Name" />
                </BoundFormGroup>
                <BoundFormGroup className="first-name-group" model={this.props.model} errorName="personError">
                    <label htmlFor={this.ids.firstName}>First Name</label>
                    <BoundInput id={this.ids.firstName} type="text" className="form-control first-name" model={this.props.model} name="firstName" errorName="personError" placeholder="First Name" />
                </BoundFormGroup>
                <BoundFormGroup className="middle-name-group" model={this.props.model} errorName="personError">
                    <label htmlFor={this.ids.middleName}>Middle Name</label>
                    <BoundInput id={this.ids.middleName} type="text" className="form-control middle-name" model={this.props.model} name="middleName" errorName="personError" placeholder="Middle Name" />
                </BoundFormGroup>
                <BoundFormGroup className="last-name-group" model={this.props.model} errorName="personError">
                    <label htmlFor={this.ids.lastName}>Last Name</label>
                    <BoundInput id={this.ids.lastName} type="text" className="form-control last-name" model={this.props.model} name="lastName" errorName="personError" placeholder="Last Name" />
                </BoundFormGroup>
                <BoundFormGroup className="dob-group" model={this.props.model} errorName="personError">
                    <label htmlFor={this.ids.dob}>Date of Birth</label>
                    <BoundInput id={this.ids.dob} type="text" className="form-control" model={this.props.model} name="dob" placeholder="Date of Birth" />
                </BoundFormGroup>
                <BoundFormGroup className="gender-group" model={this.props.model} errorName="personError">
                    <label htmlFor={this.ids.gender}>Gender</label>
                    <BoundSelect id={this.ids.gender} className="form-control" model={this.props.model} name="gender" placeholder="Gender" title="Gender">
                        <option value="">Gender...</option>
                        <option value="M">Male</option>
                        <option value="F">Female</option>
                        <option value="U">Unknown</option>
                        <option value="U">Unspecified</option>
                    </BoundSelect>
                </BoundFormGroup>
                <BoundFormGroup className="passport-group" model={this.props.model} errorName="personError">
                    <label htmlFor={this.ids.passport}>Passport</label>
                    <BoundInput id={this.ids.passport} type="text" className="form-control" model={this.props.model} name="passport" placeholder="Passport" />
                </BoundFormGroup>
            </div>
        );
    }
}

export default PersonSearchEditor;