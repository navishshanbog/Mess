import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundFormGroup from "form/view/BoundFormGroup";
import BoundAlert from "form/view/BoundAlert";
import idUtils from "util/id";

class PhoneSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            phone: idUtils.next("phone"),
            mobile: idUtils.next("mobile"),
            home: idUtils.next("home"),
            work: idUtils.next("work"),
            business: idUtils.next("business"),
            other: idUtils.next("other")
        };
    }
    render() {
        return (
            <div className="phone-search-editor">
                <BoundAlert id={this.ids.helpId} model={this.props.model} name="phoneError" className="alert-danger">
                    <span className="glyphicon glyphicon-info-sign"></span>
                </BoundAlert>
                <BoundFormGroup className="phone-group" model={this.props.model} errorName="phoneError">
                    <label htmlFor={this.ids.phone}>Phone</label>
                    <BoundInput id={this.ids.phone} type="tel" className="form-control phone" model={this.props.model} name="phone" placeholder="Phone Number" />
                </BoundFormGroup>
                {/*
                <BoundFormGroup className="mobile-group" model={this.props.model} errorName="phoneError">
                    <label htmlFor={this.ids.mobile}>Mobile</label>
                    <BoundInput id={this.ids.mobile} type="tel" className="form-control mobile" model={this.props.model} name="mobile" placeholder="Mobile" />
                </BoundFormGroup>
                <BoundFormGroup className="home-group" model={this.props.model} errorName="phoneError">
                    <label htmlFor={this.ids.home}>Home</label>
                    <BoundInput id={this.ids.home} type="tel" className="form-control home" model={this.props.model} name="home" placeholder="Home" />
                </BoundFormGroup>
                <BoundFormGroup className="work-group" model={this.props.model} errorName="phoneError">
                    <label htmlFor={this.ids.work}>Work</label>
                    <BoundInput id={this.ids.work} type="tel" className="form-control work" model={this.props.model} name="work" placeholder="Work" />
                </BoundFormGroup>
                <BoundFormGroup className="business-group" model={this.props.model} errorName="phoneError">
                    <label htmlFor={this.ids.business}>Business</label>
                    <BoundInput id={this.ids.business} type="tel" className="form-control business" model={this.props.model} name="business" placeholder="Business" />
                </BoundFormGroup>
                <BoundFormGroup className="other-group" model={this.props.model} errorName="phoneError">
                    <label htmlFor={this.ids.other}>Other</label>
                    <BoundInput id={this.ids.other} type="tel" className="form-control other" model={this.props.model} name="other" placeholder="Other" />
                </BoundFormGroup>
                */}
            </div>
        );
    }
}

export default PhoneSearchEditor;