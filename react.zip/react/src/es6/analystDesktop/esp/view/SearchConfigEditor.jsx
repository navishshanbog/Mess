import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundCheckbox from "form/view/BoundCheckbox";

class SearchConfigEditor extends React.Component {
    render() {
        return (
            <div className="search-config-editor">
                <div className="checkbox">
                    <label>
                        <BoundCheckbox model={this.props.model} name="includePnr" placeholder="Include PNR" /> Include PNR in Search Results
                    </label>
                </div>
            </div>
        );
    }
}

export default SearchConfigEditor;