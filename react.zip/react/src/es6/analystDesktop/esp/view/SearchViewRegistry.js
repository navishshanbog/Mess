import * as React from "react";
import SystemSearchEditor from "./SystemSearchEditor";
import PersonSearchEditor from "./PersonSearchEditor";
import BirthSearchEditor from "./BirthSearchEditor";
import AddressSearchEditor from "./AddressSearchEditor";
import PhoneSearchEditor from "./PhoneSearchEditor";
import OrgSearchEditor from "./OrgSearchEditor";
import DocSearchEditor from "./DocSearchEditor";

const system = {
    title: "System",
    icon: "record",
    editor(model) {
        return <SystemSearchEditor model={model} />;
    }
}
const person = {
    title: "Person",
    icon: "user",
    editor(model) {
        return <PersonSearchEditor model={model} />;
    }
};
const birth = {
    title: "Birth",
    icon: "baby-formula",
    editor(model) {
        return <BirthSearchEditor model={model} />;
    }
};
const address = {
    title: "Address",
    icon: "home",
    editor(model) {
        return <AddressSearchEditor model={model} />;
    }
};
const phone = {
    title: "Phone",
    icon: "phone",
    editor(model) {
        return <PhoneSearchEditor model={model} />;
    }
};
const org = {
    title: "Organisation",
    icon: "briefcase",
    editor(model) {
        return <OrgSearchEditor model={model} />;
    }
};
const doc = {
    title: "Credential",
    icon: "file",
    editor(model) {
        return <DocSearchEditor model={model} />;
    }
};

export default {
    system: system,
    person: person,
    birth: birth,
    address: address,
    phone: phone,
    org: org,
    doc: doc
};