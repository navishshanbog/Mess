import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundSelect from "form/view/BoundSelect";
import BoundFormGroup from "form/view/BoundFormGroup";
import BoundHelpBlock from "form/view/BoundHelpBlock";
import idUtils from "util/id";

class SystemSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            clientId: idUtils.next("clientId")
        };
    }
    render() {
        return (
            <div className="system-search-editor">
                <BoundFormGroup model={this.props.model} errorName="clientIdError">
                    <label htmlFor={this.ids.clientId}>Client ID</label>
                    <BoundInput id={this.ids.clientId} type="text" className="form-control" model={this.props.model} name="clientId" placeholder="Client ID" />
                    <BoundHelpBlock model={this.props.model} name="clientIdError" />
                </BoundFormGroup>
            </div>
        );
    }
}

export default SystemSearchEditor;