import * as React from "react";
import BoundInput from "form/view/BoundInput";
import idUtils from "util/id";

class TextSearchEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            text: idUtils.next("text")
        };
    }
    render() {
        <div className="text-search-editor">
            <div className="form-group">
                <BoundInput id={this.ids.text} type="text" className="form-control" model={this.props.model} name="text" placeholder="Search All" />
            </div>
        </div>
    }
}

export default TextSearchEditor;