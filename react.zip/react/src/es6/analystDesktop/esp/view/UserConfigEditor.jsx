import * as React from "react";
import BoundInput from "form/view/BoundInput";
import BoundCheckbox from "form/view/BoundCheckbox";
import BoundFormGroup from "form/view/BoundFormGroup";
import BoundHelpBlock from "form/view/BoundHelpBlock";
import idUtils from "util/id";

class UserConfigEditor extends React.Component {
    constructor(props) {
        super(props);
        this.ids = {
            username: idUtils.next("username"),
            usernameHelp: idUtils.next("username-help"),
            password: idUtils.next("password"),
            passwordHelp: idUtils.next("password-help")
        };
    }
    render() {
        return (
            <div className="user-config-editor">
                <BoundFormGroup model={this.props.model} name="username" errorName="usernameError">
                    <label htmlFor={this.ids.username}>Username</label>
                    <BoundInput id={this.ids.username} type="text" className="form-control" model={this.props.model} name="username" placeholder="Username" errorHelpId={this.ids.usernameHelp} />
                    <BoundHelpBlock id={this.ids.usernameHelp} model={this.props.model} name="usernameError" />
                </BoundFormGroup>
                <BoundFormGroup model={this.props.model} name="password" errorName="passwordError">
                    <label htmlFor={this.ids.password}>Password</label>
                    <BoundInput id={this.ids.password} type="password" className="form-control" model={this.props.model} name="password" placeholder="Password" errorHelpId={this.passwordHelp} />
                    <BoundHelpBlock id={this.ids.passwordHelp} model={this.props.model} name="passwordError" />
                </BoundFormGroup>
            </div>
        );
    }
}

export default UserConfigEditor;