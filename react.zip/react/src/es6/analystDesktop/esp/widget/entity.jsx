import * as React from "react";
import appContext from "app/context";
import layout from "layout/bootstrap/layout";
import EntityView from "../view/Entity";
import EntityStore from "../store/Entity";
import EntityService from "../service/EntityService";
import SearchConfigStore from "../store/SearchConfig";
import UserConfigStore from "../store/UserConfig";

class EntityWidgetApp {
    constructor() {
        this.entityView = <EntityView model={EntityStore} />;
    }
    index() {
        let id = appContext.moduleParams.id;
        let request = { id: id };
        request.includePnr = SearchConfigStore.includePnr;
        request.userConfig = UserConfigStore.get();
        EntityStore.details.loadStart(request);
        EntityService.getMasteredDetails(request).then((result) => {
            EntityStore.details.loadComplete(result);
        }).catch((err) => {
            EntityStore.details.loadError(err);
        });

        layout.go({
            title: "Entity Details",
            main: this.entityView
        });
    }
}

export default new EntityWidgetApp();