import * as React from "react";
import appContext from "app/context";
import layout from "layout/bootstrap/layout";
import EntityListStore from "../store/EntityList";
import EntityListContainer from "../view/EntityListContainer";
import MockEntityService from "../service/impl/MockEntityService";
import EntityService from "../service/EntityService";
import IwcActions from "../action/IwcActions";
import config from "../config";

// for testing ui - move into a separate application
//EntityService.target = new MockEntityService();

class EntityListWidgetApp {
    constructor() {
        this.iwcActions = new IwcActions();
        this.listView = <EntityListContainer model={EntityListStore} actions={this} />;
    }
    index() {
        this.iwcActions.iwcUrl = appContext.moduleParams["ozpIwc.peer"] || config.iwcUrl;
        this.iwcActions.searchDataRef.watch((change, done) => {
            this._onSearchChange(change);
        });
        layout.go({
            title: "Entity Search Result",
            main: this.listView
        });
    }
    _onSearchChange(change) {
        const payload = change.newValue;
        console.log("-- On Change: " + JSON.stringify(change));
        const done = payload.done;
        const result = payload.result;
        const error = payload.error;
        if(!done) {
            EntityListStore.loadStart(payload.request);
        } else {
            if(error) {
                EntityListStore.loadError(error);
            } else {
                EntityListStore.loadComplete(result.data);
            }
        }
    }
    selectEntity(entity) {
        console.log("-- Select Entity: " + JSON.stringify(entity));
        // load our entity stuff
        
        //appContext.open({ path: "analystDesktop/esp/widget/entity/:entityId", params: { entityId: id }});
    }
}

export default new EntityListWidgetApp();

