import * as React from "react";
import appContext from "app/context";
import layout from "layout/bootstrap/layout";
import SearchStore from "../store/Search";
import SearchEditor from "../view/EntitySearchEditorContainer";
import EntityListStore from "../store/EntityList";
import EntityListView from "../view/EntityListContainer";
import SearchConfigStore from "../store/SearchConfig";
import SearchConfigEditor from "../view/SearchConfigEditor";
import UserConfigStore from "../store/UserConfig";
import UserConfigEditor from "../view/UserConfigEditor";
import EntityService from "../service/EntityService";
import SearchableDataModel from "../model/SearchableDataModel";
import MockEntityService from "../service/impl/MockEntityService";

// setup mock service
//EntityService.target = new MockEntityService();

class SearchWidgetApp {
    constructor() {
        this.userConfigView = <UserConfigEditor model={UserConfigStore} />;
        this.searchConfigView = <SearchConfigEditor model={SearchConfigStore} />;
        this.searchMenu =
            <div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <span className="glyphicon glyphicon-search"></span> Search Config
                    </div>
                    <div className="panel-body">{this.searchConfigView}</div>
                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <span className="glyphicon glyphicon-user"></span> User Config
                    </div>
                    <div className="panel-body">{this.userConfigView}</div>
                </div>
                
                <button type="button" className="btn btn-default" onClick={(e) => { this.handleMenuAction(e) }}>OK</button>
                
            </div>;
        this.searchView = <SearchEditor model={SearchStore} actions={this} />;
        this.searchResultModel = new SearchableDataModel(EntityListStore);
        this.searchResultView = <EntityListView model={this.searchResultModel} actions={this} />;
        const prevToEditorAction = () => {
            this.index();
        };
        this.prevToEditor = {
            title: "Entity Search",
            action: prevToEditorAction
        }
    }
    handleMenuAction(e) {
        layout.model.closeMenu();
        if(this.menuCloseAction) {
            this.menuCloseAction();
            delete this.menuCloseAction;
        }
    }
    index() {
        layout.go({
            title: "Entity Search",
            main: this.searchView,
            menu: this.searchMenu
        });
    }
    result() {
        layout.go({
            title: "Entity Search Results",
            prev: this.prevToEditor,
            main: this.searchResultView
        });
    }
    _searchInternal() {
        const request = SearchStore.params;
        request.includePnr = SearchConfigStore.includePnr;
        request.userConfig = UserConfigStore.get();
        EntityListStore.loadStart(request);
        EntityService.search(request).then((result) => {
            EntityListStore.loadComplete(result.data);
        }).catch((err) => {
            EntityListStore.loadError(err);
        });

        this.result();
    }
    search() {
        if(SearchStore.validate().hasError) {
            return;
        }

        // validate the user configuration
        if(UserConfigStore.validate().hasError) {
            this.menuCloseAction = () => {
                this._searchInternal();
            };
            layout.model.openMenu();
            return;
        }

        this._searchInternal();
    }
    clearSearch() {
         SearchStore.clear();
    }
    selectEntity(entity) {
        console.log("-- Select Entity: " + JSON.stringify(entity));
        //appContext.open({ path: "analystDesktop/esp/widget/entity/:entityId", params: { entityId: id }});
        appContext.open({ path: "analystDesktop/esp/widget/entity", params: { id: entity.MSTR_ENTY_ID, name: entity.NAME }});
    }
}

export default new SearchWidgetApp();