import * as React from "react";
import appContext from "app/context";
import layout from "layout/bootstrap/layout";
import SearchStore from "../store/Search";
import SearchEditor from "../view/EntitySearchEditorContainer";
import SearchConfigStore from "../store/SearchConfig";
import SearchConfigEditor from "../view/SearchConfigEditor";
import UserConfigStore from "../store/UserConfig";
import UserConfigEditor from "../view/UserConfigEditor";
import EntityService from "../service/EntityService";
import IwcActions from "../action/IwcActions";
import config from "../config";

class SearchEditorWidgetApp {
    constructor() {
        this.userConfigView = <UserConfigEditor model={UserConfigStore} />;
        this.searchConfigView = <SearchConfigEditor model={SearchConfigStore} />;
        this.searchMenu =
            <div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <span className="glyphicon glyphicon-search"></span> Search Config
                    </div>
                    <div className="panel-body">{this.searchConfigView}</div>
                </div>
                <div className="panel panel-primary">
                    <div className="panel-heading">
                        <span className="glyphicon glyphicon-user"></span> User Config
                    </div>
                    <div className="panel-body">{this.userConfigView}</div>
                </div>
                
                <button type="button" className="btn btn-default" onClick={(e) => { this.handleMenuAction(e) }}>OK</button>
                
            </div>;
        this.searchView = <SearchEditor model={SearchStore} actions={this} />;
        this.iwcActions = new IwcActions();
    }
    handleMenuAction(e) {
        layout.model.closeMenu();
        if(this.menuCloseAction) {
            this.menuCloseAction();
            delete this.menuCloseAction;
        }
    }
    index() {
        this.iwcActions.iwcUrl = appContext.moduleParams["ozpIwc.peer"] || config.iwcUrl;
        layout.go({
            title: "Entity Search Editor",
            main: this.searchView,
            menu: this.searchMenu
        });
    }
    _searchInternal() {
        const request = SearchStore.params;
        request.includePnr = SearchConfigStore.includePnr;
        request.userConfig = UserConfigStore.get();
        // TODO: indicate search is in progress
        this.iwcActions.search(request).then(() => {
            console.log("-- Search Completed");
        }).catch((err) => {
            console.error(err);  
        });
    }
    search() {
        if(SearchStore.validate().hasError) {
            return;
        }

        // validate the user configuration
        if(UserConfigStore.validate().hasError) {
            this.menuCloseAction = () => {
                this._searchInternal();
            };
            layout.model.openMenu();
            return;
        }

        this._searchInternal();
    }
    clearSearch() {
         SearchStore.clear();
    }
    selectEntity(entity) {
        console.log("-- Select Entity: " + JSON.stringify(entity));
        //appContext.open({ path: "analystDesktop/esp/widget/entity/:entityId", params: { entityId: id }});
    }
}

export default new SearchEditorWidgetApp();