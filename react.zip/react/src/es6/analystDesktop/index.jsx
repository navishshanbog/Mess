import * as React from "react";
import layout from "layout/bootstrap/layout";
import AppLink from "app/view/AppLink";

const widgets =
    <div className="panel panel-primary">
        <div className="panel-heading">Widgets</div>
        <div className="list-group">
            <AppLink className="list-group-item" path="analystDesktop/esp/widget/search" title="Search Widget" />
            <AppLink className="list-group-item" path="analystDesktop/esp/widget/searchEditor" title="Search Editor Widget" />
            <AppLink className="list-group-item" path="analystDesktop/esp/widget/entityList" title="Entity List Widget" />
        </div>
    </div>;

const tests =
    <div className="panel panel-primary">
        <div className="panel-heading">Tests</div>
        <div className="list-group">
            <AppLink className="list-group-item" path="analystDesktop/esp/service/impl/TDQueryEntityServiceTest" title="Teradata Query Entity Service Test" />
        </div>
    </div>;
    

const main =
    <div className="container">
        <p>See links below for all things Analyst Desktop</p>
        {widgets}
        {tests}
    </div>;

export default () => {
    layout.go({
        title: "Analyst Desktop Home",
        main: main
    });
};