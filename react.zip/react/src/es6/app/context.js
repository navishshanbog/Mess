import ContextModel from "app/model/Context";

export default new ContextModel();