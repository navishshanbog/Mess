import require from "require";
import Model from "util/Model";
import lang from "util/lang";
import stringUtils from "util/string";
import uriUtils from "util/uri";
import pathUtils from "util/path";

const emptyStringFormatter = () => {
    return stringUtils.empty;
};

class BasicPathMapper {
    get defaultModulePath() {
        if(!this._defaultModulePath) {
            this._defaultModulePath = "index";
        }
        return this._defaultModulePath;
    }
    set defaultModulePath(value) {
        this._defaultModulePath = value;
    }
    mapPath(path, params) {
        return { modulePath: (path || this.defaultModulePath), moduleParams: params };
    }
}

class PathTemplateMapper {
    constructor(template, modulePath) {
        this.template = template;
        this.modulePath = modulePath;
    }

    get template() {
        return this._template;
    }
    set template(value) {
        if(value !== this._template) {
            if(value) {
                this._template = value;
                this._compiledTemplate = new uriUtils.Template(value);
            } else {
                delete this._template;
                delete this._compiledTemplate;
            }
        }
    }
    /**
     * Map the path - if a modulePath has been configured, this will be used as the path,
     * otherwise the module path will be the path without place-holders
     * - i.e. one/:two/three would produce one/three as the module path
     */
    mapPath(path, params) {
        var matchResult = this._compiledTemplate.match(path);
        if(matchResult.match) {
            var moduleParams = Object.assign({}, matchResult.params, params);
            var modulePath = this.modulePath || pathUtils.normalize(this.template.format(emptyStringFormatter));
            return { modulePath: modulePath, moduleParams: moduleParams };
        }
    }
}

class Context extends Model {
    defaultProps() {
        return {
            init: true,
            loading: false,
            menuOpen: false
        };
    }

    _use(modulePath) {
        let s = this._useState;
        if(!s) {
            s = {};
            this._useState = s;
        }
        var ms = s[modulePath];
        if(ms) {
            return ms.error ? Promise.reject(ms.error) : Promise.resolve(ms.module);
        }

        return new Promise((resolve, reject) => {
            require([modulePath], (m) => {
                // to deal with modules marked as es modules
                var rm = m && m.__esModule ? m.default : m;
                s[modulePath] = { module: rm };
                resolve(rm);
            }, (error) => {
                console.error(error);
                s[modulePath] = { error: error };
                reject(error);
            });
        });
    }

    /**
     * The application context window
     */
    get window() {
        if(!this._window) {
            // by default, the global window reference is used
            this._window = window;
        }
        return this._window;
    }
    set window(value) {
        this._window = value;
    }

    /**
     * Location manager/service for the application context
     */
    get location() {
        if(!this._location) {
            this._location = window.location;
        }
        return this._location;
    }
    set location(value) {
        this._location = value;
    }

    /**
     * History mode for the application context
     */
    get historyMode() {
        if(this._historyMode) {
            this._historyMode = "push";
        }
        return this._historyMode;
    }
    set historyMode(value) {
        this._historyMode = value;
    }

    /**
     * Set the base path for the application context
     */
    get basePath() {
        if(!this._basePath) {
            this._basePath = pathUtils.sep;
        }
        return this._basePath;
    }
    set basePath(value) {
        this._basePath = value;
    }
    
    /**
     * The default path mapper
     */
    get defaultPathMapper() {
        if(!this._defaultPathMapper) {
            this._defaultPathMapper = new BasicPathMapper();
        }
        return this._defaultPathMapper;
    }
    set defaultPathMapper(value) {
       this._defaultPathMapper = value;
    }
    
    containsPathMapper(pathMapper) {
        return this._pathMappers && this._pathMappers.some(function(reg) {
            return reg.o === pathMapper;
        });
    }
    /**
     * Adds a path mapper
     */
    addPathMapper(pathMapper, scope) {
        if(pathMapper && !this.containsPathMapper(pathMapper)) {
            if(!this._pathMappers) {
                this._pathMappers = [];
            }
            let f = lang.isFunction(pathMapper) ? pathMapper : lang.isFunction(pathMapper.mapPath) ? pathMapper.mapPath.bind(pathMapper) : undefined;
            if(f) {
                this._pathMappers.push({ o: pathMapper, f: f, s: scope });
            }
        }
    }

    /**
     * Add template path mapper
     */
    addPathTemplateMapper(template, modulePath) {
        if(template) {
            this.addPathMapper(new PathTemplateMapper(template, modulePath));
        }
    }
            
    mapPath(path, params) {
        let r;
        if(this._pathMappers) {
            this._pathMappers.some(function(reg) {
                r = reg.f.call(reg.s, path, params);
                if(r) {
                    return true;
                }
            });
        }
        if(!r) {
            r = lang.isFunction(this.defaultPathMapper) ? this.defaultPathMapper(path, params) : this.defaultPathMapper.mapPath(path, params);
        }
        return r;
    }
   
    resolvePlace() {
        let place = {};
        let path = this.location.pathname;
        if(this.basePath) {
            var basePathIdx = path.indexOf(this.basePath);
            if(basePathIdx >= 0) {
                path = path.substring(basePathIdx + this.basePath.length);
            }
        }
        path = stringUtils.stripLeft(path, pathUtils.sep);

        let ext = pathUtils.extname(path);

        if(ext) {
            path = path.substring(0, path.length - ext.length);
        }

        if(path) {
            place.path = path;
        }

        let search = this.location.search;
        let params;
        if(search && search.length > 1) {
            params = uriUtils.decode(search.substring(1));
            place.params = params;
        }
        
        // resolve app module and parameters
        let modPath =  this.mapPath(path, params);
        place.modulePath = modPath.modulePath;
        place.moduleParams = modPath.moduleParams;

        return place;
    }

    get loading() {
        return this.get("loading");
    }
    
    get error() {
        return this.get("error");
    }

    /**
     * Get the current path
     */
    get path() {
        return this.get("path");
    }

    /**
     * Get the current parameters
     */
    get params() {
        return this.get("params") || {};
    }
                  
    /**
     * Get the current module path
     */
    get modulePath() {
        return this.get("modulePath");
    }

    /**
     * Get the current module
     */
    get module() {
        return this.get("module");
    }

    /**
     * Get current module params
     */
    get moduleParams() {
        return this.get("moduleParams") || {};
    }
             
    get _pHandlers() {
        if(!this.__pHandlers) {
            this.__pHandlers = {
                onLoadEnd: this._onLoadEnd.bind(this),
                onLoadError: this._onLoadError.bind(this),
                onModuleLoad: this._onModuleLoad.bind(this)
            };
        }
        return this.__pHandlers;
    }

    _onLoadEnd() {
        this.set({ loading: false, init: false }).notify();
    }

    _onLoadError(error) {
        this.set({
            error: error,
            title: undefined,
            menu: undefined,
            main: undefined
        });
        this._onLoadEnd();
    }

    _runModule() {
        let r;
        let module = this.module;
        if(module) {
            try {
                if(lang.isFunction(module)) {
                    r = module();
                } else if(lang.isFunction(module.go)) {
                    r = module.go();
                } else if(lang.isFunction(module.index)) {
                    r = module.index();
                } else {
                    r = module;
                }

                // only attempt updating the view and title if a value is returned - otherwise assume the module
                // has taken care of updating the context
                if(r) {
                    let view = r.view ? r.view : r;
                    if(view) {
                        this.view = view;
                    }
                    let title = r.title ? r.title : undefined;
                    if(title) {
                        this.title = title;
                    }
                }
            } catch(err) {
                return Promise.reject(err);
            }
        }
        return Promise.resolve(this.view);
    }
           
    _onModuleLoad(module) {
        this.set("module", module);
        if(this.isPropChanged("module")) {
            let oldModule = this.getOldValue("module");
            if(oldModule && lang.isFunction(oldModule.wo)) {
                oldModule.wo();
            }
        }
        this._runModule().then(this._pHandlers.onLoadEnd).catch(this._pHandlers.onLoadError);
    }

    _onLoadStart() {
        this.set({
            error: undefined,
            module: undefined,
            loading: true
        });
        this.set(this.resolvePlace());
        this.notify();
    }
              
    /**
     * Load the place being resolved from the current location
     */
    _loadModule() {
        this._onLoadStart();
        return this._use(this.modulePath).then(this._pHandlers.onModuleLoad).catch(this._pHandlers.onLoadError);
    }
    
    createPath() {
        if(arguments.length === 0) {
            return this.basePath;
        }
        let els = [this.basePath];
        Array.prototype.forEach.call(arguments, (arg) => {
            els.push(arg);
        });
        return pathUtils.join(els);
    }
    
    createUrl(opts) {
        let url;
        if(opts) {
            let path;
            let params;
            if(lang.isString(opts)) {
                path = opts;
            } else {
                path = opts.path;
                params = opts.params;   
            }

            if(!path) {
                url = this.location.pathname;
            } else {
                url = path;
                url = pathUtils.join(pathUtils.sep, this.basePath, url);
                if(this.extension) {
                    url += this.extension;
                }
            }

            if(params) {
                const template = new uriUtils.Template(url);
                url = template.format(params);

                const paramsForEncoding = Object.assign({}, params);
                template.paramNames.forEach((paramName) => {
                    console.log("-- Path Param: " + paramName);
                    delete paramsForEncoding[paramName];
                });

                let ps = uriUtils.encode(paramsForEncoding, { propFilter: uriUtils.propFilters.allowPrimitives });
                if(ps) {
                    url += "?" + ps;
                }
            }
            
        } else {
            url = this.location.href;
        }
        return url;
    }
    
    get url() {
        return this.location.href;
    }
    set url(value) {
        this.load(value);
    }
    
    load(opts) {
        let url = this.createUrl(opts);
        if(url !== this.location.href) {
            this._setPropChanged("url", this.location.href, url);
            if(!opts || !opts.noHistory) {
                if(stringUtils.equalsIgnoreCase(this.historyMode, "replace")) {
                    this.window.history.replaceState(null, "", url);
                } else {
                    this.window.history.pushState(null, "", url);
                }
            }
            return this._loadModule();
        }
        return Promise.resolve();
    }

    open() {
        return this.load.apply(this, arguments);
    }

    get place() {
        return { title: this.title, path: this.path, params: this.params };
    }
    set place(value) {
        this.load(value);
    }

    get extension() {
        return this.get("extension");
    }

    get isInit() {
        return this.get("init");
    }

    init() {
        // add our pop state listener
        this._popStateListener = (e) => {
            this._loadModule();
        };
        this.window.addEventListener("popstate", this._popStateListener);
        // set the initial extension
        this.set("extension", pathUtils.extname(this.location.pathname));
        this.set("init", true);
        return this._loadModule();
    }

    destroy() {
        this.window.removeEventListener("popstate", this._popStateListener);
        delete this._popStateListener;
    }

    get title() {
        return this.get("title");
    }
    set title(value) {
        this.set("title", value);
    }

    get view() {
        return this.get("view");
    }
    set view(value) {
        this.set("view", value);
    }

}

export { Context as default, Context, BasicPathMapper, PathTemplateMapper };