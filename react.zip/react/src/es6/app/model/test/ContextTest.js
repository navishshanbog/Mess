import testRunner from "test/runner";
import Context from "../model/Context";

const suite = {
    title: "Application Context Model Test",
    testInit(ctx) {
        const testContext = new Context();
        testContext.basePath = "/static/dibp";
         
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};