import * as React from "react";
import appContext from "app/context";
import lang from "util/lang";
import AppStatus from "./AppStatus";
import AppError from "./AppError";
import AppBody from "./AppBody";
import css from "util/css";

class App extends React.Component {
    render() {
        return <div className="app">
                   <AppStatus />
                   <AppError />
                   <AppBody />
               </div>;
    }
}

export default App;