import * as React from "react";
import appContext from "app/context";

var getState = () => {
    return {
        view: appContext.view,
        error: appContext.error
    };
};

class AppBody extends React.Component {
    constructor(props) {
        super(props);
        this._appContextChanged = this._appContextChanged.bind(this);
        this.state = getState();
    }
    componentDidMount() {
        appContext.observe(this._appContextChanged);
        this.setState(getState());
    }
    componentWillUnmount() {
        appContext.forget(this._appContextChanged);
    }
    _appContextChanged() {
        if(appContext.isPropChanged("view") || appContext.isPropChanged("error")) {
            this.setState(getState());
        }
    }
    render() {
        if(this.state.error) {
            return false;
        }
        return <div className="app-body">{this.state.view}</div>;
    }
}

export default AppBody;