import * as React from "react";
import appContext from "app/context";
import Error from "common/view/Error";

const getState = () => {
    return {
        error: appContext.error
    };
};

class AppError extends React.Component {
    constructor(props) {
        super(props);
        this._appContextChanged = this._appContextChanged.bind(this);
        this.state = getState();
    }
    componentDidMount() {
        appContext.observe(this._appContextChanged);
        this.setState(getState());
    }
    componentWillUnmount() {
        appContext.forget(this._appContextChanged);
    }
    _appContextChanged() {
        if(appContext.isPropChanged("error")) {
            this.setState(getState());
        }
    }
    render() {
        return this.state.error ? <div className="app-error"><Error error={this.state.error} /></div> : false;
    }
}

export default AppError;