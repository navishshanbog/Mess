import * as React from "react";
import appContext from "app/context";
import css from "util/css";

class AppLink extends React.Component {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }

    _handleClick(e) {
        e.preventDefault();
        appContext.open({ path: this.props.path, params: this.props.params });
    }

    render() {
        return (
            <a title={this.props.title} className={css.className("app-link", this.props.className)} href={appContext.createUrl(this.props)} onClick={this._handleClick}>
                {React.Children.count(this.props.children) > 0 ? this.props.children : this.props.title}
            </a>
        );
    }
}

export default AppLink;