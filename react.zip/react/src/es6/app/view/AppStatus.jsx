import * as React from "react";
import appContext from "app/context";

const getState = () => {
    return {
        loading: appContext.loading,
        error: appContext.error
    }
};

class AppStatus extends React.Component {
    constructor(props) {
        super(props);
        this.state = getState();
        this._appContextChanged = this._appContextChanged.bind(this);
    }

    componentDidMount() {
        appContext.observe(this._appContextChanged);
        this.setState(getState());
    }

    componentWillUnmount() {
        appContext.forget(this._appContextChanged);
    }

    _appContextChanged() {
        if(appContext.isPropChanged("loading") ||
           appContext.isPropChanged("error")) {
            this.setState(getState());
        }
    }

    render() {
        if(this.state.loading || this.state.error) {
            let content;
            let statusClass;
            if(this.state.loading) {
                content = "Loading...";
                statusClass = "loading";
            } else {
                content = "An Error has Occurred";
                statusClass = "error";
            }
            return <div className={"app-status " + statusClass}>{content}</div>;
        }
        return false;
    }
}

export default AppStatus;