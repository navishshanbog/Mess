import * as React from "react";
import lang from "util/lang";
import Observable from "util/Observable";

class LogModel extends Observable {
    constructor() {
        super();
        this._entries = [];
    }
    get entries() {
        return [].concat(this._entries);
    }
    clear() {
        this._entries = [];
        this._setChanged().notify();
    }
    log(e) {
        if(e) {
            this._entries.push(e);
            this._setChanged().notify();
        }
    }
}

const model = new LogModel();

const getLogState = () => {
    return {
        entries: model.entries
    };
};

class LogView extends React.Component {
    constructor(props) {
        super(props);
        this.state = getLogState();
        this._logChanged = this._logChanged.bind(this);
    }
    componentDidMount() {
        model.observe(this._logChanged);
        this.setState(getLogState());
    }
    componentWillUnmount() {
        model.forget(this._logChanged);
    }
    _logChanged() {
        this.setState(getLogState());
    }
    render() {
        let logEntryViews = this.state.entries.map((logEntry, idx) => {
            let logValue = lang.isObject(logEntry) ? JSON.stringify(logEntry, null, "\t") : String(logEntry);
            return (
                <div key={idx} className="list-group-item">
                    <pre>{logValue}</pre>
                </div>
            );
        });
        return <div className="list-group">{logEntryViews}</div>;
    }
};

const view = <LogView />;

export default {
    view: view,
    clear() {
        model.clear.apply(model, arguments);
    },
    log() {
        model.log.apply(model, arguments);
    }
}