import * as React from "react";

class BoundComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = this.modelState;
        this._modelChanged = this._modelChanged.bind(this);
    }
    get model() {
        if(!this._model) {
            this._model = this.props.model;
        }
        return this._model;
    }
    set model(value) {
        if(value !== this._model) {
            this.unbind();
            this.model = value;
            this.bind();
        }
    }
    get modelState() {
        return this.model ? this.model.get() : {};
    }
    setStateFromModel() {
        this.setState(this.modelState);
    }
    _modelChanged() {
        this.setStateFromModel();
    }
    bind() {
        if(this.model) {
            this.model.observe(this._modelChanged);
        }
        this.setStateFromModel();
    }
    unbind() {
        if(this.model) {
            this.model.forget(this._modelChanged);
        }
    }
    componentDidMount() {
        this.bind();
        this.setStateFromModel();
    }
    componentWillUnmount() {
       this.unbind();
    }
    componentWillReceiveProps(nextProps) {
        if(nextProps.model !== undefined && nextProps.model !== this.model) {
            this.model = nextProps.model;
        }
    }
    render() {
        return false;
    }
}

export default BoundComponent;