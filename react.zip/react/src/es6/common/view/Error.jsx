import * as React from "react";
import lang from "util/lang";
import css from "util/css";

class Error extends React.Component {
    render() {
        let error = this.props.error;
        let message = lang.isString(error) ? error : error && error.message ? error.message : "An error has occurred";
        let messageContent = <div className="message">{message}</div>;
        let stack = error ? error.stack : null;
        let stackContent;
        if(stack) {
            stackContent = <div className="stack"><pre>{stack}</pre></div>;
        }

        return <div className={css.className(this.props.className, "error")} style={this.props.style} role="error">{messageContent}{stackContent}</div>;
    }
}

export default Error;