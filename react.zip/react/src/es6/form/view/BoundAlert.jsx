import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import lang from "util/lang";
import css from "util/css";

class BoundAlert extends BoundComponent {
    get modelState() {
        const model = this.model;
        const name = this.props.name;
        return { alert: model && name ? model[name] : undefined };
    }
    _modelChanged() {
        const model = this.model;
        const name = this.props.name;
        if(name && model.isPropChanged(name)) {
            this.setStateFromModel();
        }
    }
    render() {
        if(this.state.alert) {
            let alert;
            if(lang.isArray(this.state.help)) {
                alert = this.state.alert.map((e, idx) => {
                    if(e && e.message) {
                        return <span key={idx}>{e.message}</span>;
                    } else {
                        return <span key={idx}>{String(e)}</span>;
                    }
                });
            } else {
                alert = <span>{String(this.state.alert)}</span>;
            }
            const viewProps = Object.assign({}, this.props);
            delete viewProps.className;
            delete viewProps.model;
            delete viewProps.name;
            return (
                <div className={css.className("alert", this.props.className)}>
                    {this.props.children}
                    {" "}
                    {alert}
                </div>
            )
        }
        return false;
    }
}

export default BoundAlert;