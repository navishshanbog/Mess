import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class BoundCheckbox extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleChange = this._handleChange.bind(this);
        this._handleInput = this._handleInput.bind(this);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.model;
        let name = this.props.name;
        return model && name ? { value: model[name] || ""} : {};
    }
    _modelChanged() {
        let name = this.props.name;
        if(this.model.isPropChanged(name)) {
            this.setStateFromModel();
        }
    }
    _handleChange(e) {
        if(this.model && this.props.name) {
            this.model[this.props.name] = e.target.checked;
        }
    }
    _handleInput(e) {
        if(this.model && this.props.name) {
            this.model[this.props.name] = e.target.checked;
        }
    }
    _handleClick(e) {
        if(this.model && this.props.name) {
            this.model[this.props.name] = e.target.checked;
        }
    }
    render() {
        let viewProps = Object.assign({}, this.props);
        delete viewProps.model;
        delete viewProps.onChange;
        delete viewProps.onInput;
        delete viewProps.onClick;
        delete viewProps.type;
        return <input type="checkbox" {...viewProps} checked={this.state.value} value={this.state.value ? "on" : "off"} onChange={this._handleChange} onInput={this._handleInput} onClick={this._handleClick} />
    }
}

export default BoundCheckbox;