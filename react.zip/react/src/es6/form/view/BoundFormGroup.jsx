import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import BoundHelpBlock from "form/view/BoundHelpBlock";
import css from "util/css";
import lang from "util/lang";
import idUtils from "util/id";

class BoundFormGroup extends BoundComponent {
    get modelState() {
        const model = this.model;
        const errorName = this.props.errorName;
        return { error: model && errorName ? model[errorName] : undefined };
    }
    _modelChanged() {
        const model = this.model;
        const errorName = this.props.errorName;
        if(errorName && model.isPropChanged(errorName)) {
            this.setStateFromModel();
        }
    }
    render() {
        const viewProps = Object.assign({}, this.props);
        delete viewProps.className;
        delete viewProps.children;
        delete viewProps.model;
        delete viewProps.helpId;
        delete viewProps.noHelp;
        delete viewProps.errorName;
        return (
            <div {...viewProps} className={css.className("form-group", this.props.className, this.state.error ? "has-error" : undefined)}>
                {this.props.children}
            </div>
        );
    }
}

export default BoundFormGroup;