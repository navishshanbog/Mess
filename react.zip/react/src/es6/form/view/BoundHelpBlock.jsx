import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import lang from "util/lang";

class BoundHelpBlock extends BoundComponent {
    get modelState() {
        const model = this.model;
        const name = this.props.name;
        return { help: model && name ? model[name] : undefined };
    }
    _modelChanged() {
        const model = this.model;
        const name = this.props.name;
        if(name && model.isPropChanged(name)) {
            this.setStateFromModel();
        }
    }
    render() {
        if(this.state.help) {
            let helpContent;
            if(lang.isArray(this.state.help)) {
                helpContent = this.state.help.map((e, idx) => {
                    if(e && e.message) {
                        return <span key={idx}>{e.message}</span>;
                    } else {
                        return <span key={idx}>{String(e)}</span>;
                    }
                });
            } else {
                helpContent = <span>{String(this.state.help)}</span>;
            }
            return (
                <span id={this.props.id} className="help-block">
                    {this.props.children}
                    {helpContent}
                </span>
            )
        }
        return false;
    }
}

export default BoundHelpBlock;