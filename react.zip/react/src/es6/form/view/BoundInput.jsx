import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class BoundInput extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleChange = this._handleChange.bind(this);
        this._handleInput = this._handleInput.bind(this);
    }
    get modelState() {
        const model = this.model;
        const name = this.props.name;
        const errorName = this.props.errorName;
        return { value: model && name ? model[name] : "", error: model && errorName ? model[errorName] : undefined };
    }
    _modelChanged() {
        const name = this.props.name;
        const errorName = this.props.errorName;
        if((name && this.model.isPropChanged(name)) || (errorName && this.model.isPropChanged(errorName))) {
            this.setStateFromModel();
        }
    }
    _handleChange(e) {
        if(this.model && this.props.name) {
            this.model[this.props.name] = e.target.value;
        }
    }
    _handleInput(e) {
        if(this.model && this.props.name) {
            this.model[this.props.name] = e.target.value;
        }
    }
    render() {
        let viewProps = Object.assign({}, this.props);
        delete viewProps.model;
        delete viewProps.onChange;
        delete viewProps.onInput;
        delete viewProps.helpId;
        delete viewProps.errorName;
        delete viewProps.errorHelpId;
        const helpId = this.state.error ? this.props.errorHelpId : undefined;
        return <input {...viewProps} value={this.state.value || ""} onChange={this._handleChange} onInput={this._handleInput} aria-describedby={helpId} />
    }
}

export default BoundInput;