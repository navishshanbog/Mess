import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class BoundSelect extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleChange = this._handleChange.bind(this);
    }
    get modelState() {
        let model = this.model;
        let name = this.props.name;
        return model && name ? { value: model[name] || ""} : {};
    }
    componentDidMount() {
        super.componentDidMount();
        if(!this.state.options) {
            if(this.props.options) {
                this.setState({ options: this.props.options });
            } else if(this.props.optionSource) {
                this.setState({ optionsLoading: true, options: [] });
                Promise.resolve(this.props.optionSource).then((options) => {
                    this.setState({ optionsLoading: false, options: options });
                }).catch((err) => {
                    this.setState({ optionsLoading: false, options: [], optionsError: err });
                });
            }
        }
    }
    _modelChanged() {
        let model = this.model;
        let name = this.props.name;
        if(model.isPropChanged(name)) {
            this.setStateFromModel();
        }
    }
    _handleChange(e) {
        if(this.model && this.props.name) {
            this.model[this.props.name] = e.target.value;
        }
    }
    render() {
        let viewProps = Object.assign({}, this.props);
        delete viewProps.model;
        delete viewProps.onChange;
        delete viewProps.onInput;
        delete viewProps.optionSource;
        delete viewProps.options;
        let options;
        if(this.state.optionsLoading) {
            options = <option value="">Loading</option>;
        } if(this.state.optionsError) {
            options = <option value="">Error: {this.state.optionsError.message}</option>;
        } else if(this.state.options) {
            options = this.state.options.map((option) => {
                return <option value={option.value} selected={this.state.value === option.value}>{option.label}</option>;
            });
        } else {
            // take children
            options = this.props.children;
        }
        return (
            <select {...viewProps} onChange={this._handleChange}>
                {options}
            </select>
        );
    }
}

export default BoundSelect;