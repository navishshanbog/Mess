import * as React from "react";

class FileInput extends React.Component {
    constructor(props) {
        super(props);
        this._handleChange = this._handleChange.bind(this);
        this._handleRef = this._handleRef.bind(this);
    }
    _handleChange(e) {
        var files = this._ref.files;
        if(this.props.onChange) {
            this.props.onChange(files);
        }
    }
    _handleRef(ref) {
        this._ref = ref;
    }
    openFileDialog() {
        this._ref.click();
    }
    render() {
        const viewProps = Object.assign({}, this.props);
        delete viewProps.onChange;
        delete viewProps.type;
        return <input type="file" ref={this._handleRef} onChange={this._handleChange} {...viewProps} />;
    }
}

export default FileInput;


