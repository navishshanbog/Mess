import * as React from "react";
import appContext from "app/context";
import nav from "nav";
import layout from "layout/bootstrap/layout";

const title = "Home";

const navLinkHandler = (e) => {
    e.preventDefault();
    e.stopPropagation();
    layout.model.openNav();
};

const main =
<div className="container">
    <p>This is a site based on re* libraries (e.g. require, react, redux, reflux (the last two maybe at some point)).</p>
    <p>Feel free to take a look at the <a href="#menu" onClick={navLinkHandler}>nav menu</a> for some options.</p>
</div>;

export default () => {
    layout.go({
        title: title,
        nav: nav,
        main: main
    });
};