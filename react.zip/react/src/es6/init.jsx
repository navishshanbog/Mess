import appContext from "app/context";
import css from "util/css";
import * as React from "react";
import ReactDOM from "react-dom";
import pathUtils from "util/path";
import lang from "util/lang";
import App from "app/view/App";
import appConfig from "app.config";
import es6Promise from "es6-promise";

// lang (i.e. Object) polyfill
lang.polyfill();

// es6 promise polyfill
es6Promise.polyfill();

const basePath = appConfig.basePath || pathUtils.sep;
const cssPath = appConfig.cssPath || pathUtils.join(basePath, "/css");

appContext.basePath = basePath;
css.path = cssPath;

appContext.observe(() => {
    document.title = appContext.error ? "Error" : appContext.title;
});

appContext.init();
ReactDOM.render(<App />, document.getElementById("app-view-container"));


