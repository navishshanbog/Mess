// dummy import (a module is not returned - instead it is registered against the window)
import ozpIwcDummy from "ozp-iwc/ozpIwc-client";

const ozpIwc = window.ozpIwc;

// this module provides some simplified types for dealing with iwc

class DataReference {
    constructor(ref) {
        this._ref = ref;
    }
    get() {
        return this._ref.get.apply(this._ref, arguments);
    }
    set() {
        return this._ref.set.apply(this._ref, arguments);
    }
    watch() {
        return this._ref.watch.apply(this._ref, arguments);
    }
    delete() {
        return this._ref.delete.apply(this._ref, arguments);
    }
}

class IntentReference {
    constructor(ref) {
        this._ref = ref;
    }
    register() {
       return this._ref.register.apply(this._ref, arguments);
    }
    invoke() {
        return this._ref.invoke.apply(this._ref, arguments);
    }
}

class Client {
    constructor(iwcUrl) {
        this._client = new ozpIwc.Client(iwcUrl);
    }
    getDataReference(path, opts) {
        return new DataReference(new this._client.data.Reference(path, opts));
    }
    getIntentReference(path, opts) {
        return new IntentReference(new this._client.intents.Reference(path, opts));
    }
}

export default Client;