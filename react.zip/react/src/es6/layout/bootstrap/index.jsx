import * as React from "react";
import layout from "./layout";

const title = "Bootstrap Layout Home";
const main = <div className="container">Bootstrap Layout Home</div>;
const menu = <div>Menu Place Holder</div>;

export default () => {
    layout.go({
        title: title,
        menu: menu,
        main: main
    });
};