import * as React from "react";
import appContext from "app/context";
import LayoutView from "./view/Layout";
import LayoutModel from "../model/Layout";

class Layout {
    constructor() {
        this.model = new LayoutModel();
        this.view = <LayoutView model={this.model} />;
    }
    go(content) {
        if(content) {
            this.model.content = content;
            if(content.title) {
                appContext.title = content.title;
            }
        }
        appContext.view = this.view;
    }
}

const layoutInstance = new Layout();

appContext.observe(() => {
    if(appContext.loading) {
        layoutInstance.model.closeNav();
        layoutInstance.model.closeMenu();
    }
});

export default layoutInstance;