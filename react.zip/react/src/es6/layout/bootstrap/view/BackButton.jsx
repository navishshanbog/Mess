import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import appContext from "app/context";
import css from "util/css";

class BackButton extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return { prev: model ? model.prev : undefined };
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("prev")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
        const prev = this.state.prev;
        if(prev) {
            if(prev.action) {
                prev.action();
            } else {
                appContext.open(this.state.prev);
            }
        }
        
    }
    render() {
        if(this.state.prev) {
            let title;
            if(this.state.prev && this.state.prev.title) {
                title = <span className="title">{this.state.prev.title}</span>
            }
            return <button type="button" className={css.className("btn", "btn-default", "app-back-button")}
                            title={this.state.prev.title || "Previous"}
                            onClick={this._handleClick}>
                <span className="icon glyphicon glyphicon-chevron-left" aria-hidden={true}></span>
                {title}
            </button>;
        }
        return false;
    }
}

export default BackButton;