import * as React from "react";
import Title from "./Title";
import NavButton from "./NavButton";
import MenuButton from "./MenuButton";
import BackButton from "./BackButton";

class Header extends React.Component {
    render() {
        return (
            <nav className="navbar navbar-default navbar-fixed-top app-header">
                <div className="container-fluid">
                    <div className="nav navbar-form navbar-left">
                        <NavButton model={this.props.model} />
                        <BackButton model={this.props.model} />
                    </div>
                    <div className="nav navbar-form navbar-right">
                        <MenuButton model={this.props.model} />
                    </div>
                    <Title model={this.props.model} />
                </div>
            </nav>
        );
    }
}

export default Header;