import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import Header from "./Header";
import Nav from "./Nav";
import Menu from "./Menu";
import Main from "./Main";
import css from "util/css";

class Layout extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
        this._handleKeyUp = this._handleKeyUp.bind(this);
    }
    componentWillMount() {
        css.includes = ["bootstrap", "bootstrap-theme", "layout-bootstrap"];
    }
    get modelState() {
        let model = this.props.model;
        return { nav: model ? model.nav : undefined };
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("nav")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        let model = this.props.model;
        if(model) {
            model.closeNav();
            model.closeMenu();
        }
    }
    _handleKeyUp(e) {
        if(e.keyCode === 27) {
            let model = this.props.model;
            if(model) {
                model.closeNav();
                model.closeMenu();
            }
        }
    }
    render() {
        return (
            <div className={css.className("layout-bootstrap", this.state.nav ? "has-nav" : undefined)} onClick={this._handleClick} onKeyUp={this._handleKeyUp}>
                <Header model={this.props.model} />
                <Nav model={this.props.model} />
                <Menu model={this.props.model} />
                <Main model={this.props.model} />
            </div>
        );
    }
}

export default Layout;