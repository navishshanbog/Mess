import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class Main extends BoundComponent {
    get modelState() {
        let model = this.props.model;
        return model ? { main: model.main } : {};
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("main")) {
            this.setStateFromModel();
        }
    }
    render() {
        return (
            <div className="app-main">
                {this.state.main}
            </div>
        );
    }
}

export default Main;