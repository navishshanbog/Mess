import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import lang from "util/lang";
import MenuList from "./MenuList";
import css from "util/css";

class Menu extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return { menuOpen: model ? model.menuOpen : false, menu: model ? model.menu : undefined };
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("menuOpen") || model.isPropChanged("menu")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
    }
    render() {
        let content;
        if(this.state.menu) {
            if(React.isValidElement(this.state.menu) || lang.isString(this.state.menu)) {
                content = this.state.menu;
            } else {
                let items = lang.isArray(this.state.menu) ? this.state.menu : [this.state.menu];
                content = <MenuList items={items} />;
            }
        }
        return (
            <div className={css.className("app-menu", this.state.menuOpen ? "open" : "closed")} aria-hidden={!this.state.menuOpen} onClick={this._handleClick}>
                <div className="app-menu-overlay" />
                <div className="app-menu-content">
                    {content}
                </div>
            </div>
        );
    }
}

export default Menu;