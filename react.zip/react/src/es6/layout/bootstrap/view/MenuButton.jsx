import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import css from "util/css";

class MenuButton extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return { menuOpen: model ? model.menuOpen : false, menu: model ? model.menu : undefined };
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("menuOpen") || model.isPropChanged("menu")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
        let model = this.props.model;
        if(model) {
            model.toggleMenu();
        }
    }

    render() {
        if(this.state.menu) {
            return <button type="button" className={css.className("app-menu-button", "btn", "btn-default", this.state.menuOpen ? "active" : undefined)}
                        aria-expanded={this.state.menuOpen}
                        title={this.state.menuOpen ? "Close Menu" : "Open Menu"}
                        onClick={this._handleClick}
                        aria-haspopup={true}>
                <span className="glyphicon glyphicon-option-vertical" aria-hidden={true}></span>
            </button>;
        }
        return false;
    }
}

export default MenuButton;