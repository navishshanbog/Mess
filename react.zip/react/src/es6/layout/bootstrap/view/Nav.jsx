import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import lang from "util/lang";
import MenuList from "./MenuList";
import css from "util/css";

class Nav extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return { navOpen: model ? model.navOpen : false, nav: model ? model.nav : undefined };
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("navOpen") || model.isPropChanged("nav")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
    }
    render() {
        let content;
        if(this.state.nav) {
            if(React.isValidElement(this.state.nav)) {
                content = this.state.nav;
            } else {
                let items = lang.isArray(this.state.nav) ? this.state.nav : [this.state.nav];
                content = <MenuList items={items} />;
            }
        }
        return (
            <div className={css.className("app-nav", this.state.navOpen ? "open" : "closed")} aria-hidden={!this.state.navOpen} onClick={this._handleClick}>
                <div className="app-nav-overlay" />
                <div className="app-nav-content">
                    {content}
                </div>
            </div>
        );
    }
}

export default Nav;