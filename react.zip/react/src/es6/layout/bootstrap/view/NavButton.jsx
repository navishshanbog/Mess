import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import css from "util/css";

class NavButton extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return { navOpen: model ? model.navOpen : false, nav: model ? model.nav : undefined };
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("navOpen") || model.isPropChanged("nav")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
        let model = this.props.model;
        if(model) {
            model.toggleNav();
        }
    }

    render() {
        if(this.state.nav) {
            return <button type="button" className={css.className("app-nav-button", "btn", "btn-default", this.state.navOpen ? "active" : undefined)}
                        aria-expanded={this.state.navOpen}
                        title={this.state.navOpen ? "Close Navigation" : "Open Navigation"}
                        onClick={this._handleClick}
                        aria-haspopup={true}>
                <span className="glyphicon glyphicon-menu-hamburger" aria-hidden={true}></span>
            </button>;
        }
        return false;
    }
}

export default NavButton;