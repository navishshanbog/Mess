import * as React from "react";
import lang from "util/lang";
import appContext from "app/context";
import AppLink from "app/view/AppLink";
import css from "util/css";

class NavList extends React.Component {
    render() {
        let items = this.props.items;
        let kids;
        let place;
        if(items && items.length > 0) {
            kids = items.map(function(item, idx) {
                if(React.isValidElement(item)) {
                    return <div key={idx} className="list-group-item">{item}</div>;
                } else if(lang.isObject(item) && item !== null) {
                    place = item;
                }

                if(place) {
                    return <AppLink key={idx} className={css.className("list-group-item", appContext.path === place.path ? "active" : undefined)} title={place.title} path={place.path} params={place.params}>{place.title}</AppLink>
                }
            });
        }

        return <div className="list-group">{kids}</div>;
    }
}

export default NavList;