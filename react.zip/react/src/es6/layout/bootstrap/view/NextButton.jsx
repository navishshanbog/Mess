import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import appContext from "app/context";
import css from "util/css";

class NextButton extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return { next: model ? model.next : undefined };
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("next")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
        const next = this.state.next;
        if(next) {
            if(next.action) {
                next.action();
            } else {
                appContext.open(this.state.next);
            }
        }
        
    }
    render() {
        if(this.state.next) {
            let title;
            if(this.state.next && this.state.next.title) {
                title = <span className="title">{this.state.next.title}</span>
            }
            return <button type="button" className={css.className("btn", "btn-default", "app-next-button")}
                            title={this.state.next.title || "Previous"}
                            onClick={this._handleClick}>
                <span className="icon glyphicon glyphicon-chevron-right" aria-hidden={true}></span>
                {title}
            </button>;
        }
        return false;
    }
}

export default NextButton;