import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class Title extends BoundComponent {
    get modelState() {
        let model = this.props.model;
        return model ? { header: model.header, title: model.title } : {};
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("header") || model.isPropChanged("title")) {
            this.setStateFromModel();
        }
    }
    render() {
        return (
            <div className="app-title">
                {this.state.header || this.state.title}
            </div>
        );
    }
}

export default Title;