import * as React from "react";
import layout from "./layout";

const title = "Material Layout Home";
const main = "Material Design Layout Home";
const menu = <div>Menu Place Holder</div>;

export default () => {
    layout.go({
        title: title,
        menu: menu,
        main: main
    });
};