import * as React from "react";
import MenuButton from "./MenuButton";
import Title from "./Title";

class Header extends React.Component {
    render() {
        return (
            <header className="mdl-layout__header is-casting-shadow">
                <MenuButton model={this.props.model} />
                <div className="mdl-layout__header-row">
                    <Title model={this.props.model} />
                </div>
            </header>
        );
    }
}

export default Header;