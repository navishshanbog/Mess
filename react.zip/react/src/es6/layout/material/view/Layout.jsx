import * as React from "react";
import css from "util/css";
import Header from "./Header";
import Menu from "./Menu";
import Main from "./Main";
import Obfuscator from "./Obfuscator";

class Layout extends React.Component {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
        this._handleKeyUp = this._handleKeyUp.bind(this);
    }
    componentWillMount() {
        css.includes = ["material-design-icons/material-icons", "material-design-lite/material.min", "layout-material"];
    }
    _handleClick(e) {
        let model = this.props.model;
        if(model) {
            model.closeMenu();
        }
    }
    _handleKeyUp(e) {
        if(e.keyCode === 27) {
            let model = this.props.model;
            if(model) {
                model.closeMenu();
            }
        }
    }
    render() {
        return (
            <div className="layout-material mdl-layout__container" onClick={this._handleClick} onKeyUp={this._handleKeyUp}>
                <div className="mdl-layout mdl-js-layout mdl-layout--fixed-header has-drawer is-upgraded" data-upgraded=",MaterialLayout">
                    <Header model={this.props.model} />
                    <Menu model={this.props.model} />
                    <Main model={this.props.model} />
                    <Obfuscator model={this.props.model} />
                </div>
            </div>
        );
    }
}

export default Layout;