import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import lang from "util/lang";
import MenuList from "./MenuList";
import Title from "./Title";
import css from "util/css";

class Menu extends BoundComponent {
    get modelState() {
        let model = this.props.model;
        return { menuOpen: model ? model.menuOpen : false, menu: model ? model.menu : undefined };
    }
    _modelChanged() {
        const model = this.props.model;
        if(model.isPropChanged("menuOpen") || model.isPropChanged("menu")) {
            this.setStateFromModel();
        }
    }
    render() {
        let content;
        if(this.state.menu) {
            if(React.isValidElement(this.state.menu) || lang.isString(this.state.menu)) {
                content = this.state.menu;
            } else {
                let items = lang.isArray(this.state.menu) ? this.state.menu : [this.state.menu];
                content = <MenuList items={items} />;
            }
        }
        return (
            <div className={"mdl-layout__drawer" + (this.state.menuOpen ? " is-visible" : "") } aria-hidden={!this.state.menuOpen}>
                <Title model={this.props.model} />
                <nav className="mdl-navigation">
                    {content}
                </nav>
            </div>
        );
    }
}

export default Menu;