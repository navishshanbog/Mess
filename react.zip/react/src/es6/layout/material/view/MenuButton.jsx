import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class MenuButton extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return model ? { menuOpen: model.menuOpen, menu: model.menu } : {};
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("menuOpen") || model.isPropChanged("menu")) {
            this.setStateFromModel();
        }
    }
    _handleClick(e) {
        e.stopPropagation();
        let model = this.props.model;
        if(model) {
            model.toggleMenu();
        }
    }

    render() {
        if(this.state.menu) {
            return (
                <div aria-expanded={this.state.menuOpen} role="button" className="mdl-layout__drawer-button" onClick={this._handleClick}>
                    <i className="material-icons">{"\uE5D2"}</i>
                </div>
            );
        }
        return false;
    }
}

export default MenuButton;