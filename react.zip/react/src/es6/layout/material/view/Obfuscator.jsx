import * as React from "react";
import BoundComponent from "common/view/BoundComponent";

class Obfuscator extends BoundComponent {
    get modelState() {
        return { menuOpen: this.model ? this.model.menuOpen : false };
    }
    _modelChanged() {
        let model = this.model;
        if(model.isPropChanged("menuOpen")) {
            this.setStateFromModel();
        }
    }
    render() {
        return (
            <div className={"mdl-layout__obfuscator" + (this.state.menuOpen ? " is-visible" : "")}></div>
        );
    }
}

export default Obfuscator;