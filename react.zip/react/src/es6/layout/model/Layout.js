import Model from "util/Model";

class Layout extends Model {
    defaultProps() {
        return { navOpen: false, menuOpen: false };
    }

    get menu() {
        return this.get("menu");
    }
    set menu(value) {
        this.set("menu", value).notify();
    }

    get menuOpen() {
        return this.get("menuOpen");
    }
    set menuOpen(value) {
        this.set("menuOpen", value).notify();
    }
    
    openMenu() {
        this.menuOpen = true;
    }

    closeMenu() {
        this.menuOpen = false;
    }

    toggleMenu() {
        this.menuOpen = !this.menuOpen;
    }

    get nav() {
        return this.get("nav");
    }
    set nav(value) {
        this.set("nav", value).notify();
    }

    get navOpen() {
        return this.get("navOpen");
    }
    set navOpen(value) {
        this.set("navOpen", value).notify();
    }

    openNav() {
        this.navOpen = true;
    }

    closeNav() {
        this.navOpen = false;
    }

    toggleNav() {
        this.navOpen = !this.navOpen;
    }

    get main() {
        return this.get("main");
    }
    set main(value) {
        this.set("main", value).notify();
    }

    get title() {
        return this.get("title");
    }
    set title(value) {
        this.set("title", value).notify();
    }

    get header() {
        return this.get("header");
    }
    set header(value) {
        this.set("header", value).notify();
    }

    get prev() {
        return this.get("prev");
    }
    set prev(value) {
        this.set("prev", value).notify();
    }

    get next() {
        return this.get("next");
    }
    set next(value) {
        this.set("next", value).notify();
    }

    get content() {
        return {
            header: this.header,
            title: this.title,
            menu: this.menu,
            nav: this.nav,
            main: this.main,
            prev: this.prev,
            next: this.next
        };
    }
    set content(value) {
        this.set({
            header: value ? value.header : undefined,
            title: value ? value.title : undefined,
            menu: value ? value.menu : undefined,
            nav: value ? value.nav : undefined,
            main: value ? value.main : undefined,
            prev: value ? value.prev : undefined,
            next: value ? value.next : undefined
        }).notify();
    }
}

export default Layout;