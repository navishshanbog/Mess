import * as React from "react";
export default [
    { title: "Home", path: "index" },
    { title: "Utilities", path: "util/index" },
    { title: "Analyst Desktop", path: "analystDesktop/index" }
];