export default {
    home: { title: "Home", path: "index" },
    utilitiesHome: { title: "Utilities", path: "util/index" }
}