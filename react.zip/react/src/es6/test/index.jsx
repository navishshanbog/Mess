import * as React from "react";
import testRunner from "./runner";

const suite = {
    title: "Testing Example",
    testAllOk(ctx) {
        ctx.message("Here's a sample message");
        ctx.assert(true);
        ctx.assert(true, "A specified assert message");
    },
    testSomeOk(ctx) {
        ctx.message("Here's a sample message");
        ctx.assert(true);
        ctx.assert(true, "A specified assert message");
        ctx.assert(false);
        ctx.assert(false, "A specified assert message");
        throw new Error("A Sample Error");
    },
    testAllFailed(ctx) {
        ctx.message("Here's a sample message");
        ctx.assert(false);
        ctx.assert(false, "A specified assert message");
    }
};

export default () => {
    testRunner({
        suite: suite
    });
};