class MockHistory {
    constructor(eventTarget) {
        this.eventTarget = eventTarget;
        this.state = [];
    }
    get eventTarget() {
        return this._eventTarget;
    }
    set eventTarget(value) {
        this._eventTarget = value;
    }
    get length() {
        return 0;
    }
    get scrollRestoration() {
        return this._scrollRestoration;
    }
    set scrollRestoration(value) {
        this._scrollRestoration = value;
    }
    back() {
        
    }
    forward() {

    }
    go() {

    }
    pushState() {

    }
    replaceState() {

    }
}

export default MockHistory;