import EventTarget from "util/EventTarget";

class MockWindow extends EventTarget {
    
}