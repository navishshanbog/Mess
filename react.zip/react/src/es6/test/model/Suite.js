import Model from "util/Model";
import TestModel from "./Test";
import lang from "util/lang";
import stringUtils from "util/string";

class SuiteStore extends Model {
    get tests() {
        if(!this._tests) {
            this._tests = [];
        }
        return this._tests;
    }

    load(suite) {
        delete this._tests;
        delete this._init;
        delete this._destroy;

        if(suite) {
            var destroyHandler;
            if(lang.isFunction(suite.init)) {
                this._init = () => {
                    suite.init();
                };
                if(lang.isFunction(suite.destroy)) {
                    this._destroy = () => {
                        suite.destroy();
                    };
                }
            }

            Object.keys(suite).forEach((name) => {
                if(stringUtils.startsWithIgnoreCase(name, "test")) {
                    let test = new TestModel();
                    test.title = name;
                    test.test = suite[name];
                    this.tests.push(test)
                }
            });
        }

        this._setPropChanged("tests").notify();
    }
    
    run() {
        let initPromise = Promise.resolve(this._init ? this._init() : undefined);
        return initPromise.then(() => {
            let testPromises = this.tests.map((test) => {
                return Promise.resolve(test.run());
            });
            return Promise.all(testPromises);
        }).then(() => {
            if(this._destroy) {
                return Promise.resolve(this._destroy());
            }
        });
        
    }

    loadAndRun(suite) {
        this.load(suite);
        this.run();
    }
}

export default SuiteStore;