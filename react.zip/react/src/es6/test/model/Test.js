import Model from "util/Model";

var resultType = {
    assert: "assert",
    message: "message",
    error: "error",
    action: "action",
    view: "view"
};

var createAssert = (test) => {
    var f = (r, message) => {
        var ok = r ? true : false;
        test._addResult({ type: resultType.assert, ok: ok, message: message || (ok ? "OK" : "FAIL")});
    };
    f.ok = f;
    f.equal = (actual, expected, message) => {
        var ok = actual === expected;
        test._addResult({ type: resultType.assert, ok: ok, message: (message || (ok ? "OK" : "FAIL")), values: { actual: actual, expected: expected } });
    };
    return f;
};

var createMessage = (test) => {
    return (msg, value) => {
        test._addResult({ type: resultType.message, message: msg, value: value });
    };
};

var createError = (test) => {
    return (e) => {
        test._addResult({ type: resultType.error, error: e });
    };
};

var createAction = (test) => {
    return (action, name) => {
        test._addResult({ type: resultType.action, action: action, name: name });
    };
};

var createView = (test) => {
    return (view) => {
        test._addResult({ type: resultType.view, view: view });
    }
};

class Test extends Model {
    get startDate() {
        return this.get("startDate");
    }
    get endDate() {
        return this.get("endDate");
    }
    get results() {
        if(!this._results) {
            this._results = [];
        }
        return this._results;
    }
    get resultsSummary() {
        var results = this.results;
        var assertCount = 0;
        var assertOkCount = 0;
        var assertFailCount = 0;
        var errorCount = 0;
        
        if(results && results.length > 0) {
            results.forEach((item) => {
                if(item.type === resultType.assert) {
                    assertCount ++;
                    if(item.ok) {
                        assertOkCount ++;
                    } else {
                        assertFailCount ++;
                    }
                } else if(item.type === resultType.error) {
                    errorCount ++;
                }
            });
        }

        return {
            startDate: this.startDate,
            endDate: this.endDate,
            assertCount: assertCount,
            assertOkCount: assertOkCount,
            assertFailCount: assertFailCount,
            errorCount: errorCount
        };
    }
    _addResult(result) {
        if(result) {
            this.results.push(result);
            this._setPropChanged("results").notify();
        }
    }
    run() {
        delete this._results;

        var assert = createAssert(this);
        var message = createMessage(this);
        var error = createError(this);
        var action = createAction(this);
        var view = createView(this);

        var testContext = {
            assert: assert,
            message: message,
            error: error,
            action: action,
            view: view
        };

        return new Promise((resolve, reject) => {
            var handleEnd = () => {
                this.set("endDate", new Date()).notify();
                resolve(this.results);
            };

            var handleEndError = (err) => {
                error(err);
                handleEnd();
            };

            this.set({
                startDate: new Date(),
                endDate: undefined,
            }).notify();

            try {
                Promise.resolve(this.test(testContext)).then(handleEnd).catch(handleEndError);
            } catch(e) {
                handleEndError(e);
            }
        });
    }
}

Test.resultType = resultType;

export default Test;