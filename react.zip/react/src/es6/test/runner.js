import * as React from "react";
import SuiteView from "./view/Suite";
import SuiteModel from "test/model/Suite";
import layout from "layout/bootstrap/layout";

const suiteModel = new SuiteModel();

const main = <div className="container"><SuiteView model={suiteModel} /></div>;

export default (opts) => {
    const suite = opts.suite;
    suiteModel.loadAndRun(suite);
    layout.go({
        title: suite ? suite.title : "Suite Not Specified",
        menu: opts.menu,
        prev: opts.prev,
        main: main
    });
};