import SuiteStore from "test/model/Suite";

export default new SuiteStore();