import * as React from "react";

class ActionResult extends React.Component {
    constructor(props) {
        super(props);
        this.state = { running: false };
        this._handleClick = this._handleClick.bind(this);
    }
    _handleClick(e) {
        this.setState({ running: true });
        Promise.resolve(this.props.result.action()).then(() => {
            this.setState({ running: false });
        }).catch((err) => {
            this.setState({ running: false });  
        });
    }
    render() {
        const result = this.props.result;
        const title = result.name || "Execute Action";
        const icon = this.state.running ? <span className="glyphicon glyphicon-refresh spin"></span> : <span className="glyphicon glyphicon-play"></span>;
        return (
            <div className="list-group-item test-action">
                <button type="button" className="btn" disabled={this.state.running} onClick={this._handleClick} title={title}>
                    {icon} {title}
                </button>
            </div>
        );
    }
}

export default ActionResult;


