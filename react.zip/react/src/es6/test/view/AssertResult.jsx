import * as React from "react";

class AssertResult extends React.Component {
    render() {
        var result = this.props.result;
        var context = result.ok ? "success" : "danger";
        var messageContent = <div className="test-result-assert-message">
                                {result.ok ? "\u2713" : "\u2717"}
                                {" "}
                                {result.message}
                            </div>;
        var valueContent;
        if(!result.ok && result.values) {
            valueContent = <div className="values">
                            <div className="expected">
                                <label className="label">Expected:</label>
                                <div className="value">{String(result.values.expected)}</div>
                            </div>
                            <div className="actual">
                                <label className="label">Actual:</label>
                                <div className="value">{String(result.values.actual)}</div>
                            </div>
                        </div>;
        }
        return (
            <div className={"list-group-item list-group-item-" + context}>
                {messageContent}
                {valueContent}
            </div>
        );
    }
}

export default AssertResult;


