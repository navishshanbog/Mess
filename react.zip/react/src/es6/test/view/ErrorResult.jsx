import * as React from "react";
import lang from "util/lang";
import Error from "common/view/Error";

class ErrorResult extends React.Component {
    render() {
        let result = this.props.result;

        return (
            <div className="list-group-item list-group-item-danger">
                <Error className="test-result test-result-error" error={result.error} />
            </div>
        );
    }
}

export default ErrorResult;