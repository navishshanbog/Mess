import * as React from "react";
import lang from "util/lang";

class MessageResult extends React.Component {
    constructor(props) {
        super(props);
        this._handleClick = this._handleClick.bind(this);
    }
    _handleClick(e) {
        e.preventDefault();
        this.props.result.action();
    }
    render() {
        const result = this.props.result;
        const message = result.message;
        const value = result.value;
        const messageContent = lang.isObject(message) ? <pre>{JSON.stringify(message, null, "\t")}</pre> : String(message);
        const valueContent = value ? lang.isObject(value) ? <pre>{JSON.stringify(value, null, "\t")}</pre> : String(value) : undefined;
        
        return (
            <div className="list-group-item">
                {messageContent}
                {valueContent}
            </div>
        );
    }
}

export default MessageResult;