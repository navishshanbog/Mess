import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import Test from "./Test";

class Suite extends BoundComponent {
    get modelState() {
        let model = this.props.model;
        return model ? { tests: model.tests } : {};
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("tests")) {
            this.setStateFromModel();
        }
    }
    render() {
        var tests = this.state.tests;
        var content;
        if(tests && tests.length > 0) {
            content = tests.map(function(test, idx) {
                return <Test key={"test" + idx}  model={test} />
            });
        } else {
            content = "No Tests in Suite";
        }

        return <div className="test-suite">{content}</div>
    }
}

export default Suite;