import * as React from "react";
import BoundComponent from "common/view/BoundComponent";
import TestSummary from "./TestSummary";
import TestResultList from "./TestResultList";

class Test extends BoundComponent {
    constructor(props) {
        super(props);
        this._handleRunClick = this._handleRunClick.bind(this);
        this._handleHeaderClick = this._handleHeaderClick.bind(this);
    }
    get modelState() {
        let model = this.props.model;
        return model ? {
            title: model.title,
            startDate: model.startDate,
            endDate: model.endDate,
            results: model.results,
            summary: model.resultsSummary,
            expanded: true
        } : {};
    }
    _modelChanged() {
        let model = this.props.model;
        if(model.isPropChanged("title") ||
           model.isPropChanged("startDate") ||
           model.isPropChanged("endDate") ||
           model.isPropChanged("results")) {
            this.setStateFromModel();
        }
    }
    _handleRunClick(e) {
        e.preventDefault();
        if(this.props.model) {
            this.props.model.run();
        }
    }
    _handleHeaderClick() {
        this.setState({ expanded: !this.state.expanded });
    }
    render() {
        let startDate = this.state.startDate;
        let endDate = this.state.endDate;
        let results = this.state.results;
        let summary = this.state.summary;
        let stateClassName;
        let stateIcon;
        let bodyContent;
        let summaryContent;

        if(startDate) {
            if(!endDate) {
                stateIcon = <span className="glyphicon glyphicon-refresh spin"></span>;
            } else {
                stateIcon = summary.assertCount > 0 ? summary.errorCount > 0 || summary.assertFailCount > 0 ? <span>{"\u2717"}</span> : <span>{"\u2713"}</span> : undefined;
            }

            stateClassName = summary.assertCount > 0 ? summary.errorCount > 0 || summary.assertFailCount > 0 ? "danger" : "success" : "default";
            if(results && results.length > 0) {
                summaryContent = <TestSummary summary={summary} />;
                bodyContent = this.state.expanded ? <TestResultList results={results} /> : undefined;
            } else {
                bodyContent = this.state.expanded ? <div className="panel-body">No Results to Display</div> : undefined;
            }
        } else {
            bodyContent = this.state.expanded ? <div className="panel-body"><a href="#run" title="Run Test" onClick={this._handleRunClick}>Run Test</a></div> : undefined;
        }

        return (
            <div className={"test panel " + (stateClassName ? "panel-" + stateClassName : "")}>
                <div className="test-heading panel-heading" onClick={this._handleHeaderClick}>
                    <h3 className="panel-title">{this.state.title} {stateIcon}</h3>
                    {summaryContent}
                </div>
                {bodyContent}
            </div>
        );
    }
};

export default Test;


