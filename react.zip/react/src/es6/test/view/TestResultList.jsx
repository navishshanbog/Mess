import * as React from "react";
import TestModel from "test/model/Test";
import AssertResult from "./AssertResult";
import ActionResult from "./ActionResult";
import MessageResult from "./MessageResult";
import ErrorResult from "./ErrorResult";
import ViewResult from "./ViewResult";
import Error from "common/view/Error";

class TestResultList extends React.Component {
    render() {
        let results = this.props.results;
        if(results && results.length > 0) {
            var content = results.map((item, idx) => {
                if(TestModel.resultType.assert === item.type) {
                    return <AssertResult key={"result" + idx} result={item} />;
                } else if(TestModel.resultType.action === item.type) {
                    return <ActionResult key={"result" + idx} result={item} />;
                } else if(TestModel.resultType.error === item.type) {
                    return <ErrorResult key={"result" + idx} result={item} />
                } else if(TestModel.resultType.view === item.type) {
                    return <ViewResult key={"result" + idx} result={item} />
                }
                return <MessageResult key={"result" + idx} result={item} />;
            });
            return <div className="list-group">{content}</div>;
        }
        return false;
    }
};

export default TestResultList;