import * as React from "react";

class TestSummary extends React.Component {
    render() {
        let summary = this.props.summary;
        let testOkCount;
        if(summary.assertOkCount > 0) {
            testOkCount = <span className="label label-success" title={"Tests OK: " + summary.assertOkCount}>{summary.assertOkCount}</span>;
        }
        let testFailCount;
        if(summary.assertFailCount > 0) {
            testFailCount = <span className="label label-danger" title={"Tests Failed: " + summary.assertFailCount}>{summary.assertFailCount}</span>;
        }
        let testDuration;
        if(summary.assertCount > 0 && summary.startDate && summary.endDate) {
            testDuration = <span className="label label-info" title={"Duration: " + (summary.endDate - summary.startDate) + " ms"}>{summary.endDate - summary.startDate} ms</span>
        }
        return <div className="test-summary">
            {testOkCount}
            {" "}
            {testFailCount}
            {" "}
            {testDuration}
        </div>;
    }
}

export default TestSummary;