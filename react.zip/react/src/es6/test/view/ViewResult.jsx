import * as React from "react";

class ViewResult extends React.Component {
    render() {
        var result = this.props.result;
        return (
            <div className="list-group-item test-view">
                {result.view}
            </div>
        );
    }
}

export default ViewResult;