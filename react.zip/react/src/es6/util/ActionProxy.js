import lang from "./lang";
import Proxy from "./Proxy";

/**
 * The action dispatcher is a variant of the 'standard' Dispatcher (i.e. a flux Dispatcher) that invokes target methods on registered
 * actions. It is basically a composite proxy with some additional functionality.
 * E.g.
 * const ad = new ActionDispatcer();
 * ad.targetMethods = ["search", "save"];
 * const component = {
 *      search(params) {
 *          console.log("Search");
 *      }
 * };
 * ad.register(component);
 * ad.search(params) will invoke the component.search(params) method, however ad.save() won't do anything
 * Anyway, it'll all be clear in the unit test ./test/ActionProxy.js
 */
class ActionProxy extends Proxy {
    constructor(opts) {
        super();
        this.methods = opts ? opts.methods : undefined;
    }
    _invokeActionsMethod(r) {
        r.pending = true;
        const m = r.o[this._invoking];
        if(lang.isFunction(m)) {
            m.apply(r.o, this._args);
        }
        r.invoked = true;
    }
    _beginInvoke(name, args) {
        if(this._invoking) {
            throw new Error(`Already Invoking - method ${this._invoking}`);
        }
        if(this._actions) {
            this._actions.forEach((r) => {
                r.pending = false;
                r.invoked = false;
            });
        }
        this._invoking = name;
        this._args = args;
    }
    _endInvoke() {
        if(this._actions) {
            this._actions.forEach((r) => {
                delete r.pending;
                delete r.invoked;
            });
        }
        delete this._invoking;
        delete this._args;
    }
    _invokeMethod(name, args) {
        this._beginInvoke(name, args);
        try {
            if(this._actions) {
                const al = [].concat(this._actions);
                al.forEach((r) => {
                    if(!r.pending && !r.invoked) {
                        this._invokeActionsMethod(r);
                    }
                });
            }
        } finally {
            this._endInvoke();
        }
    }
    register(actions) {
        if(actions) {
            if(!this._actions) {
                this._actions = [{ o: actions }];
            } else if(!this.isRegistered(actions)) {
                this._actions.push({ o: actions });
            }
        }
    }
    isRegistered(actions) {
        return this.indexOf(actions) >= 0;
    }
    indexOf(actions) {
        let foundIdx = -1;
        if(this._actions) {
            this._actions.some((a, idx) => {
                if(a.o === actions) {
                    foundIdx = idx;
                    return true;
                }
            });
        }
        return foundIdx;
    }
    _getReg(actions) {
        const idx = this.indexOf(actions);
        return idx >= 0 ? this._actions[idx] : undefined;
    }
    unregister(actions) {
        const idx = this.indexOf(actions);
        if(idx >= 0) {
            let r = this._actions.splice(idx, 1);
            if(this._actions.length === 0) {
                delete this._actions;
            }
            r.pending = true;
            r.invoked = true;
        }
    }
    _waitForImpl(actions) {
        const r = this._getReg(actions);
        if(r) {
            if(!r.pending) {
                this._invokeActionsMethod(r);
            } else if(!r.invoked) {
                throw new Error("Circular reference detected waiting for: " + actions);
            }
        }
    }
    waitFor() {
        if(!this._invoking) {
            throw new Error("Must be invoking");
        }
        if(this._actions && arguments.length > 0) {
            Array.prototype.forEach.call(arguments, function(arg) {
                if(lang.isArray(arg)) {
                    arg.forEach(this._waitForImpl, this);
                } else {
                    this._waitForImpl(arg);
                }
            }, this);
        }
    }
}

export default ActionProxy;