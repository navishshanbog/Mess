import lang from "./lang";
import idUtils from "./id";

class Dispatcher {
    _nextId() {
        if(!this._idSeq) {
            this._idSeq = new idUtils.Sequence("did:");
        }
        return this._idSeq.next();
    }
    register(o, scope) {
        if(o) {
            let id = this._nextId();
            if(!this._cb) {
                this._cb = {};
            }
            
            let f = lang.isFunction(o) ? o : (payload) => {
                if(lang.isFunction(o.handleDispatch)) {
                    o.handleDispatch(payload);
                } else if(payload && payload.type && lang.isFunction(o[payload.type])) {
                    o[payload.type](payload);
                }
            };
            this._cb[id] = { id: id, o: o, f: f, s: scope };
            return id;
        }
    }
    unregister(o) {
        if(o && this._cb && this._cb[o]) {
            delete this._cb[o];
        } else if(o && this._cb) {
            let found;
            let idCb;

            Object.keys(this._cb).some((id) => {
                idCb = this._cb[id];
                if(idCb.o === o) {
                    found = cb;
                    return true;
                }
            });

            if(found) {
                delete this._cb[found.id];
            }
        }
    }
    _waitForId(id) {
        let r = this._cb[id];
        if(r) {
            if(!r.pending) {
                this._invokeCallback(r);
            } else if(!r.handled) {
                throw new Error("Circular reference detected waiting for: " + id);
            }
        }
    }
    waitFor() {
        if(!this._dispatching) {
            throw new Error("Must be dispatching");
        }
        if(this._cb && arguments.length > 0) {
            Array.prototype.forEach.call(arguments, function(arg) {
                if(Array.isArray(arg)) {
                    arg.forEach(this._waitForId, this);
                } else {
                    this._waitForId(arg);
                }
            }, this);
        }
    }
    _beginDispatch(payload) {
        var r;
        for(var id in this._cb) {
            r = this._cb[id];
            r.pending = false;
            r.handled = false;
        }
        this._payload = payload;
        this._dispatching = true;
    }
    _endDispatch() {
        delete this._payload;
        delete this._dispatching;
    }
    _invokeCallback(r) {
        r.pending = true;
        r.f.call(r.s, this._payload);
        r.handled = true; 
    }
    dispatch(payload) {
        if(this._dispatching) {
            throw new Error("Already dispatching");
        }
        if(this._cb) {
            this._beginDispatch(payload);
            try {
                var r;
                for(var id in this._cb) {
                    r = this._cb[id];
                    if(r && !r.pending) {
                        this._invokeCallback(r);
                    }
                }
            } finally {
                this._endDispatch();
            }
        }
    }
    get dispatching() {
        return this._dispatching ? true : false;
    }
}

export default Dispatcher;