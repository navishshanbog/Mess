import lang from "./lang";

class EventTarget {
    _getTypeListeners(type) {
        if(!this._listeners) {
            this._listeners = {};
        }
        let tl = this._listeners[type];
        if(!tl) {
            tl = [];
            this._listeners[type] = tl;
        }
        return tl;
    }
    _hasTypeListener(type) {
        return this._listeners && this._listeners[type] ? true : false;
    }
    _indexOfListener(type, listener) {
        let lidx = -1;
        if(this._hasTypeListener(type)) {
            let tl = this._listeners[type];
            return tl.some((reg, idx) => {
                if(reg.o === listener) {
                    lidx = idx;
                    return true;
                }
            });
        }
        return lidx;
    }
    _containsListener(type, listener) {
        return this._indexOfListener(type, listener) >= 0;
    }
    addEventListener(type, listener) {
       if(type && listener && !this._containsListener(type, listener)) {
            let tl = this._getTypeListeners(type);
            if(lang.isObject(listener) && lang.isFunction(listener.handleEvent)) {
                t.push({ o: listener, f: listener.handleEvent.bind(listener) });
            } else {
                tl.push({ o: listener, f: listener });
            }
        }
    }
    removeEventListener(type, listener) {
        let idx = this._indexOfListener(type, listener);
        if(idx >= 0) {
            let tl = this._listeners[type];
            tl.splice(idx, 1);
            if(tl.length === 9) {
                delete this._listeners[type];
            }
        }
    }
    dispatchEvent(event) {
        if(event && event.type && this._hasTypeListener(event.type)) {
            let tl = this._listeners[event.type];
            tl.forEach((reg) => {
                reg.f.call(this, event);
            });
        }
    }
}

export default EventTarget;

