import Observable from "./Observable";
import lang from "./lang";

class Model extends Observable {
    constructor(props) {
        super();
        this._initProps = props;
    }

    get _propState() {
        if(!this.__propState) {
            let i;
            if(this.defaultProps) {
                if(lang.isFunction(this.defaultProps)) {
                    i = this.defaultProps();
                } else {
                    i = this.defaultProps;
                }
            }
            if(!i) {
                i = {};
            }
            if(this._initProps) {
                Object.assign(i, this._initProps);
            }
            var p = Object.assign({}, i);
            this.__propState = { p: p, i: i };
        }
        return this.__propState;
    }

    _getImpl(name) {
        return this._propState.p[name];
    }

    get() {
        if(arguments.length > 0) {
            if(arguments.length === 1 && lang.isString(arguments[0])) {
                return this._getImpl(arguments[0]);
            }
            let r = {};
            Array.prototype.forEach.call(arguments, function(arg) {
                if(lang.isString(arg)) {
                    r[arg] = this._getImpl(arg);
                } else if(lang.isArray(arg)) {
                    arg.forEach(function(name) {
                        r[name] = this._getImpl(name);
                    }, this);
                } else if(lang.isObject(arg) && arg !== null) {
                    let val;
                    Object.keys(arg).forEach(function(name) {
                        val = this._getImpl(name);
                        r[name] = val !== undefined ? val : arg[name];
                    }, this);
                }
            }, this);
            return r;
        } 
        
        return Object.assign({}, this._propState.p);
    }

    _unsetImpl(name) {
        var props = this._propState.p;
        var old = props[name];
        if(old !== undefined) {
            delete props[name];
            this._setPropChanged(name, old, undefined);
        }
        return this;
    }

    unset() {
        if(arguments.length > 0) {
            Array.prototype.forEach.call(arguments, function(arg) {
                if(lang.isString(arg)) {
                    this._unsetImpl(arg);
                } else if(lang.isArray(arg)) {
                    arg.forEach(this._unsetImpl, this);
                }
            }, this);
        } else {
            // all props will be unset
            Object.keys(this._propState.p).forEach(this._unsetImpl, this);
        }
        return this;
    }

    clear() {
        return this.unset();
    }
    
    _propValuesEqual(name, old, value) {
        if(this.propEq && this.propEq[name]) {
            return this.propEq[name](old, value);
        }
        return value === old;
    }

    _setImpl(name, value) {
        if(value === undefined) {
            this._unsetImpl(name);
        } else {
            var props = this._propState.p;
            var old = props[name];
            if(!this._propValuesEqual(name, old, value)) {
                props[name] = value;
                this._setPropChanged(name, old, value);
            }
        }
        return this;
    }

    set() {
        if(arguments.length > 0) {
            var firstArg = arguments[0];
            if(lang.isString(firstArg)) {
                this._setImpl.apply(this, arguments);
            } else {
                Array.prototype.forEach.call(arguments, function(arg) {
                    if(lang.isObject(arg) && arg !== null) {
                        Object.keys(arg).forEach(function(name) {
                            this._setImpl(name, arg[name]);
                        }, this);
                    }
                }, this);
            }
        }
        return this;
    }
    
    _resetImpl(name) {
        return this._setImpl(name, this._propState.i[name]);
    }

    reset() {
        if(arguments.length > 0) {
            Array.prototype.forEach.call(arguments, function(arg) {
                if(lang.isString(arg)) {
                    this._resetImpl(arg);
                } else if(lang.isArray(arg)) {
                    arg.forEach(this._resetImpl, this);
                }
            }, this);
        } else {
            Object.keys(this._propState.p).forEach(this._resetImpl, this);
        }
        return this;
    }
           
    _setPropChanged(name, old, value) {
        var pcs = this._propState.c;
        if(!pcs) {
            pcs = {};
            this._propState.c = pcs;
        }
        var pc = pcs[name];
        if(!pc) {
            pc = {};
            pcs[name] = pc;
        }
        pc.old = old;
        pc.value = value;
        this._setChanged();
        return this;
    }
    
    get anyPropChanged() {
        return this._propState.c ? true : false;
    }
    
    isPropChanged(name) {
        return this._propState.c && this._propState.c[name] ? true : false;
    }
    
    get propChanges() {
        return this._propState.c ? Object.assign({}, this._propState.c) : {};
    }
    
    getPropChange(name) {
        if(this._propState.c) {
            var pc = this._propState.c[name];
            if(pc) {
                return Object.assign({}, pc);
            }
        }
    }
    
    getOldValue(name) {
        var pc = this.getPropChange(name);
        if(pc) {
            return pc.old;
        }
    }
    
    _clearChanged() {
        delete this._propState.c;
        super._clearChanged();
    }

    toJSON() {
        return this.get();
    }
};

export default Model;