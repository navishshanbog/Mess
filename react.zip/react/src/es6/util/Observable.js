import lang from "./lang";

class Observable {
    notify(arg) {
        if(this.changed) {
            try {
                if(this.hasObserver) {
                    const observers = [].concat(this._observers);
                    const forget = [];
                    this._notifyState = {
                        forget: forget
                    };
                    observers.forEach((reg) => {
                        if(forget.length === 0 || forget.indexOf(reg) < 0) {
                            reg.f.call(reg.s, this, arg);
                        }
                    });

                }
            } finally {
                this._clearChanged();
                delete this._notifyState;
            }
        }
        return this;
    }

    get notifying() {
        return this._notifyState ? true : false;
    }

    isObserver(o) {
        return this._observers && this._observers.some(function(r) {
            return r.o === o;
        });
    }

    get observerCount() {
        return this._observers ? this._observers.length : 0;
    }

    get hasObserver() {
        return this.observerCount > 0
    }

    observe(observer, scope) {
        if(observer && !this.isObserver(observer)) {
            if(!this._observers) {
                this._observers = [];
            }
            let f = lang.isFunction(observer) ? observer : lang.isFunction(observer.update) ? observer.update.bind(observer) : undefined;
            if(f) {
                this._observers.push({ o: observer, f: f, s: scope });
            }
        }
        return this;
    }

    forget(observer) {
        if(this._observers && observer) {
            let foundIdx = -1;
            let reg;
            this._observers.some((r, idx) => {
                if(r.o === observer) {
                    reg = r;
                    foundIdx = idx;
                    return true;
                }
            });
            if(foundIdx >= 0) {
                this._observers.splice(foundIdx, 1);
                if(this._observers.length === 0) {
                    delete this._observers;
                }

                if(this._notifyState && this._notifyState.forget.indexOf(reg) < 0) {
                    this._notifyState.forget.push(reg);
                }
            }
        }
        return this;
    }

    forgetAll() {
        delete this._observers;
    }

    get changed() {
        return this._changed ? true : false;
    }

    _setChanged() {
        this._changed = true;
        return this;
    }

    _clearChanged() {
        this._changed = false;
        return this;
    }

}

export default Observable;