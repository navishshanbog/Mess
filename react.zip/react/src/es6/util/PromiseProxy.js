import lang from "util/lang";
import DelegatingProxy from "./DelegatingProxy";

class PromiseProxy extends DelegatingProxy {
    _invokeMethod(name, args) {
        // guarantees we return a promise
        try {
            return Promise.resolve(super._invokeMethod(name, args));
        } catch(e) {
            return Promise.reject(e);
        }
    }
}

export default PromiseProxy;