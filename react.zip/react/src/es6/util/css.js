import pathUtils from "./path";

const state = {
    path: "/css",
    sheets: {}
};

const setPreLoadedImpl = function(id) {
    var sid = String(id);
    if(sid) {
        state.sheets[sid] = { id: id, pre: true };
    }
};

const addSheet = function(id) {
    if(id) {
        var sid = String(id);
        if(sid && !state.sheets[sid]) {
            var link = document.createElement("link");
            link.rel = "stylesheet";
            link.href = pathUtils.join(state.path, sid + ".css");
            document.head.appendChild(link);
            state.sheets[sid] = { id: id, link: link };
        }
    }
};

const addSheetArray = function(a) {
    if(a) {
        a.forEach(addSheet);
    }
};

const addSheets = function() {
    Array.prototype.forEach.call(arguments, function(arg) {
        if(Array.isArray(arg)) {
            addSheetArray(arg);
        } else if(arg) {
            addSheet(arg);
        }
    });
};

const removeSheet = function(id) {
    if(id) {
        var sid = String(id);
        if(sid && state.sheets[sid]) {
            var r = state.sheets[sid];
            if(!r.pre) {
                if(r.link) {
                    document.head.removeChild(r.link);
                }
                delete state.sheets[sid];
            }
        }
    }
};

const removeSheetArray = function(a) {
    if(a) {
        a.forEach(removeSheet);
    }
};

const removeSheets = function() {
    Array.prototype.forEach.call(arguments, function(arg) {
        if(Array.isArray(arg)) {
            removeSheetArray(arg);
        } else if(arg) {
            removeSheet(arg);
        }
    });
};

const classNameAppendElement = function(e, h) {
    if(Array.isArray(e)) {
        classNameAppendArray(e, h);
    } else {
        h(e);
    }
};

const classNameAppendArray = function(a, h) {
    a.forEach(function(e) {
        classNameAppendElement(e, h);
    });
};

const className = function() {
    var r = [];
    var m = {};
    var h = function(e) {
        if(e !== undefined && e !== null) {
            var s = String(e);
            if(s && !m[s]) {
                r.push(s);
                m[s] = s;
            }
        }
    };

    Array.prototype.forEach.call(arguments, function(arg) {
        classNameAppendElement(arg, h);
    });

    if(r.length > 0) {
        return r.join(" ");
    }
};

const hierarchy = function() {
    var r = [];
    var prefix;
    
    var h = function(e) {
        if(e !== undefined && e !== null) {
            var s = String(e);
            if(s) {
                var c = (prefix ? prefix + "-" : "") + s;
                r.push(c);
                prefix = c;
            }
        }
    };
    
    Array.prototype.forEach.call(arguments, function(arg) {
        classNameAppendElement(arg, h);
    });

    return className(r);
};

const master =  function() {
    var r = [];
    var prefix;
    
    var h = function(e) {
        if(e !== undefined && e !== null) {
            var s = String(e);
            if(s) {
                var c = (prefix ? prefix + "-" : "") + s;
                r.push(c);
                if(!prefix) {
                    prefix = c;
                }
            }
        }
    };
    
    Array.prototype.forEach.call(arguments, function(arg) {
        classNameAppendElement(arg, h);
    });

    return className(r);
};

className.hierarchy = hierarchy;
className.master = master;

export default {
    get path() {
        return state.path;
    },
    set path(value) {
        if(value) {
            state.path = value;
        }
    },
    set preLoaded(value) {
        if(value) {
            if(Array.isArray(value)) {
                value.forEach(addPre);
            } else {
                setPreLoadedImpl(value);
            }
        }
    },
    set includes(value) {
        if(!value) {
            value = [];
        }
        if(value) {
            var forRemoval = [];
            var forAdd = [];

            for(var id in state.sheets) {
                if(value.indexOf(id) < 0) {
                    forRemoval.push(id);
                }
            }

            value.forEach(function(id) {
                if(!state.sheets[id]) {
                    forAdd.push(id);
                }
            });

            removeSheets(forRemoval);
            addSheets(forAdd);
        }
    },
    addSheets: addSheets,
    removeSheets: removeSheets,
    className: className
};