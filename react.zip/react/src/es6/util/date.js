import stringUtils from "./string";

const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const am = "AM";
const pm = "PM";
const ad = "AD";
const bc = "BC";

const padChar = "0";

const padLeft = (s, length) => {
    return stringUtils.padLeft(s, length, padChar);
};

const stripLeft = (s) => {
    return stringUtils.stripLeft(s, padChar);
};

const quoteChar = "'";

class StringReader {
    constructor(s) {
        this._s = s;
        this._pos = 0;
    }
    read(count) {
        let r = this._s.substring(this._pos, this._pos + count);
        this._pos += count;
        return r;
    }
}

class DateElementFormat {
    constructor(length) {
        this.length = length;
    }
}

class DayInMonthFormat extends DateElementFormat {
    format(date) {
        return padLeft(String(date.getDate()), this.length);
    }
    parse(reader, result) {
        result.date = parseInt(stripLeft(reader.read(this.length)));
    }
    toString() {
        return "Day in Month (" + this.length + ")";
    }
}

class MonthInYearFormat extends DateElementFormat {
    format(date) {
        if(this.length <= 2) {
            return padLeft(String(date.getMonth() + 1), this.length);
        }
        let monthName = monthNames[date.getMonth()];
        return this.length === 3 ? monthName.substring(0, 3) : monthName;
    }
    parse(reader, result) {
        if(this.length <= 2) {
            result.month = parseInt(stripLeft(reader.read(this.length))) - 1;
        } else {
            let text = reader.read(this.length);
            let foundMonth = -1;
            monthNames.some(function(mn, idx) {
                if(stringUtils.startsWithIgnoreCase(mn, text)) {
                    foundMonth = idx;
                    return true;
                }
            });
            if(foundMonth >= 0) {
                result.month = foundMonth;
            } else {
                throw new Error("Invalid Month String: " + text);
            }
        }
    }
    toString() {
        return "Month in Year (" + this.length + ")";
    }
}

class YearFormat extends DateElementFormat {
    format(date) {
        let s = String(date.getFullYear());
        if(this.length < s.length) {
            return s.substring(s.length - this.length);
        }
        return padLeft(s, this.length);
    }
    parse(reader, result) {
        result.year = parseInt(stripLeft(reader.read(this.length)));
    }
    toString() {
        return "Year (" + this.length + ")";
    }
}

class LiteralFormat extends DateElementFormat{
    constructor(literal) {
        super(literal.length);
        this._literal = literal;
    }
    format() {
        return this._literal;
    }
    parse(reader, result) {
        let text = reader.read(this.length);
        // TODO: possibly check they are equal
    }
    toString() {
        return "Literal: '" + this._literal + "'";
    }
}

class HourInDayZeroBasedFormat extends DateElementFormat{
    format(date) {
        let s = String(date.getHours());
        return padLeft(s, this.length);
    }
    parse(reader, result) {
        result.hours = parseInt(stripLeft(reader.read(this.length)));
    }
    toString() {
        return "Hour in Day Zero Based (" + this.length + ")";
    }
}

class HourInDayOneBasedFormat extends DateElementFormat {
    format(date) {
        let s = String(date.getHours() + 1);
        return padLeft(s, this.length);
    }
    parse(reader, result) {
        result.hours = parseInt(stripLeft(reader.read(this.length))) - 1;
    }
    toString() {
        return "Hour in Day One Based (" + this.length + ")";
    }
}

const adjust12Hour = (hours12, amPm) => {
    if(hours12 === 12 && amPm.am) {
        return 0;
    }
    return hours12 + (amPm.pm ? 12 : 0);
};

class HourInAmPmOneBasedFormat extends DateElementFormat {
    format(date) {
        let hours = date.getHours();
        if(hours > 12) {
            hours -= 12;
        }
        if(hours === 0) {
            hours = 12;
        }
        let s = String(hours);
        return padLeft(s, this.length);
    }
    parse(reader, result) {
        let hours12 = parseInt(stripLeft(reader.read(this.length)));
        if(result.amPm) {
            result.hours = adjust12Hour(hours12, result.amPm);
            delete result.amPm;
        } else {
            result.hours12 = hours12;
        }
    }
    toString() {
        return "Hour in am/pm 1-12 (" + this.length + ")";
    }
}

class HourInAmPmZeroBasedFormat extends DateElementFormat {
    format(date) {
        let hours = date.getHours();
        if(hours >= 12) {
            hours -= 12;
        }
        let s = String(hours);
        return padLeft(s, this.length);
    }
    parse(reader, result) {
        let hours12 = parseInt(stripLeft(reader.read(this.length))) + 1;
        if(result.amPm) {
            result.hours = adjust12Hour(hours12, result.amPm);
            delete result.amPm;
        } else {
            result.hours12 = hours12;
        }
    }
    toString() {
        return "Hour in am/pm padded 0-11 (" + this.length + ")";
    }
}

class AmPmMarkerFormat extends DateElementFormat {
    format(date) {
        return date.getHours() < 12 ? am : pm;
    }
    parse(reader, result) {
        let text = reader.read(2);
        if(stringUtils.equalsIgnoreCase(text, am) || stringUtils.equalsIgnoreCase(text, pm)) {
            let isAm = stringUtils.equalsIgnoreCase(text, am);
            if(result.hours12 !== undefined) {
                result.hours = adjust12Hour(result.hours12, { am: isAm, pm: !isAm });
                delete result.hours12;
            } else {
                result.amPm = { am: isAm, pm: !isAm };
            }
        }
    }
    toString() {
        return "Am/pm marker (" + this.length + ")";
    }
}

class MinuteFormat extends DateElementFormat {
    format(date) {
        return padLeft(String(date.getMinutes()), this.length);
    }
    parse(reader, result) {
        result.minutes = parseInt(stripLeft(reader.read(this.length)));
    }
    toString() {
        return "Minute in Hour (" + this.length + ")";
    }
}

class SecondFormat extends DateElementFormat {
    format(date) {
        return padLeft(String(date.getSeconds()), this.length);
    }
    parse(reader, result) {
        result.seconds = parseInt(stripLeft(reader.read(this.length)));
    }
    toString() {
        return "Second in Minute (" + this.length + ")";
    }
}

class MillisecondFormat extends DateElementFormat {
    format(date) {
        return padLeft(String(date.getMilliseconds()), this.length);
    }
    parse(reader, result) {
        result.milliseconds = parseInt(stripLeft(reader.read(this.length)));
    }
    toString() {
        return "Millisecond (" + this.length + ")";
    }
}

class Rfc822TimezoneOffsetFormat extends DateElementFormat {
    format(date) {
        let o = date.getTimezoneOffset();
        let sign = o <= 0 ? "+" : "-";
        let a = Math.abs(o);
        let hours = Math.floor(a / 60);
        let minutes = a - (hours * 60);
        return sign + stringUtils.padLeft(hours, 2, padChar) + stringUtils.padLeft(minutes, 2, padChar);
    }
    parse(reader, result) {
        let text = reader.read(5);
        let sign = text.charAt(0);
        let hours = parseInt(stripLeft(text.substring(1, 3)));
        let minutes = parseInt(stripLeft(text.substring(3, 5)));
        let timezoneOffset = hours * 60 + minutes;
        if(sign === "+") {
            timezoneOffset = 0 - timezoneOffset;
        }
        result.timezoneOffset = timezoneOffset;
    }
    toString() {
        return "Rfc 822 Time Zone Offset (" + this.length + ")";
    }
}

class ISO8601TimezoneOffsetFormat extends DateElementFormat {
    format(date) {
        let o = date.getTimezoneOffset();
        let sign = o <= 0 ? "+" : "-";
        let a = Math.abs(o);
        let hours = Math.floor(a / 60);
        if(this.length === 1) {
            return sign + hours;
        }
        
        let minutes = a - (hours * 60);
        return sign + stringUtils.padLeft(hours, 2, padChar) + (this.length === 2 ? "" : ":") + stringUtils.padLeft(minutes, 2, padChar);
    }
    parse(reader, result) {
        let text;
        if(this.length === 1) {
            text = reader.read(3);
        } else if(this.length === 2) {
            text = reader.read(5);
        } else if(this.length === 3) {
            text = reader.read(6);
        }
        let sign = text.charAt(0);
        let hours = parseInt(stripLeft(text.substring(1, 3)));
        let minutes = 0;
        if(this.length === 2) {
            minutes = parseInt(stripLeft(text.substring(3, 5)));
        } else if(this.length === 3) {
            minutes = parseInt(stripLeft(text.substring(4, 6)));
        }
        let timezoneOffset = hours * 60 + minutes;
        if(sign === "+") {
            timezoneOffset = 0 - timezoneOffset;
        }
        result.timezoneOffset = timezoneOffset;
    }
    toString() {
        return "ISO 8601 Time Zone Offset (" + this.length + ")";
    }
}

class DayNameInWeekFormat extends DateElementFormat {
    format(date) {
        let day = date.getDay();
        let dayName = dayNames[day];
        if(this.length <= 3) {
            return dayName.substring(0, this.length);
        }
        return dayName;
    }
    parse() {
        
    }
    toString() {
        return "Day Name in Week";
    }
}

class DayNumberInWeekFormat extends DateElementFormat {
    format(date) {
        let day = date.getDay();
        let a = day === 0 ? 7 : day;
        return String(a);
    }
    parse() {
        
    }
    toString() {
        return "Day Number in Week";
    }
}

const daysInMonth = (month, year) => {
    let dc = new Date(year, month + 1, 0);
    return dc.getDate();
};

const daysInYear = (year) => {
    let i = 0;
    let c = 0;
    while(i < 12) {
        c += daysInMonth(i, year);
        i ++;
    }
    return c;
};

const dayInYear = (date) => {
    let month = date.getMonth();
    
    let i = 0;
    let diy = date.getDate();
    while(i < month) {
        diy += daysInMonth(i, date.getFullYear());
        i ++;
    }
    
    return diy;
};

const weekInYear = function(date) {
    let diy = dayInYear(date);
    return Math.floor(diy / 7) + 1;
};

const weekInMonth = function(date) {
    return Math.floor(date.getDate() / 7) + 1;
};

class DayInYearFormat extends DateElementFormat {
    format(date) {
        return padLeft(String(dayInYear(date)), this.length);
    }
    parse() {
        
    }
    toString() {
        return "Day in Year";
    }
}

class WeekInYearFormat extends DateElementFormat {
    format(date) {
        return padLeft(String(weekInYear(date)), this.length);
    }
    parse() {
        
    }
    toString() {
        return "Week in Year";
    }
}

class WeekInMonthFormat extends DateElementFormat {
    format(date) {
        return padLeft(String(weekInMonth(date)), this.length);
    }
    parse() {
        
    }
    toString() {
        return "Week in Month";
    }
}

class EraDesignatorFormat extends DateElementFormat {
    format(date) {
        let year = date.getFullYear();
        return year > 0 ? ad : bc;
    }
    parse() {
        
    }
    toString() {
        return "Era Designator";
    }
}

const formatMap = {
    d(length) {
        return new DayInMonthFormat(length);
    },
    M(length) {
        return new MonthInYearFormat(length);
    },
    y(length) {
        return new YearFormat(length);
    },
    Y(length) {
        return new YearFormat(length);
    },
    H(length) {
        return new HourInDayZeroBasedFormat(length);
    },
    h(length) {
        return new HourInAmPmOneBasedFormat(length);
    },
    a(length) {
        return new AmPmMarkerFormat(length);
    },
    k(length) {
        return new HourInDayOneBasedFormat(length);
    },
    K(length) {
        return new HourInAmPmZeroBasedFormat(length);
    },
    m(length) {
        return new MinuteFormat(length);
    },
    s(length) {
        return new SecondFormat(length);
    },
    S(length) {
        return new MillisecondFormat(length);
    },
    Z(length) {
        return new Rfc822TimezoneOffsetFormat(length);
    },
    E(length) {
        return new DayNameInWeekFormat(length);
    },
    D(length) {
        return new DayInYearFormat(length);
    },
    w(length) {
        return new WeekInYearFormat(length);
    },
    G(length) {
        return new EraDesignatorFormat(length);
    },
    X(length) {
        return new ISO8601TimezoneOffsetFormat(length);
    },
    u(length) {
        return new DayNumberInWeekFormat(length);
    },
    W(length) {
        return new WeekInMonthFormat(length);
    }
};

class DateFormat {
    constructor(formatString) {
        this._formatString = formatString;
        this._elements = [];
        this._compile();
    }
    _compile() {
        let buf = stringUtils.empty;
        let formatChar;
        let formatLength;
        let quoted = stringUtils.empty;
        let qq = false;
        
        let addFormatElement = (idx) => {
            if(formatChar) {
                var format;
                var e = formatMap[formatChar];
                if(e) {
                    format = e(formatLength); 
                }
                
                if(!format) {
                    throw new Error("Invalid Date Format (" + idx + "): " + this._formatString);
                }
                
                this._elements.push(format);
                formatChar = null;
                formatLength = 0;
            }
        };
        
        let addLiteralElement = () => {
            if(buf.length > 0) {
                this._elements.push(new LiteralFormat(buf));
                buf = stringUtils.empty;
            }
        };
        
        var standardHandler = (ch, code, idx) => {
            if(formatChar && formatChar === ch) {
                formatLength ++;
                return;
            }
            
            addFormatElement(idx);
            
            if(ch === quoteChar) {
                quoted = stringUtils.empty;
                handler = quoteHandler;
            } else if(formatMap[ch]) {
                addLiteralElement();
                formatChar = ch;
                formatLength = 1;
            } else {
                buf += ch;
            }
        };
        
        var quoteHandler = (ch, code, idx) => {
            if(ch === quoteChar) {
                if(quoted.length === 0) {
                    buf += quoteChar;
                    quoted = stringUtils.empty;
                    handler = standardHandler;
                }
                if(qq) {
                    quoted += quoteChar;
                }
                qq = !qq;
            } else {
                if(qq) {
                    buf += quoted;
                    standardHandler(ch, code, idx);
                    quoted = stringUtils.empty;
                    handler = standardHandler;
                } else {
                    quoted += ch;
                }
            }
        };
        
        var handler = standardHandler;
        
        stringUtils.forEach(this._formatString, function() {
            handler.apply(this, arguments);
        }, this);
        
        addLiteralElement();
        addFormatElement();
    }
    format(date) {
        if(date) {
            var r = "";
            this._elements.forEach((e) => {
                r += e.format(date);
            });
            return r;
        }
    }
    _createDate(r) {
        let date = r.date;
        let month = r.month;
        let year = r.year;
        let hours = r.hours || (r.hours12 ? adjust12Hour(r.hours12, { am: true, pm: false }) : 0);
        let minutes = r.minutes || 0;
        let seconds = r.seconds || 0;
        let milliseconds = r.milliseconds || 0;
        let rawDate = new Date(year, month, date, hours, minutes, seconds, milliseconds);
        if(r.timezoneOffset && r.timezoneOffset !== rawDate.getTimezoneOffset()) {
            let diff = r.timezoneOffset - rawDate.getTimezoneOffset();
            minutes -= diff;
            return new Date(year, month, date, hours, minutes, seconds, milliseconds);
        }
        return rawDate;
    }
    parse(text) {
        if(text) {
            let r = {};
            let reader = new StringReader(text);
            this._elements.forEach(function(e) {
                e.parse(reader, r);
            });
            return this._createDate(r);
        }
    }
    toString() {
        return this._formatString + ": " + this._elements.toString();
    }
}

const compiled = {};

const date = {
    Format: DateFormat,
    dayNames: dayNames,
    monthNames: monthNames,
    daysInMonth: daysInMonth,
    daysInYear: daysInYear,
    dayInYear: dayInYear,
    weekInYear: weekInYear,
    weekInMonth: weekInMonth,
    getFormat(formatString) {
        let fmt = compiled[formatString];
        if(!fmt) {
            fmt = new DateFormat(formatString);
            compiled[formatString] = fmt;
        }
        return fmt;
    },
    format(date, formatString) {
        return this.getFormat(formatString).format(date);
    },
    parse(text, formatString) {
        return this.getFormat(formatString).parse(text);
    }
};

export { date as default, DateFormat };


