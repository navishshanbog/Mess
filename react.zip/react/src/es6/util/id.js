class Sequence {
    constructor(prefix) {
        this._prefix = prefix !== undefined && prefix !== null ? prefix : "";
    }
    next() {
        if(this._id === undefined) {
            this._id = 0;
        } else {
            this._id ++;
        }
        return this._prefix + this._id;
    }
}

const instances = {};
const defaultInstance = new Sequence();


const id = {
    Sequence: Sequence,
    getSequence(name) {
        if(name !== undefined) {
            let instance = instances[name];
            if(!instance) {
                instance = new Sequence(name);
                instances[name] = instance;
            }
            return instance;
        }
        return defaultInstance;
    },
    next(name) {
        return this.getSequence(name).next();
    }
};

export { id as default, id, Sequence };