import * as React from "react";
import AppLink from "app/view/AppLink";
import nav from "nav";
import layout from "layout/bootstrap/layout";

const title = "Utilities";

const testLinks =
<div className="list-group">
    <AppLink className="list-group-item" path="util/test/lang" title="Language Utilities Test" />
    <AppLink className="list-group-item" path="util/test/path" title="Path Utilities Test" />
    <AppLink className="list-group-item" path="util/test/date" title="Date Utilities Test" />
    <AppLink className="list-group-item" path="util/test/id" title="Id Utilties Test" />
    <AppLink className="list-group-item" path="util/test/string" title="String Utilties Test" />
    <AppLink className="list-group-item" path="util/test/sort" title="Sort Utilities Test" />
    <AppLink className="list-group-item" path="util/test/Observable" title="Observable Test" />
    <AppLink className="list-group-item" path="util/test/Model" title="Model Test" />
    <AppLink className="list-group-item" path="util/test/PromiseProxy" title="Promise Proxy Test" />
    <AppLink className="list-group-item" path="util/test/promise" title="Promise Utilities Test" />
    <AppLink className="list-group-item" path="util/test/ActionProxy" title="Action Proxy Test" />
</div>;

const testsPanel =
<div className="panel panel-primary">
    <div className="panel-heading">Utility Tests</div>
    {testLinks}
</div>;

const main =
<div className="container">
    {testsPanel}
</div>;

export default () => {
    layout.go({
        title: title,
        nav: nav,
        main: main
    })
};