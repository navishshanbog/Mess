const stringType = typeof("");
const objectType = typeof({});
const numberType = typeof(1);
const booleanType = typeof(true);
const functionType = typeof(function() {});

const lang = {
    isString(o) {
        return typeof(o) === stringType;
    },
    isObject(o) {
        return typeof(o) === objectType;
    },
    isNumber(o) {
        return typeof(o) === numberType;
    },
    isBoolean(o) {
        return typeof(o) === booleanType;
    },
    isDate(o) {
        return o instanceof Date;
    },
    isArray(o) {
        return Array.isArray(o);
    },
    isFunction(o) {
        return typeof(o) === functionType;
    },
    polyfill() {
        if(!lang.isFunction(Object.assign)) {
            Object.assign = function() {
                let target;
                let al = arguments.length;
                if(al > 0) {
                    target = arguments[0];
                }

                if(target === undefined || target === null) {
                    throw new TypeError("Cannot convert null or undefined to an object");
                }

                let output = Object(target);
                let source;
                for(let i = 1; i < al; i ++) {
                    source = arguments[i];
                    if(source !== undefined && source !== null) {
                        for(let key in source) {
                            if(source.hasOwnProperty(key)) {
                                output[key] = source[key];
                            }
                        }
                    }
                }
                return output;
            };
        }
    }
}

export { lang as default };