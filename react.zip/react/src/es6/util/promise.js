export default {
    /**
     * This is used for hanging promises (e.g. iwc). Note that the target has to return a promise.
     */
    invokeWithRetry(target, opts) {
        let period = opts && opts.period ? opts.period : 1000;
        // note - if a timeout is not specified, this thing will continue indefinitely
        let timeout = opts.timeout && opts.timeout ? opts.timeout : 0;

        return new Promise((resolve, reject) => {
            let timeoutId;
            let time = period;
            let invokeState = { done: false };

            let invokeImmediate = () => {
                target().then((response) => {
                    if(!invokeState.done) {
                        invokeState.done = true;
                        resolve(response);
                    }
                }).catch((err) => {
                    if(!invokeState.done) {
                        invokeState.done = true;
                        reject(err);
                    }
                });
            };

            let timeoutHandler = () => {
                if(!invokeState.done) {
                    if(timeout > 0 && time >= timeout) {
                        reject(new Error("The invocation has timed out"));
                    } else {
                        time += period;
                        invokeImmediate();
                        setTimeout(timeoutHandler, period);
                    }
                }
            };
            
            setTimeout(timeoutHandler);
        });
    },
    invokeDelayed(target, opts) {
        let delay = opts && opts.delay ? opts.delay : 1000;
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                Promise.resolve(target()).then((response) => {
                    resolve(response);
                }).catch((err) => {
                    reject(err);
                });
            }, delay);
        });
    }
};