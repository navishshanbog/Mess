import lang from "./lang";

var asc = {
    id: "asc",
    toggle: function() {
        return desc;
    },
    toString: function() {
        return this.id;
    }
};

var desc = {
    id: "desc",
    toggle: function() {
        return asc;
    },
    toString: function() {
        return this.id;
    }
};

export default {
    order: {
        asc: asc,
        desc: desc,
        ascending: asc,
        descending: desc,
        Asc: asc,
        Desc: desc,
        Ascending: asc,
        Descending: desc,
        isAscending(o) {
            return o && o.id === asc.id;
        },
        isDescending(o) {
            return o && o.id === desc.id;
        }
    },
    toSortNumber(v) {
        if(lang.isNumber(v)) {
            return v;
        }

        if(lang.isDate(v)) {
            return v.getTime();
        }

        if(lang.isString(v)) {
            return parseInt(v);
        }

        if(lang.isBoolean(v)) {
            return v ? 1 : 0;
        }

        return 0;
    },
    toSortString(v) {
        if(lang.isString(v)) {
            return v;
        }
        
        return String(v);
    },
    compare(l, r) {
        if(lang.isNumber(l)) {
            return l - this.toSortNumber(r);
        }

        if(lang.isDate(l)) {
            return l.getTime() - this.toSortNumber(r);
        }

        if(lang.isString(l)) {
            return l.localeCompare(this.toSortString(r));
        }

        if(lang.isBoolean(l)) {
            return (l ? 1 : 0) - this.toSortNumber(r);
        }

        return 0;
    }
};