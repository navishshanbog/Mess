const empty = "";
        
const chars = {
    cr: "\r",
    lf: "\n",
    tab: "\t",
    space: " ",
    zero: "0",
    nine: "9",
    a: "a",
    z: "z",
    A: "A",
    Z: "Z"
};

const charCodes = {};
        
for(var c in chars) {
    charCodes[c] = chars[c].charCodeAt(0);
}

const isWhitespace = function(ch) {
    var code = ch.charCodeAt(0);
    return isNaN(code) ||
            (code >= 9 && code <= 13) ||
            code === 32 ||
            code === 133 ||
            code === 160 ||
            code === 5760 ||
            (code >= 8192 && code <= 8202) ||
            code === 8232 ||
            code === 8233 ||
            code === 8239 ||
            code === 8287 ||
            code === 12288;
};

const isNotWhitespace = function(ch) {
    return !isWhitespace(ch);
};

const isDigit = function(ch) {
    var code = ch.charCodeAt(0);
    return code >= charCodes.zero && code <= charCodes.nine;
};

const isNotDigit = function(ch) {
    return !isDigit(ch);
};

const isAlpha = function(ch) {
    var code = ch.charCodeAt(0);
    return (code >= charCodes.a && code <= charCodes.z) || (code >= charCodes.A && code <= charCodes.Z);
};

const isNotAlpha = function(ch) {
    return !isAlpha(ch);
};

const isAlphaNumeric = function(ch) {
    return isAlpha(ch) || isDigit(ch);
};

const isNotAlphaNumeric = function(ch) {
    return !isAlpha(ch) && !isDigit(ch);
};

const startsWith = function(text, match) {
    return text.indexOf(match) === 0;
};

const endsWith = function(text, match) {
    if(match.length <= text.length) {
        var idx = text.lastIndexOf(match);
        return idx >= 0 && (idx + match.length === text.length);
    }

    return false;
};

const contains = function(text, match) {
    return text.indexOf(match) >= 0;
};

const filters = {
    isWhitespace: isWhitespace,
    whitespace: isWhitespace,
    isNotWhitespace: isNotWhitespace,
    nonWhitespace: isNotWhitespace,
    isDigit: isDigit,
    digit: isDigit,
    isNotDigit: isNotDigit,
    nonDigit: isNotDigit,
    isAlpha: isAlpha,
    alpha: isAlpha,
    isNotAlpha: isNotAlpha,
    nonAlpha: isNotAlpha,
    isAlphaNumeric: isAlphaNumeric,
    alphaNumeric: isAlphaNumeric,
    isNotAlphaNumeric: isNotAlphaNumeric,
    nonAlphaNumeric: isNotAlphaNumeric
};

export default {
    empty: empty,
    filters: filters,
    each(text, cb, scope) {
        if(text) {
            let tl = text.length;
            for(let i = 0; i < tl; i ++) {
                cb.call(scope, text.charAt(i), i, text);
            }
        }
    },
    forEach() {
        this.each.apply(this, arguments);
    },
    some(text, pr, scope) {
        if(text) {
            let tl = text.length;
            for(let i = 0; i < tl; i ++) {
                if(pr.call(scope, text.charAt(i), i, text)) {
                    return true;
                }
            }
        }

        return false;
    },
    someFromEnd(text, pr, scope) {
        if(text) {
            var tl = text.length;
            for(let i = tl - 1; i >= 0; i--) {
                if(pr.call(scope, text.charAt(i), i, text)) {
                    return true;
                }
            }
        }

        return false;
    },
    every(text, pr, scope) {
        if(text) {
            let tl = text.length;
            for(let i = 0; i < tl; i ++) {
                if(!pr.call(scope, text.charAt(i), i, text)) {
                    return false;
                }
            }
            return true;
        }

        return true;
    },
    everyFromEnd(text, pr, scope) {
        if(text) {
            var tl = text.length;
            for(var i = tl - 1; i >= 0; i--) {
                if(!pr.call(scope, text.charAt(i), i, text)) {
                    return false;
                }
            }
        }

        return true;
    },
    filter(text, pr, scope) {
        if(text) {
            var r = empty;
            this.each(text, function(ch) {
                if(pr.apply(this, arguments)) {
                    r += ch;
                }
            }, scope);

            return r;
        }

        return text;
    },
    split(text, pr, scope) {
        var r = [];
        var b = empty;
        if(text) {
            this.each(text, function(ch) {
                if(pr.apply(this, arguments)) {
                    if(b) {
                        r.push(b);
                        b = empty;
                    }
                } else {
                    b += ch;
                }
            }, scope);

            if(b) {
                r.push(b);
            }
        }
        return r;
    },
    reject(text, pr, scope) {
        if(text) {
            var r = empty;
            this.each(text, function(ch) {
                if(!pr.apply(this, arguments)) {
                    r += ch;
                }
            }, scope);

            return r;
        }

        return text;
    },
    removeWhitespace(text) {
        return this.reject(text, this.filters.whitespace);
    },
    findIndexOf(text, pr, scope) {
        var foundIdx = -1;
        if(pr) {
            this.some(text, function(ch, idx, text) {
                if(pr.apply(this, arguments)) {
                    foundIdx = idx;
                    return true;
                }
            }, scope);
        }
        return foundIdx;
    },
    findLastIndexOf(text, pr, scope) {
        var foundIdx = -1;
        if(pr) {
            this.someFromEnd(text, function(ch, idx, text) {
                if(pr.apply(this, arguments)) {
                    foundIdx = idx;
                    return true;
                }
            }, scope);
        }
        return foundIdx;
    },
    leftTrim(text) {
        var idx = this.findIndexOf(text, this.filters.nonWhitespace);
        if(idx >= 0) {
            return idx === 0 ? text : text.substring(idx);
        }
    },
    trimLeft() {
        return this.leftTrim.apply(this, arguments);
    },
    rightTrim(text) {
        var idx = this.findLastIndexOf(text, this.filters.nonWhitespace);
        if(idx >= 0) {
            return idx === text.length - 1 ? text : text.substring(0, idx + 1);
        }
    },
    trimRight() {
        return this.rightTrim.apply(this, arguments);
    },
    trim(text) {
        return this.rightTrim(this.leftTrim(text));
    },
    isBlank(text) {
        if(text) {
            return this.every(text, this.filters.whitespace);
        }
        return true;
    },
    isNotBlank(text) {
        return !this.isBlank(text);
    },
    startsWith(text, match) {
        if(text && match) {
            return startsWith(text, match);
        }
        return false;
    },
    startsWithIgnoreCase(text, match) {
        if(text && match) {
            return startsWith(text.toLowerCase(), match.toLowerCase());
        }
        return false;
    },
    ensureStartsWith(text, startsWith) {
        return !this.startsWith(text, startsWith) ? startsWith + text : text;
    },
    ensureStartsWithIgnoreCase(text, startsWith) {
        return !this.startsWithIgnoreCase(text, startsWith) ? startsWith + text : text;
    },
    endsWith(text, match) {
        if(text && match) {
            return endsWith(text, match);
        }
        return false;
    },
    endsWithIgnoreCase(text, match) {
        if(text && match) {
            return endsWith(text.toLowerCase(), match.toLowerCase());
        }
        return false;
    },
    ensureEndsWith(text, endsWith) {
        return !this.endsWith(text, endsWith) ? text + endsWith : text;
    },
    ensureEndsWithIgnoreCase(text, endsWith) {
        return !this.endsWithIgnoreCase(text, endsWith) ? text + endsWith : text;
    },
    contains(text, match) {
        if(text && match) {
            return contains(text, match);
        }
        return false;
    },
    containsIgnoreCase(text, match) {
        if(text && match) {
            return contains(text.toLowerCase(), match.toLowerCase());
        }
        return false;
    },
    equalsIgnoreCase(l, r) {
        if(l && r) {
            return l.toLowerCase() === r.toLowerCase();
        }
        return l === r;
    },
    padLeft(s, length, padChar) {
        if(!padChar) {
            padChar = " ";
        }
        var r = s || "";
        while(r.length < length) {
            r = padChar + r;
        }
        return r;
    },
    stripLeft(s, stripChar) {
        if(s) {
            var idx = this.findIndexOf(s, function(ch) {
                return ch !== stripChar;
            });
            if(idx > 0) {
                return s.substring(idx);
            }
        }
        return s;
    },
    padRight(s, length, padChar) {
        if(!padChar) {
            padChar = " ";
        }
        var r = s || "";
        while(r.length < length) {
            r = r + padChar;
        }
        return r;
    },
    stripRight(s, stripChar) {
        if(s) {
            var idx = this.findLastIndexOf(s, function(ch) {
                return ch !== stripChar;
            });
            if(idx < s.length - 1) {
                return s.substring(0, idx + 1);
            }
        }
        return s;
    }
};