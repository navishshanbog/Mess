import testRunner from "test/runner";
import lang from "util/lang";
import ActionProxy from "util/ActionProxy";
import places from "places";

const suite = {
    title: "Action Proxy Test",
    testBasic(ctx) {
        var pxy = new ActionProxy({
            methods: ["search", "save"]
        });

        const actions1 = {
            search(params) {
                this.searchParams = params;
            }
        };

        const actions2 = {
            save(params) {
                this.saveParams = params;
            }
        };

        const actions3 = {
            save(params) {
                this.saveParams = params;
            },
            search(params) {
                this.searchParams = params;
            }
        };

        pxy.register(actions1);
        pxy.register(actions2);
        pxy.register(actions3);

        pxy.search({ name: "woo" });
        pxy.save({ value: "poo" });

        ctx.assert(actions1.searchParams ? true : false, "Check that actions1 has search params");
        ctx.assert(!actions1.saveParams ? true : false, "Check that actions1 does not have save params");
        ctx.assert.equal(actions1.searchParams.name, "woo", "Check value");
        ctx.assert(actions2.saveParams ? true : false, "Check that actions1 has save params");
        ctx.assert(!actions2.searchParams ? true : false, "Check that actions2 does not have search params");
        ctx.assert.equal(actions2.saveParams.value, "poo", "Check value");
        ctx.assert(actions3.saveParams ? true : false, "Check that actions3 has save params");
        ctx.assert(actions3.saveParams ? true : false, "Check that actions3 has search params");
        ctx.assert.equal(actions3.searchParams.name, "woo", "Check value");
        ctx.assert.equal(actions3.saveParams.value, "poo", "Check value");
    },
    testWaitFor(ctx) {
        var pxy = new ActionProxy({
            methods: ["search"]
        });

        const results = [];

        const actions1 = {
            search(params) {
                results.push(1);
            }
        };

        const actions2 = {
            search(params) {
                pxy.waitFor(actions1);
                results.push(2);
            }
        };

        const actions3 = {
            search(params) {
                pxy.waitFor(actions2);
                results.push(3);
            }
        };

        pxy.register(actions2);
        pxy.register(actions1);
        pxy.register(actions3);

        pxy.search({ name: "woo" });

        ctx.assert.equal(results.length, 3, "Check all actions have been invoked");
        ctx.assert.equal(results[0], 1, "Check Order");
        ctx.assert.equal(results[1], 2, "Check Order");
        ctx.assert.equal(results[2], 3, "Check Order");
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};