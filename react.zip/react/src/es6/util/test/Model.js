import testRunner from "test/runner";
import Model from "util/Model";
import dateUtils from "util/date";
import places from "places";

const dateFormat = dateUtils.getFormat("dd/MM/yyyy");

class TestModel extends Model {
    defaultProps() {
        return {
            firstName: "Sunburn",
            lastName: "Slapper",
            dob: "01/01/1972"
        };
    }
    get firstName() {
        return this.get("firstName");
    }
    set firstName(value) {
        this.set("firstName", value);
    }
    get lastName() {
        return this.get("lastName");
    }
    set lastName(value) {
        this.set("lastName", value);
    }
    get dob() {
        return this.get("dob");
    }
    set dob(value) {
        this.set("dob", value);
    }
}

const suite = {
    title: "Model Test",
    testPropModifiers(ctx) {
        var testModel = new TestModel();
        testModel.observe(() => {
            ctx.message("-- Prop Changes: " + JSON.stringify(testModel.propChanges));
        });

        ctx.message("Testing Basic Property Set");

        testModel.firstName = "Roger";
        ctx.assert.equal(testModel.firstName, "Roger", "Check property value getter/setter");
        ctx.assert(testModel.changed, "Check that the model is changed");
        ctx.assert(testModel.isPropChanged("firstName"), "Check that the firstName property is changed");
        ctx.assert.equal(testModel.getOldValue("firstName"), "Sunburn", "Check old value of firstName property");
        testModel.notify();
        ctx.assert(!testModel.changed, "Check model is not changed after notify");
        ctx.assert(!testModel.anyPropChanged, "Check that no properties have changed after notify");

        testModel.lastName = "Knobbery";
        testModel.dob = "08/08/1968";
        ctx.assert(testModel.changed, "Check that the model is changed");
        ctx.assert(testModel.isPropChanged("lastName"), "Check lastName is changed");
        ctx.assert(testModel.isPropChanged("dob"), "Check dob is changed");
        testModel.notify();
        ctx.assert(!testModel.changed, "Check model is not changed after notify");
        ctx.assert(!testModel.anyPropChanged, "Check that no properties have changed after notify");
    },
    testPropDefaults(ctx) {
        var testModel = new TestModel();
        ctx.assert.equal(testModel.firstName, "Sunburn", "Check Default firstName");
        ctx.assert.equal(testModel.lastName, "Slapper", "Check default lastName");
        ctx.assert.equal(testModel.dob, "01/01/1972", "Check default dob");
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};

