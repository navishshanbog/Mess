import testRunner from "test/runner";
import Observable from "util/Observable";
import places from "places";

class TestObservable extends Observable {
    constructor() {
        super();
        this._props = {};
    }
    get firstName() {
        return this._props.firstName;
    }
    set firstName(value) {
        if(value !== this._props.firstName) {
            this._props.firstName = value;
            this._setChanged();
        }
    }
    get lastName() {
        return this._props.lastName;
    }
    set lastName(value) {
        if(value !== this._props.lastName) {
            this._props.lastname = value;
            this._setChanged();
        }
    }
    toJSON() {
        return Object.assign({}, this._props);
    }
}

const suite = {
    title: "Observable Test",
    testSimple(ctx) {
        var funcObservedCount = 0;
        var observedCount = [];
        
        var funcObserver = function(o) {
            funcObservedCount ++;
            ctx.message("-- Func Update Observable State: " + JSON.stringify(o));
        };
        
        var observer = {
            update: function(o) {
                observedCount ++;
                ctx.message("-- Update Observable State: " + JSON.stringify(o));
            }
        };
        
        var subject = new TestObservable();
        subject.observe(funcObserver);
        subject.observe(observer);
        
        ctx.message("Setting First Name to Sunburn");
        subject.firstName = "Sunburn";
        ctx.message("Is Changed: " + subject.changed);
        ctx.assert(subject.changed, "Check that the subject has changed");
        subject.notify();
        ctx.message("Setting Last Name to Slapper");
        subject.lastName = "Slapper";
        ctx.assert(subject.changed, "Check that the subject has changed");
        ctx.message("Notifying Observers");
        subject.notify();
        
        ctx.message("Removing Func Observer");
        subject.forget(funcObserver);
        
        ctx.message("Setting Last Name to Rubber");
        subject.lastName = "Rubber";
        ctx.message("Notifying Observers");
        subject.notify();
        
        ctx.message("Removing Main Observer");
        subject.forget(observer);
        
        ctx.message("Setting First Name to Natural");
        subject.firstName = "Natural";
        ctx.message("Notifying Observers");
        subject.notify();
        
        ctx.assert.equal(observedCount, 3, "Check Observed Count");
        ctx.assert.equal(funcObservedCount, 2, "Check Func Observed Count");
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};