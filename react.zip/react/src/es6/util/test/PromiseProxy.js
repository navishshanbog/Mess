import testRunner from "test/runner";
import lang from "util/lang";
import PromiseProxy from "util/PromiseProxy";
import places from "places";

const suite = {
    title: "Promise Proxy Test",
    testBasic(ctx) {
        var pxy = new PromiseProxy({
            target: {
                _oneValue: "one",
                _twoValue: "two",
                one(name) {
                    console.log("-- Name: " + name);
                    return this._oneValue + name;
                },
                two() {
                    return this._twoValue;
                }
            },
            methods: ["one"]
        });

        ctx.assert(lang.isFunction(pxy.one), "Check that proxied method is present");
        ctx.assert(!lang.isFunction(pxy.two));

        return pxy.one("sample").then((r) => {
            ctx.assert.equal(r, "onesample", "Check output of proxied method");
        });
    },
    testPromise(ctx) {
        var target = {
            one() {
                return new Promise((resolve, reject) => {
                    window.setTimeout(() => {
                        resolve("one");
                    }, 2000);
                });
            },
            two() {
                return new Promise((resolve, reject) => {
                    window.setTimeout(() => {
                        reject("two");
                    }, 1000);
                });
            }
        };
        var pxy = new PromiseProxy({
            target: target,
            methods: ["one", "two"]
        });

        return pxy.one().then((r) => {
            ctx.assert.equal(r, "one", "Check one value");

            return pxy.two().catch(function(e) {
                ctx.assert.equal(e, "two", "Check two error");
            });
        });
    },
    testNoTarget(ctx) {
        var pxy = new PromiseProxy({
            methods: ["one", "two"]
        });

        pxy.one().catch((err) => {
            ctx.assert.ok(true, "We should receive an error");
            ctx.message("Error Received: " + err);
        });
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};