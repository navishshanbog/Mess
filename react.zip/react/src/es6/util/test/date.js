import testRunner from "test/runner";
import dateUtils from "util/date";
import places from "places";

const suite = {
    title: "Date Utilities Test",
    testFormatting(ctx) {
        let date = new Date(2001, 6, 4, 12, 8, 56, 235);
            
        let fmt = dateUtils.getFormat("yyyy.MM.dd G 'at' HH:mm:ss Z");
        ctx.message("Formatting Date with " + fmt);
        let text = fmt.format(date);
        ctx.message("Date Formatted: " + text);
        ctx.assert.equal(text, "2001.07.04 AD at 12:08:56 " + dateUtils.getFormat("Z").format(date), "Check Formatting");
        
        fmt = dateUtils.getFormat("EEE, MMM d, ''yy");
        ctx.message("Formatting Date with: " + fmt);
        text = fmt.format(date);
        ctx.message("Date Formatted: " + text);
        ctx.assert.equal(text, "Wed, Jul 4, '01", "Check Formatting");
        
        fmt = dateUtils.getFormat("h:mm a");
        ctx.message("Formatting Date with: " + fmt);
        text = fmt.format(date);
        ctx.message("Date Formatted: " + fmt.format(date));
        ctx.assert.equal(text, "12:08 PM", "Check Formatting");
        
        fmt = dateUtils.getFormat("hh 'o''clock' a, Z");
        ctx.message("Formatting Date with: " + fmt);
        text = fmt.format(date);
        ctx.message("Date Formatted: " + text);
        ctx.assert.equal(text, "12 o'clock PM, " + dateUtils.getFormat("Z").format(date), "Check Formatting");
        
        fmt = dateUtils.getFormat("K:mm a, Z");
        ctx.message("-- Date Formatted: " + fmt.format(date));
        
        fmt = dateUtils.getFormat("yyyyy.MMMMM.dd GGG hh:mm aaa");
        ctx.message("-- Date Formatted: " + fmt.format(date));
        
        fmt = dateUtils.getFormat("EEE, d MMM yyyy HH:mm:ss Z");
        ctx.message("-- Date Formatted: " + fmt.format(date));
        
        fmt = dateUtils.getFormat("yyMMddHHmmssZ");
        ctx.message("-- Date Formatted: " + fmt.format(date));
        
        fmt = dateUtils.getFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        ctx.message("-- Date Formatted: " + fmt.format(date));
        
        fmt = dateUtils.getFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        ctx.message("-- Date Formatted: " + fmt.format(date));
        
        fmt = dateUtils.getFormat("YYYY-'W'ww-u");
        ctx.message("-- Date Formatted: " + fmt.format(date));
    },
    testParsing: function(ctx) {
        let fmt = dateUtils.getFormat("dd/MM/yyyy");
        let s = "01/01/2011";
        let r = fmt.parse(s);
        ctx.message("-- Parse Result: " + fmt + ": " + s + " -> " + r);
        
        ctx.assert.equal(r.getDate(), 1, "Check day of month is correct");
        ctx.assert.equal(r.getMonth(), 0, "Check month is correct");
        ctx.assert.equal(r.getFullYear(), 2011, "Check year is correct");
        
        fmt = dateUtils.getFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        s = "1996-08-20T14:56:22.333-0200";
        r = fmt.parse(s);    
        ctx.message("-- Parse Result: " + fmt + ": " + s + " -> " + r);
        
        fmt = dateUtils.getFormat("yyyy-MMM-dd'T'hh:mm:ss a");
        s = "2009-Jan-01T11:52:22 pm";
        r = fmt.parse(s);
        ctx.message("-- Parse Result: " + fmt + ": " + s + " -> " + r);
        
        s = "2009-Dec-01T11:52:22 am";
        r = fmt.parse(s);
        ctx.message("-- Parse Result: " + fmt + ": " + s + " -> " + r);
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};

