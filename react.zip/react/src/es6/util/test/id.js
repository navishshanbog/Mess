import testRunner from "test/runner";
import id from "util/id";
import places from "places";

const suite = {
    title: "Id Utilities Test",
    testDefaultInstance(ctx) {
        const defaultSequence = id.getSequence();
        ctx.message("Global Id: " + defaultSequence.next());
        ctx.message("Global Id: " + defaultSequence.next());
        ctx.message("Global Id: " + defaultSequence.next());
        ctx.message("Global Id: " + defaultSequence.next());
        ctx.message("Global Id: " + defaultSequence.next());
    },
    testNamedInstance(ctx) {
        var namedSequence = id.getSequence("named");
        ctx.message("Local Id: " + namedSequence.next());
        ctx.message("Local Id: " + namedSequence.next());
        ctx.message("Local Id: " + namedSequence.next());
        ctx.message("Local Id: " + namedSequence.next());
        ctx.message("Local Id: " + namedSequence.next());
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};