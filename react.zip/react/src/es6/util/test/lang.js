import testRunner from "test/runner";
import lang from "util/lang";
import places from "places";

const suite = {
    title: "Language Utilities Tests",
    testTypeChecking(ctx) {
        ctx.message("String Type Checking");
        ctx.assert(lang.isString(""), "Check empty string");
        ctx.assert(!lang.isString(null), "Check null is not a string");
        ctx.assert(!lang.isString(undefined), "Check undefined is not a string");
        ctx.assert(!lang.isString(1), "Check the number 1 is not a string");
        ctx.assert(!lang.isString(true), "Check the boolean true is not a string");
        ctx.assert(!lang.isString(false), "Check the boolean false is not a string");
        ctx.assert(!lang.isString({ foo: "too"}), "Check that an object is not a string");

        ctx.message("Number Type Checking");
        ctx.assert(lang.isNumber(0), "Check 0 is number");
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};