import testRunner from "test/runner";
import pathUtils from "util/path";
import places from "places";

const suite = {
    title: "Path Utilities Test",
    testAll(ctx) {
        var r = pathUtils.join("woo");
        
        ctx.message("path: " + r);
        
        ctx.assert.equal(r, "woo", "Test single element");
        
        r = pathUtils.join("woo", "foo");
        
        ctx.message("path: " + r);
        
        ctx.assert.equal(r, "woo/foo", "Test Multiple simple elements");
        
        r = pathUtils.join("woo/", "/foo");
        
        ctx.message("path: " + r);
        
        ctx.assert.equal(r, "woo/foo", "Test Multiple simple elements with separators");
        
        r = pathUtils.join("/woo", "foo/");
        
        ctx.message("path: " + r);
        
        ctx.assert.equal(r, "/woo/foo/", "Test Multiple simple elements with separators");
        
        r = pathUtils.join("/woo/", "/foo/");
        
        ctx.message("path: " + r);
        
        ctx.assert.equal(r, "/woo/foo/", "Test Multiple simple elements with separators");
        
        r = pathUtils.join("woo", "foo", ["/bar", "/gun/", "poo/"]);
        
        ctx.message("path: " + r);
        
        ctx.assert.equal(r, "woo/foo/bar/gun/poo/", "Test Multiple elements with separators");
        
        r = pathUtils.join("/a/b/c", "../d");
        
        ctx.message("-- Relative: " + r);
        
        ctx.assert.equal(r, "/a/b/d", "Test Relative");
        
        r = pathUtils.join("a/b/c/d", "../../e");
        
        ctx.message("-- Relative: " + r);
        
        ctx.assert.equal(r, "a/b/e", "Test Relative");
        
        r = pathUtils.join("/a/b", "../../../../w");
        
        ctx.message("-- Relative: " + r);
        
        ctx.assert.equal(r, "/w", "Test Going crazy with parent dirs");
        
        r = pathUtils.normalize("a/b/c/d/e/f/g/../h/./i");
        
        ctx.message("-- Normalize result: " + r);
        
        ctx.assert.equal(r, "a/b/c/d/e/f/h/i", "Ensure we've skipped g");

        r = pathUtils.normalize("a//b/c/d/e/f//g");

        ctx.message("-- Normalize Result " + r);
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};