import testRunner from "test/runner";
import promiseUtils from "util/promise";
import places from "places";

const suite = {
    title: "Promise Utilities Test",
    testWithRetryTimeout(ctx) {
        ctx.message("Invoke With Retry Start: " + new Date());
        return promiseUtils.invokeWithRetry(() => {
            return new Promise((resolve, reject) => {
                // we want it to timeout
            });
        }, { period: 500, timeout: 5000}).then(() => {
            ctx.assert(false, "This shouldn't happen");
        }).catch((err) => {
            ctx.message("Invoke With Retry End: " + new Date());
            ctx.assert(true, "We should get a timeout error");
        });
    },
    testWithRetryGood(ctx) {
        ctx.message("Invoke With Retry Start: " + new Date());
        return promiseUtils.invokeWithRetry(() => {
            return promiseUtils.invokeDelayed(() => {
                return "Woo";
            });
        }, { period: 500, timeout: 5000 }).then((value) => {
            ctx.message("Invoke With Retry End: " + new Date());
            ctx.assert(true, "We should return ok");
            ctx.assert.equal(value, "Woo", "Check returned value");
        }).catch((err) => {
            ctx.assert(false, "We shouldn't get an error");
        });
    },
    testDelayed(ctx) {
        ctx.message("Delayed Start: " + new Date());
        return promiseUtils.invokeDelayed(() => {
            ctx.message("Delayed Complete: " + new Date());
        }, { delay: 2000 });
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};