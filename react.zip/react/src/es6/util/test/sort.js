import testRunner from "test/runner";
import sortUtils from "util/sort";
import places from "places";

const suite = {
    title: "Sort Utilities Test",
    testCompareStrings(ctx) {
        let r = sortUtils.compare("one", "one");
        
        ctx.assert.equal(r, 0, "Ensure Equal");
        
        r = sortUtils.compare("one", "two");

        ctx.assert.ok(r < 0, "Ensure less than");
        
        r = sortUtils.compare("one", "four");
        
        ctx.assert.ok(r > 0, "Ensure greater than"); 
    },
    testCompareNumbers(ctx) {
        let r = sortUtils.compare(1, 1);
        
        ctx.assert.equal(r, 0, "Ensure Equal");
        
        r = sortUtils.compare(1, 2);
        
        ctx.assert.ok(r < 0, "Ensure less than");
        
        r = sortUtils.compare(1, 0);
        
        ctx.assert.ok(r > 0, "Ensure greater than");
    },
    testCompareBooleans(ctx) {
        let r = sortUtils.compare(true, true);
        
        ctx.assert.equal(r, 0, "Ensure true equal");
        
        r = sortUtils.compare(true, false);
        
        ctx.assert.ok(r > 0, "Ensure greater than");
        
        r = sortUtils.compare(false, false);
        
        ctx.assert.equal(r, 0, "Ensure false equal");
        
        r = sortUtils.compare(false, true);
        
        ctx.assert.ok(r < 0, "Ensure less than");
    },
    testCompareDates(ctx) {
        let r = sortUtils.compare(new Date(2012, 8, 1), new Date(2012, 8, 1));
        
        ctx.assert.equal(r, 0, "Ensure equal");
        
        r = sortUtils.compare(new Date(2012, 8, 1), new Date(2012, 8, 2));
        
        ctx.assert.ok(r < 0, "Ensure less than");
        
        r = sortUtils.compare(new Date(2012, 8, 1), new Date(2012, 7, 20));
        
        ctx.assert.ok(r > 0, "Ensure greater than");
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};