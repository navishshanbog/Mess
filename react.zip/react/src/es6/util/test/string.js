import testRunner from "test/runner";
import stringUtils from "util/string";
import places from "places";

const suite = {
    title: "String Utilities Test",
    testAll(ctx) {
        var testString = " \t\r\nHere's some good stuff\twef \r\n";

        ctx.message("Filtered Find Index");
        
        ctx.assert.equal(stringUtils.findIndexOf(testString, stringUtils.filters.nonWhitespace), 4, "Check Find Index Of");
        ctx.assert.equal(stringUtils.findLastIndexOf(testString, stringUtils.filters.nonWhitespace), 29, "Check Find Last Index Of");
        
        ctx.message("Trim");
        
        ctx.assert.equal(stringUtils.leftTrim(testString), "Here's some good stuff\twef \r\n", "Check Trim Left Works");
        ctx.assert.equal(stringUtils.rightTrim(testString), " \t\r\nHere's some good stuff\twef", "Check Trim Right Works");

        ctx.assert.equal(stringUtils.trim(testString), "Here's some good stuff\twef", "Check Trim Works");

        ctx.assert.equal(stringUtils.removeWhitespace(testString), "Here'ssomegoodstuffwef", "Check Remove Whitespace");

        ctx.assert.ok(stringUtils.some(testString, function(ch) {
            return ch === "H";
        }), "Check Some Predicate Positive");
        ctx.assert.ok(!stringUtils.some(testString, function(ch) {
            return ch === "Z";
        }), "Check Some Predicate Negative");

        ctx.assert.ok(stringUtils.every(testString, stringUtils.filters.nonDigit), "Check Every Predicate Positive");
        ctx.assert.ok(!stringUtils.every(testString, stringUtils.filters.digit), "Check Every Predicate Negative");

        ctx.message("Is Blank");

        ctx.assert.ok(stringUtils.isBlank(null), "Check Blank");
        ctx.assert.ok(stringUtils.isBlank(undefined), "Check Blank");
        ctx.assert.ok(stringUtils.isBlank(""), "Check Blank");
        ctx.assert.ok(stringUtils.isBlank(" "), "Check Blank");
        ctx.assert.ok(stringUtils.isBlank(" \t\r\n  "), "Check Blank");

        ctx.message("Is Not Blank");

        ctx.assert.ok(stringUtils.isNotBlank("   a"), "Check Not Blank");
        ctx.assert.ok(stringUtils.isNotBlank("W"), "Check Not Blank");
        ctx.assert.ok(!stringUtils.isNotBlank(" "), "Check Negative");
        ctx.assert.ok(!stringUtils.isNotBlank(" \t\r\r\r\n\n"), "Check Negative");

        ctx.message("Starts With");
        
        ctx.assert.ok(stringUtils.startsWith("Some", "So"), "Check Starts With");
        ctx.assert.ok(stringUtils.startsWithIgnoreCase("SOME", "so"), "Check Starts With Ignore Case");
        ctx.assert.ok(!stringUtils.startsWith("Some", "Somer"), "Check Starts With");
        ctx.assert.ok(!stringUtils.startsWith("Some", "Boo"), "Check Starts With");
        ctx.assert.ok(!stringUtils.startsWithIgnoreCase("SOME", "SOMER"), "Check Starts With Ignore Case");
        
        ctx.message("Ends With");
        
        ctx.assert.ok(stringUtils.endsWith("Some", "me"), "Check Ends With");
        ctx.assert.ok(!stringUtils.endsWith("Some", "foo"), "Check Ends With");
        ctx.assert.ok(!stringUtils.endsWith("Some", "ShitSome"), "Check Ends With");
        ctx.assert.ok(!stringUtils.endsWith("SOME", "me"), "Check Ends With");
        ctx.assert.ok(stringUtils.endsWithIgnoreCase("SOME", "me"), "Check Ends With Ignore Case");
        ctx.assert.ok(!stringUtils.endsWithIgnoreCase("SOME", "foo"), "Check Ends With Ignore Case");

        ctx.assert.ok(stringUtils.endsWith("Foo", "Foo"), "Check Ends With");

        var sr = stringUtils.split("Some\r\t One thinks this is shite.", stringUtils.filters.whitespace);
        
        ctx.message("Split Elements: " + JSON.stringify(sr));

        ctx.assert.equal(sr.length, 6, "Check Whitespace Split");

        ctx.assert.equal(sr[0], "Some", "Check Split Element");
        ctx.assert.equal(sr[1], "One", "Check Split Element");
        ctx.assert.equal(sr[2], "thinks", "Check Split Element");
        ctx.assert.equal(sr[3], "this", "Check Split Element");
        ctx.assert.equal(sr[4], "is", "Check Split Element");
        ctx.assert.equal(sr[5], "shite.", "Check Split Element");
        
        ctx.message("Padding");
        
        ctx.assert.equal(stringUtils.padLeft("a", 5), "    a", "Check default padding left");
        ctx.assert.equal(stringUtils.padLeft("a", 5, "0"), "0000a", "Check padding left");
        ctx.assert.equal(stringUtils.padRight("a", 5), "a    ", "Check default padding right");
        ctx.assert.equal(stringUtils.padRight("a", 5, "0"), "a0000", "Check padding right");
        
        ctx.assert.equal(stringUtils.padLeft("Poo", 1), "Poo");
        ctx.assert.equal(stringUtils.padLeft("Poo", 2), "Poo");
        ctx.assert.equal(stringUtils.padLeft("Poo", 3), "Poo");
        ctx.assert.equal(stringUtils.padLeft("Poo", 4), " Poo");
        
        ctx.assert.equal(stringUtils.padRight("Poo", 1), "Poo");
        ctx.assert.equal(stringUtils.padRight("Poo", 2), "Poo");
        ctx.assert.equal(stringUtils.padRight("Poo", 3), "Poo");
        ctx.assert.equal(stringUtils.padRight("Poo", 4), "Poo ");
        
        ctx.message("Strip");
        
        ctx.assert.equal(stringUtils.stripLeft("08", "0"), "8");
        ctx.assert.equal(stringUtils.stripLeft("085", "8"), "085");
        ctx.assert.equal(stringUtils.stripLeft(""), "");
        
        ctx.assert.equal(stringUtils.stripRight("80", "0"), "8");
        ctx.assert.equal(stringUtils.stripRight("809", "0"), "809");
        ctx.assert.equal(stringUtils.stripRight(""), "");
    }
};

export default () => {
    testRunner({
        suite: suite,
        prev: places.utilitiesHome
    });
};