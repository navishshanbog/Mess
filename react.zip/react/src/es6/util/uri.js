import lang from "./lang";
import stringUtils from "./string";

const allowNotNullOrUndefined = (name, value) => {
    return value !== undefined && value !== null;
};

const allowPrimitives = (name, value) => {
    return allowNotNullOrUndefined(name, value) && !lang.isArray(value) && !lang.isObject(value);
};

const propFilters = {
    allowNotNullOrUndefined: allowNotNullOrUndefined,
    allowPrimitives: allowPrimitives
};

const defaults = {
    sep: "&",
    eq: "=",
    propFilter: allowNotNullOrUndefined
};

const uri = {
    propFilters: propFilters,
    defaults: defaults,
    decode(str, opts) {
        if(str) {
            let r = {};
            let elements = str.split(defaults.sep);
            let nv;
            let name;
            let value;
            elements.forEach(function(element) {
                nv = element.split(defaults.eq);
                if(nv.length === 2) {
                    name = decodeURIComponent(nv[0]);
                    value = decodeURIComponent(nv[1]);
                    if(Array.isArray(r[name])) {
                        r[name].push(value);
                    } else if(r[name] !== undefined) {
                        let e = r[name];
                        r[name] = [e, value];
                    } else {
                        r[name] = value;
                    }
                }
            });
            return r;
        }
    },
    encode(obj, opts) {
        var r = "";
        
        if(obj) {
            var propFilter = opts && opts.propFilter ? opts.propFilter : this.defaults.propFilter;
            
            var propEncoder = function(name, value) {
                if(propFilter(name, value)) {
                    if(r.length > 0) {
                        r += defaults.sep;
                    }
                    r += encodeURIComponent(name) + defaults.eq + encodeURIComponent(value);
                }
            };
            
            var value;
            Object.keys(obj).forEach(function(name) {
                value = obj[name];
                if(Array.isArray(value)) {
                    value.forEach(function(el) {
                        propEncoder(name, el);
                    });
                } else {
                    propEncoder(name, value);
                }
            });
        }
        
        return r;
    }
};

const TemplateDefaults = {
    paramStart(ch) {
        return ch === ":";
    },
    paramEnd(ch) {
        return stringUtils.filters.isNotAlphaNumeric(ch) && ch !== "_";
    },
    defaultParamMap: function() {
        return stringUtils.empty;
    }
}

class Template {
    static get defaults() {
        return TemplateDefaults;
    }

    constructor(text, opts) {
        this._text = text;
        this._paramStart = opts && opts.paramStart ? opts.paramStart : TemplateDefaults.paramStart;
        this._paramEnd = opts && opts.paramEnd ? opts.paramEnd : TemplateDefaults.paramEnd;
        this._defaultParamMap = opts && opts.defaultParamMap ? opts.defaultParamMap : TemplateDefaults.defaultParamMap;
        this._compile();
    }

    _addParamNames(node, paramNames) {
        if(node._name) {
            if(paramNames.indexOf(node._name) < 0) {
                paramNames.push(node._name);
            }
            if(node._next) {
                this._addParamNames(node._next, paramNames);
            }
        }
    }

    get paramNames() {
        if(!this._paramNames) {
            this._paramNames = [];
            this._addParamNames(this, this._paramNames);
        }
        return [].concat(this._paramNames);
    }
    
    _compile() {
        let tailText;
        let nextText;
        let paramEndIdx;
        let param;
        
        let idx = stringUtils.findIndexOf(this._text, this._paramStart);
        if(idx >= 0) {
            this._head = this._text.substring(0, idx);
            tailText = this._text.substring(idx + 1);
            paramEndIdx = stringUtils.findIndexOf(tailText, this._paramEnd);
            if(paramEndIdx > 0) {
                this._name = tailText.substring(0, paramEndIdx);
                if(paramEndIdx < tailText.length - 1) {
                    this._next = new URITemplate(tailText.substring(paramEndIdx), { paramStart: this._paramStart, paramEnd: this._paramEnd, defaultParamMap: this._defaultParamMap });
                }
            } else {
                this._name = tailText;
            }
        }

        if(this._head === undefined) {
            this._head = this._text;
        }
    }
       
    format(params) {
        let paramMap = lang.isFunction(params) ? params : (name) => {
            return params ? params[name] : undefined;
        };
        let r = this._head;
        let value;
        if(this._name) {
            value = paramMap(this._name);
            if(value === undefined) {
                value = this._defaultParamMap(this._name);
            }
            r += encodeURIComponent(value);

            if(this._next) {
                r += this._next.format(params);
            }
        }
        
        return r;
    }

    _addMatch(paramName, text, result) {
        var matchValue = decodeURIComponent(text);
        var current = result.params[paramName];
        if(current === undefined) {
            result.params[paramName] = matchValue;
        } else if(lang.isArray(current)) {
            current.push(matchValue);
        } else {
            result.params[paramName] = [current, matchValue];
        }
    }

    _matchParam(text, paramName, node, result) {
        let paramEndIdx = text.indexOf(node._head);
        if(paramEndIdx >= 0) {
            this._addMatch(paramName, text.substring(0, paramEndIdx), result);
            let tail = text.substring(paramEndIdx + node._head.length);
            if(node._next) {
                this._matchParam(tail, node._name, node._next, result);
            } else if(node._name) {
                this._addMatch(node._name, tail, result);
                result.match = true;
            } else {
                result.match = tail.length === 0;
            }
        } else {
            result.match = false;
        }
    }

    _matchInto(text, node, result) {
        if(text.startsWith(node._head)) {
            let tail = text.substring(node._head.length);
            if(node._next) {
                this._matchParam(tail, node._name, node._next, result);
            } else if(node._name) {
                this._addMatch(node._name, tail, result);
                result.match = true;
            } else {
                result.match = text.length === node._head.length;
            }
        } else {
            result.match = false;
        }
    }
           
    match(text) {
        let result = { match: false, params: {} };
        this._matchInto(text, this, result);
        return result;
    }

    toString() {
        return this._text;
    }
}

uri.Template = Template;

export default uri;
