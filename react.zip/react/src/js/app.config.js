define(function() {
    return {
        basePath: "/"
    }
});