import * as React from "react";

interface EntityActivityListItemProps { item: any }

class EntityActivityListItem extends React.Component<EntityActivityListItemProps, {}> {
    render() {
        return <div>A place-holder for an entity activity list item</div>;
    }
}

export { EntityActivityListItem as default, EntityActivityListItemProps };