"use strict";
const formatOptions = {
    textAttributes: {
        off: 0,
        bold: 1,
        underscore: 4,
        blink: 5,
        reverse: 7,
        concealed: 8
    },
    foregroundColors: {
        black: 30,
        red: 31,
        green: 32,
        yellow: 33,
        blue: 34,
        magenta: 35,
        cyan: 36,
        white: 37
    },
    backgroundColors: {
        black: 40,
        red: 41,
        green: 42,
        yellow: 43,
        blue: 44,
        magenta: 45,
        cyan: 46,
        white: 47
    }
};

class Formatter {
    addTextAttribute(flag) {
        var value = this._textAttributes !== undefined ? this._textAttributes & flag : flag;
        if(value !== this._textAttributes) {
            this._textAttributes = value;
            delete this._formatter;
        }
        return this;
    }

    get foregroundColor() {
        return this._foregroundColor;
    }

    set foregroundColor(value) {
        if(value !== this._foregroundColor) {
            this._foregroundColor = value;
            delete this._formatter;
        }
    }

    get backgroundColor() {
        return this._backgroundColor;
    }

    set backgroundColor(value) {
        if(value !== this._backgroundColor) {
            this._backgroundColor = value;
            delete this._formatter;
        }
    }

    bold() {
        return this.addTextAttribute(formatOptions.textAttributes.bold);
    }

    underscore() {
        return this.addTextAttribute(formatOptions.textAttributes.underscore);
    }

    blink() {
        return this.addTextAttribute(formatOptions.textAttributes.blink);
    }
    
    reverse() {
        return this.addTextAttribute(formatOptions.textAttributes.reverse);
    }

    foregroundBlack() {
        this.foregroundColor = formatOptions.foregroundColors.black;
        return this;
    }

    black() {
        return this.foregroundBlack();
    }

    foregroundRed() {
        this.foregroundColor = formatOptions.foregroundColors.red;
        return this;
    }

    red() {
        return this.foregroundRed();
    }

    foregroundGreen() {
        this.foregroundColor = formatOptions.foregroundColors.green;
        return this;
    }

    green() {
        return this.foregroundGreen();
    }

    foregroundYellow() {
        this.foregroundColor = formatOptions.foregroundColors.yellow;
        return this;
    }

    yellow() {
        return this.foregroundYellow();
    }

    foregroundBlue() {
        this.foregroundColor = formatOptions.foregroundColors.blue;
        return this;
    }

    blue() {
        return this.foregroundBlue();
    }

    foregroundMagenta() {
        this.foregroundColor = formatOptions.foregroundColors.magenta;
        return this;
    }

    magenta() {
        return this.foregroundMagenta();
    }

    foregroundCyan() {
        this.foregroundColor = formatOptios.foregroundColors.cyan;
        return this;
    }

    cyan() {
        return this.foregroundCyan();
    }

    foregroundWhite() {
        this.foregroundColor = formatOptions.foregroundColors.white;
        return this;
    }

    white() {
        return this.foregroundWhite();
    }

    backgroundBlack() {
        this.backgroundColor = formatOptions.backgroundColors.black;
        return this;
    }

    backgroundRed() {
        this.backgroundColor = formatOptions.backgroundColors.red;
        return this;
    }

    backgroundGreen() {
        this.backgroundColor = formatOptions.backgroundColors.green;
        return this;
    }

    backgroundYellow() {
        this.backgroundColor = formatOptions.backgroundColors.yellow;
        return this;
    }
    
    backgroundBlue() {
        this.backgroundColor = formatOptions.backgroundColors.blue;
        return this;
    }

    backgroundMagenta() {
        this.backgroundColor = formatOptions.backgroundColors.magenta;
        return this;
    }

    backgroundCyan() {
        this.backgroundColor = formatOptions.backgroundColors.cyan;
        return this;
    }

    backgroundWhite() {
        this.backgroundColor = formatOptions.backgroundColors.white;
        return this;
    }

    format(text) {
        if(!this._formatter) {
            let els = [];
            if(this._textAttributes !== undefined) {
                els.push(this._textAttributes);
            }
            if(this._foregroundColor !== undefined) {
                els.push(this._foregroundColor);
            }
            if(this._backgroundColor !== undefined) {
                if(this._foregroundColor === undefined) {
                    els.push("");
                } else {
                    els.push(this._backgroundColor);
                }
            }

            if(els.length > 0) {
                let formatString = els.join(";") + "m";
                this._formatter = (text) => {
                    return "\x1b[" + formatString + text + "\x1b[0m";
                };
            } else {
                this._formatter = (text) => {
                    return text;
                };
            }
        }

        return this._formatter(text);
    }
};

module.exports = {
    formatOptions: formatOptions,
    Formatter: Formatter,
    format(text, opts) {
        var formatter = new Formatter();
        if(opts) {
            if(opts.textAttributes) {
                if(Array.isArray(opts.textAttributes)) {
                    opts.textAttributes.forEach(formatter.addTextAttribute, formatter);
                } else {
                    formatter.addTextAttribute(opts.textAttributes);
                }
            }
            if(opts.foregroundColor !== undefined) {
                formatter.foregroundColor = opts.foregroundColor;
            }
            if(opts.backgroundColor !== undefined) {
                formatter.backgroundColor = opts.backgroundColor;
            }
        }
        return formatter.format(text);
    },
    formatter() {
        return new Formatter();
    }
};