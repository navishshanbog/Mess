"use strict";
const ascii = require("./ascii");

var formatted = ascii.format("SAMPLE", {
    textAttributes: ascii.formatOptions.textAttributes.bold,
    foregroundColor: ascii.formatOptions.foregroundColors.red,
    backgroundColor: ascii.formatOptions.backgroundColors.blue
});

console.log("-- Formatted: " + formatted);

var formatter = new ascii.Formatter();
formatter.bold().underscore().blue();

console.log("-- Formatted: " + formatter.format("BLUE GOODIES"));