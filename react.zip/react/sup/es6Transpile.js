"use strict";
const babel = require("babel-core");
const transpile = require("./transpile");
const pathUtils = require("path");

const babelConfig = {
    presets: ["es2015", "react"],
    plugins: ["transform-es2015-modules-amd"]
};

const render = (data) => {
    return babel.transform(data.toString("utf8"), babelConfig).code;
};

const defaultOptions = {
    toExtension: ".js"
};

const es6Transpile = (opts) => {
    console.log("ES6 Transpile: " + JSON.stringify(opts));
    return transpile(Object.assign({}, defaultOptions, opts, { renderer: render }));
};

es6Transpile.defaultOptions = defaultOptions;

module.exports = es6Transpile;