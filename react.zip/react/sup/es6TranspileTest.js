"use strict";
const es6Transpile = require("./es6Transpile");
const pathUtils = require("path");

const srcDir = pathUtils.join(__dirname, "../src/es6");
const destDir = pathUtils.join(__dirname, "dist/woo/js");

es6Transpile({ path: srcDir, toDir: destDir }).then(() => {
    console.info("-- Success");
}).catch((err) => {
    console.error(err);  
});