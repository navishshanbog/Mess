"use strict";
const fs = require("fs");
const pathUtils = require("path");

const EXISTS_ERROR_CODE = "EEXIST";
const NOT_EXISTS_ERROR_CODE = "ENOENT";

const isExistsError = (err) => {
    return err && err.code === EXISTS_ERROR_CODE;
};

const isNotExistsError = (err) => {
    return err && err.code === NOT_EXISTS_ERROR_CODE;
};

const mkdirImmediate = (opts) => {
    return new Promise((resolve, reject) => {
        fs.mkdir(opts.path, opts.mode, (err) => {
            if(err) {
                if(isExistsError(err)) {
                    resolve({ path: opts.path, created: false });
                } else {
                    reject(err);
                }
            } else {
                resolve({ path: opts.path, created: true });
            }
        });
    });
};

const mkdir = (opts) => {
    return mkdirImmediate(opts).catch((err) => {
        if(isNotExistsError(err)) {
            let parentOpts = Object.assign({}, opts, { path: pathUtils.dirname(opts.path) });
            return mkdir(parentOpts).then(() => {
                return mkdirImmediate(opts);  
            });
        }
    });
};

const rmdirImmediate = (opts) => {
    return new Promise((resolve, reject) => {
        fs.rmdir(opts.path, (err) => {
            if(err) {
                if(isNotExistsError(err)) {
                    resolve();
                } else {
                    reject(err);
                }
            }
            resolve();
        });
    });
};

const rmdir = (opts) => {
    let path = opts.path;
    let recursive = opts ? opts.recursive : false;
    if(recursive) {
        return readdir(opts).then((files) => {
            if(files && files.length > 0) {
                var filePromises = files.map((file) => {
                    return rm(Object.assign({}, opts, { path: pathUtils.join(path, file) }));
                });
                return Promise.all(filePromises);
            }
        }).then(() => {
            return rmdirImmediate(opts);
        }).catch((err) => {
            if(!isNotExistsError(err)) {
                throw err;
            }  
        });
    }
    return rmdirImmediate(opts);
};

const rm = (opts) => {
    return stat(opts).then((stats) => {
        if(stats.isDirectory()) {
            return rmdir(opts);
        } else if(stats.isFile()) {
            return unlink(opts);
        }
    }).catch((err) => {
        if(!isNotExistsError(err)) {
            throw err;
        }
    });
};

const readFile = (opts) => {
    let path = opts.path;
    let readOpts;
    if(opts.encoding || opts.flag) {
        readOpts = {
            encoding: opts.encoding || null,
            flag: opts.flag
        };
    }
    return new Promise((resolve, reject) => {
        fs.readFile(path, readOpts, (err, data) => {
            if(err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
};

const writeFile = (opts) => {
    return new Promise((resolve, reject) => {
        fs.writeFile(opts.path, opts.data, opts, (err) => {
            if(err) {
                reject(err);
            } else {
                resolve();
            }
        });
    });
};

const readdir = (opts) => {
    return new Promise((resolve, reject) => {
        fs.readdir(opts.path, opts, (err, files) => {
            if(err) {
                reject(err);
            } else {
                resolve(files);
            }
        });
    });
};

const stat = (opts) => {
    return new Promise((resolve, reject) => {
        fs.stat(opts.path, (err, stats) => {
            if(err) {
                reject(err);
            } else {
                resolve(stats);
            }
        });
    });
};

const unlink = (opts) => {
    return new Promise((resolve, reject) => {
        fs.unlink(opts.path, (err) => {
            if(err) {
                reject(err);
            } else {
                resolve();
            }
        });
    });
};

const visitDirFile = (opts) => {
    let filePath = pathUtils.join(opts.path, opts.file);
    let relFilePath = pathUtils.join(opts.relPath || "", opts.file);
    return stat({ path: filePath }).then((stats) => {
        let nextOpts = { path: filePath, basePath: opts.basePath, relPath: relFilePath, file: opts.file, visitor: opts.visitor };
        if(stats.isDirectory()) {
            return visitDir(nextOpts);
        } else if(stats.isFile()) {
            return visitFile(nextOpts);
        }
    });
};

const visitDir = (opts) => {
    return readdir(opts).then((files) => {
        if(files && files.length > 0) {
            let p;
            files.forEach((file) => {
                let fileOpts = Object.assign({}, opts, { basePath: opts.basePath || opts.path, file: file });
                if(p) {
                    p = p.then(() => {
                        return visitDirFile(fileOpts);
                    });
                } else {
                    p = visitDirFile(fileOpts);
                }
            });
            return p;
        }
    });
};

const visitFile = (opts) => {
    try {
        return Promise.resolve(opts.visitor({
            path: opts.path,
            basePath: opts.basePath || pathUtils.dirname(opts.path),
            relPath: opts.relPath || pathUtils.basename(opts.path),
            file: opts.file || pathUtils.basename(opts.path)
        }));
    } catch(e) {
        return Promise.reject(e);
    }
};

const visit = (opts) => {
    let path = opts.path;
    let visitor;
    if(opts.visitor) {
        visitor = opts.visitor.visitFile ? opts.visitor.visitFile.bind(opts.visitor) : opts.visitor;
    } else {
        visitor = () => {};
    }
    return stat(opts).then((stats) => {
        const visitOpts = Object.assign({}, opts, { visitor: visitor });
        if(stats.isDirectory()) {
            return visitDir(visitOpts);
        } else if(stats.isFile()) {
            return visitFile(visitOpts);
        }
    });
};

const copyFileImmediate = (opts) => {
    let write = (data) => {
        return writeFile({ path: opts.toPath, data: data });
    };
    return readFile(opts).then((data) => {
        if(opts.dataMap) {
            return Promise.resolve(opts.dataMap(data)).then((mappedData) => {
                return write(mappedData);
            });
        } else {
            return write(data);
        }
    });
};

const copyFileCheck = (opts) => {
    if(opts.overwrite) {
        return copyFileImmediate(opts);
    } else {
        return stat(opts).then((stats) => {
            return stat({ path: opts.toPath }).then((toStats) => {
                return stats.mtime > toStats.mtime ? copyFileImmediate(opts) : Promise.resolve();
            }).catch((err) => {
                return isNotExistsError(err) ? copyFileImmediate(opts) : Promise.reject(err);
            });
        });
    }
};

const copyFile = (opts) => {
    let toDir;
    let toPath;
    if(opts.toFile) {
        toDir = pathUtils.dirname(opts.toFile);
        toPath = opts.toFile;
    } else if(opts.toDir) {
        toDir = opts.toDir;
        toPath = pathUtils.join(opts.toDir, pathUtils.basename(opts.relPath || opts.path));
    }
    if(toDir && toPath) {
        return mkdir({ path: toDir }).then((res) => {
            return copyFileCheck(Object.assign({}, opts, { toPath: toPath, overwrite: opts.overwrite || res.created }));
        });
    }
    return Promise.resolve();
};

const copyDirFile = (opts) => {
    let filePath = pathUtils.join(opts.path, opts.file);
    return stat({ path: filePath }).then((fileStats) => {
        let destPath = pathUtils.join(opts.toDir, opts.file);
        if(fileStats.isDirectory()) {
            return mkdir({ path: destPath }).then(() => {
                return copyDir(Object.assign({}, opts, { path: filePath, toDir: destPath }));
            });
        } else {
            return copyFile(Object.assign({}, opts, { path: filePath, toFile: destPath }));
        }
    });
};

const copyDir = (opts) => {
    return readdir(opts).then((files) => {
        if(files && files.length > 0) {
            var filePromises = files.map((file) => {
                return copyDirFile(Object.assign({}, opts, { file: file }));
            });
            return Promise.all(filePromises);
        }
        return Promise.resolve();
    });
};

const copy = (opts) => {
    return stat(opts).then((stats) => {
        if(stats.isDirectory()) {
            return copyDir(opts);
        } else {
            return copyFile(opts);
        }
    });
};

module.exports = {
    isNotExistsError: isNotExistsError,
    isExistsError: isExistsError,
    stat: stat,
    mkdir: mkdir,
    rm: rm,
    copyDir: copyDir,
    copyFile: copyFile,
    copy: copy,
    visitDir: visitDir,
    visitFile: visitFile,
    visit: visit
};