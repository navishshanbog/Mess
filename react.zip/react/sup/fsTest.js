"use strict";
const fsTasks = require("./fs");
const pathUtils = require("path");

const srcDir = pathUtils.join(__dirname, "../src/js");
const destDir = pathUtils.join(__dirname, "dist/woo/js");

fsTasks.mkdir({ path: destDir }).then((res) => {
    fsTasks.copy({ path: srcDir, toDir: res.path });
});