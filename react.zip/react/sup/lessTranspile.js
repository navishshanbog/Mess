"use strict";
const transpile = require("./transpile");
const less = require("less");
const pathUtils = require("path");

const render = (data, opts) => {
    console.log("Render Less: " + JSON.stringify(opts));
    return less.render(data.toString("utf8"), {
        filename: opts.path
    }).then((out) => {
        return out.css;
    });
};

const defaultOptions = {
    toExtension: ".css"
};

const lessTranspile = (opts) => {
    console.log("Less Transpile: " + JSON.stringify(opts));
    return transpile(Object.assign({}, defaultOptions, opts, { renderer: render }));
};

lessTranspile.defaultOptions = defaultOptions;

module.exports = lessTranspile;