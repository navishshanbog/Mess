"use strict";
const lessTranspile = require("./lessTranspile");
const pathUtils = require("path");

const srcDir = pathUtils.join(__dirname, "../src/less");
const destDir = pathUtils.join(__dirname, "dist/woo/css");

lessTranspile({ path: srcDir, toDir: destDir }).then(() => {
    console.log("-- Success");
}).catch((err) => {
    console.error(err);  
});