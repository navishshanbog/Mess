"use strict";
const argPrefix = "--";

var optsString = process.argv.join("");
var firstArgIdx = optsString.indexOf(argPrefix);
if(firstArgIdx > 0) {
    optsString = optsString.substring(firstArgIdx);
}

var elements = optsString.split(argPrefix);

var opts = {};
var name;
var value;
var existingValue;
var nameValuePair;
elements.forEach(function(e) {
    nameValuePair = e.split("=");
    if(nameValuePair.length === 2) {
        name = nameValuePair[0];
        value = nameValuePair[1];
        if(name && value) {
            existingValue = opts[name];
            if(existingValue) {
                if(Array.isArray(existingValue)) {
                    existingValue.push(value);
                } else {
                    opts[name] = [existingValue, value];
                }
            } else {
                opts[name] = value;
            }
        }
    } else if(nameValuePair.length === 1) {
        opts[nameValuePair[0]] = true;
    }
});

module.exports = opts;