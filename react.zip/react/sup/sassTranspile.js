"use strict";
const transpile = require("./transpile");
const sass = require("node-sass");
const pathUtils = require("path");

const render = (data, opts) => {
    console.log("Render Sass: " + JSON.stringify(opts));
    return new Promise((resolve, reject) => {
        sass.render({
            data: data.toString("utf8"),
            includePaths: [opts.basePath]
        }, function(err, result) {
            if(err) {
                reject(err);
            }
            resolve(result.css);
        });
    });
};

const defaultOptions = {
    toExtension: ".css"
};

const sassTranspile = (opts) => {
    console.log("Sass Transpile: " + JSON.stringify(opts));
    return transpile(Object.assign({}, defaultOptions, opts, { renderer: render }));
};

sassTranspile.defaultOptions = defaultOptions;

module.exports = sassTranspile;