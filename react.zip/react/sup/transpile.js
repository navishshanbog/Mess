"use strict";
const fs = require("./fs");
const pathUtils = require("path");

const replaceExtension = (path, newExt) => {
    let ext = pathUtils.extname(path);
    return (ext ? path.substring(0, path.length - ext.length) : path) + newExt;
};

const transpileFile = (opts) => {
    let toFile;
    if(opts.toFile) {
        toFile = opts.toFile;
    } else if(opts.toDir) {
        toFile = replaceExtension(pathUtils.join(opts.toDir, opts.relPath), opts.toExtension);
    }
    console.log(`Transpiling: ${opts.path} -> ${toFile}`);
    const renderer = opts.renderer;
    const dataMap = (data) => {
        return renderer(data, opts);
    };
    return fs.copyFile(Object.assign({}, opts, { path: opts.path, toFile: toFile, dataMap: dataMap, overwrite: opts.overwrite })).catch((err) => {
        console.error(err);  
    });
};

const createVisitor = (opts) => {
    const toExtension = opts.toExtension;
    const toDir = opts.toDir;
    const renderer = opts.renderer;
    return (pathOpts) => {
        let toFile = pathUtils.join(toDir, replaceExtension(pathOpts.relPath, toExtension));
        return transpileFile({
            path: pathOpts.path,
            relPath: pathOpts.relPath,
            basePath: pathOpts.basePath,
            toFile: toFile,
            toExtension: toExtension,
            renderer: renderer,
            overwrite: opts.overwrite
        });
    };
};

const transpileDir = (opts) => {
    return fs.visitDir({ path: opts.path, visitor: createVisitor(opts) });
};

const transpile = (opts) => {
    return fs.stat(opts).then((stats) => {
        if(stats.isDirectory()) {
            return transpileDir(opts);
        } else if(stats.isFile()) {
            return transpileFile(opts);
        }
    });
};

module.exports = transpile;