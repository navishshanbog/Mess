"use strict";
const ts = require("typescript");
const transpile = require("./transpile");
const pathUtils = require("path");

const tsConfig = {
    compilerOptions: {
        module: ts.ModuleKind.AMD,
        jsx: "react"
    }
};

const render = (data) => {
    return ts.transpileModule(data.toString("utf8"), tsConfig).outputText;
};

const defaultOptions = {
    toExtension: ".js",
};

const tsTranspile = (opts) => {
    console.log("TypeScript Transpile: " + JSON.stringify(opts));
    return transpile(Object.assign({}, defaultOptions, opts, { renderer: render }));
};

tsTranspile.defaultOptions = defaultOptions;

module.exports = tsTranspile;