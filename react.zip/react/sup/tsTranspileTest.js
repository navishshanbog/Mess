"use strict";
const tsTranspile = require("./tsTranspile");
const pathUtils = require("path");

const srcDir = pathUtils.join(__dirname, "../src/ts");
const destDir = pathUtils.join(__dirname, "dist/woo/js");

tsTranspile({ path: srcDir, toDir: destDir }).then(() => {
    console.info("-- Success");
}).catch((err) => {
    console.error(err);  
});