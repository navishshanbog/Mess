"use strict";
const fs = require("fs");
const fsTasks = require("./sup/fs");
const es6Transpile = require("./sup/es6Transpile");
const lessTranspile = require("./sup/lessTranspile");
const sassTranspile = require("./sup/sassTranspile");
const tsTranspile = require("./sup/tsTranspile");
const pathUtils = require("path");

const src = pathUtils.join(__dirname, "src");
const dest = pathUtils.join(__dirname, "dist");
const node_modules = pathUtils.join(__dirname, "node_modules");
const cssSrc = pathUtils.join(src, "/css");

const tsSources = [
    pathUtils.join(src, "/ts")
];
const es6Sources = [
    pathUtils.join(src, "/es6")
];
const jsSources = [
    pathUtils.join(src, "/js"),
    pathUtils.join(node_modules, "react/dist"),
    pathUtils.join(node_modules, "react-dom/dist"),
    pathUtils.join(node_modules, "es6-promise/dist")
];
const lessSources = [
    pathUtils.join(src, "/less")
];
const sassSources = [
    pathUtils.join(src, "/sass")
];
const cssSources = [
    cssSrc,
    pathUtils.join(node_modules, "/bootstrap/dist/css")
];
const fontSources = [
    pathUtils.join(node_modules, "/bootstrap/fonts")
];
const imgSources = [
    pathUtils.join(src, "/img")
];
const templateSrc = pathUtils.join(src, "/index.html");

const jsDest = pathUtils.join(dest, "/js");
const cssDest = pathUtils.join(dest, "/css");
const imgDest = pathUtils.join(dest, "/img");
const fontDest = pathUtils.join(dest, "/fonts");

const createDirWatchHandler = (src, dest, task) => {
    return (eventType, filename) => {
        const fromPath = pathUtils.join(src, filename);
        console.info(`Publishing: ${fromPath}`);
        task({ path: fromPath, basePath: src, relPath: filename, toDir: dest, overwrite: true }).catch((err) => {
            if(fsTasks.isNotExistsError(err)) {
                console.info(`File Removed: ${fromPath}`);
            } else {
                console.error(err);
            }
        });
    }
};

const watchDir = (src, dest, task) => {
    const watchHandler = createDirWatchHandler(src, dest, task);
    return fs.watch(src, { recursive: true}, watchHandler); 
};

module.exports = {
    publishEs6() {
        const ps = es6Sources.map((es6Src) => {
            return es6Transpile({ path: es6Src, toDir: jsDest, overwrite: true });
        });
        return Promise.all(ps);
    },
    publishTypeScript() {
        const ps = tsSources.map((tsSrc) => {
            return tsTranspile({ path: tsSrc, toDir: jsDest, overwrite: true });
        });
        return Promise.all(ps);
    },
    publishJs() {
        const ps = jsSources.map((jsSrc) => {
            return fsTasks.copy({ path: jsSrc, toDir: jsDest, overwrite: true });
        });
        return Promise.all(ps);
    },
    cleanJs() {
        return fsTasks.rm({ path: jsDest, recursive: true });
    },
    publishAllScripts() {
        return this.publishJs().then(() => {
            return this.publishTypeScript();
        }).then(() => {
            return this.publishEs6();
        });
    },
    publishLess() {
        const ps = lessSources.map((lessSrc) => {
            return lessTranspile({ path: lessSrc, toDir: cssDest });
        });
        return Promise.all(ps);
    },
    publishSass() {
        const ps = sassSources.map((sassSrc) => {
            return sassTranspile({ path: sassSrc, toDir: cssDest });
        });
        return Promise.all(ps);
    },
    publishCss() {
        const ps = cssSources.map((cssSrc) => {
            return fsTasks.copy({ path: cssSrc, toDir: cssDest });
        });
        // material design
        ps.push(fsTasks.copy({ path: pathUtils.join(node_modules, "/material-design-lite/dist"), toDir: pathUtils.join(cssDest, "/material-design-lite")}));
        return Promise.all(ps);
    },
    publishFonts() {
        const ps = fontSources.map((fontSrc) => {
            return fsTasks.copy({ path: fontSrc, toDir: fontDest });
        });
        return Promise.all(ps);
    },
    publishAllStyles() {
        return this.publishCss().then(() => {
            return this.publishSass();
        }).then(() => {
            return this.publishLess();
        });
    },
    publishImages() {
        const ps = imgSources.map((imgSrc) => {
            return fsTasks.copy({ path: imgSrc, toDir: imgDest });
        });
        return Promise.all(ps);
    },
    publishTemplate() {
        console.log("Publishing Template");
        return fsTasks.copy({ path: templateSrc, toDir: dest });
    },
    /*
    templateWatch() {
        return fsTasks.watchAndSync(templateSrc, templateDest).then((ref) => {
            this._templateWatchRef = ref;
        });
    },
    */
    clean() {
        return fsTasks.rm({ path: dest, recursive: true });
    },
    publishAll() {
        return this.clean().then(() => {
            return this.publishAllScripts();
        }).then(() => {
            return this.publishAllStyles();
        }).then(() => {
            return this.publishFonts();
        }).then(() => {
            return this.publishImages();
        }).then(() => {
            return this.publishTemplate();
        });
    },
    default() {
        return this.publishAll()
    },
    watchAndPublishEs6() {
        this.publishEs6Watchers = es6Sources.map((es6Src) => {
            return watchDir(es6Src, jsDest, es6Transpile);
        });
    },
    watchAndPublishTypeScript() {
        this.publishTypeScriptWatchers = tsSources.map((tsSrc) => {
            return watchDir(tsSrc, jsDest, tsTranspile);
        });
    },
    watchAndPublishJs() {
        this.publishJsWatchers = jsSources.map((jsSrc) => {
            return watchDir(jsSrc, jsDest, fsTasks.copy);
        });
    },
    watchAndPublishLess() {
        this.publishLessWatchers = lessSources.map((lessSrc) => {
            return watchDir(lessSrc, cssDest, lessTranspile);
        });
    },
    watchAndPublishSass() {
        this.publishSassWatchers = sassSources.map((sassSrc) => {
            return watchDir(sassSrc, cssDest, sassTranspile);
        });
    },
    watchAndPublishCss() {
        this.publishCssWatchers = cssSources.map((cssSrc) => {
            return watchDir(cssSrc, cssDest, fsTasks.copy);
        });
    },
    watchAndPublishFonts() {
        this.publishFontsWatchers = fontSources.map((fontSrc) => {
            return watchDir(fontSrc, fontDest, fsTasks.copy);
        });
    },
    watchAndPublishImages() {
        this.publishImageWatchers = imgSources.map((imgSrc) => {
            return watchDir(imgSrc, imgDest, fsTasks.copy);
        });
    },
    watchAndPublishTemplate() {
        this.templateWatcher = fs.watch(templateSrc, () => {
            this.publishTemplate();
        });
    },
    watch() {
        this.watchAndPublishEs6();
        this.watchAndPublishTypeScript();
        this.watchAndPublishJs();
        this.watchAndPublishLess();
        this.watchAndPublishSass();
        this.watchAndPublishCss();
        this.watchAndPublishImages();
        this.watchAndPublishTemplate();
    }
};