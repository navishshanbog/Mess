//
//     React demo components KeyLines v4.6.0-9745
//
//     Copyright © 2011-2018 Cambridge Intelligence Limited.
//     All rights reserved.
//

import React from 'react';
import PropTypes from 'prop-types'
// We use createClass instead of ES6 class syntax, as createClass automatically binds our methods to 'this': https://facebook.github.io/react/docs/reusable-components.html#no-autobinding
class RightPanel extends React.Component {
  render() {
    // determine if we have a fullscreen function available to show or not the fsBtn
    const fullscreenClass = typeof doFullScreen == 'function' ? '' : 'hide';
    return (
      <div className='rhs span4'>
        <div id="rhscontent" className="citext">
          <ul id="toggleTab" className={`nav nav-tabs vertical-tabs fshide ${fullscreenClass}`}>
            <li className="active"><a id="toggleRight"><i id="toggleIcon" className="icon-chevron-down"></i> </a></li>
          </ul>
          <div style={{ minHeight: "580px", height: "580px" }} className="tab-content">
            <h3 className="demo-title">
              <div className="pull-right">
                <a href="#" data-toggle="tooltip" data-placement="left" id="fullscreenDisabled" className={`btn btn-small btn-spaced disabled fshide ${fullscreenClass}`}>
                  <i className="icon-resize-full icon-white"></i>
                </a>
                <a href="#" data-toggle="tooltip" data-placement="left" id="fullscreenButton" className={`btn btn-small btn-spaced ${fullscreenClass}`}>
                  <i className="icon-resize-full icon-white"></i>
                </a>
              </div>
              <div>{this.props.title}</div>
            </h3>
            <p>{this.props.description}</p>
            <div className="cicontent">
              <img className='kl-center' src={'images/' + this.props.name + '/reactjs.png'} width='75%' />
              {this.props.children}
            </div>
          </div>
        </div>
      </div>
    );
  }
};

RightPanel.propTypes = {
  name: PropTypes.string.isRequired, // this is the name of the demo
  title: PropTypes.string.isRequired, // this is the title of the demo
  description: PropTypes.string.isRequired, // this is the short description of the demo
};

// We use createClass instead of the native ES6 class because it automatically binds 'this': https://facebook.github.io/react/blog/2015/01/27/react-v0.13.0-beta-1.html#autobinding
class LeftPanel extends React.Component {
  render() {
    return (
      <div className='lhs span8'>
        <div id='fullscreen'>
          <div className='cicontainer'>
            {this.props.children}
          </div>
        </div>
      </div>
    );
  }
};

export { LeftPanel, RightPanel };
