// If you are using Node.js as your web server, you should first install Express by running:
//
// > npm install express
//
// You can then start your web server by running this file:
//
// > node server.js
//
// If you can't run Node or Express, just use a simple Python server
//    
//  > python -m SimpleHTTPServer 8080
//
// Then you can navigate to http://localhost:8080 in your web browser to see the demo running.

var path = require('path');
var axios = require('axios');
var btoa = require('btoa');

// Helper to get the major version of Express
function getVersion(){
  // Since Express 3.3 version is not exposed any longer
  var version = (express.version || '4.').match(/^(\d)+\./)[1];
  return Number(version);
}

var express = require('express');

var app;

var version = getVersion();

// Depending on the version number there are several ways to create an app
if(version === 2){
  app = express.createServer();
} else if(version > 2){
  app = express();
}

app.use('/', express["static"].apply(null, [__dirname + '/']));

app.get('/', function (req, res) {
  res.sendFile(path.join(__dirname, 'index.htm'));
});

app.get('/gremlinproxy', function (req, res) {

    var query = req.query.input;
    console.log("-- request ", query);
    var username = 'excbnl';
    var password = 'strikeit';
    var basicAuth = 'Basic ' + btoa(username + ':' + password);
    console.log("-- basicAuth ", basicAuth);
    var reqConfig = {
        url: targetUrl,
        method: 'POST',
        data: JSON.stringify({"gremlin": query}),
//        data: JSON.stringify({"gremlin": "g.V().has('node', 'cid:87335501319').valueMap()"}),  //UNSecure
        headers: {
            "Content-Type": 'application/json',//req.header("Content-Type"),
            'Authorization': basicAuth
        }
    };
    return axios(reqConfig).then(function(result) {
        console.log("result data ", result.data);
        res.set('Content-Type', result.headers["content-type"]);
        res.send(result.data);
    }).catch(function(error) {
        console.error("API Error: ", error);
        if (error.response) {
            res.status(error.response.status);
            res.send(error.response.data);
        } else {
            res.status(500).send(JSON.stringify(error));
        }
    });
});

app.listen(8080);

console.log('Server running. Browse to http://localhost:8080');
