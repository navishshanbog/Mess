//
//     Copyright © 2011-2018 Cambridge Intelligence Limited.
//     All rights reserved.    
//
//     Sample Code
//!    Use React to bind events to a chart.
//
// This demo uses webpack to manage dependencies and build
import React from 'react';
import PropTypes from 'prop-types';
import { render } from 'react-dom';
import { Chart } from 'react-keylines';
import { LeftPanel, RightPanel } from 'react-demo';
import { createClient, makeTemplateTag } from 'gremlin';
import { axios } from "../node_modules/axios/lib/axios";

KeyLines.paths({ assets: 'assets/' });

// DemoControls is a controlled component: http://facebook.github.io/react/docs/forms.html#controlled-components
// We use createClass instead of ES6 class syntax, as createClass automatically binds our methods to 'this': https://facebook.github.io/react/docs/reusable-components.html#no-autobinding
class DemoControls extends React.Component {
  constructor(props) {
    // we call super as we want to access this.props later
    super(props);
    this.changeLabel = this.changeLabel.bind(this);
  }
  
  changeLabel(event) {
    let label = event.currentTarget.value;
    // the parent function to call with the new label value
    this.props.changeLabel(label);
  }
  render() {
    return (
      <fieldset className='framework-fieldset'>
        <legend>Events</legend>
        <h5>Selection change:</h5>
        <p>To demo 'selectionchange', select a chart item and rename it:</p>
        <input type='text' disabled={this.props.disableTextField} value={this.props.currentText} onChange={this.changeLabel} />
        <button type='button' className='btn btn-kl' onClick={this.props.layout}>Layout</button>
      </fieldset>
    );
  }
};

DemoControls.propTypes = {
  // function to call with the text of the new label
  changeLabel: PropTypes.func.isRequired,
  // function to call to run a KeyLines layout
  layout: PropTypes.func
}

class ReactDemo extends React.Component {
  constructor(props) {
    super(props)
    this.selectionchange = this.selectionchange.bind(this);
    this.changeLabel = this.changeLabel.bind(this);
    this.loadedChart = this.loadedChart.bind(this);
    this.layout = this.layout.bind(this);
    
    this.state = {
      currentText: "",
      disableTextField: true
    }
  }

    componentDidMount() {
    console.log("-- I am loading");
// SECURED => http://phd2e1.customs.gov.au:8187/?gremlin=g.V().has('node','cdh:168799928').valueMap()"
// UNSECURED => http://phd2e1.customs.gov.au:8189/?gremlin=g.V().has('node','cid:87335501319').valueMap()"
        //--cdh:146923544
        var input = "g.V().has('node','cdh:146923544').bothE().bothV().bothE().map(union(inV().values('node'),outV().values('node'),values('ef')).fold())";

        console.log("-- axios calling.. ");
        var resultData;
        axios.get('http://localhost:8077/gremlinproxy?input='+input).then(function(result) {
            resultData = result.data.result.data;
            console.log("result data ", result.data.result.data);
        }).catch(function(error) {
            console.error("API Error: ", error);
            if (error.response) {
                //res.status(error.response.status);
                //res.send(error.response.data);
            } else {
                //res.status(500).send(JSON.stringify(error));
            }
        });
        console.log("--successful connection ", gremlin);
  }
 
  selectionchange() {
    const selection = this.chart.selection();
    let state = {
      currentText: "",
      disableTextField: true,
    }
    if (selection.length) {
      this.active = selection;
      const selectedItem = this.chart.getItem(selection);
      if (selectedItem && selectedItem.length === 1 && selectedItem[0].t) {
        state.currentText = selectedItem[0].t;
      }
      state.disableTextField = false;
    } else {
      this.active = null;
    }
    this.setState(state);
  }
  changeLabel(label) {
    // this.active is the last selection
    if (this.active) {
      this.chart.setProperties(this.active.map(id => ({ id, t: label })));
      this.setState({
        currentText: label
      });
    }
  }
  // get a reference to the loaded chart
  loadedChart(chart) {
    this.chart = chart;
  }
  // run a layout if the chart has been loaded
  layout() {
    if (this.chart) {
      this.chart.layout();
    }
  }
  
  render() {
    console.log("data --> ", data);
    return (
      <div>
        <LeftPanel>
          {/* data is a global variable stored in reactbasics-data.js */}
          <Chart
            ready={this.loadedChart}
            selectionchange={this.selectionchange}
            data={data}
            animateOnLoad={true}
            options={{
              logo: { u: 'assets/Logo.png' }
            }}
            style={{ height: "580px" }}
            containerClassName='cichart'
          />
        </LeftPanel>
        <RightPanel name='reactbasics' title='React Integration' description='Use React to bind events to the chart.'>
          <DemoControls layout={this.layout} changeLabel={this.changeLabel} currentText={this.state.currentText} disableTextField={this.state.disableTextField} />
        </RightPanel>
      </div>
    );
  }
}


// render our top-level component into the DOM
render(<ReactDemo />, document.getElementById('kl-container'));
