const path = require('path');

const config = {
  entry: {
    main: ['./src/reactbasics.js']
  },

  output: {
    path: path.resolve(__dirname),
    filename: 'reactbasics.js'
  },

  resolve: {
    modules: ['react', 'node_modules']
  },

  module: {
    rules: [{
      test: /\.jsx?$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel-loader',
      query: {
        presets: ['es2015', 'react']
      }
    }]
  }
};

module.exports = config;
