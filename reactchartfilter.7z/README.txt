It is recommended to serve this demo from a server rather than the file system.

This demo requires webpack to build and run. To install webpack (and other dependencies) run `npm install`. To run the demo, run `npm run build && npm start`

Then you can navigate to http://localhost:8080 in your web browser to see the demo running

File Name                Description
assets/                  KeyLines image assets directory
css/keylines.css         KeyLines style settings
fonts/                   Default KeyLines font files
images/                  Icon, glyph and flag images for use with KeyLines
index.htm                A 'hello world' sample file
js/keylines.js           The KeyLines JavaScript component
map/*                    Map display code
react/*                  React integration code
src/reactchartfilter.js  The source file that will be built by webpack
ts/keylines.d.ts         TypeScript definition file for KeyLines (alpha)
vendor/*                 External libraries
server.js                A simple NodeJS webserver for testing the zip contents
