//
//     Copyright © 2011-2018 Cambridge Intelligence Limited.
//     All rights reserved.    
//
//     Sample Code
//!    Use React and the time bar to filter chart items.
//
// This demo uses webpack to manage dependencies and build
import * as React from 'react';
import {render} from 'react-dom';
import {Chart, Timebar} from 'react-keylines';
import {LeftPanel, RightPanel} from 'react-demo';
import { Spinner, SpinnerSize } from 'office-ui-fabric-react/lib/Spinner';
import { Dropdown, IDropdown, DropdownMenuItemType, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import { ChoiceGroup, IChoiceGroupOption } from 'office-ui-fabric-react/lib/ChoiceGroup';
import {Checkbox} from 'office-ui-fabric-react/lib/Checkbox';

import axios from "axios";
import moment from "moment";

KeyLines.paths({assets: 'assets/'});
const customNodeImage = {
    "landing": "images/icons/customFlight.png",
    //"landing": "images/icons/airplane-landing.png",
    "take-off": "images/icons/airplane-take-off.png",
    "email": "images/icons/email.png",
    "address": "images/icons/address.png",
    "poAddress": "images/icons/address2.png",
    "mobile": "images/icons/customMobile.png",
    "landLine": "images/icons/customLandLine.png",
    "cid": "images/icons/customPerson.png",
    "pid": "images/icons/customPerson.png",
    "cdh": "images/icons/customPerson.png",
    "iris": "images/icons/customPerson.png",
    "etas": "images/icons/customEtas.png"
}

const MyLinks = ["phone", "address", "email", "flight"];

function fetchData(input) {
    return axios.get('http://u7007320.dinnp.bcz.gov.au:8080/gremlinproxy?input=' + input)
        .then(function (response) {
            return response
        })
        .catch(function (error) {
            return error
        })
}

class ReactDemo extends React.Component {

    flights;
    address;
    emails;
    phones;
    nodes;
    links;



    constructor(props) {
        super(props);
        this.onTimebarChange = this.onTimebarChange.bind(this);
        this.loadedTimebar = this.loadedTimebar.bind(this);
        this.loadedChart = this.loadedChart.bind(this);
        this.onChangeMultiSelect = this.onChangeMultiSelect.bind(this);

        this.flights = [];
        this.address = [];
        this.emails = [];
        this.phones = [];
        this.nodes=[];
        this.links= [
            { key: 'Header4', text: 'Links', itemType: DropdownMenuItemType.Header }
        ];


        this.state = {
            graphKeylinesData: [{}],
            flights: true,
            address: true,
            emails: true,
            phones: true,
            searchCriteria: "",
            searchText: "Search",
            disableSelection: true,
            isBusy: false,
            selectedItem: { key: "" },
            selectedItems: [],
            customNodes: [],
            customLinks: [],
            filterSelection: []
        }
    }

    // filter the items on the chart according to the range of the timebar
    onTimebarChange() {
        // if all our components are loaded
        if (this.chart && this.timebar) {
            // filter the chart to show only items in the new range
            this.chart.filter(this.timebar.inRange, {animate: false, type: 'link'}).then(() => {
                // and then adjust the chart's layout
                this.chart.layout('tweak', {animate: true, time: 1000});
            });
        }
    }

    getCustomImage(nodeValue) {
        var temp = nodeValue.split(":");
        if (MyLinks.includes(temp[0])) {
            if (temp[0] == 'address') {
                console.log("-- add of nodeValue ", nodeValue);
                this.address.push(nodeValue);
                console.log("-- after adding nodeValue ", this.address);
                if ((temp[1].indexOf('po.box') || temp[1].indexOf('po.Box') || temp[1].indexOf('p o box')) == -1) {
                    return customNodeImage['address'];
                }
                return customNodeImage['poAddress'];
            } else if (temp[0] == 'phone') {
                //console.log("-- custom node for phone ", nodeValue);
                this.phones.push(nodeValue);
                //console.log("-- custom node for phone ", this.phones, nodeValue);

                if (temp[1].startsWith('04')) {
                    return customNodeImage['mobile'];
                }
                return customNodeImage['landLine'];
            } else if (temp[0] == 'flight') {
                this.flights.push(nodeValue);
                if (temp[1].slice(-1) == 'a') return customNodeImage['landing'];
                else if (temp[1].slice(-1) == 'd') return customNodeImage['take-off'];
                else return customNodeImage['flight'];
            } else if (temp[0] == 'email') {
                this.emails.push(nodeValue);
            } else {
                this.nodes.push({key:nodeValue, text:nodeValue});
            }
        }
        console.log("-- this.addresses", this.address);
        return customNodeImage[temp[0]];
    }

    buildNodes() {
        //console.log("-- this.addresses", this.address);
        //console.log("-- this.and the links ", this.links);
        var tempNodes = [
            { key: 'Header4', text: 'Addresses', itemType: DropdownMenuItemType.Header }
        ];
        tempNodes.push(this.address);
        tempNodes.push({key: 'Header4', text: 'Phones', itemType: DropdownMenuItemType.Header})
        tempNodes.push(this.phones);
        tempNodes.push({key: 'Header4', text: 'Emails', itemType: DropdownMenuItemType.Header})
        tempNodes.push(this.emails);
        tempNodes.push({key: 'Header4', text: 'Entities', itemType: DropdownMenuItemType.Header})
        tempNodes.push(this.nodes);
        tempNodes.push({key: 'Header4', text: 'Flights', itemType: DropdownMenuItemType.Header})
        tempNodes.push(this.flights);
        this.setState({customNodes: tempNodes, customLinks: this.links});
    }

    addToLinks(linkText) {
        this.links.push({key:linkText, text: linkText});
    }
    // Make data align with business  "abc".slice(-1)
    makeKeyLinesItemsOfGraphData(results) {
        var items = [];

        results.forEach(function (data) {
            // Check if its a node
            var temp = data[0].split(":");
            var isLink = MyLinks.includes(temp[0]);
            //console.log("-- id ", data[0]);
            //console.log("-- chart item ", data, this.getCustomImage(data[0]));

            if (isLink) {
                /*var linkText = temp[1];
                //console.log("-- link text ", linkText, temp[0]);
                if(temp[0] == 'flight') {
                    linkText = moment(new Date(data[2])).format("DD/MM/YYYY")
                }
                //console.log("-- link text if flight ", customNodeImage[temp[0]]);
                // if(this.chart.contains(data[0]))
                //console.log("-- link text if flight ", temp[0], customNodeImage[temp[0]]);
                //var linkText = temp[0] == 'flight' ? moment(new Date(data[2])).format("DD/MM/YYYY") : data[2]; */
                //var found = items.filter(function(item) { return item.id === data[0]; });
                if (!this.chart.getItem(data[0])) {
                    items.push({
                        type: 'node',
                        id: data[0],
                        t: data[0],
                        fs: 10,
                        u: this.getCustomImage(data[0]),//customNodeImage[temp[0]],
                        c: '#aec7e8',
                        d: data[0],
                        dt: [data[2]]
                    });
                }
                //found = items.filter(function(item) { return item.id === data[1]; });
                if (!this.chart.getItem(data[1])) {
                    temp = data[1].split(":");
                    items.push({
                        type: 'node',
                        id: data[1],
                        t: data[1],
                        fs: 10,
                        u: this.getCustomImage(data[1]),//customNodeImage[temp[0]],
                        c: '#aec7e8',
                        d: data[1],
                        dt: [data[2]]
                    });
                }
                //found = items.filter(function(item) { return item.id === data[0] + "-" + data[1]; });
                if (!this.chart.getItem(data[0] + "-" + data[1])) {
                    this.addToLinks(data[0]+ " - "+data[1]);
                    items.push({
                        type: 'link',
                        id: data[0] + "-" + data[1],
                        id1: data[0],
                        id2: data[1],
                        fs: 10,
                        dt: [data[2]]
                        // Show a link label
                        //t:  moment(new Date(data[2])).format("DD/MM/YYYY"),
                        // Save the entire edge on the link for future use
                        //d: data
                    });
                }
            }
            else {
                // Node 1
                //var found = items.filter(function(item) { return item.id === data[0]; });
                if (!this.chart.getItem(data[0])) {
                    temp = data[0].split(":");
                    items.push({
                        type: 'node',
                        id: data[0],
                        t: data[0],
                        fs: 10,
                        u: this.getCustomImage(data[0]),//customNodeImage[temp[0]],
                        c: '#aec7e8',
                        d: data[0],
                        dt: [data[2]]
                    });
                }
                //found = items.filter(function(item) { return item.id === data[1]; });
                if (!this.chart.getItem(data[1])) {
                    temp = data[1].split(":");
                    // Node 2
                    items.push({
                        type: 'node',
                        id: data[1],
                        t: data[1],
                        fs: 10,
                        u: this.getCustomImage(data[1]),//customNodeImage[temp[0]],
                        c: '#aec7e8',
                        d: data[1],
                        dt: [data[2]]
                    });
                }
                //found = items.filter(function(item) { return item.id === data[0] + "-" + data[1]; });
                if (!this.chart.getItem(data[0] + "-" + data[1])) {
                    items.push({
                        id: data[0] + "-" + data[1],
                        type: 'link',
                        id1: data[0],
                        id2: data[1],
                        dt: [data[2]],
                        fs: 10,
                        // Show a link label
                        //t: moment(new Date(data[2])).format("DD/MM/YYYY"),//data[2],
                        // Save the entire edge on the link for future use
                        // d: data
                    });
                }
            }
        }.bind(this))
        this.buildNodes();
        //console.log("-- the nodes ", this.customNodes);
        //console.log("-- the nodes ", this.customLinks);
        return items;
    }

    expandData(nodeValue, animate, callback) {
        //console.log("-- node value ", nodeValue);
        var input = `g.V().has('node','` + nodeValue + `').bothE().bothV().bothE().map(union(inV().values('node'),outV().values('node'),values('ef')).fold())`;
        fetchData(input)
            .then(function (result) {

                console.log("-- result from service ", result);
                // create the layout options
                var layoutOptions = {
                    // name: 'standard',
                    top: [],
                    fix: "all",
                    fit: true,
                    animate: true,
                    tidy: true
                };

                var temp = this.makeKeyLinesItemsOfGraphData(result.data.result.data);
                //console.log("-- temp ", temp);
                // var layoutOptions = {
                //     name: this.lastLayout.name,
                //     top: this.lastLayout.top,
                //     fix: "all"
                // };

                var expandedItems = temp.map(function (item) {
                    return item.id;
                });
                //console.log("-- excpanded items", expandedItems);
                var newItems = [];
                temp.forEach(function (item) {
                    if (!this.chart.getItem(item.id)) {
                        newItems.push(item);
                    } else {
                        //console.log("-- th enode ", this.chart.getItem(item.id).dt);
                        //console.log(" -- the node to push ", item);
                    }
                }.bind(this));
                //console.log("-- new items ", newItems);

                // Only call expand if there is new data to add
                if (newItems.length > 0) {
                    // expand the chart with the new data
                    layoutOptions.top = ['topNode'];
                    //console.log("-- animate ", animate);
                    var expandOptions = {
                        layout: layoutOptions,
                        time: 500,
                        // Don't animate the expand if it's the initial load or we only added links
                        animate: animate && newItems.some(function (item) {
                            //console.log("-- item.type==='node'", item.type==='node', item);
                            return item.type === 'node';
                        })
                    };
                    //console.log("-- chart and new items ", newItems.length);
                    this.chart.expand(
                        newItems,
                        expandOptions/*,
                    function () {
                        // Zoom to the expanded items
                        this.chart.zoom('fit', {
                            animate: true,
                            time: 500,
                            ids: expandedItems
                        }, callback);
                    }*/
                    );
                    this.timebar.merge(newItems, function () {
                        this.timebar.zoom('fit', {animate: true});
                    })
                } else {
                    this.timebar.load(expandedItems, function () {
                        this.timebar.zoom('fit', {animate: false});
                    })
                    this.setState({graphKeylinesData: expandedItems});
                }
                this.setState({isBusy: false});
            }.bind(this));
        //console.log("-- the data to be rendered ", this.state.graphKeylinesData, expandedItems, newItems);
    }

    isNode(item) {
        //console.log("-- here is the item ", item);
        return item && item.type === 'node';
    }

    expandClickedData(clickedID) {
        //console.log("clicked Id ", clickedID);
        var clickedItem = this.chart.getItem(clickedID);
        //console.log("clicked Item ", clickedItem);
        if (this.isNode(clickedItem)) {
            //console.log("clicked item is Node  ", clickedItem.id);
            // expand into the chart the new data
            this.setState({isBusy: true});
            this.expandData(clickedItem.id, true, function () {

            });
        }
        // on background click do nothing
    }


    runFirstQuery() {
        //console.log("run first query ");
        // expand the data into the chart
        this.setState({isBusy: true});
        this.updatedSelectedItem = this.state.selectedItems ? this.copyArray(this.state.selectedItems) : [];
        this.expandData("cdh:146923544", true, function () {
            highlightSelections = true;
        });
    }



    // get a reference to the loaded timebar
    loadedTimebar(timebar) {
        this.timebar = timebar;
    }

    // get a reference to the loaded chart
    loadedChart(chart) {
        this.chart = chart;
        // load an empty chart and run the first query
        this.runFirstQuery();
        //this.chart.load({ type: 'LinkChart', items: [] }, this.runFirstQuery);
        this.chart.bind('dblclick', this.expandClickedData.bind(this));
    }

    onChangeMultiSelect (item) {
        const updatedSelectedItem = this.state.selectedItems ? this.copyArray(this.state.selectedItems) : [];
        if (item.selected) {
            // add the option if it's checked
            updatedSelectedItem.push(item.key);
        } else {
            // remove the option if it's unchecked
            const currIndex = updatedSelectedItem.indexOf(item.key);
            if (currIndex > -1) {
                updatedSelectedItem.splice(currIndex, 1);
            }
        }
        //console.log("-- selected items ", updatedSelectedItem);
        this.setState({
            selectedItems: updatedSelectedItem
        });
    };

    copyArray (array) {
        const newArray = [];
        for (let i = 0; i < array.length; i++) {
            newArray[i] = array[i];
        }
        return newArray;
    };

    render() {
        var chartHeight = (window.screen.height - 300).toString() + "px";
        data.items = this.state.graphKeylinesData;
        //console.log("-- hcart height ", data, data.items);
        var spin= <div></div>
        if(this.state.isBusy) {
            spin = <Spinner size={SpinnerSize.large} label="Seriously, still loading..." ariaLive="assertive" />;
        } else
            spin = <div></div>
        const selectedItem = this.state.selectedItem;
        const selectedItems = this.state.selectedItems;
        //console.log("-- this.selection items ", this.state.filterSelection, this.state.customNodes);
        return (
            <section>
                <div id="chart-items">
                    <Chart
                        ready={this.loadedChart}
                        data={data}
                        animateOnLoad={true}
                        style={{height: chartHeight}}
                        containerClassName='cichart'
                    />
                    <Timebar
                        ready={this.loadedTimebar}
                        data={data}
                        change={this.onTimebarChange}
                        animateOnLoad={true}
                        style={{height: "150px"}}
                        containerClassName='citimebar'
                    />
                </div>
                <div id="menu-items">
                    <img src="assets/DIBP.png" alt="Dept of Home Affairs"/>

                    <h2> Filters </h2>
                    <div id="filter-option1" class="clear">
                        <div id="first-half">
                            <Checkbox label="Flights" defaultChecked={true} onChange={ (e,isChecked) => {
                                    this.setState({flights: isChecked});
                                    isChecked ? this.chart.show(this.flights, {animate: true}) : this.chart.hide(this.flights, {animate: true});
                                }}
                            ariaDescribedBy={'hide or show Flights'}/>
                        </div>
                        <div id="second-half">
                            <Checkbox label="Address" defaultChecked={true} onChange={ (e,isChecked) => {
                                    this.setState({address: isChecked});
                                    isChecked ? this.chart.show(this.address, {animate: true}) : this.chart.hide(this.address, {animate: true});
                                }}
                            ariaDescribedBy={'hide or show Addresses'}/>
                        </div>
                    </div>
                    <div id="filter-option1" class="clear, filter-2">
                        <div id="first-half">
                            <Checkbox label="Emails" defaultChecked={true} onChange={ (e,isChecked) => {
                                this.setState({emails: isChecked});
                                isChecked ? this.chart.show(this.emails, {animate: true}) : this.chart.hide(this.emails, {animate: true});
                            }}
                                      ariaDescribedBy={'hide or show Emails'}/>
                        </div>
                        <div id="second-half">
                            <Checkbox label="Phones" defaultChecked={true} onChange= { (e,isChecked) => {
                                this.setState({phones: isChecked});
                                isChecked ? this.chart.show(this.phones, {animate: true}) : this.chart.hide(this.phones, {animate: true});
                                }}
                            ariaDescribedBy={'hide or show Phones'}/>
                        </div>
                    </div>

                    <div id="second-filter-options" class="filter-2">
                        <h2> Highlights</h2>
                        <div>
                            <ChoiceGroup className="filter-choicegroup"
                                options={[
                                    {
                                        key: 'Node',
                                        text: 'Node'
                                    },// as IChoiceGroupOption,
                                    {
                                        key: 'Link',
                                        text: 'Link'
                                    }
                                ]}
                                onChange={ (e, option) => {
                                    this.setState({selectedItems: [], disableSelection: false});
                                    var cNodes = this.state.customNodes;
                                    var cLinks = this.state.customLinks;
                                    option.key =='Node' ? this.setState({filterSelection: cNodes}) : this.setState({filterSelection: cLinks});
                                }}
                            />
                            <Dropdown
                                disabled={this.state.disableSelection}
                                placeHolder="Select options"
                                onFocus={console.log('onFocus called')}
                                onBlur={console.log('onBlur called')}
                                onChanged = {this.onChangeMultiSelect}
                                selectedKeys = {this.state.selectedItems}
                                multiSelect
                                options= {this.state.filterSelection}
                            />
                            {/*<SearchBox
                                disabled={this.state.disableSeach}
                                placeholder={this.state.searchText}
                                value={this.state.searchText}
                                onSearch={newValue => {
                                    this.chart.selection()
                                    //console.log('value is ' + newValue)
                                }}
                                onFocus={() => //console.log('onFocus called')}
                                onBlur={() => //console.log('onBlur called')}
                                onChange={() => //console.log('onChange called')}
                            />*/}
                        </div>
                    </div>
                    <div id="spinner">
                        {spin}
                    </div>
                </div>

            </section>
        );
    }
};

// render our top-level component into the DOM
render(<ReactDemo/>, document.getElementById('kl-container'));


