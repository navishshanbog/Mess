const path = require('path');

const config = {
  entry: {
    main: ['./src/reactchartfilter.js']
  },

  output: {
    path: path.resolve(__dirname),
    filename: 'reactchartfilter.js'
  },

  resolve: {
    modules: ['react', 'node_modules']
  },

  module: {
    rules: [{
      test: /\.jsx?$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel-loader',
      query: {
        presets: ['es2015', 'react', 'es2016']
      }
    }]
  }
};

module.exports = config;
