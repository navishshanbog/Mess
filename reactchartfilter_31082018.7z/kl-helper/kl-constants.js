const customNodeImage = {
    //"landing": "images/icons/customFlight.png",
    "landing": "images/icons/airplane-landing.png",
    "take-off": "images/icons/airplane-take-off.png",
    "email": "images/icons/email.png",
    "address": "images/icons/address.png",
    "poAddress": "images/icons/address2.png",
    "mobile": "images/icons/customMobile.png",
    "landLine": "images/icons/customLandLine.png",
    "cid": "images/icons/customPerson.png",
    "pid": "images/icons/customPerson.png",
    "cdh": "images/icons/customPerson.png",
    "irsc": "images/icons/customPerson.png",
    "etas": "images/icons/customEtas.png",
    "poi": "images/icons/poi.png",
}
const lockOptions = {wait: true};
const MyLinks = ["phone", "address", "email", "flight"];

export {customNodeImage, lockOptions, MyLinks};