import * as React from "react";
import { Home } from "./components/Home/Home";
import { Filter } from "./components/Filter/Filter";
import { About } from "./components/About/About";
import { AppContext } from "./AppContext";
import { HashRouter as Router, Route, Link, Switch } from 'react-router-dom'


export class App extends React.Component {
  render() {
      return (
            <Router>
                <div>
                    <nav>
                        <Link to="/">Home</Link>
                        <Link to="/About">About</Link>
                        <Link to="/Filter">Filter</Link>
                    </nav>
                    <Switch>
                        <Route exact path="/" component={Home} />
                        <Route exact path="/About" component={About} />
                        <Route exact path="/Filter" component={Filter} />
                    </Switch>
                </div>
            </Router>
    );
  }
}


/*
export class App extends React.Component {
  render() {
    return <Home />;
  }
}
 */
