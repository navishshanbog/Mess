import * as React from "react";
import { ApplicationModel } from "./models";

export function createModels() {
  return {
    applicationModel: new ApplicationModel(),
    junkModel: new ApplicationModel()
  };
}

export const models = createModels();

export const AppContext = React.createContext(models);
