import { observer } from "mobx-react";
import * as React from "react";
import { AppContext } from "../../AppContext";
import {App} from "../../App";

class About extends React.Component<any, any> {
    //private aM = AppContext.Provider(applicationModel);
    render() {
        const { applicationModel } = React.useContext(AppContext);
        const { junkModel } = React.useContext(AppContext);
        //const { applicationModel } = React.(AppContext);
       // console.log("-- application Model ", applicationModel);
        return (
            <div>

                    About and applicatio Number {applicationModel.counter}

            </div>
        )
    }
}

export { About }
