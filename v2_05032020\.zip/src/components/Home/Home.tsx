import { observer } from "mobx-react";
import * as React from "react";
import { AppContext } from "../../AppContext";
import { Button, Container, NumberDisplay } from "./styles";

interface Props {}

export const Home = observer(function(props: Props) {
  const { applicationModel } = React.useContext(AppContext);
  const { junkModel } = React.useContext(AppContext);

  return (
    <Container>
      <Button onClick={applicationModel.decrement}>-</Button>
      <NumberDisplay data-testid="counter-value">
        {applicationModel.counter}
      </NumberDisplay>
      <Button onClick={applicationModel.increment}>+</Button>

        <Button onClick={junkModel.decrement}>-</Button>
        <NumberDisplay data-testid="counter-value">
            {junkModel.counter}
        </NumberDisplay>
        <Button onClick={junkModel.increment}>+</Button>
    </Container>

  );
});
