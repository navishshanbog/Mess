import { ApplicationModel } from './ApplicationModel';

test('that counters initial value is zero', () => {
    const applicationModel = new ApplicationModel();

    expect(applicationModel.counter).toBe(0);
});

test('that increment, increments counter by one', () => {
    const applicationModel = new ApplicationModel();

    applicationModel.increment();

    expect(applicationModel.counter).toBe(1);
});

test('that decrement, decrements counter by one', () => {
    const applicationModel = new ApplicationModel();

    applicationModel.decrement();

    expect(applicationModel.counter).toBe(-1);
});
