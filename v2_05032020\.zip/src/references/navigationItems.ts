const naviagtionItems = [
    {
        text: "Home",
        path: "/home",
        icon: "icon-home"
    }, {
        text: "Filter",
        path: "/filter",
        icon: "icon-filter"
    }, {
        text: "Search",
        path: "/search",
        icon: "icon-search"
    }, {
        text: "Contact",
        path: "/contact",
        icon: "icon-contact"
    }, {
        text: "Terms",
        path: "/terms",
        icon: "icon-terms"
    }, {
        text: "Login",
        path: "/login",
        icon: "icon-login"
    }, {
        text: "AdvertWithUs",
        path: "/advert",
        icon: "icon-advert"
    },
];

export { naviagtionItems }
