How to use wiremock instead of real data services:

1. Download wiremock-standalone-2.6.0.jar from the internet
2. Run "java -jar wiremock-standalone-2.6.0.jar --port 3001 --no-request-journal --global-response-templating --root-dir C:\Apps\Projects\analystdesktop\Playground\wiremock"
   If you have checked out AD to a different location, change the root-dir to point to this directory (directory containing the 'mappings' subdirectory)
3. Change 'apiBaseUrl' value in \analystdesktop\widget\site\app\router\dataServices.js to 'http://localhost:3001'
4. Start node server   